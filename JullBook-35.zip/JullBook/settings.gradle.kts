pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Injekt de Mihon (com.github.mihonapp:injekt), requerido por las extensiones de la API 1.6.
        maven(url = "https://jitpack.io") {
            content { includeGroup("com.github.mihonapp") }
        }
    }
}
rootProject.name = "JullBook"
include(":app")
