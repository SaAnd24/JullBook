package com.jullbook.app

import com.jullbook.app.sources.ExtensionLoader
import com.jullbook.app.sources.MangaDownloads
import com.jullbook.app.sources.ProtoIndex
import com.jullbook.app.sources.RepoClient
import eu.kanade.tachiyomi.source.Source
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream

/** Pruebas unitarias de lógica pura (sin Android). Se ejecutan con ./gradlew testDebugUnitTest. */
class SourcesLogicTest {

    @Test
    fun repoUrlsNormalize() {
        assertEquals("https://x.org/r/index.min.json", RepoClient.normalize("https://x.org/r/"))
        assertEquals("https://x.org/r/index.min.json", RepoClient.normalize(" https://x.org/r/index.min.json "))
        try { RepoClient.normalize("http://x.org/index.min.json"); fail() } catch (e: RepoClient.BadRepo) {}
        try { RepoClient.normalize("https://x.org/other.json"); fail() } catch (e: RepoClient.BadRepo) {}
    }

    @Test
    fun imageTypesAreDetected() {
        assertEquals("jpg", MangaDownloads.extOf(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0)))
        assertEquals("png", MangaDownloads.extOf(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)))
        assertEquals("gif", MangaDownloads.extOf("GIF89a".toByteArray()))
        assertEquals("webp", MangaDownloads.extOf("RIFF1234WEBPVP8 ".toByteArray()))
        assertTrue(MangaDownloads.looksLikeHtml("  <!DOCTYPE html><html>".toByteArray()))
        assertFalse(MangaDownloads.looksLikeHtml(byteArrayOf(0xFF.toByte(), 0xD8.toByte())))
    }

    @Test
    fun namesAreSafe() {
        assertEquals("a_b_c", MangaDownloads.safe("a/b:c"))
        assertEquals("_", MangaDownloads.safe("..."))
    }

    // ------------------------------------------------------------------ API 1.6

    @Test
    fun repoUrlsAcceptProtoIndexAndFolders() {
        val pb = "https://github.com/keiyoushi/extensions/raw/repo/index.pb"
        assertEquals(pb, RepoClient.normalize(pb))
        assertEquals("https://x.org/r/index.min.json", RepoClient.normalize("https://x.org/r"))
        assertTrue(RepoClient.isProtoUrl(pb))
        assertFalse(RepoClient.isProtoUrl("https://x.org/r/index.min.json"))
        assertEquals("https://x.org/r/index.pb", RepoClient.siblingProtoUrl("https://x.org/r/index.min.json"))
    }

    @Test
    fun extensionApiRangeIncludes16() {
        assertEquals(1.6, ExtensionLoader.libVersionOf("1.6.69")!!, 0.0)
        assertEquals(1.4, ExtensionLoader.libVersionOf("1.4.12")!!, 0.0)
        assertNull(ExtensionLoader.libVersionOf("abc"))
        assertTrue(ExtensionLoader.isSupported(1.4))
        assertTrue(ExtensionLoader.isSupported(1.5))
        assertTrue(ExtensionLoader.isSupported(1.6))
        assertFalse(ExtensionLoader.isSupported(1.3))
        assertFalse(ExtensionLoader.isSupported(1.7))
        assertFalse(ExtensionLoader.isSupported(null))
    }

    @Test
    fun memoSurvivesCopies() {
        val m = SManga.create().apply {
            url = "/a"; title = "A"
            memo = buildJsonObject { put("id", "42") }
        }
        assertEquals(JsonPrimitive("42"), m.copy().memo["id"])

        val c = SChapter.create().apply {
            url = "/c"; name = "C"
            memo = buildJsonObject { put("token", "x") }
        }
        val d = SChapter.create().also { it.copyFrom(c) }
        assertEquals(JsonPrimitive("x"), d.memo["token"])
        assertTrue(SManga.create().memo.isEmpty())
    }

    /** Una fuente 1.4/1.5 que solo implementa getMangaDetails/getChapterList sigue funcionando con getMangaUpdate. */
    @Test
    fun getMangaUpdateDefaultServesLegacySources() = runBlocking {
        val src = object : Source {
            override val id = 1L
            override val name = "fake"
            var detailsCalls = 0
            var chapterCalls = 0
            override suspend fun getMangaDetails(manga: SManga): SManga {
                detailsCalls++
                return manga.copy().also { it.description = "desc" }
            }
            override suspend fun getChapterList(manga: SManga): List<SChapter> {
                chapterCalls++
                return listOf(SChapter.create().apply { url = "/1"; name = "1" })
            }
        }
        val manga = SManga.create().apply { url = "/m"; title = "M" }
        val keep = listOf(SChapter.create().apply { url = "/old"; name = "old" })

        val both = src.getMangaUpdate(manga, keep, fetchDetails = true, fetchChapters = true)
        assertEquals("desc", both.manga.description)
        assertEquals("/1", both.chapters.single().url)

        val onlyDetails = src.getMangaUpdate(manga, keep, fetchDetails = true, fetchChapters = false)
        assertEquals("/old", onlyDetails.chapters.single().url) // los capítulos que ya había se devuelven intactos
        assertEquals(2, src.detailsCalls)
        assertEquals(1, src.chapterCalls)
    }

    // ------------------------------------------------------------------ index.pb

    private fun varint(out: ByteArrayOutputStream, value: Long) {
        var v = value
        while (v and 0x7f.inv().toLong() != 0L) {
            out.write(((v and 0x7f) or 0x80).toInt())
            v = v ushr 7
        }
        out.write(v.toInt())
    }

    private fun str(out: ByteArrayOutputStream, field: Int, text: String) = bytes(out, field, text.toByteArray())

    private fun bytes(out: ByteArrayOutputStream, field: Int, b: ByteArray) {
        varint(out, (field.toLong() shl 3) or 2)
        varint(out, b.size.toLong())
        out.write(b)
    }

    private fun num(out: ByteArrayOutputStream, field: Int, v: Long) {
        varint(out, field.toLong() shl 3)
        varint(out, v)
    }

    private fun sampleIndex(gzip: Boolean): ByteArray {
        val files = ByteArrayOutputStream().also { str(it, 1, "tachiyomi-en.demo-v1.6.69.apk"); str(it, 2, "eu.kanade.tachiyomi.extension.en.demo.png") }
        val s1 = ByteArrayOutputStream().also { num(it, 1, 123456789012L); str(it, 2, "Demo"); str(it, 3, "en"); str(it, 4, "https://demo.example") }
        val s2 = ByteArrayOutputStream().also { num(it, 1, 7L); str(it, 2, "Demo ES"); str(it, 3, "es") }
        val ext = ByteArrayOutputStream().also {
            str(it, 1, "Tachiyomi: Demo")
            str(it, 2, "eu.kanade.tachiyomi.extension.en.demo")
            bytes(it, 3, files.toByteArray())
            num(it, 5, 69)
            str(it, 6, "1.6.69")
            bytes(it, 8, s1.toByteArray())
            bytes(it, 8, s2.toByteArray())
            num(it, 99, 5) // campo desconocido: debe ignorarse
        }
        val bad = ByteArrayOutputStream().also { str(it, 1, "Sin APK"); str(it, 2, "x.y") } // sin apk: se descarta
        val root = ByteArrayOutputStream().also {
            bytes(it, 101, ext.toByteArray())
            bytes(it, 101, bad.toByteArray())
            num(it, 1, 1) // campo desconocido en la raíz
        }.toByteArray()
        if (!gzip) return root
        return ByteArrayOutputStream().also { o -> GZIPOutputStream(o).use { it.write(root) } }.toByteArray()
    }

    @Test
    fun protoIndexIsParsedWithAndWithoutGzip() {
        for (gz in listOf(true, false)) {
            val entries = ProtoIndex.parse(sampleIndex(gz))
            assertEquals(1, entries.size)
            val e = entries[0]
            assertEquals("eu.kanade.tachiyomi.extension.en.demo", e.pkg)
            assertEquals(69L, e.versionCode)
            assertEquals("1.6.69", e.versionName)
            assertEquals(2, e.sources.size)
            assertEquals(123456789012L, e.sources[0].id)
            assertEquals("https://demo.example", e.sources[0].baseUrl)
            assertNull(e.sources[1].baseUrl)
        }
    }

    @Test
    fun protoEntriesBecomeAvailableExtensions() {
        val list = RepoClient.fromProto(ProtoIndex.parse(sampleIndex(true)), "https://x.org/repo/index.pb")
        val a = list.single()
        assertEquals("Demo", a.name) // sin el prefijo «Tachiyomi: »
        assertEquals("https://x.org/repo/apk/tachiyomi-en.demo-v1.6.69.apk", a.apkUrl)
        assertEquals("https://x.org/repo/icon/eu.kanade.tachiyomi.extension.en.demo.png", a.iconUrl)
        assertEquals("all", a.lang) // varios idiomas
        assertEquals(1.6, a.libVersion!!, 0.0)
        assertTrue(ExtensionLoader.isSupported(a.libVersion))
    }

    @Test
    fun relativeUrlsCannotEscapeTheRepoFolder() {
        val base = "https://x.org/repo"
        assertEquals("https://cdn.org/a.apk", RepoClient.resolve("https://cdn.org/a.apk", base, "apk"))
        assertEquals("https://x.org/repo/apk/a.apk", RepoClient.resolve("a.apk", base, "apk"))
        assertEquals("https://x.org/repo/apk/a.apk", RepoClient.resolve("apk/a.apk", base, "apk")) // ya trae su carpeta
        assertNull(RepoClient.resolve("../a.apk", base, "apk"))
        assertNull(RepoClient.resolve("/etc/a.apk", base, "apk"))
        assertNull(RepoClient.resolve("http://evil.org/a.apk", base, "apk"))
        assertNull(RepoClient.resolve("", base, "apk"))
    }

    @Test
    fun brokenProtoIsRejectedNotCrashing() {
        for (junk in listOf(byteArrayOf(0x0a, 0x7f), byteArrayOf(0x1f, 0x8b.toByte(), 0, 0), byteArrayOf(0xff.toByte()))) {
            try {
                ProtoIndex.parse(junk)
                fail("debería rechazarse")
            } catch (e: ProtoIndex.Malformed) {
            }
        }
    }
}
