package com.jullbook.app.sources

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Estado persistente del sistema de fuentes (SharedPreferences, sin tocar jullbook.db). */
class ExtStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jull_sources", Context.MODE_PRIVATE)

    // ---- Repositorios añadidos por el usuario (no hay ninguno por defecto) ----

    fun repos(): List<Repo> {
        val arr = runCatching { JSONArray(sp.getString("repos", "[]")) }.getOrDefault(JSONArray())
        val out = ArrayList<Repo>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val url = o.optString("url")
            if (url.isNotBlank()) out.add(Repo(url, o.optString("name", url), o.optString("fp").ifBlank { null }))
        }
        return out
    }

    fun saveRepos(list: List<Repo>) {
        val arr = JSONArray()
        for (r in list) arr.put(JSONObject().put("url", r.url).put("name", r.name).put("fp", r.fingerprint ?: ""))
        sp.edit().putString("repos", arr.toString()).apply()
    }

    // ---- Firmas aprobadas por el usuario ----

    fun trusted(): Set<String> = sp.getStringSet("trusted", emptySet()) ?: emptySet()

    fun trust(signature: String) {
        sp.edit().putStringSet("trusted", trusted() + signature).apply()
    }

    fun untrust(signature: String) {
        sp.edit().putStringSet("trusted", trusted() - signature).apply()
    }

    // ---- Extensiones desactivadas ----

    fun disabled(): Set<String> = sp.getStringSet("disabled", emptySet()) ?: emptySet()

    fun setEnabled(pkg: String, enabled: Boolean) {
        val cur = disabled()
        sp.edit().putStringSet("disabled", if (enabled) cur - pkg else cur + pkg).apply()
    }

    // ---- Contenido adulto: oculto por defecto ----

    var showNsfw: Boolean
        get() = sp.getBoolean("show_nsfw", false)
        set(v) { sp.edit().putBoolean("show_nsfw", v).apply() }

    var warnedCode: Boolean
        get() = sp.getBoolean("warned_code", false)
        set(v) { sp.edit().putBoolean("warned_code", v).apply() }

    // ---- Obras descargadas (clave = "<idFuente>|<urlObra>") ----

    class DlManga(
        val key: String,
        val title: String,
        val dir: String,
        val seriesId: Long,
        val chapters: Map<String, String> // urlCapítulo -> ruta del CBZ
    )

    fun dlManga(key: String): DlManga? {
        val o = runCatching { JSONObject(sp.getString("dl:$key", null) ?: return null) }.getOrNull() ?: return null
        val ch = HashMap<String, String>()
        o.optJSONObject("chapters")?.let { c -> c.keys().forEach { k -> ch[k] = c.optString(k) } }
        return DlManga(key, o.optString("title"), o.optString("dir"), o.optLong("series", -1L), ch)
    }

    fun saveDlManga(m: DlManga) {
        val ch = JSONObject()
        for ((k, v) in m.chapters) ch.put(k, v)
        val o = JSONObject().put("title", m.title).put("dir", m.dir).put("series", m.seriesId).put("chapters", ch)
        sp.edit().putString("dl:${m.key}", o.toString()).apply()
    }
}
