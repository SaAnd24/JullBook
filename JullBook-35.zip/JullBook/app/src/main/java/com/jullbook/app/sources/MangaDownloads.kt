package com.jullbook.app.sources

import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class DlState { QUEUED, RUNNING, DONE, ERROR, CANCELED }

class DlItem(
    val id: String,
    val sourceId: Long,
    val sourceName: String,
    val mangaUrl: String,
    val mangaTitle: String,
    val author: String?,
    val chapterUrl: String,
    val chapterName: String,
    val chapterNumber: Float,
    val state: DlState,
    val done: Int = 0,
    val total: Int = 0,
    val error: String? = null
) {
    fun with(state: DlState = this.state, done: Int = this.done, total: Int = this.total, error: String? = this.error) =
        DlItem(id, sourceId, sourceName, mangaUrl, mangaTitle, author, chapterUrl, chapterName, chapterNumber, state, done, total, error)
}

/**
 * Cola de descargas de capítulos. Cada capítulo se guarda como un CBZ válido (una imagen por página, nombradas
 * 0001.ext, 0002.ext… para conservar el orden) en la carpeta privada de la app, y se escribe página a página
 * (nunca hay más de una imagen en memoria). Los CBZ se leen con el lector de cómics existente.
 *
 * Reanudación: un CBZ no puede ampliarse a medias, así que un capítulo interrumpido se reinicia desde cero
 * al reintentarlo (la cola solo vive mientras la app está abierta; lo ya guardado sí persiste).
 */
class MangaDownloads(private val hub: SourceHub) {

    val items = MutableStateFlow<List<DlItem>>(emptyList())

    private class Payload(val manga: SManga, val chapter: SChapter)

    private val payloads = HashMap<String, Payload>()
    private val lock = Any()
    private var running = false
    private var currentId: String? = null
    private var currentJob: Job? = null

    private val root: File get() = File(hub.app.filesDir, "jullbook_manga")

    fun id(sourceId: Long, mangaUrl: String, chapterUrl: String) = "$sourceId|$mangaUrl|$chapterUrl"

    fun mangaKey(sourceId: Long, mangaUrl: String) = "$sourceId|$mangaUrl"

    /** Capítulos de esta obra que ya están guardados en el dispositivo. */
    fun downloaded(sourceId: Long, mangaUrl: String): Set<String> {
        val m = hub.store.dlManga(mangaKey(sourceId, mangaUrl)) ?: return emptySet()
        return m.chapters.filter { File(it.value).exists() }.keys
    }

    /** Añade capítulos a la cola. Devuelve cuántos se añadieron (se omiten los ya guardados o ya en cola). */
    fun enqueue(src: LoadedSource, manga: SManga, chapters: List<SChapter>): Int {
        val have = downloaded(src.id, manga.url)
        var added = 0
        synchronized(lock) {
            val cur = items.value.toMutableList()
            for (c in chapters) {
                val id = id(src.id, manga.url, c.url)
                if (c.url in have) continue
                val existing = cur.indexOfFirst { it.id == id }
                if (existing >= 0 && cur[existing].state in setOf(DlState.QUEUED, DlState.RUNNING)) continue
                val item = DlItem(
                    id, src.id, src.label, manga.url, manga.title, manga.author, c.url, c.name, c.chapter_number, DlState.QUEUED
                )
                if (existing >= 0) cur[existing] = item else cur.add(item)
                payloads[id] = Payload(manga.copy(), copyChapter(c))
                added++
            }
            items.value = cur
        }
        if (added > 0) kick()
        return added
    }

    private fun copyChapter(c: SChapter): SChapter = SChapter.create().also { it.copyFrom(c) }

    fun cancel(id: String) {
        update(id) { if (it.state == DlState.QUEUED || it.state == DlState.RUNNING) it.with(state = DlState.CANCELED) else it }
        if (currentId == id) currentJob?.cancel()
    }

    fun retry(id: String) {
        update(id) { if (it.state == DlState.ERROR || it.state == DlState.CANCELED) it.with(state = DlState.QUEUED, done = 0, error = null) else it }
        kick()
    }

    fun retryAllFailed() {
        items.update { l -> l.map { if (it.state == DlState.ERROR) it.with(state = DlState.QUEUED, done = 0, error = null) else it } }
        kick()
    }

    fun cancelAll() {
        items.update { l -> l.map { if (it.state == DlState.QUEUED || it.state == DlState.RUNNING) it.with(state = DlState.CANCELED) else it } }
        currentJob?.cancel()
    }

    fun clearFinished() {
        synchronized(lock) {
            items.update { l -> l.filter { it.state == DlState.QUEUED || it.state == DlState.RUNNING } }
            payloads.keys.retainAll(items.value.map { it.id }.toSet())
        }
    }

    private fun update(id: String, f: (DlItem) -> DlItem) {
        items.update { l -> l.map { if (it.id == id) f(it) else it } }
    }

    private fun kick() {
        synchronized(lock) {
            if (running) return
            running = true
        }
        hub.startDownloadService()
        hub.scope.launch(Dispatchers.IO) {
            try {
                while (true) {
                    val next = synchronized(lock) {
                        val n = items.value.firstOrNull { it.state == DlState.QUEUED }
                        if (n == null) running = false
                        n
                    } ?: return@launch
                    runItem(next)
                }
            } finally {
                synchronized(lock) { running = false }
            }
        }
    }

    private suspend fun runItem(item: DlItem) {
        update(item.id) { it.with(state = DlState.RUNNING, done = 0, error = null) }
        currentId = item.id
        val job = hub.scope.launch(Dispatchers.IO) { download(item) }
        currentJob = job
        job.join()
        currentJob = null
        currentId = null
        // Cancelado desde la interfaz mientras corría: el estado ya es CANCELED. Si terminó sin marcar nada, es un fallo inesperado.
        update(item.id) { if (it.state == DlState.RUNNING) it.with(state = DlState.ERROR, error = "Interrumpida") else it }
    }

    private suspend fun download(item: DlItem) {
        val p = payloads[item.id]
        val ls = hub.sources().firstOrNull { it.id == item.sourceId }
        val src = ls?.source as? HttpSource
        if (p == null || ls == null || src == null) {
            update(item.id) { it.with(state = DlState.ERROR, error = "La fuente ya no está disponible (extensión desinstalada o desactivada).") }
            return
        }
        val dir = File(File(root, safe(ls.name)), safe(p.manga.title).take(60) + " [" + hash8(item.sourceId.toString() + p.manga.url) + "]")
        dir.mkdirs()
        val target = File(dir, fileNameFor(p.chapter))
        val part = File(dir, target.name + ".part")
        try {
            val pages: List<Page> = when (val r = hub.pages(ls, p.chapter)) {
                is Res.Ok -> r.value
                is Res.Err -> throw DlException(r.message)
            }
            if (pages.isEmpty()) throw DlException("La fuente no devolvió ninguna página para este capítulo.")
            update(item.id) { it.with(total = pages.size) }

            ZipOutputStream(BufferedOutputStream(FileOutputStream(part))).use { zip ->
                zip.setLevel(Deflater.NO_COMPRESSION) // las imágenes ya están comprimidas
                for ((i, page) in pages.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    val bytes = fetchPage(src, page)
                    val ext = extOf(bytes)
                    zip.putNextEntry(ZipEntry("%04d.%s".format(i + 1, ext)))
                    zip.write(bytes)
                    zip.closeEntry()
                    update(item.id) { it.with(done = i + 1) }
                }
            }
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) throw DlException("No se pudo guardar el archivo del capítulo.")

            val key = hub.downloads.mangaKey(item.sourceId, item.mangaUrl)
            val prev = hub.store.dlManga(key)
            val chapters = (prev?.chapters ?: emptyMap()) + (item.chapterUrl to target.absolutePath)
            hub.store.saveDlManga(ExtStore.DlManga(key, p.manga.title, dir.absolutePath, prev?.seriesId ?: -1L, chapters))
            update(item.id) { it.with(state = DlState.DONE, done = pages.size) }
            hub.chapterSink?.invoke(
                SavedChapter(item.sourceId, ls.label, item.mangaUrl, p.manga.title, p.manga.author, item.chapterUrl,
                    item.chapterName, item.chapterNumber, target, pages.size)
            )
        } catch (e: CancellationException) {
            part.delete()
            update(item.id) { it.with(state = DlState.CANCELED) }
            throw e
        } catch (e: Throwable) {
            part.delete()
            val msg = if (e is DlException) e.message ?: "Error" else hub.friendly(e)
            update(item.id) { if (it.state == DlState.CANCELED) it else it.with(state = DlState.ERROR, error = msg) }
        }
    }

    private class DlException(msg: String) : Exception(msg)

    /** Descarga una página con hasta 3 intentos. Solo hay una imagen en memoria a la vez. */
    private suspend fun fetchPage(src: HttpSource, page: Page): ByteArray {
        var last: Throwable? = null
        for (attempt in 1..3) {
            try {
                if (page.imageUrl.isNullOrEmpty()) page.imageUrl = src.getImageUrl(page)
                val resp = src.getImage(page)
                resp.use { r ->
                    if (!r.isSuccessful) throw eu.kanade.tachiyomi.network.HttpException(r.code)
                    val len = r.body.contentLength()
                    if (len > MAX_PAGE_BYTES) throw DlException("Una imagen supera el tamaño máximo permitido.")
                    val bytes = r.body.bytes()
                    if (bytes.isEmpty()) throw DlException("La fuente devolvió una imagen vacía.")
                    if (bytes.size > MAX_PAGE_BYTES) throw DlException("Una imagen supera el tamaño máximo permitido.")
                    if (looksLikeHtml(bytes)) throw DlException("La fuente devolvió una página web en lugar de una imagen (¿requiere verificación?).")
                    return bytes
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: DlException) {
                throw e
            } catch (e: Throwable) {
                last = e
                if (attempt < 3) delay(1500L * attempt)
            }
        }
        throw last ?: DlException("No se pudo descargar la página.")
    }

    companion object {
        private const val MAX_PAGE_BYTES = 60L * 1024 * 1024

        fun safe(s: String): String {
            val t = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trim('.')
            return t.ifEmpty { "_" }
        }

        fun hash8(s: String): String =
            MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).take(4).joinToString("") { "%02x".format(it) }

        /** "0012 - Nombre.cbz": el prefijo numérico mantiene el orden natural de los capítulos. */
        fun fileNameFor(c: SChapter): String {
            val n = c.chapter_number
            val prefix = if (n >= 0) {
                val whole = n.toInt()
                val frac = n - whole
                if (frac > 0.0001f) "%04d.%d".format(whole, Math.round(frac * 10)) else "%04d".format(whole)
            } else "0000"
            return (prefix + " - " + safe(c.name).take(80)) + ".cbz"
        }

        fun extOf(b: ByteArray): String {
            fun at(i: Int) = if (i < b.size) b[i].toInt() and 0xff else -1
            return when {
                at(0) == 0xFF && at(1) == 0xD8 -> "jpg"
                at(0) == 0x89 && at(1) == 0x50 && at(2) == 0x4E && at(3) == 0x47 -> "png"
                at(0) == 'G'.code && at(1) == 'I'.code && at(2) == 'F'.code -> "gif"
                at(0) == 'R'.code && at(1) == 'I'.code && at(8) == 'W'.code && at(9) == 'E'.code -> "webp"
                at(4) == 'f'.code && at(5) == 't'.code && at(6) == 'y'.code && at(7) == 'p'.code &&
                    at(8) == 'a'.code && at(9) == 'v'.code -> "avif"
                else -> "jpg"
            }
        }

        fun looksLikeHtml(b: ByteArray): Boolean {
            val head = String(b, 0, minOf(b.size, 64), Charsets.ISO_8859_1).trimStart().lowercase()
            return head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<?xml") && !head.contains("svg")
        }
    }
}
