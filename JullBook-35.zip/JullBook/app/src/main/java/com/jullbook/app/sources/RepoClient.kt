package com.jullbook.app.sources

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Cliente de repositorios de extensiones. Formatos soportados:
 *  - `index.min.json` (array JSON), el de siempre en los repositorios de Mihon/Tachiyomi;
 *  - `index.pb` (protobuf, normalmente con gzip), el índice de la API 1.6 (ver [ProtoIndex]).
 * Más `repo.json` opcional con la huella de la clave de firma.
 *
 * Los repositorios 1.6 como Keiyoushi dejaron `index.min.json` como un recambio vacío; por eso, si el JSON falla o
 * viene vacío, se prueba automáticamente el `index.pb` de la misma carpeta.
 */
object RepoClient {
    private const val MAX_INDEX_BYTES = 30L * 1024 * 1024

    class BadRepo(msg: String) : IOException(msg)

    /** Acepta la URL del índice o de la carpeta del repositorio. Solo HTTPS. */
    fun normalize(input: String): String {
        var u = input.trim()
        if (u.isEmpty()) throw BadRepo("Escribe la URL del repositorio.")
        if (!u.startsWith("https://")) throw BadRepo("Solo se admiten repositorios HTTPS (la URL debe empezar por https://).")
        val last = u.substringBefore('?').trimEnd('/').substringAfterLast('/')
        if (u.endsWith("/")) u += "index.min.json"
        else if (!last.contains('.')) u = u.trimEnd('/') + "/index.min.json" // URL de la carpeta del repositorio
        if (!u.endsWith("index.min.json") && !u.endsWith("index.pb")) {
            throw BadRepo("Jull Books lee índices «index.pb» o «index.min.json». Esta URL apunta a otro tipo de archivo.")
        }
        return u
    }

    fun baseOf(indexUrl: String): String = indexUrl.substringBeforeLast('/')

    private fun get(client: OkHttpClient, url: String): String {
        val req = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw BadRepo("El repositorio respondió con el error HTTP ${r.code}.")
            val len = r.body.contentLength()
            if (len > MAX_INDEX_BYTES) throw BadRepo("El índice es demasiado grande.")
            return r.body.string()
        }
    }

    private fun getBytes(client: OkHttpClient, url: String): ByteArray {
        val req = Request.Builder().url(url).header("Accept", "application/octet-stream, application/json").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw BadRepo("El repositorio respondió con el error HTTP ${r.code}.")
            val src = r.body.source()
            if (src.request(MAX_INDEX_BYTES + 1)) throw BadRepo("El índice es demasiado grande.")
            return src.readByteArray()
        }
    }

    fun isProtoUrl(url: String): Boolean = url.substringBefore('?').endsWith(".pb")

    fun siblingProtoUrl(indexUrl: String): String = baseOf(indexUrl) + "/index.pb"

    fun fetchIndex(client: OkHttpClient, indexUrl: String): List<AvailableExt> {
        if (isProtoUrl(indexUrl)) return fetchProto(client, indexUrl)
        val fromJson = try {
            fetchJson(client, indexUrl)
        } catch (e: BadRepo) {
            // Un repositorio 1.6 puede tener el JSON vacío o roto: se intenta el índice binario antes de rendirse.
            return runCatching { fetchProto(client, siblingProtoUrl(indexUrl)) }.getOrElse { throw e }
        }
        if (fromJson.isNotEmpty()) return fromJson
        return runCatching { fetchProto(client, siblingProtoUrl(indexUrl)) }.getOrDefault(fromJson)
    }

    fun fetchProto(client: OkHttpClient, indexUrl: String): List<AvailableExt> {
        val entries = try {
            ProtoIndex.parse(getBytes(client, indexUrl))
        } catch (e: ProtoIndex.Malformed) {
            throw BadRepo(e.message ?: "El índice binario no es válido.")
        }
        return fromProto(entries, indexUrl)
    }

    /** Convierte las entradas de `index.pb` en extensiones disponibles. Separado para poder probarlo sin red. */
    fun fromProto(entries: List<ProtoIndex.Entry>, indexUrl: String): List<AvailableExt> {
        val base = baseOf(indexUrl)
        val out = ArrayList<AvailableExt>()
        for (e in entries) {
            val apk = resolve(e.apk, base, "apk") ?: continue
            val langs = e.sources.map { it.lang }.filter { it.isNotBlank() }.distinct()
            out.add(
                AvailableExt(
                    name = e.name.removePrefix("Tachiyomi: ").removePrefix("Mihon: "),
                    pkg = e.pkg,
                    apkUrl = apk,
                    iconUrl = e.icon?.let { resolve(it, base, "icon") } ?: "$base/icon/${e.pkg}.png",
                    versionName = e.versionName,
                    versionCode = e.versionCode,
                    lang = when (langs.size) { 0 -> ""; 1 -> langs[0]; else -> "all" },
                    nsfw = false, // el índice no lo indica; la extensión instalada sí (tachiyomix.contentWarning)
                    sources = e.sources.map { AvailableSource(it.name, it.lang, it.baseUrl) },
                    repoUrl = indexUrl
                )
            )
        }
        return out
    }

    /**
     * URL absoluta HTTPS tal cual, o ruta relativa a la carpeta del repositorio. Nunca puede salir de ella.
     * Un nombre suelto va en la subcarpeta [dir] (como en el índice JSON).
     */
    fun resolve(value: String, base: String, dir: String): String? {
        val v = value.trim()
        if (v.isEmpty()) return null
        if (v.startsWith("https://")) return v
        if (v.contains("://") || v.contains("\\") || v.contains("..") || v.startsWith("/")) return null
        return if (v.contains('/')) "$base/$v" else "$base/$dir/$v"
    }

    private fun fetchJson(client: OkHttpClient, indexUrl: String): List<AvailableExt> {
        val text = get(client, indexUrl)
        val arr = try {
            JSONArray(text)
        } catch (e: Exception) {
            throw BadRepo("La respuesta no es un índice de extensiones válido (se esperaba un array JSON).")
        }
        val base = baseOf(indexUrl)
        val out = ArrayList<AvailableExt>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val pkg = o.optString("pkg")
            val apk = o.optString("apk")
            if (pkg.isBlank() || apk.isBlank()) continue
            // El nombre del APK no puede salir de la carpeta del repositorio.
            if (apk.contains("/") || apk.contains("\\") || apk.contains("..")) continue
            val srcArr = o.optJSONArray("sources") ?: JSONArray()
            val sources = ArrayList<AvailableSource>()
            for (j in 0 until srcArr.length()) {
                val s = srcArr.optJSONObject(j) ?: continue
                sources.add(AvailableSource(s.optString("name"), s.optString("lang"), s.optString("baseUrl").ifBlank { null }))
            }
            out.add(
                AvailableExt(
                    name = o.optString("name").removePrefix("Tachiyomi: ").removePrefix("Mihon: "),
                    pkg = pkg,
                    apkUrl = "$base/apk/$apk",
                    iconUrl = "$base/icon/$pkg.png",
                    versionName = o.optString("version"),
                    versionCode = o.optLong("code"),
                    lang = o.optString("lang"),
                    nsfw = o.optInt("nsfw", 0) == 1,
                    sources = sources,
                    repoUrl = indexUrl
                )
            )
        }
        return out
    }

    /** Metadatos opcionales del repositorio (repo.json): nombre y huella SHA-256 de la clave de firma. */
    fun fetchMeta(client: OkHttpClient, indexUrl: String): Pair<String?, String?> = try {
        val meta = JSONObject(get(client, baseOf(indexUrl) + "/repo.json")).optJSONObject("meta")
        val name = meta?.optString("name")?.ifBlank { null } ?: meta?.optString("shortName")?.ifBlank { null }
        val fp = meta?.optString("signingKeyFingerprint")?.ifBlank { null }
        name to fp?.lowercase()?.replace(":", "")?.replace(" ", "")
    } catch (e: Exception) {
        null to null
    }
}
