package com.jullbook.app.sources

import java.io.ByteArrayInputStream
import java.util.zip.GZIPInputStream

/**
 * Lector mínimo del índice binario `index.pb` que publican los repositorios de extensiones de la API 1.6
 * (p. ej. Keiyoushi; su `index.min.json` ahora es solo un recambio vacío).
 *
 * Formato (protobuf, normalmente comprimido con gzip). Esquema tomado de implementaciones de terceros, NO de una
 * especificación oficial, así que este lector es deliberadamente tolerante: ignora campos que no conoce y
 * valida los tamaños.
 *
 *   raíz            : campo 101 (repetido) = Extension
 *   Extension       : 1 nombre · 2 paquete · 3 Archivos{1 apk, 2 icono} · 5 versionCode · 6 versionName
 *                     · 8 (repetido) Source{1 id · 2 nombre · 3 idioma · 4 baseUrl}
 *
 * Se implementa a mano (sin kotlinx-serialization-protobuf) para poder probarlo con pruebas JVM puras.
 */
object ProtoIndex {

    class Source(val id: Long, val name: String, val lang: String, val baseUrl: String?)

    class Entry(
        val name: String,
        val pkg: String,
        val apk: String,
        val icon: String?,
        val versionCode: Long,
        val versionName: String,
        val sources: List<Source>,
    )

    class Malformed(msg: String) : Exception(msg)

    private const val MAX_UNCOMPRESSED = 64L * 1024 * 1024

    /** Descomprime si empieza por la cabecera gzip (1f 8b); si no, devuelve los bytes tal cual. */
    fun maybeGunzip(raw: ByteArray): ByteArray {
        if (raw.size < 2 || raw[0] != 0x1f.toByte() || raw[1] != 0x8b.toByte()) return raw
        GZIPInputStream(ByteArrayInputStream(raw)).use { gz ->
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val n = gz.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_UNCOMPRESSED) throw Malformed("El índice descomprimido es demasiado grande.")
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
    }

    fun parse(raw: ByteArray): List<Entry> {
        val data = try {
            maybeGunzip(raw)
        } catch (e: java.io.IOException) {
            throw Malformed("El índice está dañado (gzip no válido).")
        }
        val out = ArrayList<Entry>()
        try {
            for (f in fields(data, 0, data.size)) {
                if (f.number == 101 && f.bytes != null) {
                    val e = entry(f.bytes) ?: continue
                    out.add(e)
                }
            }
        } catch (e: Malformed) {
            throw e
        } catch (e: RuntimeException) {
            throw Malformed("El índice no tiene el formato esperado.")
        }
        return out
    }

    // ---------------------------------------------------------------- modelo

    private fun entry(b: ByteArray): Entry? {
        var name = ""
        var pkg = ""
        var apk = ""
        var icon: String? = null
        var code = 0L
        var version = ""
        val sources = ArrayList<Source>()
        for (f in fields(b, 0, b.size)) {
            when (f.number) {
                1 -> name = f.text()
                2 -> pkg = f.text()
                3 -> f.bytes?.let { files ->
                    for (g in fields(files, 0, files.size)) {
                        when (g.number) {
                            1 -> apk = g.text()
                            2 -> icon = g.text().ifBlank { null }
                        }
                    }
                }
                5 -> code = f.varint
                6 -> version = f.text()
                8 -> f.bytes?.let { sb ->
                    var id = 0L; var sn = ""; var lang = ""; var base: String? = null
                    for (g in fields(sb, 0, sb.size)) {
                        when (g.number) {
                            1 -> id = g.varint
                            2 -> sn = g.text()
                            3 -> lang = g.text()
                            4 -> base = g.text().ifBlank { null }
                        }
                    }
                    sources.add(Source(id, sn, lang, base))
                }
            }
        }
        if (pkg.isBlank() || apk.isBlank()) return null
        return Entry(name, pkg, apk, icon, code, version, sources)
    }

    // ---------------------------------------------------------------- formato de cable protobuf

    private class Field(val number: Int, val varint: Long, val bytes: ByteArray?) {
        fun text(): String = bytes?.toString(Charsets.UTF_8) ?: ""
    }

    private fun fields(b: ByteArray, from: Int, to: Int): List<Field> {
        val out = ArrayList<Field>()
        var i = from
        fun varint(): Long {
            var shift = 0
            var result = 0L
            while (true) {
                if (i >= to || shift > 63) throw Malformed("Varint truncado.")
                val v = b[i++].toInt()
                result = result or ((v and 0x7f).toLong() shl shift)
                if (v and 0x80 == 0) return result
                shift += 7
            }
        }
        while (i < to) {
            val key = varint()
            val number = (key ushr 3).toInt()
            if (number <= 0) throw Malformed("Número de campo no válido.")
            when ((key and 7).toInt()) {
                0 -> out.add(Field(number, varint(), null))
                1 -> { if (i + 8 > to) throw Malformed("Campo truncado."); i += 8 }
                2 -> {
                    val len = varint()
                    if (len < 0 || len > to - i) throw Malformed("Longitud no válida.")
                    out.add(Field(number, 0, b.copyOfRange(i, i + len.toInt())))
                    i += len.toInt()
                }
                5 -> { if (i + 4 > to) throw Malformed("Campo truncado."); i += 4 }
                else -> throw Malformed("Tipo de cable desconocido.")
            }
        }
        return out
    }
}
