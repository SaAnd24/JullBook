package com.jullbook.app.books

import com.jullbook.app.data.Format

/**
 * Interfaz modular PROPIA de Jull Books para futuras fuentes de libros (EPUB/PDF). NO es una extensión de Mihon
 * y no se presenta como tal: las extensiones de Mihon trabajan con capítulos e imágenes, no con archivos EPUB/PDF.
 *
 * Contrato: una fuente solo debe ofrecer catálogos que autoricen la búsqueda y la descarga (dominio público,
 * licencias abiertas, préstamo autorizado). No debe eludir DRM, autenticación ni muros de pago.
 *
 * Reutiliza el resto del sistema: el gestor de fuentes (listado y estado), la cola de descargas y la importación
 * local de Jull Books. Las fuentes de libros gratuitos que ya trae la app (carpeta `discover`) siguen funcionando igual.
 */
interface BookSource {
    val id: String
    val name: String
    val lang: String

    /** Licencia o condición de acceso que la fuente declara para sus archivos (texto legible). */
    val accessNote: String

    suspend fun search(query: String, page: Int): BookPage

    /** Archivos descargables (EPUB/PDF) de un resultado. Solo debe devolver los que la fuente autorice descargar. */
    suspend fun files(result: BookResult): List<BookFile>
}

class BookResult(val id: String, val title: String, val author: String?, val coverUrl: String?, val detailUrl: String?)

class BookFile(val url: String, val format: Format, val sizeBytes: Long? = null, val license: String? = null)

class BookPage(val results: List<BookResult>, val hasNext: Boolean)

/** Registro de fuentes de libros. Vacío por defecto: ninguna fuente de terceros viene preinstalada. */
object BookSources {
    private val list = ArrayList<BookSource>()

    fun register(s: BookSource) {
        if (list.none { it.id == s.id }) list.add(s)
    }

    fun all(): List<BookSource> = list.toList()
}
