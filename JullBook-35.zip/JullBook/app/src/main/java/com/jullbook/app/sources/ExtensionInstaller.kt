package com.jullbook.app.sources

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException

/**
 * Descarga, verifica e instala APKs de extensiones con PackageInstaller (siempre con confirmación del sistema).
 *
 * Verificaciones antes de instalar (procedencia y versión):
 *  1. El APK declara el mismo paquete y la misma versionCode que anuncia el índice.
 *  2. Declara la característica "tachiyomi.extension" y una versión de API soportada.
 *  3. Si el repositorio publica una huella de firma (repo.json), el certificado del APK debe coincidir.
 *  4. Si ya hay una versión instalada, la firma debe ser la misma (Android también lo exige).
 */
class ExtensionInstaller(private val ctx: Context, private val client: OkHttpClient) {

    class Result(val ok: Boolean, val message: String, val signature: String? = null)

    private val dir = File(ctx.cacheDir, "ext_apk").apply { mkdirs() }

    fun downloadAndStage(ext: AvailableExt, repoFingerprint: String?): Result {
        if (!ext.apkUrl.startsWith("https://")) return Result(false, "El APK no se sirve por HTTPS; se rechaza.")
        val lib = ext.libVersion
        if (!ExtensionLoader.isSupported(lib)) {
            return Result(false, "Usa la API de extensiones ${lib ?: "desconocida"}; Jull Books soporta ${ExtensionLoader.LIB_MIN}–${ExtensionLoader.LIB_MAX}.")
        }
        val file = File(dir, ext.pkg + ".apk")
        try {
            client.newCall(Request.Builder().url(ext.apkUrl).build()).execute().use { r ->
                if (!r.isSuccessful) return Result(false, "No se pudo descargar el APK (HTTP ${r.code}).")
                val len = r.body.contentLength()
                if (len > 250L * 1024 * 1024) return Result(false, "El APK es demasiado grande.")
                file.outputStream().use { out -> r.body.byteStream().copyTo(out) }
            }
        } catch (e: IOException) {
            file.delete()
            return Result(false, "Error de red al descargar el APK: ${e.message ?: e.javaClass.simpleName}")
        }

        val pm = ctx.packageManager
        val flags = ExtensionLoaderFlags.flags()
        @Suppress("DEPRECATION")
        val info = pm.getPackageArchiveInfo(file.absolutePath, flags)
        if (info == null) {
            file.delete()
            return Result(false, "El archivo descargado no es un APK válido.")
        }
        if (info.packageName != ext.pkg) {
            file.delete()
            return Result(false, "El APK es del paquete «${info.packageName}», pero el índice anunciaba «${ext.pkg}». Se rechaza.")
        }
        if (ExtensionLoader.longVersionCode(info) != ext.versionCode) {
            file.delete()
            return Result(false, "La versión del APK no coincide con la del índice. Se rechaza.")
        }
        if (!ExtensionLoader.isExtension(info)) {
            file.delete()
            return Result(false, "El APK no declara ser una extensión de Mihon/Tachiyomi.")
        }
        val apkLib = ExtensionLoader.libVersionOf(info.versionName, info.applicationInfo?.metaData)
        if (!ExtensionLoader.isSupported(apkLib)) {
            file.delete()
            return Result(false, "El APK usa la API de extensiones ${apkLib ?: "desconocida"}; Jull Books soporta ${ExtensionLoader.LIB_MIN}–${ExtensionLoader.LIB_MAX}.")
        }
        val sig = ExtensionLoader.signatureOf(info)
        if (sig == null) {
            file.delete()
            return Result(false, "El APK no está firmado.")
        }
        if (repoFingerprint != null && !repoFingerprint.equals(sig, ignoreCase = true)) {
            file.delete()
            return Result(false, "La firma del APK no coincide con la huella publicada por el repositorio. Se rechaza.")
        }
        // Si ya está instalada, la firma debe ser la misma.
        val installed = runCatching {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ext.pkg, flags)
        }.getOrNull()
        if (installed != null) {
            val old = ExtensionLoader.signatureOf(installed)
            if (old != null && old != sig) {
                file.delete()
                return Result(false, "La firma del APK es distinta de la de la versión instalada. Se rechaza.")
            }
        }
        return Result(true, "Verificado", sig)
    }

    /** Lanza la instalación (el sistema pedirá confirmación al usuario). */
    fun commit(pkg: String): Result {
        val file = File(dir, "$pkg.apk")
        if (!file.exists()) return Result(false, "No hay APK preparado.")
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(pkg)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = installer.createSession(params)
        return try {
            installer.openSession(id).use { session ->
                file.inputStream().use { input ->
                    session.openWrite(pkg, 0, file.length()).use { out ->
                        input.copyTo(out)
                        session.fsync(out)
                    }
                }
                val intent = Intent(ACTION).setPackage(ctx.packageName).putExtra(EXTRA_PKG, pkg)
                val pi = PendingIntent.getBroadcast(ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
                session.commit(pi.intentSender)
            }
            Result(true, "Pendiente de confirmación del sistema")
        } catch (e: Exception) {
            runCatching { installer.abandonSession(id) }
            Result(false, "No se pudo iniciar la instalación: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun uninstall(pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun cleanup(pkg: String) {
        File(dir, "$pkg.apk").delete()
    }

    /** Receptor de resultados de instalación y de cambios de paquetes. */
    fun register(onResult: (pkg: String?, ok: Boolean, message: String) -> Unit, onPackagesChanged: () -> Unit) {
        val r1 = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                val pkg = intent.getStringExtra(EXTRA_PKG)
                when (val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                    PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                        @Suppress("DEPRECATION")
                        val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                        if (confirm != null) {
                            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            runCatching { c.startActivity(confirm) }
                        }
                    }
                    PackageInstaller.STATUS_SUCCESS -> {
                        pkg?.let { cleanup(it) }
                        onResult(pkg, true, "Instalada")
                    }
                    else -> {
                        pkg?.let { cleanup(it) }
                        onResult(pkg, false, intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Error de instalación ($status)")
                    }
                }
            }
        }
        ContextCompat.registerReceiver(ctx, r1, IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)

        val r2 = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) = onPackagesChanged()
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r2, f, ContextCompat.RECEIVER_EXPORTED)
    }

    companion object {
        const val ACTION = "com.jullbook.app.EXT_INSTALL_RESULT"
        const val EXTRA_PKG = "jull_pkg"
    }
}

/** Banderas de PackageManager necesarias para leer firma y metadatos. */
object ExtensionLoaderFlags {
    @Suppress("DEPRECATION")
    fun flags(): Int = android.content.pm.PackageManager.GET_CONFIGURATIONS or android.content.pm.PackageManager.GET_META_DATA or
        (if (Build.VERSION.SDK_INT >= 28) android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
        else android.content.pm.PackageManager.GET_SIGNATURES)
}
