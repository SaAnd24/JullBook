package com.jullbook.app

import android.app.Application
import com.jullbook.app.sources.SourceHub
import eu.kanade.tachiyomi.network.NetworkHelper
import kotlinx.serialization.json.Json
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.InjektModule
import uy.kohesive.injekt.api.InjektRegistrar
import uy.kohesive.injekt.api.addSingleton
import uy.kohesive.injekt.api.addSingletonFactory

/** Registra lo que las extensiones de Mihon esperan encontrar mediante Injekt (Application, NetworkHelper, Json). */
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
class JullInjektModule(private val app: Application) : InjektModule {
    override fun InjektRegistrar.registerInjectables() {
        addSingleton(app)
        addSingletonFactory { NetworkHelper(app) }
        addSingletonFactory { Json { ignoreUnknownKeys = true; explicitNulls = false } }
    }
}

class JullApp : Application() {

    val hub: SourceHub by lazy { SourceHub(this) }

    override fun onCreate() {
        super.onCreate()
        Injekt.importModule(JullInjektModule(this))
    }
}
