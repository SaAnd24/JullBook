package com.jullbook.app.sources

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.jullbook.app.JullApp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Mantiene viva la app (notificación) mientras hay capítulos en la cola de descargas. */
class DownloadService : Service() {

    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val hub = (application as JullApp).hub
        ensureChannel()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        runCatching { ServiceCompat.startForeground(this, ID, notification("Preparando descargas…", 0, 0), type) }
        job?.cancel()
        job = hub.scope.launch {
            hub.downloads.items.collect { list ->
                val active = list.filter { it.state == DlState.QUEUED || it.state == DlState.RUNNING }
                if (active.isEmpty()) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    val run = active.firstOrNull { it.state == DlState.RUNNING }
                    val text = (run?.let { "${it.mangaTitle} · ${it.chapterName}" } ?: "En cola") + " (${active.size})"
                    val nm = getSystemService(NotificationManager::class.java)
                    nm.notify(ID, notification(text, run?.done ?: 0, run?.total ?: 0))
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    private fun notification(text: String, done: Int, total: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Descargando capítulos")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(total, done, total == 0)
            .build()

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Descargas", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    companion object {
        private const val ID = 4207
        private const val CHANNEL = "jull_downloads"
    }
}
