package com.jullbook.app.sources

import eu.kanade.tachiyomi.source.CatalogueSource

/** Estado de una extensión instalada tras intentar cargarla. */
enum class ExtState {
    /** Cargada y con fuentes utilizables. */
    READY,

    /** Instalada, pero su firma aún no se ha aprobado: NO se ejecuta ni una línea de su código. */
    UNTRUSTED,

    /** Usa una versión de la API de extensiones que Jull Books no soporta. */
    INCOMPATIBLE,

    /** Falló al cargarse (clase ausente, método de la API no implementado, etc.). */
    ERROR
}

class LoadedSource(
    val id: Long,
    val name: String,
    val lang: String,
    val source: CatalogueSource?,
    val pkg: String,
    val extName: String,
    /** Versión de la API de extensiones con la que se compiló la extensión (1.4, 1.5, 1.6…). */
    val lib: Double? = null
) {
    /** Las fuentes de la API 1.6 se refrescan con una sola llamada combinada (detalles + capítulos). */
    val isLib16: Boolean get() = (lib ?: 0.0) >= 1.6
    val label: String get() = if (lang.isBlank()) name else "$name (${lang.uppercase()})"
}

class InstalledExt(
    val pkg: String,
    val name: String,
    val versionName: String,
    val versionCode: Long,
    val libVersion: Double?,
    val nsfw: Boolean,
    /** SHA-256 (hex) del certificado con el que está firmada la extensión. */
    val signature: String?,
    val state: ExtState,
    val message: String?,
    val enabled: Boolean,
    val sources: List<LoadedSource>
)

class AvailableSource(val name: String, val lang: String, val baseUrl: String?)

class AvailableExt(
    val name: String,
    val pkg: String,
    val apkUrl: String,
    val iconUrl: String,
    val versionName: String,
    val versionCode: Long,
    val lang: String,
    val nsfw: Boolean,
    val sources: List<AvailableSource>,
    val repoUrl: String
) {
    /** Versión de la API de extensiones que declara (major.minor del versionName). */
    val libVersion: Double? get() = ExtensionLoader.libVersionOf(versionName)
}

class Repo(val url: String, val name: String, val fingerprint: String?)

/** Un capítulo descargado y guardado, listo para entrar en la biblioteca local. */
class SavedChapter(
    val sourceId: Long,
    val sourceName: String,
    val mangaUrl: String,
    val mangaTitle: String,
    val author: String?,
    val chapterUrl: String,
    val chapterName: String,
    val chapterNumber: Float,
    val file: java.io.File,
    val pages: Int
)
