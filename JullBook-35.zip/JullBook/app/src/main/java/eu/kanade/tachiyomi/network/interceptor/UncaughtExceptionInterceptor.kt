package eu.kanade.tachiyomi.network.interceptor

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

/**
 * Convierte cualquier excepción no controlada de otros interceptores en IOException, para que OkHttp no se cuelgue
 * y la app muestre un error normal. Algunas extensiones comprueban que este interceptor exista en el cliente por
 * defecto (el nombre y el paquete deben coincidir con los de Mihon).
 */
class UncaughtExceptionInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        try {
            return chain.proceed(chain.request())
        } catch (e: Exception) {
            if (e is IOException) throw e
            throw IOException(e)
        }
    }
}
