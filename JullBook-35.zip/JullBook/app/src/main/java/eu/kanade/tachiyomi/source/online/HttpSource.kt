/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4, 1.5 and 1.6 / TachiyomiX).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.source.online

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.NetworkHelper
import eu.kanade.tachiyomi.network.asObservableSuccess
import eu.kanade.tachiyomi.network.newCachelessCallWithProgress
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.util.awaitSingle
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import rx.Observable
import uy.kohesive.injekt.injectLazy
import java.net.URI
import java.net.URISyntaxException
import java.security.MessageDigest

class LicensedMangaChaptersException : RuntimeException("Licensed - No chapters to show")

/** A simple implementation for sources from a website. */
@Suppress("unused")
abstract class HttpSource : CatalogueSource {

    /** Network service. */
    protected val network: NetworkHelper by injectLazy()

    /** Base url of the website without the trailing slash, like: http://mysite.com */
    abstract val baseUrl: String

    /** Version id used to generate the source id. Bump it when the source changes in a way that breaks library entries. */
    open val versionId = 1

    /** Id of the source. By default it uses a generated id using the first 16 characters (64 bits) of the MD5 of the string "source name/language/versionId". */
    override val id by lazy { generateId(name, lang, versionId) }

    /** Headers used for requests. */
    val headers: Headers by lazy { headersBuilder().build() }

    /** Default network client for doing requests. */
    open val client: OkHttpClient
        get() = network.client

    /** Headers builder for requests. Implementations can override this method for custom headers. */
    protected open fun headersBuilder() = Headers.Builder().apply {
        add("User-Agent", network.defaultUserAgentProvider())
    }

    override fun toString() = "$name (${lang.uppercase()})"

    // ---- Popular ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getPopularManga"))
    override fun fetchPopularManga(page: Int): Observable<MangasPage> {
        return client.newCall(popularMangaRequest(page))
            .asObservableSuccess()
            .map { response -> popularMangaParse(response) }
    }

    protected open fun popularMangaRequest(page: Int): Request = notUsed()

    protected open fun popularMangaParse(response: Response): MangasPage = notUsed()

    // ---- Search ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getSearchManga"))
    override fun fetchSearchManga(page: Int, query: String, filters: FilterList): Observable<MangasPage> {
        return client.newCall(searchMangaRequest(page, query, filters))
            .asObservableSuccess()
            .map { response -> searchMangaParse(response) }
    }

    protected open fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request = notUsed()

    protected open fun searchMangaParse(response: Response): MangasPage = notUsed()

    // ---- Latest ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getLatestUpdates"))
    override fun fetchLatestUpdates(page: Int): Observable<MangasPage> {
        return client.newCall(latestUpdatesRequest(page))
            .asObservableSuccess()
            .map { response -> latestUpdatesParse(response) }
    }

    protected open fun latestUpdatesRequest(page: Int): Request = notUsed()

    protected open fun latestUpdatesParse(response: Response): MangasPage = notUsed()

    // ---- Details ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getMangaDetails"))
    override fun fetchMangaDetails(manga: SManga): Observable<SManga> {
        return client.newCall(mangaDetailsRequest(manga))
            .asObservableSuccess()
            .map { response -> mangaDetailsParse(response).apply { initialized = true } }
    }

    open fun mangaDetailsRequest(manga: SManga): Request {
        return GET(baseUrl + manga.url, headers)
    }

    protected open fun mangaDetailsParse(response: Response): SManga = notUsed()

    // ---- Chapters ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getChapterList"))
    override fun fetchChapterList(manga: SManga): Observable<List<SChapter>> {
        return if (manga.status != SManga.LICENSED) {
            client.newCall(chapterListRequest(manga))
                .asObservableSuccess()
                .map { response -> chapterListParse(response) }
        } else {
            Observable.error(LicensedMangaChaptersException())
        }
    }

    protected open fun chapterListRequest(manga: SManga): Request {
        return GET(baseUrl + manga.url, headers)
    }

    protected open fun chapterListParse(response: Response): List<SChapter> = notUsed()

    // ---- Pages ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getPageList"))
    override fun fetchPageList(chapter: SChapter): Observable<List<Page>> {
        return client.newCall(pageListRequest(chapter))
            .asObservableSuccess()
            .map { response -> pageListParse(response) }
    }

    protected open fun pageListRequest(chapter: SChapter): Request {
        return GET(baseUrl + chapter.url, headers)
    }

    protected open fun pageListParse(response: Response): List<Page> = notUsed()

    // ---- Image url / image ----

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getImageUrl"))
    open fun fetchImageUrl(page: Page): Observable<String> {
        return client.newCall(imageUrlRequest(page))
            .asObservableSuccess()
            .map { imageUrlParse(it) }
    }

    protected open fun imageUrlRequest(page: Page): Request {
        return GET(page.url, headers)
    }

    protected open fun imageUrlParse(response: Response): String = notUsed()

    /** Resolves the final image url of [page] (only needed when the page list did not provide it). */
    open suspend fun getImageUrl(page: Page): String {
        @Suppress("DEPRECATION")
        return fetchImageUrl(page).awaitSingle()
    }

    @Deprecated("Use the non-RxJava API instead", replaceWith = ReplaceWith("getImage"))
    open fun fetchImage(page: Page): Observable<Response> {
        return client.newCachelessCallWithProgress(imageRequest(page), page)
            .asObservableSuccess()
    }

    /** Returns the response of the image of [page]. The caller must close it. */
    open suspend fun getImage(page: Page): Response {
        @Suppress("DEPRECATION")
        return fetchImage(page).awaitSingle()
    }

    protected open fun imageRequest(page: Page): Request {
        return GET(page.imageUrl!!, headers)
    }

    /** Request used by Jull Books to download an image (public wrapper of the protected contract). */
    fun imageRequestFor(page: Page): Request = imageRequest(page)

    // ---- Urls ----

    fun SChapter.setUrlWithoutDomain(url: String) {
        this.url = getUrlWithoutDomain(url)
    }

    fun SManga.setUrlWithoutDomain(url: String) {
        this.url = getUrlWithoutDomain(url)
    }

    private fun getUrlWithoutDomain(orig: String): String {
        return try {
            val uri = URI(orig.replace(" ", "%20"))
            var out = uri.path
            if (uri.query != null) out += "?" + uri.query
            if (uri.fragment != null) out += "#" + uri.fragment
            out
        } catch (e: URISyntaxException) {
            orig
        }
    }

    open fun getMangaUrl(manga: SManga): String {
        return mangaDetailsRequest(manga).url.toString()
    }

    open fun getChapterUrl(chapter: SChapter): String {
        return pageListRequest(chapter).url.toString()
    }

    open fun prepareNewChapter(chapter: SChapter, manga: SManga) {}

    /**
     * extensions-lib 1.6: URL opened by "Open in WebView" in the browse screen. Defaults to the site root.
     */
    open fun getHomeUrl(): String = baseUrl

    override fun getFilterList() = FilterList()

    /** The 1.6 request/parse hooks are deprecated without replacement; 1.6 sources do not implement them. */
    private fun notUsed(): Nothing = throw IllegalStateException("Not used")

    companion object {
        fun generateId(name: String, lang: String, versionId: Int): Long {
            val key = "${name.lowercase()}/$lang/$versionId"
            val bytes = MessageDigest.getInstance("MD5").digest(key.toByteArray())
            return (0..7).map { bytes[it].toLong() and 0xff shl 8 * (7 - it) }.reduce(Long::or) and Long.MAX_VALUE
        }
    }
}
