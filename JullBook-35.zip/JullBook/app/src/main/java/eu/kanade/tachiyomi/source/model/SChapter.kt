/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4, 1.5 and 1.6 / TachiyomiX).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.source.model

import kotlinx.serialization.json.JsonObject
import java.io.Serializable

interface SChapter : Serializable {

    var url: String
    var name: String
    var date_upload: Long
    var chapter_number: Float
    var scanlator: String?

    /** extensions-lib 1.6: free-form JSON object the extension can use to carry its own state. */
    var memo: JsonObject

    fun copyFrom(other: SChapter) {
        name = other.name
        url = other.url
        date_upload = other.date_upload
        chapter_number = other.chapter_number
        scanlator = other.scanlator
        memo = other.memo
    }

    companion object {
        fun create(): SChapter {
            return SChapterImpl()
        }
    }
}

class SChapterImpl : SChapter {

    override lateinit var url: String
    override lateinit var name: String
    override var date_upload: Long = 0
    override var chapter_number: Float = -1F
    override var scanlator: String? = null
    override var memo: JsonObject = JsonObject(emptyMap())
}
