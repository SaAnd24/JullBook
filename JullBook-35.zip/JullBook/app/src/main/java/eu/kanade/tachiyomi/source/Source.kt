/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4, 1.5 and 1.6 / TachiyomiX).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.source

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceScreen
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import eu.kanade.tachiyomi.util.awaitSingle
import rx.Observable
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

interface Source {

    val id: Long

    val name: String

    val lang: String
        get() = ""

    // ---- Browse (extensions-lib 1.6 moved these up from CatalogueSource; 1.4/1.5 sources inherit them unchanged) ----

    suspend fun getPopularManga(page: Int): MangasPage {
        @Suppress("DEPRECATION")
        return (this as? CatalogueSource)?.fetchPopularManga(page)?.awaitSingle()
            ?: throw UnsupportedOperationException("Source does not support browsing: $name")
    }

    suspend fun getSearchManga(page: Int, query: String, filters: FilterList): MangasPage {
        @Suppress("DEPRECATION")
        return (this as? CatalogueSource)?.fetchSearchManga(page, query, filters)?.awaitSingle()
            ?: throw UnsupportedOperationException("Source does not support searching: $name")
    }

    suspend fun getLatestUpdates(page: Int): MangasPage {
        @Suppress("DEPRECATION")
        return (this as? CatalogueSource)?.fetchLatestUpdates(page)?.awaitSingle()
            ?: throw UnsupportedOperationException("Source does not support latest updates: $name")
    }

    fun getFilterList(): FilterList = FilterList()

    // ---- Manga / chapters / pages ----

    /** 1.5 API. 1.6 sources implement [getMangaUpdate] instead; callers in the app should prefer that one. */
    suspend fun getMangaDetails(manga: SManga): SManga {
        @Suppress("DEPRECATION")
        return fetchMangaDetails(manga).awaitSingle()
    }

    /** 1.5 API. 1.6 sources implement [getMangaUpdate] instead; callers in the app should prefer that one. */
    suspend fun getChapterList(manga: SManga): List<SChapter> {
        @Suppress("DEPRECATION")
        return fetchChapterList(manga).awaitSingle()
    }

    /**
     * extensions-lib 1.6: fetches the details and/or the chapter list of [manga] in a single call.
     * [chapters] are the chapters the caller already has (in source order); they are returned untouched when
     * [fetchChapters] is false. The default implementation serves 1.4/1.5 sources through [getMangaDetails] and
     * [getChapterList]; 1.6 sources override it.
     */
    suspend fun getMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        val details = if (fetchDetails) getMangaDetails(manga) else manga
        val chapterList = if (fetchChapters) getChapterList(manga) else chapters
        return SMangaUpdate(details, chapterList)
    }

    suspend fun getPageList(chapter: SChapter): List<Page> {
        @Suppress("DEPRECATION")
        return fetchPageList(chapter).awaitSingle()
    }

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getMangaUpdate"))
    fun fetchMangaDetails(manga: SManga): Observable<SManga> = throw IllegalStateException("Not used")

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getMangaUpdate"))
    fun fetchChapterList(manga: SManga): Observable<List<SChapter>> = throw IllegalStateException("Not used")

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getPageList"))
    fun fetchPageList(chapter: SChapter): Observable<List<Page>> = throw IllegalStateException("Not used")
}

interface CatalogueSource : Source {

    override val lang: String

    val supportsLatest: Boolean

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getPopularManga"))
    fun fetchPopularManga(page: Int): Observable<MangasPage> = throw IllegalStateException("Not used")

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getSearchManga"))
    fun fetchSearchManga(page: Int, query: String, filters: FilterList): Observable<MangasPage> =
        throw IllegalStateException("Not used")

    @Deprecated("Use the non-RxJava API instead", ReplaceWith("getLatestUpdates"))
    fun fetchLatestUpdates(page: Int): Observable<MangasPage> = throw IllegalStateException("Not used")
}

interface SourceFactory {
    fun createSources(): List<Source>
}

/** Marker: the source does not count against metered-connection restrictions. */
interface UnmeteredSource

interface ConfigurableSource : Source {

    /** Preferences storage of this source (file "source_<id>"). */
    fun getSourcePreferences(): SharedPreferences =
        Injekt.get<Application>().getSharedPreferences(preferenceKey(), Context.MODE_PRIVATE)

    fun setupPreferenceScreen(screen: PreferenceScreen)
}

fun ConfigurableSource.preferenceKey(): String = "source_" + id

fun ConfigurableSource.getPreferences(): SharedPreferences =
    Injekt.get<Application>().getSharedPreferences(preferenceKey(), Context.MODE_PRIVATE)

fun ConfigurableSource.getPreferencesLazy(): Lazy<SharedPreferences> = lazy { getPreferences() }

fun sourcePreferences(key: String): SharedPreferences =
    Injekt.get<Application>().getSharedPreferences(key, Context.MODE_PRIVATE)
