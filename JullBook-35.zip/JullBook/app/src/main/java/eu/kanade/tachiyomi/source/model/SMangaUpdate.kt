/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4, 1.5 and 1.6 / TachiyomiX).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.source.model

/**
 * Result of [eu.kanade.tachiyomi.source.Source.getMangaUpdate] (extensions-lib 1.6): the manga with refreshed
 * details and/or its chapter list. When a part was not requested the caller's own value is returned for it.
 */
data class SMangaUpdate(
    val manga: SManga,
    val chapters: List<SChapter>,
)
