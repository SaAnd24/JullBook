# Licencias y atribuciones de terceros

## Mihon / Tachiyomi (Apache License 2.0)

La carpeta `app/src/main/java/eu/kanade/tachiyomi/` es una **reimplementación independiente en Kotlin** de la superficie
pública de la API de extensiones (extensions-lib 1.4 / 1.5), escrita para Jull Books siguiendo los contratos del proyecto
Mihon (https://github.com/mihonapp/mihon) y de Tachiyomi. No se copiaron archivos del repositorio de Mihon: el código fuente
de `source-api` no se pudo leer durante el desarrollo (GitHub bloquea el acceso automatizado), de modo que firmas y
comportamientos se reconstruyeron de la documentación y de la API conocida. Los nombres de paquete, clases y funciones deben
coincidir exactamente con los de Mihon para que las extensiones existentes funcionen; esos nombres son el contrato público.

- Copyright 2015 Javier Tomás
- Copyright 2024 Mihon Open Source Project
- Licencia: Apache License, Version 2.0 → `docs/LICENSE-Apache-2.0.txt`
- Modificaciones: reescritura completa para Jull Books; sin WebView/Cloudflare, sin cookies persistentes, sin pantallas de preferencias de fuente (ver docs/MIHON_COMPATIBILITY.md).

Cada archivo de esa carpeta lleva una cabecera que lo indica.

## Dependencias nuevas (todas con licencia permisiva)

| Librería | Uso | Licencia |
|---|---|---|
| OkHttp / Okio (Square) 5.0.0-alpha.14 | Red de las extensiones | Apache-2.0 |
| jsoup 1.18.1 | Análisis HTML (`ParsedHttpSource`) | MIT |
| RxJava 1.3.8 | API heredada (`fetchPopularManga`…) | Apache-2.0 |
| Injekt (com.github.inorichi.injekt:injekt-core:65b0440) | Inyección que las extensiones esperan | Apache-2.0 (a verificar en el repositorio de origen) |
| kotlinx-serialization-json 1.7.3 | `Json` para las extensiones | Apache-2.0 |
| androidx.preference 1.2.1 | `ConfigurableSource` (firma de `setupPreferenceScreen`) | Apache-2.0 |

Las extensiones que instale el usuario son software de terceros con sus propias licencias; Jull Books no las incluye.
