pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Solo para Injekt (com.github.inorichi.injekt), que usan las extensiones de Mihon/Tachiyomi.
        maven("https://jitpack.io") { content { includeGroupByRegex("com\\.github\\.inorichi.*") } }
    }
}
rootProject.name = "JullBook"
include(":app")
