package com.jullbook.app.ui.reader

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Bookmark
import com.jullbook.app.data.EpubSearch
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.Mark
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ReaderStore
import com.jullbook.app.data.SearchHit
import com.jullbook.app.data.Sentences
import com.jullbook.app.data.pctText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

internal class EpubTheme(val bg: Color, val fg: Color)

private val EPUB_THEMES = listOf(
    EpubTheme(Color(0xFFFAF8F3), Color(0xFF1C1B19)), // Claro
    EpubTheme(Color(0xFF000000), Color(0xFFC8C4BA)), // Oscuro
    EpubTheme(Color(0xFFF1E6CC), Color(0xFF4B3B2A)), // Sepia
    EpubTheme(Color(0xFF2B2B2D), Color(0xFFD6D6D6)), // Gris
    EpubTheme(Color(0xFF0F1626), Color(0xFFC9D4EA))  // Azul noche
)
private val THEME_NAMES = listOf("Claro", "Oscuro", "Sepia", "Gris", "Azul noche")
private val FAMILY_NAMES = listOf("Sans", "Serif", "Mono", "Cursiva")
private val MARGINS = listOf(12, 24, 40, 64)
private val MARGIN_NAMES = listOf("Mínimos", "Estrechos", "Medios", "Anchos")
private val MARK_COLORS = listOf(0x66FFE04A, 0x6672D572, 0x6663B3FF, 0x66FF7EB6)
private const val NARR_COLOR = 0x55FFB300
private const val HIT_COLOR = 0x99FF9800.toInt()

/** Frase sobre la que se ha hecho pulsación larga. */
private class Pick(val ch: Int, val block: Int, val s: Int, val e: Int, val text: String, val word: String, val frac: Float)

/** Ajustes de lectura: se guardan al soltar el control. */
private class ReadSettings(val prefs: com.jullbook.app.data.Prefs) {
    var font by mutableFloatStateOf(prefs.epubFont)
    var margin by mutableIntStateOf(prefs.epubMargin.coerceIn(0, MARGINS.lastIndex))
    var theme by mutableIntStateOf(prefs.epubTheme)
    var family by mutableIntStateOf(prefs.epubFamily.coerceIn(0, 3))
    var line by mutableFloatStateOf(prefs.epubLine)
    var para by mutableFloatStateOf(prefs.epubPara)
    var justify by mutableStateOf(prefs.epubJustify)
    var tapZones by mutableStateOf(prefs.epubTapZones)
    var brightness by mutableFloatStateOf(prefs.epubBrightness)
    var keepOn by mutableStateOf(prefs.epubKeepOn)
    var lockRot by mutableStateOf(prefs.epubLockRotation)

    fun reset() {
        font = 18f; margin = 1; theme = -1; family = 1; line = 1.55f; para = 10f
        justify = false; tapZones = true; brightness = -1f; keepOn = true; lockRot = false
        save()
    }

    fun save() {
        prefs.epubFont = font; prefs.epubMargin = margin; prefs.epubTheme = theme; prefs.epubFamily = family
        prefs.epubLine = line; prefs.epubPara = para; prefs.epubJustify = justify; prefs.epubTapZones = tapZones
        prefs.epubBrightness = brightness; prefs.epubKeepOn = keepOn; prefs.epubLockRotation = lockRot
    }
}

@Composable
fun EpubReader(book: Book, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var session by remember { mutableStateOf<EpubSession?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(book.id) {
        withContext(Dispatchers.IO) {
            try {
                session = EpubSession.open(ctx, Uri.parse(book.uri))
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                error = "No se pudo abrir este EPUB. El archivo puede estar dañado."
            }
        }
    }
    DisposableEffect(Unit) { onDispose { session?.close() } }

    val s = session
    val err = error
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            err != null -> ReaderMessage(err, onBack)
            s == null -> ReaderLoading()
            s.info.spine.isEmpty() -> ReaderMessage("Este EPUB no tiene contenido legible.", onBack)
            else -> EpubBody(book, s, start, vm, onBack)
        }
    }
}

@Composable
private fun EpubBody(book: Book, s: EpubSession, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val prefs = vm.prefs
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current
    val reporter = rememberReporter(book.id, vm)
    val tick = rememberPageTick()
    var lastPageKey by remember { mutableStateOf<Long?>(null) }
    val chapters = s.info.spine.size
    val density = LocalDensity.current
    val measurer = rememberTextMeasurer(cacheSize = 8)
    val pag = remember(s) { EpubPaginator(s, measurer) }
    val anchor = remember { Anchor(start?.sub ?: 0, start?.frac ?: 0f) }
    val st = remember { ReadSettings(prefs) }
    val store = remember { ReaderStore(ctx.applicationContext) }
    val marks = remember(book.id) { mutableStateListOf<Mark>().apply { addAll(store.marks(book.id)) } }
    val bookmarks = remember(book.id) { mutableStateListOf<Bookmark>().apply { addAll(store.bookmarks(book.id)) } }
    val narr = remember(s) { Narrator(ctx.applicationContext, s, prefs, book.title) }
    DisposableEffect(narr) { onDispose { narr.release() } }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    var target by remember { mutableIntStateOf((start?.pos ?: 0).coerceIn(0, chapters - 1)) }
    var shown by remember { mutableStateOf<Shown?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var chrome by remember { mutableStateOf(true) }
    var sheet by remember { mutableIntStateOf(0) }
    var percent by remember { mutableFloatStateOf(start?.percent ?: 0f) }
    var pageIdx by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(1) }
    var curPage by remember { mutableStateOf<EpubPage?>(null) }
    var cmd by remember { mutableStateOf<PageCmd?>(null) }
    var pick by remember { mutableStateOf<Pick?>(null) }
    var noteDraft by remember { mutableStateOf("") }
    var tempMark by remember { mutableStateOf<Mark?>(null) }
    var searchQ by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<SearchHit>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var searchProg by remember { mutableStateOf(0f) }

    // "Auto" usa el tema que eligió el usuario en JullBook (estable: Juli Experience nunca llega al lector).
    val scheme = MaterialTheme.colorScheme
    val theme = if (st.theme in EPUB_THEMES.indices) EPUB_THEMES[st.theme] else EpubTheme(scheme.background, scheme.onBackground)

    ReaderWindowEffects(
        hideBars = !chrome && sheet == 0,
        keepOn = st.keepOn || narr.state == NarrState.PLAYING,
        lockRotation = st.lockRot,
        brightness = st.brightness
    )

    // Configuración de paginación: tamaño real de la pantalla y ajustes de texto.
    val cfg = remember(size, st.font, st.margin, density, st.family, st.line, st.para, st.justify) {
        if (size.width <= 0 || size.height <= 0) {
            null
        } else {
            val top = with(density) { PAGE_TOP_DP.dp.toPx() }.roundToInt()
            val bottom = with(density) { PAGE_BOTTOM_DP.dp.toPx() }.roundToInt()
            PageCfg(
                size.width, size.height - top - bottom, st.font,
                with(density) { MARGINS[st.margin].dp.toPx() }.roundToInt(), density,
                st.family, st.line, st.para, st.justify
            )
        }
    }

    // Pagina el capítulo pedido. Al cambiar los ajustes se espera un instante (los deslizadores no repaginan en cada tick)
    // y se conserva la página actual hasta que la nueva paginación está lista.
    LaunchedEffect(target, cfg) {
        val c = cfg ?: return@LaunchedEffect
        val cached = pag.peek(target, c)
        val pages = cached ?: run {
            if (shown?.ch == target) delay(200)
            pag.get(target, c)
        }
        shown = Shown(target, c, pages)
    }

    fun goTo(i: Int, atEnd: Boolean = false) {
        sheet = 0
        val t = i.coerceIn(0, chapters - 1)
        if (t == target) return
        anchor.sub = 0
        anchor.frac = 0f
        anchor.atEnd = atEnd
        cmd = null
        target = t
    }

    /** Salta a un punto exacto (bloque + fracción) de cualquier capítulo. */
    fun goToAnchor(ch: Int, sub: Int, frac: Float) {
        sheet = 0
        val t = ch.coerceIn(0, chapters - 1)
        anchor.sub = sub
        anchor.frac = frac
        anchor.atEnd = false
        val sh = shown
        if (t == target && sh != null && sh.ch == t) {
            cmd = PageCmd(t, pageIndexFor(sh.pages, anchor), false)
        } else {
            cmd = null
            target = t
        }
    }

    val cur = shown?.ch ?: target

    // ---- Narración: el lector sigue a la voz (cambia de capítulo y de página solo) ----
    val np = narr.pos
    LaunchedEffect(np?.ch) {
        val q = narr.pos ?: return@LaunchedEffect
        if (narr.state != NarrState.IDLE && q.ch != target) {
            anchor.sub = q.block
            anchor.frac = 0f
            anchor.atEnd = false
            cmd = null
            target = q.ch
        }
    }
    val sh0 = shown
    val narrPage = if (np != null && sh0 != null && np.ch == sh0.ch) pageIndexOfChar(sh0.pages, np.block, np.s) else -1
    LaunchedEffect(narrPage, sh0?.ch, narr.state) {
        val sh = shown ?: return@LaunchedEffect
        if (narr.state == NarrState.PLAYING && narrPage >= 0) cmd = PageCmd(sh.ch, narrPage, true)
    }

    fun listenFrom(block: Int, off: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        sheet = 0
        chrome = false
        narr.start(cur, block, off)
    }

    fun listenFromPage() {
        val p = curPage
        val c = p?.chunks?.firstOrNull { it.text != null }
        if (c != null) listenFrom(c.block, (c.start - (if (c.src?.bullet == true) 3 else 0)).coerceAtLeast(0))
        else listenFrom(p?.sub ?: 0, 0)
    }

    // ---- Marcadores y resaltados ----
    val isBookmarked = shown?.let { sh -> bookmarks.any { it.ch == sh.ch && pageIndexFor(sh.pages, Anchor(it.sub, it.frac)) == pageIdx } } == true

    fun toggleBookmark() {
        val sh = shown ?: return
        val page = curPage ?: return
        val here = bookmarks.filter { it.ch == sh.ch && pageIndexFor(sh.pages, Anchor(it.sub, it.frac)) == pageIdx }
        if (here.isNotEmpty()) {
            bookmarks.removeAll(here)
        } else {
            val label = page.chunks.firstOrNull { it.text != null }?.text?.text?.trim()?.take(90).orEmpty()
            bookmarks.add(Bookmark(System.currentTimeMillis(), sh.ch, page.sub, page.frac, label, percent, System.currentTimeMillis()))
        }
        store.saveBookmarks(book.id, bookmarks.toList())
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    fun existingMark(p: Pick): Mark? = marks.firstOrNull { it.ch == p.ch && it.block == p.block && it.s < p.e && it.e > p.s }

    fun saveMarks() = store.saveMarks(book.id, marks.toList())

    fun applyColor(p: Pick, color: Int) {
        val ex = existingMark(p)
        if (ex != null) {
            val i = marks.indexOfFirst { it.id == ex.id }
            if (i >= 0) marks[i] = ex.copy(color = color)
        } else {
            marks.add(Mark(System.nanoTime(), p.ch, p.block, p.s, p.e, color, "", p.text, System.currentTimeMillis(), p.frac))
        }
        saveMarks()
    }

    fun removeMark(id: Long) {
        marks.removeAll { it.id == id }
        saveMarks()
    }

    fun saveNote(p: Pick, note: String) {
        val ex = existingMark(p)
        if (ex != null) {
            val i = marks.indexOfFirst { it.id == ex.id }
            if (i >= 0) marks[i] = ex.copy(note = note.trim())
        } else {
            marks.add(Mark(System.nanoTime(), p.ch, p.block, p.s, p.e, MARK_COLORS[0], note.trim(), p.text, System.currentTimeMillis(), p.frac))
        }
        saveMarks()
    }

    // ---- Búsqueda en el libro ----
    LaunchedEffect(searchQ) {
        val q = searchQ.trim()
        if (q.length < 2) {
            hits = emptyList()
            searching = false
            return@LaunchedEffect
        }
        delay(350)
        searching = true
        searchProg = 0f
        val r = withContext(Dispatchers.Default) {
            EpubSearch.run(s, q) { d, t -> searchProg = d.toFloat() / t.coerceAtLeast(1) }
        }
        hits = r
        searching = false
    }

    val shownMarks = marks.toList() +
        listOfNotNull(
            np?.takeIf { narr.state != NarrState.IDLE }?.let { Mark(-1, it.ch, it.block, it.s, it.e, NARR_COLOR, "", "", 0) },
            tempMark
        )

    Box(Modifier.fillMaxSize().background(theme.bg).onSizeChanged { size = it }) {
        val sh = shown
        if (sh == null) {
            ReaderLoading()
        } else {
            key(sh) {
                val prevPage by produceState<EpubPage?>(if (sh.ch > 0) pag.peek(sh.ch - 1, sh.cfg)?.lastOrNull() else null) {
                    if (value == null && sh.ch > 0) value = pag.get(sh.ch - 1, sh.cfg).lastOrNull()
                }
                val nextPage by produceState<EpubPage?>(if (sh.ch < chapters - 1) pag.peek(sh.ch + 1, sh.cfg)?.firstOrNull() else null) {
                    if (value == null && sh.ch < chapters - 1) value = pag.get(sh.ch + 1, sh.cfg).firstOrNull()
                }
                ChapterPager(
                    session = s,
                    shown = sh,
                    prev = prevPage,
                    next = nextPage,
                    initial = remember { pageIndexFor(sh.pages, anchor) },
                    theme = theme,
                    marks = shownMarks,
                    tapZones = st.tapZones,
                    cmd = cmd,
                    onCmdDone = { cmd = null },
                    onTap = {
                        tempMark = null
                        chrome = !chrome
                    },
                    onLongPress = { c, off, lay ->
                        val b = c.src
                        if (b != null) {
                            val bt = b.sp.toString().replace('\uFFFC', ' ')
                            val shift = if (b.bullet) 3 else 0
                            val boff = (c.start + off - shift).coerceIn(0, (bt.length - 1).coerceAtLeast(0))
                            val sent = Sentences.at(bt, boff)
                            if (sent != null) {
                                val full = lay.layoutInput.text.text
                                val word = runCatching {
                                    val r = lay.getWordBoundary(off.coerceIn(0, full.length))
                                    full.substring(r.start.coerceAtLeast(0), r.end.coerceAtMost(full.length))
                                        .trim { !it.isLetterOrDigit() }
                                }.getOrDefault("")
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                pick = Pick(sh.ch, c.block, sent.s, sent.e, bt.substring(sent.s, sent.e), word, (sent.s + shift).toFloat() / (bt.length + shift).coerceAtLeast(1))
                                sheet = 5
                            }
                        }
                    },
                    onPage = { i, count, page ->
                        val pk = sh.ch * 100_000L + i
                        if (lastPageKey != null && lastPageKey != pk) tick()
                        lastPageKey = pk
                        pageIdx = i
                        pageCount = count
                        curPage = page
                        anchor.sub = page.sub
                        anchor.frac = page.frac
                        anchor.atEnd = false
                        val pct = s.percentAt(sh.ch, (i + 1f) / count.coerceAtLeast(1))
                        percent = pct
                        reporter.update(sh.ch, page.sub, page.frac, pct)
                    },
                    onSwap = { dir -> goTo(sh.ch + dir, atEnd = dir < 0) }
                )
            }
        }

        if (isBookmarked) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(end = 22.dp)
                    .width(14.dp)
                    .height(28.dp)
                    .clip(RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                    .background(Color(0xFFE5484D))
            )
        }

        ReaderChrome(
            visible = chrome,
            title = book.title,
            subtitle = s.info.titleFor(cur),
            onBack = onBack,
            actions = {
                IconButton(onClick = { sheet = 3 }) { Icon(Icons.Default.Search, contentDescription = "Buscar en el libro") }
                IconButton(onClick = { toggleBookmark() }) {
                    Icon(
                        if (isBookmarked) RIcons.Bookmark else RIcons.BookmarkBorder,
                        contentDescription = "Marcador",
                        tint = if (isBookmarked) Color(0xFFFFC107) else Color.White
                    )
                }
                IconButton(onClick = { sheet = 1 }) { Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Contenido") }
                IconButton(onClick = { sheet = 2 }) { Icon(Icons.Default.Settings, contentDescription = "Ajustes de lectura") }
            },
            bottom = {
                if (narr.state == NarrState.IDLE) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = { listenFromPage() }, enabled = shown != null) {
                            Icon(RIcons.Headset, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Escuchar")
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { narr.prepare(); sheet = 4 }) { Text("Voz y narración") }
                    }
                } else {
                    NarrationControls(narr, onVoice = { sheet = 4 })
                }
                narr.error?.let {
                    Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFB4AB), modifier = Modifier.padding(vertical = 4.dp))
                }
                PageSlider(page = pageIdx, count = pageCount) { i -> shown?.let { cmd = PageCmd(it.ch, i, false) } }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { goTo(cur - 1) }, enabled = cur > 0) { Text("‹ Anterior") }
                    Text(
                        "${pctText(percent)} · Cap. ${cur + 1}/$chapters · Pág. ${pageIdx + 1}/$pageCount",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    TextButton(onClick = { goTo(cur + 1) }, enabled = cur < chapters - 1) { Text("Siguiente ›") }
                }
            }
        )

        // Con los controles ocultos, la narración deja una pastilla mínima para pausar o detener.
        if (!chrome && narr.state != NarrState.IDLE && sheet == 0) {
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp),
                shape = RoundedCornerShape(50),
                color = Color(0xCC000000)
            ) {
                Row(Modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { narr.prevSentence() }) { Icon(RIcons.SkipPrev, null, tint = Color.White) }
                    IconButton(onClick = { narr.toggle() }) {
                        Icon(if (narr.state == NarrState.PLAYING) RIcons.Pause else Icons.Default.PlayArrow, "Pausar o continuar", tint = Color.White)
                    }
                    IconButton(onClick = { narr.nextSentence() }) { Icon(RIcons.SkipNext, null, tint = Color.White) }
                    IconButton(onClick = { narr.stop() }) { Icon(RIcons.Stop, "Detener narración", tint = Color.White) }
                }
            }
        }

        if (sheet != 0) {
            ReaderSheets(
                kind = sheet,
                book = book,
                session = s,
                cur = cur,
                st = st,
                marks = marks,
                bookmarks = bookmarks,
                narr = narr,
                pick = pick,
                existing = pick?.let { existingMark(it) },
                searchQ = searchQ,
                onSearchQ = { searchQ = it },
                hits = hits,
                searching = searching,
                searchProg = searchProg,
                noteDraft = noteDraft,
                onNoteDraft = { noteDraft = it },
                onJumpChapter = { goTo(it) },
                onJumpAnchor = { ch, sub, frac -> goToAnchor(ch, sub, frac) },
                onHit = { h ->
                    tempMark = Mark(-2, h.ch, h.block, h.s, h.e, HIT_COLOR, "", "", 0)
                    goToAnchor(h.ch, h.block, h.frac)
                },
                onColor = { p, c -> applyColor(p, c); sheet = 0 },
                onRemoveMark = { removeMark(it) },
                onRemoveBookmark = { id ->
                    bookmarks.removeAll { it.id == id }
                    store.saveBookmarks(book.id, bookmarks.toList())
                },
                onEditNote = { p -> noteDraft = existingMark(p)?.note.orEmpty(); sheet = 6 },
                onSaveNote = { p, n -> saveNote(p, n); sheet = 0 },
                onListen = { p -> listenFrom(p.block, p.s) },
                onCopy = { clipboard.setText(AnnotatedString(it)); sheet = 0 },
                onShare = { text ->
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "«$text»\n— ${book.title}")
                    runCatching { ctx.startActivity(Intent.createChooser(i, "Compartir cita").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    sheet = 0
                },
                onDefine = { word ->
                    val es = s.info.language?.startsWith("es", ignoreCase = true) != false
                    val q = Uri.encode((if (es) "significado de " else "define ") + word)
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: ActivityNotFoundException) { }
                    sheet = 0
                },
                onVoiceSettings = {
                    val i = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { ctx.startActivity(i) } catch (e: Exception) {
                        runCatching { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }
                },
                onDismiss = { sheet = 0 }
            )
        }
    }
}

@Composable
private fun NarrationControls(narr: Narrator, onVoice: () -> Unit) {
    val playing = narr.state == NarrState.PLAYING
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        NarrBtn(RIcons.FastRewind, "Párrafo anterior") { narr.prevParagraph() }
        NarrBtn(RIcons.SkipPrev, "Frase anterior") { narr.prevSentence() }
        if (narr.state == NarrState.LOADING) {
            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp) }
        } else {
            FilledIconButton(onClick = { narr.toggle() }, modifier = Modifier.size(48.dp)) {
                Icon(if (playing) RIcons.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Pausar" else "Continuar")
            }
        }
        NarrBtn(RIcons.SkipNext, "Frase siguiente") { narr.nextSentence() }
        NarrBtn(RIcons.FastForward, "Párrafo siguiente") { narr.nextParagraph() }
        NarrBtn(RIcons.Headset, "Voz y narración") { onVoice() }
        NarrBtn(RIcons.Stop, "Detener") { narr.stop() }
    }
}

@Composable
private fun NarrBtn(icon: ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) { Icon(icon, contentDescription = desc) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReaderSheets(
    kind: Int,
    book: Book,
    session: EpubSession,
    cur: Int,
    st: ReadSettings,
    marks: List<Mark>,
    bookmarks: List<Bookmark>,
    narr: Narrator,
    pick: Pick?,
    existing: Mark?,
    searchQ: String,
    onSearchQ: (String) -> Unit,
    hits: List<SearchHit>,
    searching: Boolean,
    searchProg: Float,
    noteDraft: String,
    onNoteDraft: (String) -> Unit,
    onJumpChapter: (Int) -> Unit,
    onJumpAnchor: (Int, Int, Float) -> Unit,
    onHit: (SearchHit) -> Unit,
    onColor: (Pick, Int) -> Unit,
    onRemoveMark: (Long) -> Unit,
    onRemoveBookmark: (Long) -> Unit,
    onEditNote: (Pick) -> Unit,
    onSaveNote: (Pick, String) -> Unit,
    onListen: (Pick) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit,
    onDefine: (String) -> Unit,
    onVoiceSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        when (kind) {
            1 -> ContentsSheet(session, cur, marks, bookmarks, onJumpChapter, onJumpAnchor, onRemoveMark, onRemoveBookmark)
            2 -> SettingsSheet(st)
            3 -> SearchSheet(session, searchQ, onSearchQ, hits, searching, searchProg, onHit)
            4 -> VoiceSheet(narr, onVoiceSettings)
            5 -> if (pick != null) MarkSheet(pick, existing, onColor, onRemoveMark, onEditNote, onListen, onCopy, onShare, onDefine, onDismiss)
            6 -> if (pick != null) NoteSheet(pick, noteDraft, onNoteDraft, onSaveNote, onDismiss)
        }
    }
}

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 14.dp, bottom = 2.dp))
}

@Composable
private fun SliderRow(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ContentsSheet(
    session: EpubSession,
    cur: Int,
    marks: List<Mark>,
    bookmarks: List<Bookmark>,
    onJumpChapter: (Int) -> Unit,
    onJumpAnchor: (Int, Int, Float) -> Unit,
    onRemoveMark: (Long) -> Unit,
    onRemoveBookmark: (Long) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Capítulos") })
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Marcadores (${bookmarks.size})") })
            FilterChip(selected = tab == 2, onClick = { tab = 2 }, label = { Text("Notas (${marks.size})") })
        }
        Spacer(Modifier.height(6.dp))
        when (tab) {
            0 -> {
                val toc = session.info.toc
                LazyColumn(Modifier.heightIn(max = 520.dp)) {
                    items(toc.size) { i ->
                        val t = toc[i]
                        val active = t.spine == cur
                        Text(
                            t.title,
                            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onJumpChapter(t.spine) }
                                .padding(start = (20 + 16 * t.level.coerceIn(0, 4)).dp, end = 20.dp, top = 12.dp, bottom = 12.dp)
                        )
                    }
                }
            }
            1 -> {
                if (bookmarks.isEmpty()) {
                    Text("Aún no hay marcadores. Toca el icono de marcador de la barra superior para guardar la página en la que estás.",
                        style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(20.dp))
                } else {
                    LazyColumn(Modifier.heightIn(max = 520.dp)) {
                        items(bookmarks.sortedWith(compareBy({ it.ch }, { it.sub }, { it.frac }))) { b ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onJumpAnchor(b.ch, b.sub, b.frac) }.padding(start = 20.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("${session.info.titleFor(b.ch)} · ${pctText(b.percent)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (b.label.isNotBlank()) Text(b.label, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { onRemoveBookmark(b.id) }) { Icon(Icons.Default.Delete, contentDescription = "Quitar marcador") }
                            }
                        }
                    }
                }
            }
            else -> {
                if (marks.isEmpty()) {
                    Text("Aún no hay resaltados ni notas. Mantén pulsada una frase del libro para resaltarla o anotarla.",
                        style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(20.dp))
                } else {
                    LazyColumn(Modifier.heightIn(max = 520.dp)) {
                        items(marks.sortedWith(compareBy({ it.ch }, { it.block }, { it.s }))) { m ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onJumpAnchor(m.ch, m.block, m.frac) }.padding(start = 20.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.width(5.dp).height(44.dp).clip(RoundedCornerShape(3.dp)).background(opaque(m.color)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(session.info.titleFor(m.ch), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(m.text, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                    if (m.note.isNotBlank()) Text(m.note, style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { onRemoveMark(m.id) }) { Icon(Icons.Default.Delete, contentDescription = "Quitar") }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun opaque(c: Int): Color = Color((c and 0x00FFFFFF) or (0xFF shl 24))

@Composable
private fun SettingsSheet(st: ReadSettings) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)
    ) {
        SliderRow("Tamaño de letra", "${st.font.roundToInt()}", st.font, 12f..34f, { st.font = it }, { st.save() })

        Title("Tipografía")
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FAMILY_NAMES.forEachIndexed { i, label ->
                FilterChip(
                    selected = st.family == i,
                    onClick = { st.family = i; st.save() },
                    label = { Text(label, fontFamily = fontFamilyOf(i)) }
                )
            }
        }

        SliderRow("Interlineado", "%.2f".format(st.line), st.line, 1.2f..2.2f, { st.line = it }, { st.save() })
        SliderRow("Espacio entre párrafos", "${st.para.roundToInt()} dp", st.para, 0f..28f, { st.para = it }, { st.save() })

        Title("Alineación")
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !st.justify, onClick = { st.justify = false; st.save() }, label = { Text("Izquierda") })
            FilterChip(selected = st.justify, onClick = { st.justify = true; st.save() }, label = { Text("Justificado") })
        }

        Title("Márgenes")
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MARGIN_NAMES.forEachIndexed { i, label ->
                FilterChip(selected = st.margin == i, onClick = { st.margin = i; st.save() }, label = { Text(label) })
            }
        }

        Title("Tema")
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = st.theme == -1, onClick = { st.theme = -1; st.save() }, label = { Text("Auto") },
                leadingIcon = { Box(Modifier.size(14.dp).clip(CircleShape).background(scheme.background)) }
            )
            for (i in 0..1) {
                FilterChip(
                    selected = st.theme == i, onClick = { st.theme = i; st.save() }, label = { Text(THEME_NAMES[i]) },
                    leadingIcon = { Box(Modifier.size(14.dp).clip(CircleShape).background(EPUB_THEMES[i].bg)) }
                )
            }
        }
        Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 2..4) {
                FilterChip(
                    selected = st.theme == i, onClick = { st.theme = i; st.save() }, label = { Text(THEME_NAMES[i]) },
                    leadingIcon = { Box(Modifier.size(14.dp).clip(CircleShape).background(EPUB_THEMES[i].bg)) }
                )
            }
        }

        Title("Pantalla")
        SwitchRow("Usar el brillo del sistema", st.brightness < 0f) { on -> st.brightness = if (on) -1f else 0.6f; st.save() }
        if (st.brightness >= 0f) {
            SliderRow("Brillo", "${(st.brightness * 100).roundToInt()}%", st.brightness, 0.02f..1f, { st.brightness = it }, { st.save() })
        }
        SwitchRow("Mantener la pantalla encendida", st.keepOn) { st.keepOn = it; st.save() }
        SwitchRow("Bloquear la rotación", st.lockRot) { st.lockRot = it; st.save() }

        Title("Navegación")
        SwitchRow("Tocar los bordes para pasar de página", st.tapZones) { st.tapZones = it; st.save() }
        Text(
            "Con esto activo, tocar el borde izquierdo o derecho cambia de página; el centro muestra u oculta los controles.",
            style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant
        )

        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { st.reset() }) { Text("Restablecer valores") }
    }
}

@Composable
private fun SearchSheet(
    session: EpubSession,
    q: String,
    onQ: (String) -> Unit,
    hits: List<SearchHit>,
    searching: Boolean,
    prog: Float,
    onHit: (SearchHit) -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.padding(horizontal = 16.dp).navigationBarsPadding().imePadding()) {
        OutlinedTextField(
            value = q, onValueChange = onQ, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("Buscar en el libro") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        Spacer(Modifier.height(8.dp))
        if (searching) {
            LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
        } else if (q.trim().length >= 2) {
            Text(
                if (hits.isEmpty()) "Sin resultados" else if (hits.size >= 300) "300+ resultados (se muestran los primeros)" else "${hits.size} resultados",
                style = MaterialTheme.typography.labelMedium
            )
        } else {
            Text("Escribe al menos 2 letras. La búsqueda ignora mayúsculas y acentos.", style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            items(hits) { h ->
                Column(Modifier.fillMaxWidth().clickable { onHit(h) }.padding(vertical = 8.dp)) {
                    Text(session.info.titleFor(h.ch), style = MaterialTheme.typography.labelSmall, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        buildAnnotatedString {
                            append(h.before)
                            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = accent)) { append(h.match) }
                            append(h.after)
                        },
                        style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis
                    )
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun VoiceSheet(narr: Narrator, onVoiceSettings: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)
    ) {
        Text("Narración", style = MaterialTheme.typography.titleMedium)
        SliderRow("Velocidad", "%.2f×".format(narr.rate), narr.rate, 0.5f..2.0f, { narr.setRate(it, false) }, { narr.setRate(narr.rate, true) })
        SliderRow("Tono", "%.2f".format(narr.pitch), narr.pitch, 0.7f..1.3f, { narr.setPitch(it, false) }, { narr.setPitch(narr.pitch, true) })
        SliderRow("Pausa entre párrafos", "${narr.paraPause} ms", narr.paraPause.toFloat(), 0f..1500f, { narr.setParaPause(it.toInt(), false) }, { narr.setParaPause(narr.paraPause, true) })

        Title("Voz")
        Row(
            Modifier.fillMaxWidth().clickable { narr.setVoice("") }.padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = narr.voiceName.isBlank(), onClick = null)
            Spacer(Modifier.width(12.dp))
            Text("Automática (la mejor disponible sin conexión)", style = MaterialTheme.typography.bodyMedium)
        }
        if (narr.voices.isEmpty()) {
            Text("Cargando voces… Si no aparece ninguna, instala una en los ajustes de voz del sistema.", style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        for (v in narr.voices) {
            Row(
                Modifier.fillMaxWidth().clickable { narr.setVoice(v.name) }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = narr.voiceName == v.name, onClick = null)
                Spacer(Modifier.width(12.dp))
                Text(v.label, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { narr.preview() }) { Text("Probar voz") }
            OutlinedButton(onClick = onVoiceSettings) { Text("Más voces…") }
        }
        Text(
            "Para una narración más natural, descarga en «Más voces» las voces de alta calidad (red neuronal) del motor de texto a voz de tu teléfono.",
            style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )

        Title("Temporizador de sueño")
        val fmt = remember { java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT) }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = narr.sleepAt == 0L && !narr.sleepAtChapterEnd, onClick = { narr.clearSleep() }, label = { Text("Apagado") })
            FilterChip(selected = false, onClick = { narr.setSleepMinutes(15) }, label = { Text("15 min") })
            FilterChip(selected = false, onClick = { narr.setSleepMinutes(30) }, label = { Text("30 min") })
        }
        Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = false, onClick = { narr.setSleepMinutes(45) }, label = { Text("45 min") })
            FilterChip(selected = false, onClick = { narr.setSleepMinutes(60) }, label = { Text("60 min") })
            FilterChip(selected = narr.sleepAtChapterEnd, onClick = { narr.setSleepAtChapterEnd() }, label = { Text("Fin del capítulo") })
        }
        if (narr.sleepAt > 0L) {
            Text("Se detendrá a las ${fmt.format(java.util.Date(narr.sleepAt))}", style = MaterialTheme.typography.bodySmall, color = scheme.primary, modifier = Modifier.padding(top = 6.dp))
        }
        if (narr.state != NarrState.IDLE) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { narr.stop() }) { Text("Detener narración") }
        }
    }
}

@Composable
private fun MarkSheet(
    pick: Pick,
    existing: Mark?,
    onColor: (Pick, Int) -> Unit,
    onRemove: (Long) -> Unit,
    onEditNote: (Pick) -> Unit,
    onListen: (Pick) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit,
    onDefine: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 12.dp)) {
        Text("«${pick.text}»", style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, maxLines = 4, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            for (c in MARK_COLORS) {
                val sel = existing?.color == c
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(opaque(c))
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { onColor(pick, c) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        MenuRow(if (existing?.note.isNullOrBlank()) "Añadir nota" else "Editar nota") { onEditNote(pick) }
        MenuRow("Escuchar desde aquí") { onListen(pick) }
        MenuRow("Copiar") { onCopy(pick.text) }
        MenuRow("Compartir cita") { onShare(pick.text) }
        if (pick.word.length > 1) MenuRow("Buscar «${pick.word}»") { onDefine(pick.word) }
        if (existing != null) MenuRow("Quitar resaltado") { onRemove(existing.id); onDismiss() }
    }
}

@Composable
private fun MenuRow(label: String, onClick: () -> Unit) {
    Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

@Composable
private fun NoteSheet(pick: Pick, draft: String, onDraft: (String) -> Unit, onSave: (Pick, String) -> Unit, onCancel: () -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().imePadding().padding(bottom = 16.dp)) {
        Text("«${pick.text}»", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic, maxLines = 3, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = draft, onValueChange = onDraft, minLines = 3, modifier = Modifier.fillMaxWidth(), label = { Text("Tu nota") })
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onCancel) { Text("Cancelar") }
            Button(onClick = { onSave(pick, draft) }) { Text("Guardar") }
        }
    }
}

internal fun toAnnotated(sp: Spanned, base: Float): AnnotatedString = buildAnnotatedString {
    append(sp.toString().replace('\uFFFC', ' '))
    for (span in sp.getSpans(0, sp.length, Any::class.java)) {
        val s = sp.getSpanStart(span)
        val e = sp.getSpanEnd(span)
        if (s < 0 || e <= s) continue
        val style: SpanStyle? = when (span) {
            is StyleSpan -> when (span.style) {
                Typeface.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                Typeface.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                Typeface.BOLD_ITALIC -> SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                else -> null
            }
            is UnderlineSpan -> SpanStyle(textDecoration = TextDecoration.Underline)
            is StrikethroughSpan -> SpanStyle(textDecoration = TextDecoration.LineThrough)
            is RelativeSizeSpan -> SpanStyle(fontSize = (base * span.sizeChange).sp)
            is SuperscriptSpan -> SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = (base * 0.75f).sp)
            is SubscriptSpan -> SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = (base * 0.75f).sp)
            is TypefaceSpan -> if (span.family == "monospace") SpanStyle(fontFamily = FontFamily.Monospace) else null
            else -> null
        }
        if (style != null) addStyle(style, s, e)
    }
}

