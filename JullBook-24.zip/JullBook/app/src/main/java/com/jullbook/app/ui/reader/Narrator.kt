package com.jullbook.app.ui.reader

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Sentences
import com.jullbook.app.data.TextBlock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Frase que se está narrando: capítulo, bloque y rango dentro del texto del bloque. */
class NarrPos(val ch: Int, val block: Int, val s: Int, val e: Int)

enum class NarrState { IDLE, LOADING, PLAYING, PAUSED }

class VoiceOpt(val name: String, val label: String, val network: Boolean)

private class Seg(val block: Int, val s: Int, val e: Int, val say: String, val pauseMs: Int)

/**
 * Narrador del libro con las voces del sistema (motor de texto a voz de Android). Lee frase a frase con pausas
 * de párrafo, resalta la frase actual, pasa de capítulo solo, respeta el foco de audio y sigue sonando con la
 * pantalla apagada (servicio en primer plano).
 */
class Narrator(
    private val app: Context,
    private val session: EpubSession,
    private val prefs: Prefs,
    val bookTitle: String
) {
    var state by mutableStateOf(NarrState.IDLE)
        private set
    var pos by mutableStateOf<NarrPos?>(null)
        private set
    var voices by mutableStateOf<List<VoiceOpt>>(emptyList())
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var rate by mutableFloatStateOf(prefs.ttsRate)
        private set
    var pitch by mutableFloatStateOf(prefs.ttsPitch)
        private set
    var paraPause by mutableIntStateOf(prefs.ttsParaPause)
        private set
    var voiceName by mutableStateOf(prefs.ttsVoice)
        private set
    /** Hora (ms) a la que se detendrá la narración; 0 = sin temporizador. */
    var sleepAt by mutableLongStateOf(0L)
        private set
    var sleepAtChapterEnd by mutableStateOf(false)
        private set

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingStart: (() -> Unit)? = null

    private var segs: List<Seg> = emptyList()
    private var segCh = -1
    private var cursor = 0
    private var queued = -1
    private var gen = 0
    private var errors = 0
    private var next: Pair<Int, List<Seg>>? = null
    private var sleepJob: Job? = null
    private var loadJob: Job? = null

    private val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focus: AudioFocusRequest? = null
    private var wake: PowerManager.WakeLock? = null
    private var noisyOn = false

    private val speechAttrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (state == NarrState.PLAYING) pause()
        }
    }

    // ---------- Motor de voz ----------

    private fun bookLocale(): Locale {
        val tag = session.info.language?.replace('_', '-')?.trim().orEmpty()
        if (tag.isNotEmpty()) {
            var l = Locale.forLanguageTag(tag)
            if (l.language.length == 3) {
                val two = Locale.getISOLanguages().firstOrNull { runCatching { Locale(it).isO3Language == l.language }.getOrDefault(false) }
                if (two != null) l = Locale(two, l.country)
            }
            if (l.language.isNotEmpty()) return l
        }
        return Locale.getDefault()
    }

    private fun ensureTts(then: () -> Unit) {
        if (ttsReady) { then(); return }
        pendingStart = then
        if (tts != null) return
        error = null
        tts = TextToSpeech(app) { status ->
            main.post {
                if (status != TextToSpeech.SUCCESS) {
                    error = "Tu teléfono no tiene un motor de voz disponible. Instala o activa uno en Ajustes › Texto a voz."
                    state = NarrState.IDLE
                    tts?.shutdown()
                    tts = null
                    pendingStart = null
                    return@post
                }
                setup()
                ttsReady = true
                pendingStart?.invoke()
                pendingStart = null
            }
        }
    }

    private fun setup() {
        val t = tts ?: return
        t.setAudioAttributes(speechAttrs)
        val loc = bookLocale()
        var r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale.getDefault())
            error = "Falta la voz para «${loc.displayLanguage}». Instálala en Ajustes › Texto a voz; mientras tanto se usa el idioma del teléfono."
        }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { handle(id, started = true, failed = false) }
            override fun onDone(id: String?) { handle(id, started = false, failed = false) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { handle(id, started = false, failed = true) }
            override fun onError(id: String?, code: Int) { handle(id, started = false, failed = true) }
        })
        loadVoices(loc)
        applyVoice()
    }

    private fun loadVoices(loc: Locale) {
        val t = tts ?: return
        val all: List<Voice> = try { t.voices?.toList() ?: emptyList() } catch (e: Throwable) { emptyList() }
        val ok = all.filter {
            it.locale.language == loc.language && it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
        }.sortedWith(
            compareByDescending<Voice> { it.locale.country == loc.country }
                .thenByDescending { it.quality }
                .thenBy { it.isNetworkConnectionRequired }
                .thenBy { it.name }
        )
        voices = ok.mapIndexed { i, v ->
            val q = when {
                v.quality >= Voice.QUALITY_VERY_HIGH -> "calidad muy alta"
                v.quality >= Voice.QUALITY_HIGH -> "calidad alta"
                v.quality >= Voice.QUALITY_NORMAL -> "calidad normal"
                else -> "calidad básica"
            }
            val place = v.locale.displayCountry.ifBlank { v.locale.displayLanguage }
            VoiceOpt(v.name, "Voz ${i + 1} · $place · $q" + if (v.isNetworkConnectionRequired) " · en línea" else "", v.isNetworkConnectionRequired)
        }
    }

    /** Aplica la voz elegida; en automático escoge la de más calidad que funcione sin conexión. */
    private fun applyVoice() {
        val t = tts ?: return
        val all: List<Voice> = try { t.voices?.toList() ?: emptyList() } catch (e: Throwable) { emptyList() }
        val chosen = all.firstOrNull { it.name == voiceName }
            ?: run {
                val names = voices.map { it.name }
                val pool = all.filter { it.name in names }
                pool.filter { !it.isNetworkConnectionRequired }.maxByOrNull { it.quality } ?: pool.firstOrNull()
            }
        if (chosen != null) runCatching { t.voice = chosen }
    }

    // ---------- Texto del capítulo ----------

    private suspend fun buildSegs(ch: Int): List<Seg> = withContext(Dispatchers.Default) {
        val blocks = try {
            EpubText.parse(session.zip, session.info.spine[ch])
        } catch (e: CancellationException) {
            throw e
        } catch (ignored: Throwable) {
            emptyList()
        }
        val out = ArrayList<Seg>()
        for ((bi, b) in blocks.withIndex()) {
            if (b !is TextBlock) continue
            val text = b.sp.toString().replace('\uFFFC', ' ')
            val sents = Sentences.split(text)
            val local = ArrayList<Seg>()
            for (s in sents) {
                val say = Sentences.speakable(text.substring(s.s, s.e))
                if (say.isNotEmpty()) local.add(Seg(bi, s.s, s.e, say, 0))
            }
            if (local.isEmpty()) continue
            val pause = if (b.heading) (paraPause * 1.8f).toInt() else paraPause
            for ((k, sg) in local.withIndex()) {
                out.add(if (k == local.lastIndex) Seg(sg.block, sg.s, sg.e, sg.say, pause) else sg)
            }
        }
        if (out.isNotEmpty()) { val l = out.last(); out[out.lastIndex] = Seg(l.block, l.s, l.e, l.say, 0) }
        out
    }

    private fun firstSeg(block: Int, off: Int): Int {
        val i = segs.indexOfFirst { it.block > block || (it.block == block && it.e > off) }
        return if (i < 0) 0 else i
    }

    // ---------- Control ----------

    /** Empieza a narrar desde el bloque [block], carácter [off] (sin prefijo de viñeta) del capítulo [ch]. */
    fun start(ch: Int, block: Int, off: Int) {
        error = null
        state = NarrState.LOADING
        ensureTts {
            loadJob?.cancel()
            loadJob = scope.launch {
                var c = ch
                var list = buildSegs(c)
                var b = block
                var o = off
                while (list.isEmpty() && c < session.info.spine.size - 1) {
                    c++; b = 0; o = 0
                    list = buildSegs(c)
                }
                if (list.isEmpty()) {
                    error = "No hay texto que narrar en esta parte del libro."
                    state = NarrState.IDLE
                    return@launch
                }
                segs = list
                segCh = c
                next = null
                cursor = firstSeg(b, o)
                publishPos()
                begin(requestFocus = true)
            }
        }
    }

    private fun publishPos() {
        val sg = segs.getOrNull(cursor) ?: return
        pos = NarrPos(segCh, sg.block, sg.s, sg.e)
    }

    private fun begin(requestFocus: Boolean) {
        val t = tts ?: return
        if (requestFocus) {
            if (!grabFocus()) { state = NarrState.PAUSED; return }
            NarrationHub.narrator = this
            runCatching { ContextCompat.startForegroundService(app, Intent(app, NarrationService::class.java)) }
            registerNoisy()
            acquireWake()
        }
        gen++
        errors = 0
        t.stop()
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        queued = cursor - 1
        state = NarrState.PLAYING
        pump()
        NarrationService.refresh(app)
    }

    /** Mantiene en cola la frase actual y las dos siguientes. */
    private fun pump() {
        val t = tts ?: return
        while (queued < minOf(cursor + 2, segs.lastIndex)) {
            queued++
            val sg = segs[queued]
            val id = "$gen:$queued"
            val r = t.speak(sg.say, TextToSpeech.QUEUE_ADD, Bundle(), id)
            if (r != TextToSpeech.SUCCESS) { fail(); return }
            if (sg.pauseMs > 0) t.playSilentUtterance(sg.pauseMs.toLong(), TextToSpeech.QUEUE_ADD, "$gen:p$queued")
        }
        if (cursor >= segs.lastIndex - 3 && next == null && segCh < session.info.spine.size - 1) prefetchNext()
    }

    private fun prefetchNext() {
        val from = segCh + 1
        next = from to emptyList()
        scope.launch {
            var c = from
            var list = buildSegs(c)
            while (list.isEmpty() && c < session.info.spine.size - 1) { c++; list = buildSegs(c) }
            next = c to list
        }
    }

    private fun handle(id: String?, started: Boolean, failed: Boolean) {
        if (id == null) return
        val parts = id.split(':')
        if (parts.size != 2) return
        val g = parts[0].toIntOrNull() ?: return
        if (parts[1].startsWith("p")) return
        val idx = parts[1].toIntOrNull() ?: return
        main.post {
            if (g != gen || state != NarrState.PLAYING) return@post
            if (started) {
                errors = 0
                cursor = idx
                publishPos()
                pump()
            } else {
                if (failed && ++errors >= 3) { fail(); return@post }
                if (idx >= segs.lastIndex) chapterEnded()
            }
        }
    }

    private fun fail() {
        error = "La voz no responde. Prueba con otra voz o revisa los ajustes de texto a voz."
        pause()
    }

    private fun chapterEnded() {
        if (sleepAtChapterEnd) {
            sleepAtChapterEnd = false
            cursor = segs.lastIndex
            pause()
            return
        }
        scope.launch {
            var n = next
            if (n == null || n.second.isEmpty()) {
                var c = segCh + 1
                var list: List<Seg> = emptyList()
                while (c < session.info.spine.size) {
                    list = buildSegs(c)
                    if (list.isNotEmpty()) break
                    c++
                }
                n = if (list.isEmpty()) null else c to list
            }
            if (n == null || n.second.isEmpty()) {
                stop()
                return@launch
            }
            segCh = n.first
            segs = n.second
            next = null
            cursor = 0
            publishPos()
            begin(requestFocus = false)
        }
    }

    fun pause() {
        if (state != NarrState.PLAYING && state != NarrState.LOADING) return
        gen++
        tts?.stop()
        state = NarrState.PAUSED
        releaseWake()
        NarrationService.refresh(app)
    }

    fun resume() {
        if (state != NarrState.PAUSED || segs.isEmpty()) return
        error = null
        begin(requestFocus = true)
    }

    fun toggle() {
        when (state) {
            NarrState.PLAYING -> pause()
            NarrState.PAUSED -> resume()
            else -> {}
        }
    }

    fun stop() {
        gen++
        loadJob?.cancel()
        tts?.stop()
        state = NarrState.IDLE
        pos = null
        sleepJob?.cancel()
        sleepAt = 0L
        sleepAtChapterEnd = false
        releaseWake()
        dropFocus()
        unregisterNoisy()
        NarrationHub.narrator = null
        app.stopService(Intent(app, NarrationService::class.java))
    }

    fun release() {
        stop()
        scope.cancel()
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    private fun jump(to: Int) {
        if (segs.isEmpty()) return
        cursor = to.coerceIn(0, segs.lastIndex)
        publishPos()
        if (state == NarrState.PLAYING) begin(requestFocus = false)
    }

    fun nextSentence() {
        if (cursor >= segs.lastIndex) { if (state == NarrState.PLAYING) chapterEndedManual() } else jump(cursor + 1)
    }

    private fun chapterEndedManual() { gen++; tts?.stop(); chapterEnded() }

    fun prevSentence() = jump(cursor - 1)

    fun nextParagraph() {
        val b = segs.getOrNull(cursor)?.block ?: return
        val i = segs.indexOfFirst { it.block > b }
        if (i < 0) nextSentence() else jump(i)
    }

    fun prevParagraph() {
        val cur = segs.getOrNull(cursor) ?: return
        val startOfCur = segs.indexOfFirst { it.block == cur.block }
        // Si ya vamos avanzados en el párrafo, vuelve a su inicio; si no, al párrafo anterior.
        if (cursor > startOfCur) { jump(startOfCur); return }
        val prevBlock = segs.getOrNull(startOfCur - 1)?.block ?: run { jump(0); return }
        jump(segs.indexOfFirst { it.block == prevBlock })
    }

    // ---------- Ajustes ----------

    fun setRate(v: Float, apply: Boolean) {
        rate = v
        tts?.setSpeechRate(v)
        if (apply) { prefs.ttsRate = v; if (state == NarrState.PLAYING) begin(false) }
    }

    fun setPitch(v: Float, apply: Boolean) {
        pitch = v
        tts?.setPitch(v)
        if (apply) { prefs.ttsPitch = v; if (state == NarrState.PLAYING) begin(false) }
    }

    fun setParaPause(ms: Int, apply: Boolean) {
        paraPause = ms
        if (apply) prefs.ttsParaPause = ms // se aplica a partir del siguiente capítulo cargado
    }

    fun setVoice(name: String) {
        voiceName = name
        prefs.ttsVoice = name
        applyVoice()
        if (state == NarrState.PLAYING) begin(false)
    }

    /** Prepara las voces (sin empezar a narrar) para mostrarlas en los ajustes. */
    fun prepare() { if (!ttsReady) ensureTts { } }

    fun preview() {
        ensureTts {
            val t = tts ?: return@ensureTts
            if (state == NarrState.PLAYING) pause()
            t.setSpeechRate(rate)
            t.setPitch(pitch)
            val es = bookLocale().language == "es"
            t.speak(
                if (es) "Hola, soy tu narrador. Así sonará la lectura de tu libro." else "Hello, I'm your narrator. This is how your book will sound.",
                TextToSpeech.QUEUE_FLUSH, Bundle(), "preview"
            )
        }
    }

    fun setSleepMinutes(min: Int) {
        sleepJob?.cancel()
        sleepAtChapterEnd = false
        if (min <= 0) { sleepAt = 0L; return }
        sleepAt = System.currentTimeMillis() + min * 60_000L
        sleepJob = scope.launch {
            delay(min * 60_000L)
            sleepAt = 0L
            pause()
        }
    }

    fun setSleepAtChapterEnd() {
        sleepJob?.cancel()
        sleepAt = 0L
        sleepAtChapterEnd = true
    }

    fun clearSleep() = setSleepMinutes(0).also { sleepAtChapterEnd = false }

    // ---------- Audio ----------

    private fun grabFocus(): Boolean {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(speechAttrs)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    main.post { if (state == NarrState.PLAYING) pause() }
                }
            }
            .build()
        focus = req
        return am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun dropFocus() {
        focus?.let { am.abandonAudioFocusRequest(it) }
        focus = null
    }

    private fun registerNoisy() {
        if (noisyOn) return
        ContextCompat.registerReceiver(app, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), ContextCompat.RECEIVER_NOT_EXPORTED)
        noisyOn = true
    }

    private fun unregisterNoisy() {
        if (!noisyOn) return
        runCatching { app.unregisterReceiver(noisy) }
        noisyOn = false
    }

    private fun acquireWake() {
        if (wake?.isHeld == true) return
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JullBook:narration").also { it.acquire(6 * 3_600_000L) }
    }

    private fun releaseWake() {
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }
}

/** Referencia global al narrador activo (la usa el servicio para los botones de la notificación). */
object NarrationHub {
    @Volatile
    var narrator: Narrator? = null
}
