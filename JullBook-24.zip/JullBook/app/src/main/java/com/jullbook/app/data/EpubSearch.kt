package com.jullbook.app.data

import java.text.Normalizer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

/** Resultado de búsqueda dentro del libro. s/e: posición del texto encontrado dentro del bloque. */
class SearchHit(
    val ch: Int,
    val block: Int,
    val frac: Float,
    val s: Int,
    val e: Int,
    val before: String,
    val match: String,
    val after: String
)

/** Búsqueda de texto completo en todos los capítulos (sin distinguir mayúsculas ni acentos). */
object EpubSearch {
    private fun fold(c: Char): Char {
        if (c.code < 128) return c.lowercaseChar()
        val d = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
        return (if (d.isEmpty()) c else d[0]).lowercaseChar()
    }

    private fun fold(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(fold(c))
        return sb.toString()
    }

    suspend fun run(
        session: EpubSession,
        query: String,
        limit: Int = 300,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): List<SearchHit> {
        val q = fold(query.trim())
        if (q.length < 2) return emptyList()
        val out = ArrayList<SearchHit>()
        val total = session.info.spine.size
        for (ch in 0 until total) {
            coroutineContext.ensureActive()
            onProgress(ch, total)
            val blocks = try {
                EpubText.parse(session.zip, session.info.spine[ch])
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                continue
            }
            for ((bi, b) in blocks.withIndex()) {
                if (b !is TextBlock) continue
                val text = b.sp.toString().replace('\uFFFC', ' ')
                val f = fold(text)
                var from = 0
                while (out.size < limit) {
                    val at = f.indexOf(q, from)
                    if (at < 0) break
                    val end = at + q.length
                    val shift = if (b.bullet) 3 else 0
                    val b0 = (at - 36).coerceAtLeast(0)
                    val a1 = (end + 70).coerceAtMost(text.length)
                    out.add(
                        SearchHit(
                            ch, bi, (at + shift).toFloat() / (text.length + shift).coerceAtLeast(1), at, end,
                            (if (b0 > 0) "…" else "") + text.substring(b0, at).replace('\n', ' '),
                            text.substring(at, end),
                            text.substring(end, a1).replace('\n', ' ') + (if (a1 < text.length) "…" else "")
                        )
                    )
                    from = end
                }
                if (out.size >= limit) return out
            }
        }
        onProgress(total, total)
        return out
    }
}
