/*
 * Basado en el CloudflareInterceptor de Mihon (https://github.com/mihonapp/mihon, Apache License 2.0),
 * simplificado para JullBook (sin androidx.webkit, sin toasts/recursos de Mihon).
 */
package eu.kanade.tachiyomi.network.interceptor

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import eu.kanade.tachiyomi.network.AndroidCookieJar
import okhttp3.Headers
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

/**
 * Resuelve los retos «Checking your browser» de Cloudflare con un WebView oculto y deja la cookie cf_clearance en el
 * CookieManager compartido con OkHttp. El nombre y el paquete coinciden con los de Mihon porque algunas extensiones
 * comprueban que esté en el cliente por defecto.
 */
class CloudflareInterceptor(
    private val context: Context,
    private val cookieManager: AndroidCookieJar,
    private val defaultUserAgentProvider: () -> String,
) : Interceptor {

    private val mainHandler = Handler(Looper.getMainLooper())

    // Las peticiones a un mismo host comparten el candado mientras se resuelve el reto, así solo se abre un WebView.
    private val hostLocks = ConcurrentHashMap<String, ReentrantReadWriteLock>()

    private val listenerScript = """
        addEventListener("message", ({data}) => {
            if (data && data.source === "cloudflare-challenge") {
                mihon.postMessage(data.event);
            }
        })
    """.trimIndent()

    private fun shouldIntercept(response: Response): Boolean {
        // La cabecera cf-mitigated es la forma oficial de detectar un reto de Cloudflare.
        return response.header("cf-mitigated") == "challenge" && response.header("Server") in SERVER_CHECK
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val lock = hostLocks.computeIfAbsent(request.url.host) { ReentrantReadWriteLock() }

        val (response, clearance) = lock.read {
            val response = chain.proceed(request)
            if (!shouldIntercept(response)) return response
            response to clearance(request.url)
        }

        lock.write {
            // Otra petición pudo resolver el reto mientras esta esperaba.
            if (isCleared(request.url, clearance)) {
                response.close()
            } else {
                if (!prepareWebView()) return response
                solve(request, response, clearance)
            }
        }

        return chain.proceed(request)
    }

    private fun prepareWebView(): Boolean {
        try {
            CookieManager.getInstance()
        } catch (e: Throwable) {
            return false
        }
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_WEBVIEW)
    }

    private fun clearance(url: HttpUrl): String? =
        cookieManager.get(url).firstOrNull { it.name == "cf_clearance" }?.value

    private fun isCleared(url: HttpUrl, previousClearance: String?): Boolean {
        val clearance = clearance(url)
        return !clearance.isNullOrBlank() && clearance != previousClearance
    }

    private fun solve(request: Request, response: Response, clearance: String?) {
        try {
            response.close()
            cookieManager.remove(request.url, COOKIE_NAMES, 0)
            resolveWithWebView(request, clearance)
        } catch (e: CloudflareBypassException) {
            throw IOException(e.message ?: "No se pudo superar la protección de Cloudflare", e)
        } catch (e: Exception) {
            // OkHttp solo maneja IOException; se envuelve para no tumbar la app.
            throw IOException(e)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun resolveWithWebView(originalRequest: Request, originalClearance: String?) {
        // OkHttp no admite interceptores asíncronos: se bloquea este hilo hasta que el WebView termine.
        val latch = CountDownLatch(1)

        var webview: WebView? = null
        val challengeFound = AtomicBoolean(false)
        val cloudflareBypassed = AtomicBoolean(false)
        val challengeFailed = AtomicBoolean(false)
        val renderProcessGone = AtomicBoolean(false)

        val origRequestUrl = originalRequest.url.toString()
        // Un WebView solo carga con GET; la clearance vale para todo el sitio, así que con otros métodos se obtiene
        // en la página raíz.
        val challengeUrl = if (originalRequest.method == "GET") {
            origRequestUrl
        } else {
            originalRequest.url.newBuilder().encodedPath("/").query(null).fragment(null).build().toString()
        }
        val headers = parseHeaders(originalRequest.headers)

        mainHandler.post {
            try {
                val wv = createWebView(originalRequest)
                webview = wv

                wv.addJavascriptInterface(
                    object {
                        @Suppress("unused")
                        @JavascriptInterface
                        fun postMessage(event: String) {
                            when (event) {
                                // El reto no se puede resolver sin interacción: se aborta.
                                "interactiveBegin" -> latch.countDown()
                                "fail" -> {
                                    challengeFailed.set(true)
                                    latch.countDown()
                                }
                            }
                        }
                    },
                    "mihon",
                )

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        if (!challengeFailed.get() && isCleared(originalRequest.url, originalClearance)) {
                            cloudflareBypassed.set(true)
                            latch.countDown()
                        }

                        if (url == challengeUrl) {
                            if (!challengeFound.get()) {
                                // La primera petición no devolvió el reto: se aborta.
                                latch.countDown()
                            } else {
                                view.evaluateJavascript(listenerScript, null)
                            }
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        errorResponse: WebResourceResponse?,
                    ) {
                        if (request?.isForMainFrame == true) {
                            if (errorResponse?.responseHeaders?.get("cf-mitigated") == "challenge") {
                                challengeFound.set(true)
                            } else {
                                latch.countDown()
                            }
                        }
                    }

                    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                        // No manejarlo mataría la app; basta con fallar el bypass.
                        renderProcessGone.set(true)
                        latch.countDown()
                        return true
                    }
                }

                wv.loadUrl(challengeUrl, headers)
            } catch (e: Throwable) {
                latch.countDown()
            }
        }

        latch.await(30, TimeUnit.SECONDS)

        var webViewOutdated = false
        val cleanup = CountDownLatch(1)
        mainHandler.post {
            try {
                if (!cloudflareBypassed.get() && !renderProcessGone.get()) {
                    webViewOutdated = isWebViewOutdated()
                }
                webview?.run {
                    // Con el renderer caído solo se puede llamar a destroy.
                    if (!renderProcessGone.get()) {
                        removeJavascriptInterface("mihon")
                        stopLoading()
                    }
                    destroy()
                }
            } finally {
                cleanup.countDown()
            }
        }
        cleanup.await(5, TimeUnit.SECONDS)

        if (!cloudflareBypassed.get()) {
            // Una clearance de un reto fallido solo sería rechazada otra vez.
            cookieManager.remove(originalRequest.url, COOKIE_NAMES, 0)
            val extra = if (webViewOutdated) " Actualiza «Android System WebView» (versión demasiado antigua)." else ""
            throw CloudflareBypassException("No se pudo superar la protección de Cloudflare.$extra")
        }
    }

    private fun isWebViewOutdated(): Boolean {
        val major = WebView.getCurrentWebViewPackage()?.versionName?.substringBefore('.')?.toIntOrNull()
        return major != null && major < MINIMUM_WEBVIEW_VERSION
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(request: Request): WebView {
        return WebView(context).apply {
            with(settings) {
                javaScriptEnabled = true
                domStorageEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
                cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                setSupportMultipleWindows(true)
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                // Se evita enviar un User-Agent vacío; debe coincidir con el de OkHttp porque cf_clearance va ligada a él.
                userAgentString = request.header("User-Agent") ?: defaultUserAgentProvider()
            }
            CookieManager.getInstance().acceptThirdPartyCookies(this)
        }
    }

    private fun parseHeaders(headers: Headers): Map<String, String> {
        return headers
            // Las cabeceras inseguras hacen que el WebView lance net::ERR_INVALID_ARGUMENT.
            .filter { (name, value) -> isRequestHeaderSafe(name, value) }
            .groupBy(keySelector = { (name, _) -> name }) { (_, value) -> value }
            .mapValues { it.value.getOrNull(0).orEmpty() }
    }
}

// Basado en IsRequestHeaderSafe de Chromium (services/network/public/cpp/header_util.cc).
private fun isRequestHeaderSafe(_name: String, _value: String): Boolean {
    val name = _name.lowercase(Locale.ENGLISH)
    val value = _value.lowercase(Locale.ENGLISH)
    if (name in unsafeHeaderNames || name.startsWith("proxy-")) return false
    if (name == "connection" && value == "upgrade") return false
    return true
}

private val unsafeHeaderNames = listOf(
    "content-length", "host", "trailer", "te", "upgrade", "cookie2", "keep-alive", "transfer-encoding", "set-cookie",
)

private const val MINIMUM_WEBVIEW_VERSION = 118
private val SERVER_CHECK = arrayOf("cloudflare-nginx", "cloudflare")
private val COOKIE_NAMES = listOf("cf_clearance")

private class CloudflareBypassException(message: String) : Exception(message)
