/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4, 1.5 and 1.6 / TachiyomiX).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.network

import android.content.Context
import android.os.Build
import android.webkit.WebSettings
import eu.kanade.tachiyomi.network.interceptor.CloudflareInterceptor
import eu.kanade.tachiyomi.network.interceptor.UncaughtExceptionInterceptor
import eu.kanade.tachiyomi.network.interceptor.UserAgentInterceptor
import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * HTTP client that extensions obtain through Injekt. Like Mihon's, its default client includes the Uncaught,
 * UserAgent and Cloudflare interceptors (the latter solves "checking your browser" challenges with a hidden WebView).
 */
class NetworkHelper(private val context: Context) {

    val cookieJar = AndroidCookieJar()

    // Igual que en Mihon: Uncaught -> UserAgent -> Cloudflare (que resuelve los retos con un WebView).
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .cookieJar(cookieJar)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .callTimeout(2, TimeUnit.MINUTES)
            .cache(Cache(File(context.cacheDir, "network_cache"), 5L * 1024 * 1024))
            .addInterceptor(UncaughtExceptionInterceptor())
            .addInterceptor(UserAgentInterceptor(::defaultUserAgentProvider))
            .addInterceptor(CloudflareInterceptor(context, cookieJar, ::defaultUserAgentProvider))
            .build()
    }

    @Deprecated("The regular client handles Cloudflare by default")
    @Suppress("UNUSED")
    val cloudflareClient: OkHttpClient
        get() = client

    private val inferredUserAgent: String by lazy {
        // En algunos dispositivos (MIUI, Samsung con Android 12) obtener el UA del WebView así cuelga o falla.
        val skip = Build.MANUFACTURER.equals("xiaomi", true) || Build.MANUFACTURER.equals("samsung", true) &&
            Build.VERSION.SDK_INT == Build.VERSION_CODES.S
        if (skip) {
            DEFAULT_USER_AGENT
        } else {
            try {
                // UA parecido al de Chrome, con la versión real del WebView (cf_clearance va ligada al UA).
                WebSettings.getDefaultUserAgent(context)
                    .replace("; Android .*?\\)".toRegex(), "; Android 10; K)")
                    .replace("Version/.* Chrome/".toRegex(), "Chrome/")
            } catch (_: Throwable) {
                DEFAULT_USER_AGENT
            }
        }
    }

    fun defaultUserAgentProvider(): String = inferredUserAgent

    companion object {
        const val DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    }
}
