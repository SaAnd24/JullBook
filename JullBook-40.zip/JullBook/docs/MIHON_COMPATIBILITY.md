# Compatibilidad con extensiones de Mihon — documentación técnica

> **Estado honesto:** este código se escribió sin poder compilarlo ni ejecutarlo (el entorno de desarrollo no tenía red,
> Android SDK ni Gradle). **Ninguna extensión real se ha cargado todavía** y **la compatibilidad 1.6 tampoco se ha comprobado
> con ninguna extensión 1.6 real** (ver «Riesgos de la API 1.6»). Hasta que se haga la comprobación descrita en
> `docs/TESTS.md` (sección «Pendiente»), NO debe afirmarse que la compatibilidad funciona.

## Qué es una extensión de Mihon
Un APK Android normal con código (dex) que:
- declara `<uses-feature android:name="tachiyomi.extension"/>`,
- usa `versionName = "<libMayor>.<libMenor>.<n>"` (p. ej. `1.4.12` → API 1.4),
- declara en meta-data `tachiyomi.extension.class` sus clases de fuente (`.Foo;.Bar`, prefijo `.` = paquete),
  `tachiyomi.extension.nsfw` (1 = adulto) y opcionalmente una `SourceFactory`,
- se compila contra la API de extensiones (`compileOnly`) y **espera encontrar la API y sus librerías en la app anfitriona**.

Las extensiones de la **API 1.6 («TachiyomiX»)** añaden meta-data `tachiyomix.extensionLib` (= `1.6`), `tachiyomix.name` y
`tachiyomix.contentWarning` (0 seguro · 1 mixto · 2 adulto). `ExtensionLoader` los lee con `Bundle.get()` y no con `getString()`:
aapt guarda `1.6` como Float y `0` como Int, y `getString` devolvería `null` (el mismo fallo que Mihon corrigió en 0.20.x).
Si faltan, se usan `versionName` y `tachiyomi.extension.nsfw` como antes.

Por eso no basta con instalar el APK: la app anfitriona debe proporcionar, con los mismos nombres, `eu.kanade.tachiyomi.source.*`,
`eu.kanade.tachiyomi.network.*`, `eu.kanade.tachiyomi.util.*`, `uy.kohesive.injekt`, OkHttp, jsoup, RxJava 1, kotlinx.serialization y
androidx.preference. Jull Books lo hace así.

## Versiones soportadas
| Elemento | Soportado | Notas |
|---|---|---|
| API de extensiones | **1.4, 1.5 y 1.6** (`ExtensionLoader.LIB_MIN/LIB_MAX`) | 1.6 = «TachiyomiX» (`mihonapp/tachiyomix`, Mihon ≥ 0.20.0). |
| Índice de repositorio | `index.min.json` **e** `index.pb` | `index.pb` = protobuf con gzip (ver abajo). Si el JSON falla o viene vacío se prueba `index.pb` de la misma carpeta (Keiyoushi dejó `index.min.json` como recambio vacío). |
| `repo.json` | Opcional | Si publica `meta.signingKeyFingerprint` (SHA-256), el APK debe coincidir con ella. |

### Qué añade la API 1.6 y cómo se implementa aquí
Fuente: `CHANGELOG.md` de `mihonapp/tachiyomix`, sección 1.6.0 (28-jun-2026).

| Novedad 1.6 | Implementación |
|---|---|
| `Source.getPopularManga / getLatestUpdates / getSearchManga / getFilterList` (suben de `CatalogueSource` a `Source`) | `Source.kt`; las fuentes 1.4/1.5 siguen funcionando (se redirigen a sus `fetch*` RxJava o a sus sobreescrituras). |
| `Source.getMangaUpdate(manga, chapters, fetchDetails, fetchChapters): SMangaUpdate` | `Source.kt` + `SMangaUpdate.kt`. Por defecto usa `getMangaDetails`/`getChapterList`, así que una fuente antigua también responde a esta llamada. |
| `Source.getPageList` suspendida | Ya existía. |
| `HttpSource.getHomeUrl()`, `HttpSource.getImageUrl()` | `HttpSource.kt`. |
| `SManga.memo`, `SChapter.memo` (`JsonObject`) | `SManga.kt`, `SChapter.kt`; `copy()` y `copyFrom()` lo conservan. |
| `HttpException`, `Call.awaitSuccess` | Ya existían en `OkHttpExtensions.kt`. |
| Los `xxxRequest/xxxParse` de `HttpSource`, `ParsedHttpSource`, `rateLimit*`, `cloudflareClient`, `asObservable*` quedan *deprecated* | Se mantienen para 1.4/1.5. Los `xxxRequest/xxxParse` **ya no son abstractos**: una fuente 1.6 no los implementa. |
| Librerías mínimas: Kotlin 2.4.0, coroutines 1.11.0, serialization 1.11.0 (json, json-okio, protobuf), OkHttp 5.5.0 (+brotli, +zstd), jsoup 1.23.1, Injekt de Mihon | `app/build.gradle.kts`; Injekt viene de JitPack (`com.github.mihonapp:injekt:91edab2317`). |
| Interfaces con métodos por defecto JVM (Kotlin 2.2+) | `-jvm-default=enable`: la API del anfitrión genera métodos por defecto **y** `DefaultImpls`, así que sirven a extensiones nuevas y antiguas. |

La UI usa **una sola llamada** `getMangaUpdate` para las fuentes 1.6 (varias exigen pedir detalles y capítulos juntos);
para 1.4/1.5 se piden por separado y un fallo en los detalles no impide listar los capítulos.

### Índice `index.pb`
`ProtoIndex.kt` es un lector protobuf escrito a mano (sin dependencia) con este esquema, **tomado de implementaciones de
terceros y no de una especificación oficial**:

```
raíz       : campo 101 (repetido) = Extension
Extension  : 1 nombre · 2 paquete · 3 Archivos{1 apk, 2 icono} · 5 versionCode · 6 versionName · 8 (repetido) Source{1 id, 2 nombre, 3 idioma, 4 baseUrl}
```
Ignora campos desconocidos, limita tamaños (30 MB comprimido, 64 MB descomprimido) y solo acepta URLs HTTPS o rutas
relativas que no salgan de la carpeta del repositorio. Limitaciones: el índice no indica contenido adulto, así que las
extensiones disponibles no salen marcadas hasta instalarlas (entonces se lee `tachiyomix.contentWarning`; «mixto» y «adulto» se
ocultan por defecto).

El rango no está «hardcodeado para siempre»: es una constante en un único sitio y la interfaz muestra la API de cada extensión.

## Qué implementa Jull Books (package `eu.kanade.tachiyomi`)
`Source`, `CatalogueSource`, `SourceFactory`, `ConfigurableSource`, `UnmeteredSource`, `HttpSource`, `ParsedHttpSource`,
`SManga/SChapter` (+Impl), `Page`, `MangasPage`, `Filter*`, `UpdateStrategy`, `NetworkHelper`, `GET/POST`,
`asObservable/asObservableSuccess/await/awaitSuccess/newCachelessCallWithProgress/parseAs`, `ProgressListener`, `HttpException`,
`RateLimitInterceptor` (+`rateLimit`, `rateLimitHost`), `asJsoup`, `AppInfo`. Las API suspendidas (1.5) y las de RxJava (1.4)
se redirigen entre sí, de modo que una extensión que sobreescriba cualquiera de las dos funciona.

### Carga
`ExtensionLoader` busca paquetes instalados con la característica `tachiyomi.extension`, lee metadatos, comprueba el rango de API,
comprueba la firma y solo entonces crea un `ChildFirstPathClassLoader` (clases propias de la extensión primero, resto en la app) e
instancia las fuentes por reflexión. Cualquier `Throwable` (incluidos `NoSuchMethodError`/`AbstractMethodError` por partes de la
API no implementadas) se captura y se muestra como «No se pudo cargar» con el motivo.

### Operaciones
Búsqueda, populares, últimas, detalles, capítulos y páginas (`SourceHub`) se ejecutan en `Dispatchers.IO` con tiempo máximo y
captura de errores. La descarga resuelve `imageUrl` si falta y obtiene cada imagen con el `client` y las cabeceras de la propia
fuente.

## Riesgos de la API 1.6 (sin disimular)
- **Contrato reconstruido sin ver el código de `tachiyomix`:** el repositorio no se pudo explorar (solo se leyeron su README y su
  CHANGELOG). Las firmas exactas (p. ej. forma de `SMangaUpdate`, nulabilidad de `chapters`, tipo de `memo`) siguen el changelog
  y la guía de Keiyoushi; si alguna difiere, la extensión fallará con `NoSuchMethodError` / `AbstractMethodError` y la pantalla de
  extensiones mostrará el símbolo exacto que falta, que es lo que hay que corregir.
- **`KeiSource` vive en las propias extensiones** (paquete `keiyoushi.source`), no en el anfitrión. Se asume que extiende `HttpSource`
  y sobreescribe `client`, `headersBuilder()` y `getMangaUpdate`; por eso esos miembros siguen abiertos.
- **Actualizaciones de compilador y librerías sin compilar:** Kotlin 2.4.0, OkHttp 5.5.0 y las demás versiones se tomaron del README
  de `tachiyomix`. Pueden requerir ajustar AGP, Gradle (el flujo usa 8.9) o la versión de Compose. Injekt de Mihon se descarga de
  JitPack con un *commit* concreto; su API se asume igual que la de `uy.kohesive.injekt` que ya se usaba.
- **Cloudflare:** la API 1.6 espera que `NetworkHelper.client` resuelva los retos de Cloudflare por defecto; Jull Books sigue sin
  hacerlo (sin WebView), así que esas fuentes seguirán dando HTTP 403/503.
- **Campos posteriores a 1.6.0** (`SManga.genres`, `altTitles`, `contentRating`, `SChapter.number`… listados como *Unreleased* en
  el changelog) **no** se implementan: aún no forman parte de una versión publicada.

## Limitaciones conocidas (sin disimular)
- **Sin aislamiento:** el código de la extensión corre en el proceso de Jull Books con sus permisos. Una extensión maliciosa o
  defectuosa puede colgar la app; un fallo nativo la cerraría. Mitigaciones: firma aprobada por el usuario, verificación contra la
  huella del repositorio, nada de repositorios por defecto.
- **Cloudflare / retos de navegador:** `CloudflareInterceptor` (basado en el de Mihon) resuelve el reto automático con un WebView oculto y comparte las cookies (`cf_clearance`) con OkHttp mediante `AndroidCookieJar`. Los retos que piden interacción (captcha) no se pueden resolver y fallan con un error.
- **Cookies** solo en memoria; **sin pantalla de ajustes** de extensión (`ConfigurableSource` se carga pero no se muestra su pantalla).
- **Títulos alternativos:** la API 1.6.0 no los incluye (`SManga.altTitles` está solo en el código sin publicar); no se muestran.
- `Page.State` se implementó como enum; extensiones que usen otra forma podrían no cargar.
- Todo el contrato se reconstruyó de memoria/documentación secundaria: es la mayor fuente de riesgo de `AbstractMethodError`.

## Instalación de extensiones y Google Play
Se usa `PackageInstaller` con confirmación del sistema (`REQUEST_INSTALL_PACKAGES`), desinstalación con `REQUEST_DELETE_PACKAGES` y
`QUERY_ALL_PACKAGES` para localizar las extensiones instaladas. Cargar código descargado de terceros y esos permisos **entran
probablemente en conflicto con las políticas de Google Play** (código ejecutable fuera de Play, permisos restringidos). No se ha
verificado la política vigente: hay que comprobarla antes de publicar. Alternativas: distribuir por GitHub/F-Droid, o una variante
sin cargador de extensiones. No existe una solución universal que cumpla ambas cosas.

## Añadir fuentes
1. Biblioteca → «Mangas y manhwas» → «Fuentes y extensiones» (o menú ⋮ de la Biblioteca).
2. Pega la URL de un repositorio HTTPS (`…/index.pb` o `…/index.min.json`) y pulsa «Añadir». Jull Books no trae ninguno.
3. Instala una extensión disponible (Android pedirá confirmación; activa «instalar apps desconocidas» para Jull Books si lo pide).
4. En «Instaladas», pulsa «Revisar y confiar» tras comprobar la huella de firma.
5. «Explorar» → elige la fuente → busca → abre la obra → selecciona capítulos → «Descargar».

Usa únicamente fuentes que permitan legalmente el acceso y la descarga. Jull Books no elude DRM, autenticación ni muros de pago.

## Datos y migración
- Base de datos 6 → 7: solo se **añade** `book_category(uri, cat)`. Nada se modifica ni se borra.
- «Mover a categoría» solo escribe en esa tabla; la categoría manual manda sobre la automática (EPUB/PDF→Libros, CBZ/CBR→Cómics,
  capítulos descargados→Mangas y manhwas). No toca archivos, progreso, notas, marcadores, portadas ni agrupaciones.
- Descargas: `filesDir/jullbook_manga/<fuente>/<obra> [hash]/<0012 - nombre>.cbz`, páginas `0001.ext…` sin recomprimir. Se registran
  como cómics en la biblioteca, agrupadas en una colección con el nombre de la obra. El escaneo de carpetas SAF no borra estos archivos.
- Desinstalar una extensión no borra descargas ni progreso. Si la fuente desaparece, los capítulos guardados siguen legibles sin conexión.

## Libros EPUB/PDF
`com.jullbook.app.books.BookSource` es una interfaz **propia**, separada y vacía por defecto, para futuras fuentes de libros. No es una
extensión de Mihon. Las fuentes de libros gratuitos que ya traía la app (`discover/`) siguen intactas.
