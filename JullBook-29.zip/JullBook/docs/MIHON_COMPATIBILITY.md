# Compatibilidad con extensiones de Mihon — documentación técnica

> **Estado honesto:** este código se escribió sin poder compilarlo ni ejecutarlo (el entorno de desarrollo no tenía red,
> Android SDK ni Gradle). **Ninguna extensión real se ha cargado todavía.** Hasta que se haga la comprobación descrita en
> `docs/TESTS.md` (sección «Pendiente»), NO debe afirmarse que la compatibilidad funciona.

## Qué es una extensión de Mihon
Un APK Android normal con código (dex) que:
- declara `<uses-feature android:name="tachiyomi.extension"/>`,
- usa `versionName = "<libMayor>.<libMenor>.<n>"` (p. ej. `1.4.12` → API 1.4),
- declara en meta-data `tachiyomi.extension.class` sus clases de fuente (`.Foo;.Bar`, prefijo `.` = paquete),
  `tachiyomi.extension.nsfw` (1 = adulto) y opcionalmente una `SourceFactory`,
- se compila contra la API de extensiones (`compileOnly`) y **espera encontrar la API y sus librerías en la app anfitriona**.

Por eso no basta con instalar el APK: la app anfitriona debe proporcionar, con los mismos nombres, `eu.kanade.tachiyomi.source.*`,
`eu.kanade.tachiyomi.network.*`, `eu.kanade.tachiyomi.util.*`, `uy.kohesive.injekt`, OkHttp, jsoup, RxJava 1, kotlinx.serialization y
androidx.preference. Jull Books lo hace así.

## Versiones soportadas
| Elemento | Soportado | Notas |
|---|---|---|
| API de extensiones | **1.4 y 1.5** (`ExtensionLoader.LIB_MIN/LIB_MAX`) | Es el rango que implementan los cargadores de Tachiyomi/Mihon documentados públicamente. No se ha podido leer el código actual de Mihon (v0.20.1, 9-jul-2026) ni confirmar si ya admite más. |
| API 1.6 («TachiyomiX 1.6») | **No** | Existen forks que la soportan; no se pudo consultar su contrato (métodos nuevos). Una extensión 1.6 se muestra como «Incompatible» con el motivo exacto. |
| Índice de repositorio | `index.min.json` (array JSON) | Campos: `name, pkg, apk, lang, code, version, nsfw, sources[]`. APK = `<base>/apk/<apk>`, icono = `<base>/icon/<pkg>.png`. |
| `repo.json` | Opcional | Si publica `meta.signingKeyFingerprint` (SHA-256), el APK debe coincidir con ella. |
| Índice binario `index.pb` | **No** | Formato más reciente (visto en forks); no se pudo verificar su esquema. |

El rango no está «hardcodeado para siempre»: es una constante en un único sitio y la interfaz muestra la API de cada extensión.

## Qué implementa Jull Books (package `eu.kanade.tachiyomi`)
`Source`, `CatalogueSource`, `SourceFactory`, `ConfigurableSource`, `UnmeteredSource`, `HttpSource`, `ParsedHttpSource`,
`SManga/SChapter` (+Impl), `Page`, `MangasPage`, `Filter*`, `UpdateStrategy`, `NetworkHelper`, `GET/POST`,
`asObservable/asObservableSuccess/await/awaitSuccess/newCachelessCallWithProgress/parseAs`, `ProgressListener`, `HttpException`,
`RateLimitInterceptor` (+`rateLimit`, `rateLimitHost`), `asJsoup`, `AppInfo`. Las API suspendidas (1.5) y las de RxJava (1.4)
se redirigen entre sí, de modo que una extensión que sobreescriba cualquiera de las dos funciona.

### Carga
`ExtensionLoader` busca paquetes instalados con la característica `tachiyomi.extension`, lee metadatos, comprueba el rango de API,
comprueba la firma y solo entonces crea un `ChildFirstPathClassLoader` (clases propias de la extensión primero, resto en la app) e
instancia las fuentes por reflexión. Cualquier `Throwable` (incluidos `NoSuchMethodError`/`AbstractMethodError` por partes de la
API no implementadas) se captura y se muestra como «No se pudo cargar» con el motivo.

### Operaciones
Búsqueda, populares, últimas, detalles, capítulos y páginas (`SourceHub`) se ejecutan en `Dispatchers.IO` con tiempo máximo y
captura de errores. La descarga resuelve `imageUrl` si falta y obtiene cada imagen con el `client` y las cabeceras de la propia
fuente.

## Limitaciones conocidas (sin disimular)
- **Sin aislamiento:** el código de la extensión corre en el proceso de Jull Books con sus permisos. Una extensión maliciosa o
  defectuosa puede colgar la app; un fallo nativo la cerraría. Mitigaciones: firma aprobada por el usuario, verificación contra la
  huella del repositorio, nada de repositorios por defecto.
- **Cloudflare / retos de navegador:** no hay WebView ni `CloudflareInterceptor`. Las fuentes que lo exijan fallarán con HTTP 403/503.
- **Cookies** solo en memoria; **sin pantalla de ajustes** de extensión (`ConfigurableSource` se carga pero no se muestra su pantalla).
- **Títulos alternativos:** la API de Mihon no los incluye; no se muestran.
- `Page.State` se implementó como enum; extensiones que usen otra forma podrían no cargar.
- Todo el contrato se reconstruyó de memoria/documentación secundaria: es la mayor fuente de riesgo de `AbstractMethodError`.

## Instalación de extensiones y Google Play
Se usa `PackageInstaller` con confirmación del sistema (`REQUEST_INSTALL_PACKAGES`), desinstalación con `REQUEST_DELETE_PACKAGES` y
`QUERY_ALL_PACKAGES` para localizar las extensiones instaladas. Cargar código descargado de terceros y esos permisos **entran
probablemente en conflicto con las políticas de Google Play** (código ejecutable fuera de Play, permisos restringidos). No se ha
verificado la política vigente: hay que comprobarla antes de publicar. Alternativas: distribuir por GitHub/F-Droid, o una variante
sin cargador de extensiones. No existe una solución universal que cumpla ambas cosas.

## Añadir fuentes
1. Biblioteca → «Mangas y manhwas» → «Fuentes y extensiones» (o menú ⋮ de la Biblioteca).
2. Pega la URL de un repositorio HTTPS (`…/index.min.json`) y pulsa «Añadir». Jull Books no trae ninguno.
3. Instala una extensión disponible (Android pedirá confirmación; activa «instalar apps desconocidas» para Jull Books si lo pide).
4. En «Instaladas», pulsa «Revisar y confiar» tras comprobar la huella de firma.
5. «Explorar» → elige la fuente → busca → abre la obra → selecciona capítulos → «Descargar».

Usa únicamente fuentes que permitan legalmente el acceso y la descarga. Jull Books no elude DRM, autenticación ni muros de pago.

## Datos y migración
- Base de datos 6 → 7: solo se **añade** `book_category(uri, cat)`. Nada se modifica ni se borra.
- «Mover a categoría» solo escribe en esa tabla; la categoría manual manda sobre la automática (EPUB/PDF→Libros, CBZ/CBR→Cómics,
  capítulos descargados→Mangas y manhwas). No toca archivos, progreso, notas, marcadores, portadas ni agrupaciones.
- Descargas: `filesDir/jullbook_manga/<fuente>/<obra> [hash]/<0012 - nombre>.cbz`, páginas `0001.ext…` sin recomprimir. Se registran
  como cómics en la biblioteca, agrupadas en una colección con el nombre de la obra. El escaneo de carpetas SAF no borra estos archivos.
- Desinstalar una extensión no borra descargas ni progreso. Si la fuente desaparece, los capítulos guardados siguen legibles sin conexión.

## Libros EPUB/PDF
`com.jullbook.app.books.BookSource` es una interfaz **propia**, separada y vacía por defecto, para futuras fuentes de libros. No es una
extensión de Mihon. Las fuentes de libros gratuitos que ya traía la app (`discover/`) siguen intactas.
