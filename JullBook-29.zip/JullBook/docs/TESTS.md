# Pruebas: qué se hizo y qué NO

Leyenda: ✅ ejecutada con resultado real · 🟡 escrita pero no ejecutada · ❌ no ejecutada / no posible en el entorno de desarrollo.

Entorno de desarrollo: sin red de salida, sin Android SDK, sin Gradle ni compilador de Kotlin. Solo JRE 21.

| # | Prueba pedida | Estado | Detalle |
|---|---|---|---|
| — | Formato CBZ generado (orden 0001…0012, método 8, contenido idéntico, lectura estilo `SeekableZip` por directorio central) | ✅ | Programa Java ejecutado: «OK: 12 páginas…». Valida el formato, no el código Kotlin. |
| — | Equilibrio de llaves/paréntesis/strings en los 109 archivos Kotlin | ✅ | 0 problemas (comprobación sintáctica, **no** es compilación). |
| 1 | Tres categorías y mover obras | ❌ | Código escrito; no ejecutado en dispositivo. |
| 2 | Migración conserva datos | ❌ | Migración 6→7 solo añade una tabla (`CREATE TABLE IF NOT EXISTS`); no probada sobre una base real. |
| 3 | EPUB/PDF/CBR/CBZ siguen funcionando | ❌ | Lectores no modificados; no ejecutado. |
| 4 | Detección/carga de extensión auténtica | ❌ | Sin APK real ni red. |
| 5 | Búsqueda real y capítulos | ❌ | Sin red. |
| 6 | Descargar capítulo y verificar orden | 🟡 | Orden verificado en el formato (✅ arriba); descarga real no probada. |
| 7 | Abrir sin conexión | ❌ | Se usa el lector de cómics existente con `file://`; no probado. |
| 8 | Desinstalar no borra archivos ni progreso | ❌ | Por diseño (almacén y BD separados); no probado. |
| 9 | Errores de red, vacíos, incompatibles | 🟡 | Rutas de error implementadas (`friendly`, `INCOMPATIBLE`, respuesta vacía); sin ejecutar. |
| 10 | Compilación Gradle completa | ❌ | **No se pudo compilar.** El workflow `.github/workflows/build.yml` la ejecutará (con `testDebugUnitTest`). Es probable que haya errores de compilación que corregir. |
| — | Pruebas unitarias `SourcesLogicTest` | 🟡 | Escritas, no ejecutadas. |

## Pendiente (comprobación manual exacta)
1. Subir el proyecto a GitHub y ejecutar el workflow; corregir errores de compilación.
2. Añadir un repositorio `index.min.json` real (extensiones API 1.4/1.5), instalar UNA extensión, aprobar su firma.
3. Comprobar: carga (estado «Lista»), búsqueda, capítulos, descarga de un capítulo, apertura en modo avión, desinstalación.
4. Probar una extensión API 1.6 y confirmar que sale «Incompatible».
5. Actualizar sobre una instalación 1.3.0 con datos y confirmar que biblioteca, progreso y notas siguen intactos.
