package com.jullbook.app

import com.jullbook.app.sources.MangaDownloads
import com.jullbook.app.sources.RepoClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Pruebas unitarias de lógica pura (sin Android). Se ejecutan con ./gradlew testDebugUnitTest. */
class SourcesLogicTest {

    @Test
    fun repoUrlsNormalize() {
        assertEquals("https://x.org/r/index.min.json", RepoClient.normalize("https://x.org/r/"))
        assertEquals("https://x.org/r/index.min.json", RepoClient.normalize(" https://x.org/r/index.min.json "))
        try { RepoClient.normalize("http://x.org/index.min.json"); fail() } catch (e: RepoClient.BadRepo) {}
        try { RepoClient.normalize("https://x.org/other.json"); fail() } catch (e: RepoClient.BadRepo) {}
    }

    @Test
    fun imageTypesAreDetected() {
        assertEquals("jpg", MangaDownloads.extOf(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0)))
        assertEquals("png", MangaDownloads.extOf(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)))
        assertEquals("gif", MangaDownloads.extOf("GIF89a".toByteArray()))
        assertEquals("webp", MangaDownloads.extOf("RIFF1234WEBPVP8 ".toByteArray()))
        assertTrue(MangaDownloads.looksLikeHtml("  <!DOCTYPE html><html>".toByteArray()))
        assertFalse(MangaDownloads.looksLikeHtml(byteArrayOf(0xFF.toByte(), 0xD8.toByte())))
    }

    @Test
    fun namesAreSafe() {
        assertEquals("a_b_c", MangaDownloads.safe("a/b:c"))
        assertEquals("_", MangaDownloads.safe("..."))
    }
}
