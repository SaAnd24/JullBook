/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4 and 1.5).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.source.model

data class MangasPage(val mangas: List<SManga>, val hasNextPage: Boolean)
