/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4 and 1.5).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi.network.interceptor

import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import java.io.IOException
import java.util.ArrayDeque
import java.util.concurrent.TimeUnit

/** Sliding-window limiter: at most [permits] requests per [period]. Blocks the calling thread (OkHttp worker). */
class RateLimitInterceptor(
    private val host: String?,
    private val permits: Int,
    period: Long,
    unit: TimeUnit,
) : Interceptor {

    private val periodMs = unit.toMillis(period).coerceAtLeast(1)
    private val stamps = ArrayDeque<Long>()

    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request()
        if (host != null && req.url.host != host) return chain.proceed(req)
        acquire(chain)
        return chain.proceed(req)
    }

    private fun acquire(chain: Interceptor.Chain) {
        while (true) {
            if (chain.call().isCanceled()) throw IOException("Canceled")
            val wait: Long
            synchronized(stamps) {
                val now = System.currentTimeMillis()
                while (stamps.isNotEmpty() && now - stamps.peekFirst() >= periodMs) stamps.pollFirst()
                if (stamps.size < permits.coerceAtLeast(1)) {
                    stamps.addLast(now)
                    return
                }
                wait = periodMs - (now - stamps.peekFirst())
            }
            try {
                Thread.sleep(wait.coerceIn(1, 1000))
            } catch (e: InterruptedException) {
                throw IOException("Interrupted", e)
            }
        }
    }
}

fun OkHttpClient.Builder.rateLimit(permits: Int, period: Long = 1, unit: TimeUnit = TimeUnit.SECONDS): OkHttpClient.Builder =
    addInterceptor(RateLimitInterceptor(null, permits, period, unit))

fun OkHttpClient.Builder.rateLimitHost(
    httpUrl: HttpUrl,
    permits: Int,
    period: Long = 1,
    unit: TimeUnit = TimeUnit.SECONDS,
): OkHttpClient.Builder = addInterceptor(RateLimitInterceptor(httpUrl.host, permits, period, unit))

fun OkHttpClient.Builder.rateLimit(permits: Int, period: java.time.Duration): OkHttpClient.Builder =
    rateLimit(permits, period.toMillis(), TimeUnit.MILLISECONDS)
