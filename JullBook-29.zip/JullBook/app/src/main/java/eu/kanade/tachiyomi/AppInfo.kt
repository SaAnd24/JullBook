/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4 and 1.5).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
package eu.kanade.tachiyomi

import android.app.Application
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/** Used by extensions. Values come from the Jull Books package itself. */
@Suppress("UNUSED")
object AppInfo {
    fun getVersionCode(): Int {
        val app = Injekt.get<Application>()
        return runCatching {
            @Suppress("DEPRECATION")
            app.packageManager.getPackageInfo(app.packageName, 0).versionCode
        }.getOrDefault(1)
    }

    fun getVersionName(): String {
        val app = Injekt.get<Application>()
        return runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName }.getOrNull() ?: "2.0.0"
    }

    fun getSupportedImageMimeTypes(): List<String> = listOf(
        "image/jpeg", "image/png", "image/gif", "image/webp", "image/avif", "image/heif", "image/heic",
    )
}
