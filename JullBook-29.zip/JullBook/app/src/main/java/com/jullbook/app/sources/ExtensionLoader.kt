package com.jullbook.app.sources

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import dalvik.system.PathClassLoader
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.Source
import eu.kanade.tachiyomi.source.SourceFactory
import java.security.MessageDigest

/**
 * Descubre y carga extensiones de Mihon/Tachiyomi instaladas en el sistema.
 *
 * Contrato (el mismo que usa Mihon): el paquete declara <uses-feature android:name="tachiyomi.extension"/>,
 * el versionName tiene la forma "<libMayor>.<libMenor>.<n>" y el meta-data "tachiyomi.extension.class"
 * lista las clases de fuente (separadas por ';', con prefijo "." relativo al paquete).
 *
 * SEGURIDAD: el código de la extensión se ejecuta DENTRO del proceso de Jull Books con sus mismos permisos.
 * No hay aislamiento. Por eso una extensión no se carga hasta que el usuario aprueba su firma.
 */
object ExtensionLoader {
    const val FEATURE = "tachiyomi.extension"
    private const val META_CLASS = "tachiyomi.extension.class"
    private const val META_NSFW = "tachiyomi.extension.nsfw"

    /** Rango de la API de extensiones soportado: extensions-lib 1.4 y 1.5. */
    const val LIB_MIN = 1.4
    const val LIB_MAX = 1.5

    @Suppress("DEPRECATION")
    private val FLAGS: Int = PackageManager.GET_CONFIGURATIONS or PackageManager.GET_META_DATA or
        (if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES)

    @Suppress("DEPRECATION")
    fun installedPackages(pm: PackageManager): List<PackageInfo> {
        val all = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(FLAGS.toLong()))
        } else {
            pm.getInstalledPackages(FLAGS)
        }
        return all.filter { isExtension(it) }
    }

    fun isExtension(p: PackageInfo): Boolean = p.reqFeatures.orEmpty().any { it.name == FEATURE }

    @Suppress("DEPRECATION")
    fun signatureOf(p: PackageInfo): String? {
        val sigs = if (Build.VERSION.SDK_INT >= 28) p.signingInfo?.apkContentsSigners else p.signatures
        val first = sigs?.firstOrNull() ?: return null
        return MessageDigest.getInstance("SHA-256").digest(first.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun longVersionCode(p: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong()

    fun libVersionOf(versionName: String?): Double? = versionName?.substringBeforeLast('.', "")?.toDoubleOrNull()

    fun isSupported(lib: Double?): Boolean = lib != null && lib >= LIB_MIN && lib <= LIB_MAX

    fun loadAll(ctx: Context, trusted: Set<String>, disabled: Set<String>): List<InstalledExt> =
        installedPackages(ctx.packageManager).map { loadOne(ctx, it, trusted, disabled) }
            .sortedBy { it.name.lowercase() }

    fun loadOne(ctx: Context, pkg: PackageInfo, trusted: Set<String>, disabled: Set<String>): InstalledExt {
        val pm = ctx.packageManager
        val appInfo = pkg.applicationInfo
        val name = (appInfo?.let { pm.getApplicationLabel(it).toString() } ?: pkg.packageName)
            .removePrefix("Tachiyomi: ").removePrefix("Mihon: ")
        val versionName = pkg.versionName ?: ""
        val code = longVersionCode(pkg)
        val lib = libVersionOf(versionName)
        val sig = signatureOf(pkg)
        val enabled = pkg.packageName !in disabled
        val nsfw = appInfo?.metaData?.getInt(META_NSFW, 0) == 1

        fun fail(state: ExtState, msg: String) =
            InstalledExt(pkg.packageName, name, versionName, code, lib, nsfw, sig, state, msg, enabled, emptyList())

        if (appInfo == null) return fail(ExtState.ERROR, "El sistema no devolvió información de la aplicación.")
        if (!isSupported(lib)) {
            return fail(
                ExtState.INCOMPATIBLE,
                "Usa la API de extensiones " + (lib?.toString() ?: "desconocida") +
                    ". Jull Books solo implementa las versiones $LIB_MIN a $LIB_MAX."
            )
        }
        if (sig == null) return fail(ExtState.ERROR, "No se pudo leer la firma del paquete.")
        if (sig !in trusted) {
            return fail(ExtState.UNTRUSTED, "Firma sin aprobar: el código no se ha ejecutado.")
        }
        if (!enabled) return fail(ExtState.READY, "Desactivada.")

        return try {
            val loader = ChildFirstPathClassLoader(appInfo.sourceDir, appInfo.nativeLibraryDir, ctx.classLoader)
            val classes = (appInfo.metaData?.getString(META_CLASS) ?: "")
                .split(";").map { it.trim() }.filter { it.isNotEmpty() }
                .map { if (it.startsWith(".")) pkg.packageName + it else it }
            if (classes.isEmpty()) return fail(ExtState.ERROR, "La extensión no declara ninguna clase de fuente.")

            val sources = ArrayList<Source>()
            for (cn in classes) {
                when (val obj = Class.forName(cn, false, loader).getDeclaredConstructor().newInstance()) {
                    is Source -> sources.add(obj)
                    is SourceFactory -> sources.addAll(obj.createSources())
                    else -> throw IllegalStateException("Tipo de fuente desconocido: " + obj.javaClass.name)
                }
            }
            val loaded = sources.map {
                LoadedSource(it.id, it.name, it.lang, it as? CatalogueSource, pkg.packageName, name)
            }
            InstalledExt(pkg.packageName, name, versionName, code, lib, nsfw, sig, ExtState.READY, null, true, loaded)
        } catch (e: Throwable) {
            fail(ExtState.ERROR, describe(e))
        }
    }

    /** Mensaje útil cuando una extensión usa algo de la API que Jull Books no implementa. */
    fun describe(e: Throwable): String = when (e) {
        is NoSuchMethodError, is AbstractMethodError, is NoClassDefFoundError, is NoSuchFieldError, is ClassNotFoundException ->
            "La extensión usa una parte de la API de Mihon que Jull Books no implementa: ${e.javaClass.simpleName}: ${e.message}"
        else -> e.javaClass.simpleName + (e.message?.let { ": $it" } ?: "")
    }
}

/** Carga primero las clases de la propia extensión y delega el resto (API de Mihon, OkHttp, Kotlin…) en la app. */
class ChildFirstPathClassLoader(
    dexPath: String,
    librarySearchPath: String?,
    parent: ClassLoader
) : PathClassLoader(dexPath, librarySearchPath, parent) {

    private val systemLoader: ClassLoader? = ClassLoader.getSystemClassLoader()

    override fun loadClass(name: String?, resolve: Boolean): Class<*> {
        var c = findLoadedClass(name)
        if (c == null && systemLoader != null) {
            c = try {
                systemLoader.loadClass(name)
            } catch (_: ClassNotFoundException) {
                null
            }
        }
        if (c == null) {
            c = try {
                findClass(name)
            } catch (_: ClassNotFoundException) {
                super.loadClass(name, resolve)
            }
        }
        if (resolve) resolveClass(c)
        return c!!
    }
}
