package com.jullbook.app.sources

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Cliente de repositorios de extensiones. Formato soportado: `index.min.json` (array JSON) tal y como lo
 * publican los repositorios de extensiones de Mihon/Tachiyomi, más `repo.json` opcional con la huella de la clave.
 * NO se soporta aún el índice binario `index.pb` (extensiones 1.6): ver docs/MIHON_COMPATIBILITY.md.
 */
object RepoClient {
    private const val MAX_INDEX_BYTES = 30L * 1024 * 1024

    class BadRepo(msg: String) : IOException(msg)

    /** Acepta la URL del índice o de la carpeta del repositorio. Solo HTTPS. */
    fun normalize(input: String): String {
        var u = input.trim()
        if (u.isEmpty()) throw BadRepo("Escribe la URL del repositorio.")
        if (!u.startsWith("https://")) throw BadRepo("Solo se admiten repositorios HTTPS (la URL debe empezar por https://).")
        if (u.endsWith("/")) u += "index.min.json"
        if (!u.endsWith(".json")) u = u.trimEnd('/') + "/index.min.json"
        if (!u.endsWith("index.min.json")) throw BadRepo("Jull Books lee índices «index.min.json». Esta URL apunta a otro tipo de archivo.")
        return u
    }

    fun baseOf(indexUrl: String): String = indexUrl.substringBeforeLast('/')

    private fun get(client: OkHttpClient, url: String): String {
        val req = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw BadRepo("El repositorio respondió con el error HTTP ${r.code}.")
            val len = r.body.contentLength()
            if (len > MAX_INDEX_BYTES) throw BadRepo("El índice es demasiado grande.")
            return r.body.string()
        }
    }

    fun fetchIndex(client: OkHttpClient, indexUrl: String): List<AvailableExt> {
        val text = get(client, indexUrl)
        val arr = try {
            JSONArray(text)
        } catch (e: Exception) {
            throw BadRepo("La respuesta no es un índice de extensiones válido (se esperaba un array JSON).")
        }
        val base = baseOf(indexUrl)
        val out = ArrayList<AvailableExt>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val pkg = o.optString("pkg")
            val apk = o.optString("apk")
            if (pkg.isBlank() || apk.isBlank()) continue
            // El nombre del APK no puede salir de la carpeta del repositorio.
            if (apk.contains("/") || apk.contains("\\") || apk.contains("..")) continue
            val srcArr = o.optJSONArray("sources") ?: JSONArray()
            val sources = ArrayList<AvailableSource>()
            for (j in 0 until srcArr.length()) {
                val s = srcArr.optJSONObject(j) ?: continue
                sources.add(AvailableSource(s.optString("name"), s.optString("lang"), s.optString("baseUrl").ifBlank { null }))
            }
            out.add(
                AvailableExt(
                    name = o.optString("name").removePrefix("Tachiyomi: ").removePrefix("Mihon: "),
                    pkg = pkg,
                    apkUrl = "$base/apk/$apk",
                    iconUrl = "$base/icon/$pkg.png",
                    versionName = o.optString("version"),
                    versionCode = o.optLong("code"),
                    lang = o.optString("lang"),
                    nsfw = o.optInt("nsfw", 0) == 1,
                    sources = sources,
                    repoUrl = indexUrl
                )
            )
        }
        return out
    }

    /** Metadatos opcionales del repositorio (repo.json): nombre y huella SHA-256 de la clave de firma. */
    fun fetchMeta(client: OkHttpClient, indexUrl: String): Pair<String?, String?> = try {
        val meta = JSONObject(get(client, baseOf(indexUrl) + "/repo.json")).optJSONObject("meta")
        val name = meta?.optString("name")?.ifBlank { null } ?: meta?.optString("shortName")?.ifBlank { null }
        val fp = meta?.optString("signingKeyFingerprint")?.ifBlank { null }
        name to fp?.lowercase()?.replace(":", "")?.replace(" ", "")
    } catch (e: Exception) {
        null to null
    }
}
