package com.jullbook.app.ui

import android.graphics.Bitmap
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.SourcesPage
import com.jullbook.app.data.Images
import com.jullbook.app.sources.AvailableExt
import com.jullbook.app.sources.DlItem
import com.jullbook.app.sources.DlState
import com.jullbook.app.sources.ExtState
import com.jullbook.app.sources.ExtensionLoader
import com.jullbook.app.sources.InstalledExt
import com.jullbook.app.sources.LoadedSource
import com.jullbook.app.sources.Res
import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.NetworkHelper
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Headers
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

private val PAGES = listOf(SourcesPage.EXTENSIONS to "Extensiones", SourcesPage.BROWSE to "Explorar", SourcesPage.DOWNLOADS to "Descargas")

@Composable
fun SourcesScreen(vm: AppViewModel, onBack: () -> Unit) {
    val page = vm.sourcesPage ?: SourcesPage.EXTENSIONS
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás") }
            Text("Fuentes y extensiones", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        }
        ScrollableTabRow(
            selectedTabIndex = PAGES.indexOfFirst { it.first == page }.coerceAtLeast(0),
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            edgePadding = 8.dp
        ) {
            for ((p, label) in PAGES) Tab(selected = page == p, onClick = { vm.sourcesPage = p }, text = { Text(label) })
        }
        when (page) {
            SourcesPage.EXTENSIONS -> ExtensionsTab(vm)
            SourcesPage.BROWSE -> BrowseTab(vm)
            SourcesPage.DOWNLOADS -> DownloadsTab(vm)
        }
    }
}

// ------------------------------------------------------------------------------------------------ Extensiones

@Composable
private fun ExtensionsTab(vm: AppViewModel) {
    val hub = vm.hub
    val installed by hub.installed.collectAsState()
    val available by hub.available.collectAsState()
    val repos by hub.repos.collectAsState()
    val loading by hub.loading.collectAsState()
    val message by hub.message.collectAsState()
    val working by hub.working.collectAsState()
    val nsfw by hub.showNsfw.collectAsState()
    var url by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var trustFor by remember { mutableStateOf<InstalledExt?>(null) }
    var installFor by remember { mutableStateOf<AvailableExt?>(null) }
    var uninstallFor by remember { mutableStateOf<InstalledExt?>(null) }

    val avail = remember(available, query, nsfw) {
        available.filter { (nsfw || !it.nsfw) }.filter {
            query.isBlank() || it.name.contains(query, true) || it.sources.any { s -> s.name.contains(query, true) }
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Seguridad", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Las extensiones son código de terceros que se ejecuta DENTRO de Jull Books, con sus mismos permisos y sin aislamiento. " +
                            "Instala solo extensiones de repositorios en los que confíes y que permitan legalmente el acceso al contenido. " +
                            "Jull Books no incluye ningún repositorio ni extensión: tú decides cuáles usar.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "API de extensiones soportada: ${ExtensionLoader.LIB_MIN} a ${ExtensionLoader.LIB_MAX}. Índices: index.min.json.",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        message?.let { m ->
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(m, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { hub.message.value = null }) { Text("Cerrar") }
                    }
                }
            }
        }
        item { Text("Repositorios", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true,
                label = { Text("URL del repositorio (https://…/index.min.json)") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(onClick = { hub.addRepo(url); url = "" }, enabled = url.isNotBlank()) { Text("Añadir") }
                OutlinedButton(onClick = { hub.refreshRepos() }, enabled = repos.isNotEmpty() && !loading) { Text("Buscar actualizaciones") }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        if (repos.isEmpty()) item { Text("Aún no has añadido ningún repositorio.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(repos, key = { it.url }) { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        r.url + if (r.fingerprint != null) "\nHuella de firma publicada ✓" else "\nSin huella de firma publicada",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { hub.removeRepo(r.url) }) { Text("Quitar") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mostrar contenido adulto", Modifier.weight(1f))
                Switch(checked = nsfw, onCheckedChange = { hub.setShowNsfw(it) })
            }
        }

        item { HorizontalDivider() }
        item { Text("Instaladas (${installed.size})", style = MaterialTheme.typography.titleMedium) }
        if (installed.isEmpty()) item { Text("No hay extensiones de Mihon instaladas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(installed, key = { it.pkg }) { e ->
            val upd = hub.updateAvailable(e)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(e.name + if (e.nsfw) " · +18" else "", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "v${e.versionName} · API ${e.libVersion ?: "?"} · ${e.pkg}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val status = when {
                        e.state == ExtState.READY && !e.enabled -> "Desactivada"
                        e.state == ExtState.READY -> "Lista · ${e.sources.size} fuente(s)"
                        e.state == ExtState.UNTRUSTED -> "Firma sin aprobar (no se ejecuta)"
                        e.state == ExtState.INCOMPATIBLE -> "Incompatible"
                        else -> "No se pudo cargar"
                    }
                    Text(status, style = MaterialTheme.typography.bodySmall, color = if (e.state == ExtState.READY) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    if (e.message != null && e.state != ExtState.READY) Text(e.message, style = MaterialTheme.typography.bodySmall)
                    if (upd != null) Text("Actualización disponible: v${upd.versionName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                    if (e.state == ExtState.READY && e.enabled && e.sources.isNotEmpty()) {
                        Text(e.sources.joinToString { it.label }, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (e.state == ExtState.UNTRUSTED) TextButton(onClick = { trustFor = e }) { Text("Revisar y confiar") }
                        if (e.state == ExtState.READY) TextButton(onClick = { hub.setEnabled(e.pkg, !e.enabled) }) { Text(if (e.enabled) "Desactivar" else "Activar") }
                        if (upd != null) TextButton(onClick = { installFor = upd }, enabled = upd.pkg !in working) { Text("Actualizar") }
                        TextButton(onClick = { uninstallFor = e }) { Text("Desinstalar") }
                    }
                }
            }
        }

        item { HorizontalDivider() }
        item { Text("Disponibles (${avail.size})", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Buscar por nombre o fuente") }, modifier = Modifier.fillMaxWidth()
            )
        }
        items(avail, key = { it.pkg + "|" + it.repoUrl }) { a ->
            val inst = installed.firstOrNull { it.pkg == a.pkg }
            val supported = ExtensionLoader.isSupported(a.libVersion)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(a.name + if (a.nsfw) " · +18" else "", style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "v${a.versionName} · ${a.lang} · API ${a.libVersion ?: "?"}" + if (!supported) " · incompatible" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (supported) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                    )
                    if (a.sources.isNotEmpty()) Text(a.sources.joinToString { it.name }, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                when {
                    a.pkg in working -> Text("Instalando…", style = MaterialTheme.typography.labelMedium)
                    !supported -> {}
                    inst == null -> TextButton(onClick = { installFor = a }) { Text("Instalar") }
                    inst.versionCode < a.versionCode -> TextButton(onClick = { installFor = a }) { Text("Actualizar") }
                    else -> Text("Instalada", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }

    trustFor?.let { e ->
        val verified = hub.verifiedByRepo(e)
        AlertDialog(
            onDismissRequest = { trustFor = null },
            title = { Text("¿Confiar en ${e.name}?") },
            text = {
                Text(
                    "Al confiar, el código de esta extensión se ejecutará dentro de Jull Books, con sus permisos (red, almacenamiento propio), " +
                        "sin aislamiento. Se aprueba la firma, así que también valdrán otras extensiones firmadas con la misma clave.\n\n" +
                        "Huella SHA-256 de la firma:\n${e.signature}\n\n" +
                        if (verified) "✓ Coincide con la huella publicada por el repositorio." else "No coincide con ninguna huella publicada por tus repositorios: comprueba tú la procedencia."
                )
            },
            confirmButton = { TextButton(onClick = { hub.trust(e); trustFor = null }) { Text("Confiar y activar") } },
            dismissButton = { TextButton(onClick = { trustFor = null }) { Text("Cancelar") } }
        )
    }
    installFor?.let { a ->
        val fp = hub.repoFingerprintFor(a)
        AlertDialog(
            onDismissRequest = { installFor = null },
            title = { Text("Instalar ${a.name}") },
            text = {
                Text(
                    "Se descargará el APK de:\n${a.apkUrl}\n\nSe comprobarán paquete, versión, API y firma. " +
                        (if (fp != null) "El repositorio publica una huella de firma: el APK debe coincidir con ella." else "Este repositorio no publica huella de firma: no se puede comprobar su procedencia automáticamente.") +
                        "\n\nAndroid te pedirá confirmar la instalación. Las extensiones son código de terceros sin aislamiento; instálala solo si confías en el repositorio."
                )
            },
            confirmButton = { TextButton(onClick = { hub.install(a); installFor = null }) { Text("Descargar e instalar") } },
            dismissButton = { TextButton(onClick = { installFor = null }) { Text("Cancelar") } }
        )
    }
    uninstallFor?.let { e ->
        AlertDialog(
            onDismissRequest = { uninstallFor = null },
            title = { Text("Desinstalar ${e.name}") },
            text = { Text("Los capítulos ya descargados y tu progreso NO se borran: seguirán disponibles en la biblioteca sin conexión. Solo dejarás de poder buscar y descargar de esa fuente.") },
            confirmButton = { TextButton(onClick = { hub.uninstall(e.pkg); uninstallFor = null }) { Text("Desinstalar") } },
            dismissButton = { TextButton(onClick = { uninstallFor = null }) { Text("Cancelar") } }
        )
    }
}

// ------------------------------------------------------------------------------------------------ Explorar

private object ImgCache {
    val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
}

@Composable
private fun UrlImage(url: String?, src: LoadedSource?, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, url) {
        value = null
        if (url.isNullOrBlank()) return@produceState
        ImgCache.cache.get(url)?.let { value = it; return@produceState }
        value = withContext(Dispatchers.IO) {
            runCatching {
                val http = src?.source as? HttpSource
                val client = http?.client ?: Injekt.get<NetworkHelper>().client
                val req = GET(url, http?.headers ?: Headers.Builder().build())
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use null
                    val b = r.body.bytes()
                    Images.decodeSampled(b, 300, Bitmap.Config.ARGB_8888)
                }
            }.getOrNull()?.also { ImgCache.cache.put(url, it) }
        }
    }
    Box(modifier.aspectRatio(0.7f)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun BrowseTab(vm: AppViewModel) {
    val hub = vm.hub
    val installed by hub.installed.collectAsState()
    val nsfw by hub.showNsfw.collectAsState()
    var src by remember { mutableStateOf<LoadedSource?>(null) }
    var manga by remember { mutableStateOf<SManga?>(null) }
    val sources = remember(installed, nsfw) { hub.sources() }

    BackHandler(enabled = src != null) { if (manga != null) manga = null else src = null }

    val s = src
    val m = manga
    when {
        s != null && m != null -> MangaDetail(vm, s, m)
        s != null -> SourceBrowse(vm, s, onOpen = { manga = it })
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sources.isEmpty()) item {
                Text(
                    "No hay fuentes disponibles. Añade un repositorio en «Extensiones», instala una extensión y aprueba su firma.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(sources, key = { it.pkg + it.id }) { x ->
                Card(Modifier.fillMaxWidth().clickable { src = x }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(x.label, style = MaterialTheme.typography.titleSmall)
                        Text(x.extName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceBrowse(vm: AppViewModel, s: LoadedSource, onOpen: (SManga) -> Unit) {
    val hub = vm.hub
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(0) } // 0 populares, 1 últimas, 2 búsqueda
    var page by remember { mutableStateOf(1) }
    var results by remember { mutableStateOf(listOf<SManga>()) }
    var hasNext by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(s, mode, reload) {
        loading = true; error = null; page = 1; results = emptyList()
        val r = when (mode) {
            1 -> hub.latest(s, 1)
            2 -> hub.search(s, 1, query)
            else -> hub.popular(s, 1)
        }
        when (r) {
            is Res.Ok -> {
                results = r.value.mangas; hasNext = r.value.hasNextPage
                if (results.isEmpty()) error = "La fuente no devolvió resultados."
            }
            is Res.Err -> error = r.message
        }
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        Text(s.label, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true, label = { Text("Buscar títulos") },
            trailingIcon = { TextButton(onClick = { if (query.isNotBlank()) { mode = 2; reload++ } }) { Text("Buscar") } },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0; reload++ }, label = { Text("Populares") })
            if (s.source?.supportsLatest == true) FilterChip(selected = mode == 1, onClick = { mode = 1; reload++ }, label = { Text("Últimas") })
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp), modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(results, key = { it.url }) { x ->
                Column(Modifier.clickable { onOpen(x) }) {
                    UrlImage(x.thumbnail_url, s, Modifier.fillMaxWidth())
                    Text(runCatching { x.title }.getOrDefault("?"), style = MaterialTheme.typography.labelMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            if (hasNext && !loading) item(span = { GridItemSpan(maxLineSpan) }) {
                OutlinedButton(onClick = {
                    scope.launch {
                        loading = true
                        val next = page + 1
                        val r = when (mode) {
                            1 -> hub.latest(s, next)
                            2 -> hub.search(s, next, query)
                            else -> hub.popular(s, next)
                        }
                        when (r) {
                            is Res.Ok -> {
                                val seen = results.map { it.url }.toSet()
                                results = results + r.value.mangas.filter { it.url !in seen }
                                hasNext = r.value.hasNextPage; page = next
                            }
                            is Res.Err -> error = r.message
                        }
                        loading = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Cargar más") }
            }
        }
    }
}

private fun statusLabel(s: Int) = when (s) {
    SManga.ONGOING -> "En publicación"
    SManga.COMPLETED -> "Completado"
    SManga.LICENSED -> "Licenciado"
    SManga.PUBLISHING_FINISHED -> "Publicación terminada"
    SManga.CANCELLED -> "Cancelado"
    SManga.ON_HIATUS -> "En pausa"
    else -> "Desconocido"
}

@Composable
private fun MangaDetail(vm: AppViewModel, s: LoadedSource, base: SManga) {
    val hub = vm.hub
    var manga by remember { mutableStateOf(base) }
    var chapters by remember { mutableStateOf<List<SChapter>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    val dl by hub.downloads.items.collectAsState()
    var saved by remember { mutableStateOf(hub.downloads.downloaded(s.id, base.url)) }
    var note by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(base.url, dl) { saved = hub.downloads.downloaded(s.id, base.url) }
    LaunchedEffect(base.url) {
        loading = true
        when (val d = hub.details(s, base)) {
            is Res.Ok -> manga = d.value
            is Res.Err -> error = d.message
        }
        when (val c = hub.chapters(s, manga)) {
            is Res.Ok -> chapters = c.value
            is Res.Err -> error = c.message
        }
        loading = false
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                UrlImage(manga.thumbnail_url, s, Modifier.height(170.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(manga.title, style = MaterialTheme.typography.titleMedium)
                    manga.author?.let { Text("Autor: $it", style = MaterialTheme.typography.bodySmall) }
                    manga.artist?.takeIf { it != manga.author }?.let { Text("Ilustrador: $it", style = MaterialTheme.typography.bodySmall) }
                    Text("Estado: ${statusLabel(manga.status)}", style = MaterialTheme.typography.bodySmall)
                    Text("Fuente: ${s.label}", style = MaterialTheme.typography.bodySmall)
                    manga.getGenres()?.let { Text(it.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
        manga.description?.let { d -> item { Text(d, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)) } }
        item {
            Text(
                "Los títulos alternativos no forman parte de la API de extensiones de Mihon, así que no se muestran.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) } }
        if (chapters.isNotEmpty()) {
            item {
                Text("Capítulos (${chapters.size}) · descargados: ${chapters.count { it.url in saved }}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        val n = hub.downloads.enqueue(s, manga, chapters.filter { it.url in sel })
                        note = if (n > 0) "$n capítulo(s) en la cola." else "Nada nuevo que descargar."
                        sel = emptySet()
                    }, enabled = sel.isNotEmpty()) { Text("Descargar (${sel.size})") }
                    OutlinedButton(onClick = {
                        val n = hub.downloads.enqueue(s, manga, chapters)
                        note = if (n > 0) "$n capítulo(s) en la cola." else "Todo está descargado o en la cola."
                    }) { Text("Descargar todos") }
                }
                Row {
                    TextButton(onClick = { sel = chapters.filter { it.url !in saved }.map { it.url }.toSet() }) { Text("Seleccionar pendientes") }
                    TextButton(onClick = { sel = emptySet() }) { Text("Ninguno") }
                }
                note?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
            }
            items(chapters, key = { it.url }) { c ->
                val st = dl.firstOrNull { it.id == hub.downloads.id(s.id, base.url, c.url) }
                Row(Modifier.fillMaxWidth().clickable { sel = if (c.url in sel) sel - c.url else sel + c.url }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = c.url in sel, onCheckedChange = { sel = if (it) sel + c.url else sel - c.url })
                    Column(Modifier.weight(1f)) {
                        Text(c.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        c.scanlator?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    Text(
                        when {
                            c.url in saved -> "Guardado"
                            st?.state == DlState.RUNNING -> "${st?.done}/${st?.total}"
                            st?.state == DlState.QUEUED -> "En cola"
                            st?.state == DlState.ERROR -> "Error"
                            else -> ""
                        },
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ------------------------------------------------------------------------------------------------ Descargas

@Composable
private fun DownloadsTab(vm: AppViewModel) {
    val hub = vm.hub
    val items by hub.downloads.items.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { hub.downloads.retryAllFailed() }) { Text("Reintentar fallidas") }
                TextButton(onClick = { hub.downloads.cancelAll() }) { Text("Cancelar todo") }
                TextButton(onClick = { hub.downloads.clearFinished() }) { Text("Limpiar") }
            }
            Text(
                "Los capítulos se guardan como CBZ en el almacenamiento privado de Jull Books y aparecen en «Mangas y manhwas». " +
                    "Un capítulo interrumpido se reinicia desde cero al reintentar. La cola no se conserva al cerrar la app; lo ya guardado sí.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (items.isEmpty()) item { Text("No hay descargas.", style = MaterialTheme.typography.bodyMedium) }
        items(items, key = { it.id }) { d -> DownloadRow(d, vm) }
    }
}

@Composable
private fun DownloadRow(d: DlItem, vm: AppViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(d.mangaTitle, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.chapterName + " · " + d.sourceName, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            when (d.state) {
                DlState.RUNNING -> {
                    if (d.total > 0) LinearProgressIndicator(progress = { d.done.toFloat() / d.total }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Página ${d.done} de ${d.total}", style = MaterialTheme.typography.labelSmall)
                }
                DlState.QUEUED -> Text("En cola", style = MaterialTheme.typography.labelSmall)
                DlState.DONE -> Text("Completado · ${d.total} páginas", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                DlState.ERROR -> Text(d.error ?: "Error", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                DlState.CANCELED -> Text("Cancelado", style = MaterialTheme.typography.labelSmall)
            }
            Row {
                if (d.state == DlState.RUNNING || d.state == DlState.QUEUED) TextButton(onClick = { vm.hub.downloads.cancel(d.id) }) { Text("Cancelar") }
                if (d.state == DlState.ERROR || d.state == DlState.CANCELED) TextButton(onClick = { vm.hub.downloads.retry(d.id) }) { Text("Reintentar") }
            }
        }
    }
}
