# junrar usa slf4j de forma opcional
-dontwarn org.slf4j.**

# --- Extensiones de Mihon: se cargan por reflexión y usan estas librerías y la API de la app ---
-keep class eu.kanade.tachiyomi.** { *; }
-keep class uy.kohesive.injekt.** { *; }
-keep class rx.** { *; }
-keep class okhttp3.** { *; }
-keep class okio.** { *; }
-keep class org.jsoup.** { *; }
-keep class kotlin.** { *; }
-keep class kotlinx.serialization.** { *; }
-keep class androidx.preference.** { *; }
-dontwarn okhttp3.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
