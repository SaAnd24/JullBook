# Jull Books 2.0

Lector de libros, cómics y mangas para Android (Kotlin + Jetpack Compose). Versión 2.0.0 (versionCode 11).

## Novedades de 2.0 (sin compilar ni probar: ver `docs/TESTS.md`)
- Biblioteca con tres categorías: **Libros**, **Cómics**, **Mangas y manhwas**, con «Mover a categoría» (manual > automática, persistente, sin tocar archivos ni progreso).
- **Fuentes y extensiones** compatibles con extensiones de Mihon/Tachiyomi (API 1.4–1.5): repositorios, instalación verificada, firma aprobada por el usuario, exploración, búsqueda, ficha de obra y descarga de capítulos a CBZ legibles sin conexión.
- Cola de descargas con progreso, cancelación y reintentos.
- Interfaz modular propia para futuras fuentes de libros (`books/BookSource`).

## Compilar
Requisitos: JDK 17, Android SDK 35, Gradle 8.9.
```
./gradlew testDebugUnitTest assembleDebug
```
APK en `app/build/outputs/apk/debug/`. En GitHub: el workflow `.github/workflows/build.yml` compila y sube el APK como artefacto.
Injekt (`uy.kohesive.injekt:injekt-core:1.16.1`) se resuelve desde Maven Central; no hace falta JitPack.

## Documentación
- `docs/MIHON_COMPATIBILITY.md` — compatibilidad, versiones, formatos, limitaciones, seguridad, Google Play, cómo añadir fuentes.
- `docs/TESTS.md` — qué se probó de verdad y qué falta.
- `THIRD_PARTY_LICENSES.md`, `docs/LICENSE-Apache-2.0.txt` — licencias y atribuciones.

Jull Books no incluye repositorios ni extensiones de terceros. Usa solo fuentes que permitan legalmente el acceso y la descarga.
