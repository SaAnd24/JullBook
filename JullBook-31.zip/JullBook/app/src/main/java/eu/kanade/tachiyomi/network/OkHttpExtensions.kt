/*
 * Compatibility layer for Mihon / Tachiyomi extensions (extensions-lib 1.4 and 1.5).
 * Independent Kotlin reimplementation of the public extension API surface, written for Jull Books,
 * following the contracts of Mihon (https://github.com/mihonapp/mihon, Apache License 2.0,
 * Copyright 2015 Javier Tomás, Copyright 2024 Mihon Open Source Project).
 * See THIRD_PARTY_LICENSES.md and docs/MIHON_COMPATIBILITY.md in the project root.
 */
@file:JvmName("OkHttpExtensionsKt")

package eu.kanade.tachiyomi.network

import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromStream
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import rx.Observable
import rx.Subscription
import kotlinx.serialization.serializer
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class HttpException(val code: Int) : IllegalStateException("HTTP error " + code)

fun Call.asObservable(): Observable<Response> {
    return Observable.unsafeCreate { subscriber ->
        val call = clone()
        // Una vez recibida la respuesta, darse de baja NO debe cancelar la llamada: el cuerpo (la imagen) se lee
        // después de que el observable complete, y cancelar aquí reinicia el flujo HTTP/2 («stream was reset: CANCEL»).
        val finished = java.util.concurrent.atomic.AtomicBoolean(false)
        val subscription: Subscription = object : Subscription {
            override fun isUnsubscribed(): Boolean = call.isCanceled()
            override fun unsubscribe() {
                if (!finished.get()) call.cancel()
            }
        }
        subscriber.add(subscription)
        try {
            val response = call.execute()
            finished.set(true)
            if (!subscriber.isUnsubscribed) {
                subscriber.onNext(response)
                subscriber.onCompleted()
            } else {
                response.close()
            }
        } catch (e: Throwable) {
            if (!subscriber.isUnsubscribed) subscriber.onError(e)
        }
    }
}

fun Call.asObservableSuccess(): Observable<Response> {
    return asObservable().doOnNext { response ->
        if (!response.isSuccessful) {
            response.close()
            throw HttpException(response.code)
        }
    }
}

suspend fun Call.await(): Response {
    return suspendCancellableCoroutine { continuation ->
        val callback = object : Callback {
            override fun onResponse(call: Call, response: Response) {
                continuation.resume(response)
            }

            override fun onFailure(call: Call, e: IOException) {
                if (!continuation.isCancelled) continuation.resumeWithException(e)
            }
        }
        enqueue(callback)
        continuation.invokeOnCancellation {
            try {
                cancel()
            } catch (ex: Throwable) {
                // Ignore cancel exception
            }
        }
    }
}

suspend fun Call.awaitSuccess(): Response {
    val response = await()
    if (!response.isSuccessful) {
        response.close()
        throw HttpException(response.code)
    }
    return response
}

fun OkHttpClient.newCachelessCallWithProgress(request: Request, listener: ProgressListener): Call {
    val progressClient = newBuilder()
        .cache(null)
        .addNetworkInterceptor { chain ->
            val originalResponse = chain.proceed(chain.request())
            originalResponse.newBuilder()
                .body(ProgressResponseBody(originalResponse.body, listener))
                .build()
        }
        .build()

    return progressClient.newCall(request)
}

inline fun <reified T> Response.parseAs(): T {
    return Injekt.get<Json>().decodeFromJsonResponse(serializer(), this)
}

@OptIn(ExperimentalSerializationApi::class)
fun <T> Json.decodeFromJsonResponse(
    deserializer: kotlinx.serialization.DeserializationStrategy<T>,
    response: Response,
): T {
    return response.body.byteStream().use {
        decodeFromStream(deserializer, it)
    }
}
