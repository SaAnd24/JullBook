plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        // Las extensiones 1.6 se compilan con Kotlin 2.2+, que genera métodos por defecto JVM en las interfaces; las
        // 1.4/1.5 usan el esquema antiguo (DefaultImpls). «enable» genera ambos en la API del anfitrión (Source,
        // CatalogueSource…), así que unas y otras encuentran el método que buscan. (Es el valor por defecto de
        // Kotlin 2.2+; se fija aquí para que no cambie por accidente.)
        freeCompilerArgs.add("-jvm-default=enable")
    }
}

android {
    namespace = "com.jullbook.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jullbook.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "2.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
    packaging { resources { excludes += listOf("/META-INF/{AL2.0,LGPL2.1}", "/META-INF/DEPENDENCIES", "/META-INF/INDEX.LIST", "/META-INF/*.kotlin_module.bak") } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("com.github.junrar:junrar:7.5.5")
    // Traducción en el teléfono (Google ML Kit): los modelos de idioma se descargan una vez y luego funciona sin conexión.
    implementation("com.google.mlkit:translate:17.0.3")

    // --- Sistema de extensiones compatibles con Mihon (API de extensiones 1.4 / 1.5 / 1.6) ---
    // Las extensiones se compilan contra estas librerías y las esperan en la app anfitriona.
    // Versiones mínimas que exige la API 1.6 (README de mihonapp/tachiyomix): Kotlin 2.4.0, coroutines 1.11.0,
    // serialization 1.11.0 (json, json-okio, protobuf), OkHttp 5.5.0 (+brotli, +zstd), jsoup 1.23.1, Injekt de Mihon.
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.4.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.11.0")
    implementation("com.squareup.okhttp3:okhttp:5.5.0")
    implementation("com.squareup.okhttp3:okhttp-brotli:5.5.0")
    implementation("com.squareup.okhttp3:okhttp-zstd:5.5.0")
    implementation("com.squareup.okhttp3:logging-interceptor:5.5.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:5.5.0")
    implementation("org.jsoup:jsoup:1.23.1")
    implementation("io.reactivex:rxjava:1.3.8")
    implementation("com.github.mihonapp:injekt:91edab2317")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json-okio:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-protobuf:1.11.0")
    implementation("androidx.preference:preference-ktx:1.2.1")

    testImplementation("junit:junit:4.13.2")
}
