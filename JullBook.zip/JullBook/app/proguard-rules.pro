# junrar usa slf4j de forma opcional
-dontwarn org.slf4j.**
