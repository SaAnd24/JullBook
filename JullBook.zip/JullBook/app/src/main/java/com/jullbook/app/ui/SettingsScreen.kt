package com.jullbook.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Eggs

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        content()
    }
}

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
private fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ThemeTile(name: String, bg: Color, accent: Color, fg: Color, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .width(92.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .background(bg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp)).background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.45f)))))
        Box(Modifier.width(52.dp).height(5.dp).clip(CircleShape).background(fg.copy(alpha = 0.85f)))
        Box(Modifier.width(34.dp).height(5.dp).clip(CircleShape).background(fg.copy(alpha = 0.45f)))
        Text(name, style = MaterialTheme.typography.labelSmall, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    var name by remember(vm.userName) { mutableStateOf(vm.userName) }
    var customOpen by remember { mutableStateOf(false) }
    val pickBooks = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) vm.setFolder(true, u) }
    val pickComics = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) vm.setFolder(false, u) }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 40.dp)) {
        item {
            Column(Modifier.padding(top = 16.dp)) {
                Text("Ajustes", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)

                Group("Tú") {
                    Card {
                        Text("Cómo te llamamos", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it.take(24) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(onClick = { vm.setUserName(name) }, enabled = name.trim() != vm.userName) { Text("Guardar") }
                        }
                    }
                }

                Group("Tema") {
                    Text(
                        "El tema que elijas es también el del lector: se mantiene estable para leer sin fatiga.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        val auto = resolveScheme("auto", 0, 0, 0, systemDark)
                        ThemeTile("Automático", auto.background, auto.primary, auto.onBackground, vm.themeId == "auto") { vm.setTheme("auto") }
                        for (t in THEMES) {
                            if (!vm.themeUnlocked(t.id)) continue
                            ThemeTile(t.name, t.colors.background, t.colors.primary, t.colors.onBackground, vm.themeId == t.id) { vm.setTheme(t.id) }
                        }
                        val cs = buildScheme(Color(vm.customBg), Color(vm.customAccent), Color(vm.customText))
                        if (vm.prefs.counter("custom_made") > 0) {
                            ThemeTile("Mi tema", cs.background, cs.primary, cs.onBackground, vm.themeId == "custom") { vm.setTheme("custom") }
                        }
                        Column(
                            Modifier
                                .width(92.dp)
                                .height(104.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                                .clickable { customOpen = true },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("🎨", fontSize = 26.sp)
                            Text("Crear mi tema", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }

                Group("Juli Experience") {
                    Card {
                        SwitchRow(
                            "Activar Juli Experience",
                            "La biblioteca toma los colores de la portada que estás viendo. El lector nunca cambia de color.",
                            vm.expEnabled
                        ) { vm.changeExpEnabled(it) }
                        if (vm.expEnabled) {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for (st in ExpStyle.entries) {
                                    FilterChip(
                                        selected = vm.expStyle == st.name,
                                        onClick = { vm.changeExpStyle(st.name) },
                                        label = { Text(st.label) }
                                    )
                                }
                            }
                            Text(ExpStyle.of(vm.expStyle).blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Intensidad", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Slider(
                                value = vm.expIntensity,
                                onValueChange = { vm.changeExpIntensity(it) },
                                valueRange = 0.15f..1f
                            )
                        }
                    }
                }

                Group("Juli") {
                    Card {
                        Text("¿Cuánto habla Juli?", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0 to "En silencio", 1 to "Normal", 2 to "Habladora").forEach { (v, l) ->
                                FilterChip(selected = vm.juliTalk == v, onClick = { vm.changeJuliTalk(v) }, label = { Text(l) })
                            }
                        }
                        Text(
                            "Secretos descubiertos: ${vm.eggs.size} de ${Eggs.ALL.size}. Juli no dice dónde están.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Group("Biblioteca") {
                    Card {
                        Text("Carpeta de libros", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(folderLabel(vm.treeUri) ?: "Sin elegir", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        OutlinedButton(onClick = { pickBooks.launch(null) }) { Text("Cambiar carpeta de libros") }
                    }
                    Card {
                        Text("Carpeta de cómics", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(folderLabel(vm.comicsUri) ?: "Sin elegir", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pickComics.launch(null) }) { Text(if (vm.comicsUri == null) "Elegir carpeta" else "Cambiar") }
                            if (vm.comicsUri != null) TextButton(onClick = { vm.clearComicsFolder() }) { Text("Quitar") }
                        }
                    }
                    Card {
                        Button(onClick = { vm.startScan() }, enabled = !vm.scanning) { Text(if (vm.scanning) "Escaneando…" else "Actualizar biblioteca") }
                        SwitchRow(
                            "Portadas en línea",
                            "Opcional. Busca por internet solo las portadas que faltan. Sorpréndeme y Juli nunca usan internet.",
                            vm.onlineCovers
                        ) { vm.changeOnlineCovers(it) }
                    }
                }

                Group("Acerca de") {
                    Text(
                        "JullBook 1.0 · Todo funciona sin conexión. Solo lee tus archivos: nunca los mueve, copia, renombra ni modifica.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (customOpen) CustomThemeDialog(vm, onDismiss = { customOpen = false })
}

@Composable
private fun ColorEditor(label: String, initial: Int, onChange: (Int) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    fun emit() = onChange(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    val cur = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(cur).border(1.dp, MaterialTheme.colorScheme.outline, CircleShape))
            Text(label, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
        }
        Slider(value = h, onValueChange = { h = it; emit() }, valueRange = 0f..360f)
        Slider(value = s, onValueChange = { s = it; emit() }, valueRange = 0f..1f)
        Slider(value = v, onValueChange = { v = it; emit() }, valueRange = 0f..1f)
    }
}

@Composable
private fun CustomThemeDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var bg by remember { mutableIntStateOf(vm.customBg) }
    var accent by remember { mutableIntStateOf(vm.customAccent) }
    var text by remember { mutableIntStateOf(vm.customText) }
    val sc = buildScheme(Color(bg), Color(accent), Color(text))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear mi tema") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(sc.background).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Así se ve", style = MaterialTheme.typography.titleMedium, color = sc.onBackground)
                    Text("Un poco de texto de ejemplo para leer cómodo.", style = MaterialTheme.typography.bodySmall, color = sc.onSurfaceVariant)
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(sc.primary).padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text("Botón", color = sc.onPrimary, style = MaterialTheme.typography.labelLarge)
                    }
                }
                Text("Cada color: matiz, saturación y brillo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ColorEditor("Fondo", vm.customBg) { bg = it }
                ColorEditor("Acento", vm.customAccent) { accent = it }
                ColorEditor("Texto", vm.customText) { text = it }
                Text(
                    "El contraste se ajusta solo para que el texto siempre se lea bien.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = { vm.saveCustomTheme(bg, accent, text); onDismiss() }) { Text("Guardar y usar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
