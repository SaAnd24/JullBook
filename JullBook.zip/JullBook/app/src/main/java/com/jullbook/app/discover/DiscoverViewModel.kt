package com.jullbook.app.discover

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.AppViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap

enum class SearchStatus { IDLE, LOADING, DONE, OFFLINE, FAILED }

enum class DlStatus { CONNECTING, DOWNLOADING, SAVING, DONE, FAILED, CANCELLED, DUPLICATE }

class DownloadRequest(
    val sourceId: String,
    val title: String,
    val author: String?,
    val format: DlFormat,
    val url: String,
    val size: Long?
) {
    val key: String get() = "$sourceId|$url"
}

class DlState(
    val status: DlStatus,
    val done: Long = 0L,
    /** -1 = tamaño total desconocido. */
    val total: Long = -1L,
    val message: String? = null,
    val fileName: String? = null
) {
    val isActive: Boolean get() = status == DlStatus.CONNECTING || status == DlStatus.DOWNLOADING || status == DlStatus.SAVING
}

/** Pide la carpeta de la biblioteca (o su permiso de escritura) antes de poder guardar una descarga. */
data class FolderRequest(val isBooks: Boolean, val expected: String?, val req: DownloadRequest, val error: String? = null)

class SourceRow(val cfg: SourceConfig, val enabled: Boolean)

/**
 * Estado de la búsqueda y las descargas. Solo trabaja mientras el usuario usa la función:
 * sin servicios ni procesos permanentes. Las descargas terminan dentro de la biblioteca existente
 * (se guardan en su misma carpeta y se escanean como cualquier otro archivo).
 */
class DiscoverViewModel(app: Application) : AndroidViewModel(app) {

    private val store = SourceStore(app)
    private val sourceCache = HashMap<String, Source>()

    var text by mutableStateOf("")
    var lang by mutableStateOf<Lang?>(null)
        private set
    var status by mutableStateOf(SearchStatus.IDLE)
        private set
    var results by mutableStateOf<List<SearchResult>>(emptyList())
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var hasMore by mutableStateOf(false)
        private set

    /** Resultados descartados por no coincidir el idioma (o no indicarlo la fuente). */
    var hiddenByLang by mutableStateOf(0)
        private set
    var warnings by mutableStateOf<List<String>>(emptyList())
        private set
    var lastQuery by mutableStateOf<SearchQuery?>(null)
        private set

    var sourceList by mutableStateOf(loadSources())
        private set

    var selected by mutableStateOf<SearchResult?>(null)
        private set
    var detail by mutableStateOf<BookDetails?>(null)
        private set
    var detailLoading by mutableStateOf(false)
        private set

    val downloads = mutableStateMapOf<String, DlState>()
    var folderRequest by mutableStateOf<FolderRequest?>(null)
        private set

    private class Paging(val src: Source, var cursor: String? = null, var done: Boolean = false)

    private var paging: List<Paging> = emptyList()
    private val seen = HashSet<String>()
    private var searchJob: Job? = null
    private var detailJob: Job? = null
    private val jobs = ConcurrentHashMap<String, Job>()
    private val conns = ConcurrentHashMap<String, HttpURLConnection>()

    init {
        // Restos de descargas interrumpidas de otra sesión.
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { File(getApplication<Application>().cacheDir, "dl").deleteRecursively() }
        }
    }

    // ---- Fuentes ----

    private fun loadSources(): List<SourceRow> = store.all().map { SourceRow(it, store.isEnabled(it.id)) }

    private fun sourceFor(cfg: SourceConfig): Source = synchronized(sourceCache) {
        sourceCache.getOrPut(cfg.id) { createSource(cfg) }
    }

    private fun sourceById(id: String): Source? = sourceList.firstOrNull { it.cfg.id == id }?.let { sourceFor(it.cfg) }

    fun toggleSource(id: String, on: Boolean) {
        store.setEnabled(id, on)
        sourceList = loadSources()
    }

    /** Devuelve un mensaje de error, o null si se añadió. */
    fun addSource(name: String, url: String, user: String, pass: String): String? {
        if (name.isBlank()) return "Escribe un nombre para la fuente."
        val u = url.trim()
        if (!u.startsWith("https://", ignoreCase = true)) return "La dirección debe empezar por https://"
        if (runCatching { java.net.URL(u.replace("{searchTerms}", "x")).host.isNotBlank() }.getOrDefault(false).not()) {
            return "La dirección no es válida."
        }
        store.add(name, u, user, pass)
        sourceList = loadSources()
        return null
    }

    fun removeSource(id: String) {
        store.remove(id)
        synchronized(sourceCache) { sourceCache.remove(id) }
        sourceList = loadSources()
    }

    // ---- Búsqueda ----

    fun selectLang(l: Lang?) {
        if (lang == l) return
        lang = l
        // Si ya hay una búsqueda en pantalla, el filtro se aplica al momento.
        if (lastQuery != null) search()
    }

    fun search() {
        val q = SearchQuery(text.trim(), lang)
        searchJob?.cancel()
        seen.clear()
        results = emptyList()
        hiddenByLang = 0
        warnings = emptyList()
        hasMore = false
        loadingMore = false
        if (q.text.isEmpty() && q.lang == null) {
            lastQuery = null
            status = SearchStatus.IDLE
            return
        }
        lastQuery = q
        val active = sourceList.filter { it.enabled }.map { sourceFor(it.cfg) }
        if (active.isEmpty()) {
            status = SearchStatus.FAILED
            warnings = listOf("No hay fuentes activas. Actívalas en «Fuentes».")
            return
        }
        paging = active.map { Paging(it) }
        status = SearchStatus.LOADING
        searchJob = viewModelScope.launch { runSearch(q) }
    }

    fun loadMore() {
        val q = lastQuery ?: return
        if (loadingMore || status != SearchStatus.DONE || !hasMore) return
        loadingMore = true
        searchJob = viewModelScope.launch {
            try {
                runSearch(q)
            } finally {
                loadingMore = false
            }
        }
    }

    private class Round(var ok: Int = 0, var failed: Int = 0, var offline: Boolean = false)

    private suspend fun runSearch(q: SearchQuery) {
        val info = Round()
        var rounds = 0
        while (true) {
            val targets = paging.filter { !it.done }
            if (targets.isEmpty()) break
            val outcomes = coroutineScope {
                targets.map { pg -> async(Dispatchers.IO) { runCatching { pg.src.search(q, pg.cursor) } } }.awaitAll()
            }
            val added = ArrayList<SearchResult>()
            val warn = ArrayList<String>()
            for (i in targets.indices) {
                val pg = targets[i]
                val page = outcomes[i].getOrNull()
                if (page == null) {
                    pg.done = true
                    info.failed++
                    val (off, msg) = describe(outcomes[i].exceptionOrNull())
                    if (off) info.offline = true
                    warn.add(pg.src.name + ": " + msg)
                    continue
                }
                info.ok++
                pg.cursor = page.next
                if (page.next == null) pg.done = true
                val native = pg.src.filtersLanguage(q.lang)
                for (res in page.results) {
                    if (!seen.add(res.sourceId + "|" + res.id)) continue
                    val fixed = applyLang(res, q.lang, native)
                    if (fixed == null) hiddenByLang++ else added.add(fixed)
                }
            }
            if (added.isNotEmpty()) results = results + added
            if (warn.isNotEmpty()) warnings = (warnings + warn).distinct()
            rounds++
            // Con filtro local, una página puede quedar vacía: se prueban unas pocas más antes de rendirse.
            if (results.isNotEmpty() || q.lang == null || rounds >= 4) break
        }
        hasMore = paging.any { !it.done }
        status = when {
            results.isNotEmpty() -> SearchStatus.DONE
            info.ok == 0 && info.failed > 0 -> if (info.offline) SearchStatus.OFFLINE else SearchStatus.FAILED
            else -> SearchStatus.DONE
        }
    }

    /**
     * Idioma: nunca se inventa. Con idioma indicado por la fuente se compara; sin él, solo se acepta si la propia
     * fuente ya filtró por ese idioma (y la ficha lo deja claro). En cualquier otro caso se oculta.
     */
    private fun applyLang(r: SearchResult, want: Lang?, native: Boolean): SearchResult? {
        if (want == null) return r
        if (r.langs.isNotEmpty()) return if (want in r.langs) r else null
        return if (native) r.withFilterLang(want) else null
    }

    /** (¿sin conexión?, mensaje). */
    private fun describe(e: Throwable?): Pair<Boolean, String> = when (e) {
        is UnknownHostException -> true to "sin conexión a Internet"
        is Http.HttpFail ->
            if (e.code == 401 || e.code == 403) false to "requiere usuario y contraseña"
            else false to "no disponible (error ${e.code})"
        is Http.Insecure -> false to "la dirección debe empezar por https://"
        is SourceException -> false to (e.message ?: "respuesta no válida")
        is SocketTimeoutException -> false to "no responde"
        is ConnectException -> false to "no se pudo conectar"
        else -> false to "no disponible"
    }

    // ---- Ficha ----

    fun open(r: SearchResult) {
        detailJob?.cancel()
        selected = r
        if (r.downloads.isNotEmpty() || r.detailUrl == null) {
            detail = BookDetails(r, r.downloads)
            detailLoading = false
            return
        }
        detail = null
        detailLoading = true
        detailJob = viewModelScope.launch {
            val src = sourceById(r.sourceId)
            val res = withContext(Dispatchers.IO) {
                runCatching { src?.details(r) ?: BookDetails(r, r.downloads) }
            }
            detailLoading = false
            val d = res.getOrNull()
            if (d != null) {
                detail = d
                // La lista pasa a mostrar los formatos ya resueltos.
                results = results.map { if (it.sourceId == r.sourceId && it.id == r.id) d.result else it }
            } else {
                detail = BookDetails(r, emptyList(), describe(res.exceptionOrNull()).second)
            }
        }
    }

    fun closeDetail() {
        detailJob?.cancel()
        selected = null
        detail = null
        detailLoading = false
    }

    fun loadCover(sourceId: String, url: String): Bitmap? = RemoteCovers.load(url, sourceById(sourceId)?.authOrNull())

    // ---- Descarga ----

    private val BAD = Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]")
    private val SPACES = Regex("\\s+")

    fun fileNameFor(req: DownloadRequest): String {
        var base = req.title
        if (!req.format.isComic && !req.author.isNullOrBlank()) base += " - " + req.author
        base = base.replace(BAD, " ").replace(SPACES, " ").trim().trim('.').trim()
        if (base.length > 110) base = base.take(110).trim()
        if (base.isEmpty()) base = if (req.format.isComic) "Cómic" else "Libro"
        return base + "." + req.format.ext
    }

    private class Msg(text: String) : Exception(text)

    fun cancelFolderRequest() {
        folderRequest = null
    }

    fun onFolderPicked(app: AppViewModel, uri: Uri) {
        val fr = folderRequest ?: return
        if (fr.expected != null && uri.toString() != fr.expected) {
            folderRequest = fr.copy(
                error = "Esa no es la carpeta de tu biblioteca. Elige la misma que usas en JullBook (puedes cambiarla en Ajustes)."
            )
            return
        }
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Throwable) {
            folderRequest = fr.copy(error = "No se pudo obtener permiso de escritura en esa carpeta.")
            return
        }
        folderRequest = null
        // Sin carpeta configurada: la elegida pasa a ser la de la biblioteca (misma función que usa Ajustes).
        if (fr.expected == null) app.setFolder(fr.isBooks, uri)
        download(app, fr.req)
    }

    fun cancelDownload(key: String) {
        jobs[key]?.cancel()
        val c = conns[key]
        downloads[key] = DlState(DlStatus.CANCELLED)
        if (c != null) viewModelScope.launch(Dispatchers.IO) { runCatching { c.disconnect() } }
    }

    fun download(app: AppViewModel, req: DownloadRequest) {
        val key = req.key
        if (downloads[key]?.isActive == true) return
        val ctx = getApplication<Application>()
        val isBooks = !req.format.isComic
        val rootStr = if (isBooks) (app.treeUri ?: app.comicsUri) else (app.comicsUri ?: app.treeUri)
        if (rootStr == null) {
            folderRequest = FolderRequest(isBooks, null, req)
            return
        }
        val root = Uri.parse(rootStr)
        if (!Saf.hasWrite(ctx, root)) {
            folderRequest = FolderRequest(isBooks, rootStr, req)
            return
        }
        val name = fileNameFor(req)
        if (app.library.books.values.any { it.fileName.equals(name, ignoreCase = true) }) {
            downloads[key] = DlState(DlStatus.DUPLICATE, message = "Ya está en tu biblioteca", fileName = name)
            return
        }
        downloads[key] = DlState(DlStatus.CONNECTING, total = req.size ?: -1L)
        val job = viewModelScope.launch(Dispatchers.IO) {
            var tmp: File? = null
            var conn: HttpURLConnection? = null
            try {
                if (Saf.exists(ctx, root, name)) {
                    downloads[key] = DlState(DlStatus.DUPLICATE, message = "Ya está en tu biblioteca", fileName = name)
                    return@launch
                }
                val c = Http.open(req.url, sourceById(req.sourceId)?.authOrNull(), null, if (req.url.contains("ws-export.wmcloud.org")) 120000 else 20000)
                conn = c
                conns[key] = c
                val ct = (c.contentType ?: "").lowercase()
                if (ct.startsWith("text/html") || ct.contains("json") || ct.contains("xml")) throw Msg("La fuente no entregó un archivo válido")
                val total = c.contentLengthLong.takeIf { it > 0 } ?: req.size ?: -1L
                val dir = File(ctx.cacheDir, "dl").apply { mkdirs() }
                if (total > 0 && dir.usableSpace < total + 8L * 1024 * 1024) throw Msg("No hay espacio suficiente en el dispositivo")
                val f = File.createTempFile("dl_", ".part", dir)
                tmp = f
                var done = 0L
                c.inputStream.use { input ->
                    FileOutputStream(f).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var last = 0L
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = SystemClock.elapsedRealtime()
                            if (now - last > 120) {
                                last = now
                                downloads[key] = DlState(DlStatus.DOWNLOADING, done, total)
                            }
                        }
                    }
                }
                ensureActive()
                if (total > 0 && done < total) throw Msg("La descarga quedó incompleta")
                if (!validMagic(f, req.format)) throw Msg("El archivo descargado no es un ${req.format.label} válido")
                downloads[key] = DlState(DlStatus.SAVING, done, if (total > 0) total else done)
                Saf.save(ctx, root, name, req.format.mime, f)
                downloads[key] = DlState(DlStatus.DONE, done, if (total > 0) total else done, fileName = name)
                withContext(Dispatchers.Main) { app.onDownloadSaved() }
            } catch (e: Throwable) {
                if (e is CancellationException || !isActive) {
                    downloads[key] = DlState(DlStatus.CANCELLED)
                    if (e is CancellationException) throw e
                } else {
                    downloads[key] = DlState(DlStatus.FAILED, message = failText(e))
                }
            } finally {
                conn?.let { runCatching { it.disconnect() } }
                conns.remove(key)
                jobs.remove(key)
                tmp?.let { runCatching { it.delete() } }
            }
        }
        jobs[key] = job
    }

    private fun failText(e: Throwable): String = when {
        e is Msg -> e.message ?: "Descarga fallida"
        e is UnknownHostException -> "Sin conexión a Internet"
        e is Http.HttpFail -> if (e.code == 401 || e.code == 403) "La fuente requiere usuario y contraseña" else "La fuente respondió con error ${e.code}"
        e is Http.Insecure -> "La descarga no es segura (https)"
        e is SocketTimeoutException -> "La fuente no responde"
        e is IOException && ((e.message ?: "").contains("ENOSPC") || (e.message ?: "").contains("No space", ignoreCase = true)) ->
            "No hay espacio suficiente para guardar el archivo"
        e is IOException -> "Descarga fallida: ${e.message ?: "error de red"}"
        else -> "Descarga fallida"
    }

    private fun validMagic(f: File, fmt: DlFormat): Boolean {
        val head = ByteArray(1024)
        val n = f.inputStream().use { it.read(head) }
        if (n < 4) return false
        val zip = head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() && head[2].toInt() == 3 && head[3].toInt() == 4
        val rar = head[0] == 'R'.code.toByte() && head[1] == 'a'.code.toByte() && head[2] == 'r'.code.toByte() && head[3] == '!'.code.toByte()
        val pdf = String(head, 0, n, Charsets.ISO_8859_1).contains("%PDF-")
        return when (fmt) {
            DlFormat.EPUB -> zip
            DlFormat.PDF -> pdf
            DlFormat.CBZ, DlFormat.CBR -> zip || rar
        }
    }
}
