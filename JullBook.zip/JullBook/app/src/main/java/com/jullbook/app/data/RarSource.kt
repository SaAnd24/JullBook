package com.jullbook.app.data

import android.content.Context
import android.net.Uri
import com.github.junrar.Archive
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/** Lectura de CBR (RAR) con junrar. Se extraen las páginas a la caché de la app; el archivo original no se toca. */
object RarSource {
    class Unsupported(val v5: Boolean) : IOException(if (v5) "RAR5 no soportado" else "RAR no soportado")

    private const val KEEP_CACHED = 2

    private fun nameOf(h: Any): String {
        for (m in arrayOf("getFileName", "getFileNameString")) {
            try {
                val r = h.javaClass.getMethod(m).invoke(h) as? String
                if (r != null) return r
            } catch (ignored: Throwable) {
            }
        }
        return ""
    }

    private val SINK = object : OutputStream() {
        override fun write(b: Int) {}
        override fun write(b: ByteArray, off: Int, len: Int) {}
    }

    /**
     * Devuelve las páginas del CBR ya extraídas (en orden natural). Reutiliza la caché si ya se extrajo.
     * [check] se llama durante el proceso para poder cancelarlo.
     */
    fun prepare(ctx: Context, b: Book, check: () -> Unit): List<File> {
        val root = File(ctx.cacheDir, "cbr")
        root.mkdirs()
        val dir = File(root, "${b.id}_${b.modified}")
        val order = File(dir, "order.txt")
        val done = File(dir, ".done")
        if (done.exists() && order.exists()) {
            val files = order.readLines().filter { it.isNotBlank() }.map { File(dir, it) }.filter { it.exists() }
            if (files.isNotEmpty()) {
                dir.setLastModified(System.currentTimeMillis())
                return files
            }
        }
        dir.deleteRecursively()
        trim(root, dir)
        dir.mkdirs()
        val tmp = File(root, "tmp_${b.id}.rar")
        try {
            val ins = ctx.contentResolver.openInputStream(Uri.parse(b.uri)) ?: throw IOException("No se pudo abrir el archivo")
            ins.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        check()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            val extracted = ArrayList<Pair<String, File>>()
            Archive(tmp).use { a ->
                var n = 0
                for (h in a.fileHeaders) {
                    check()
                    if (h.isDirectory) continue
                    val name = nameOf(h).replace('\\', '/')
                    if (SeekableZip.isImage(name)) {
                        val ext = name.substringAfterLast('.', "jpg").lowercase().filter { it.isLetterOrDigit() }.take(5).ifEmpty { "jpg" }
                        val f = File(dir, "p${n++}.$ext")
                        FileOutputStream(f).use { a.extractFile(h, it) }
                        extracted.add(name to f)
                    } else {
                        // En archivos "sólidos" hay que descomprimir también lo que no se usa.
                        a.extractFile(h, SINK)
                    }
                }
            }
            if (extracted.isEmpty()) throw IOException("El archivo no contiene imágenes")
            val sorted = extracted.sortedWith(Comparator { x, y -> naturalCompare(x.first, y.first) })
            order.writeText(sorted.joinToString("\n") { it.second.name })
            done.writeText("ok")
            return sorted.map { it.second }
        } catch (t: Throwable) {
            dir.deleteRecursively()
            val label = t.javaClass.simpleName + " " + (t.message ?: "")
            if (label.contains("V5", ignoreCase = true) || label.contains("RAR5", ignoreCase = true)) throw Unsupported(true)
            throw t
        } finally {
            tmp.delete()
        }
    }

    /** Conserva solo los últimos cómics extraídos para no llenar el almacenamiento. */
    private fun trim(root: File, current: File) {
        root.listFiles()?.forEach { if (it.isFile) it.delete() }
        val dirs = (root.listFiles() ?: emptyArray())
            .filter { it.isDirectory && it != current }
            .sortedByDescending { it.lastModified() }
        dirs.drop(KEEP_CACHED).forEach { it.deleteRecursively() }
    }
}
