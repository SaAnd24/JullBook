package com.jullbook.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.pager.PagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullbook.app.AppViewModel
import com.jullbook.app.Tab
import com.jullbook.app.ui.reader.ReaderHost

private tailrec fun Context.activityOf(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activityOf()
    else -> null
}

/** Fondo de pantalla con luz ambiental (Juli Experience) sobre el color del tema. */
@Composable
fun Modifier.screenBg(): Modifier {
    val a = LocalAmbient.current
    return this.background(MaterialTheme.colorScheme.background).ambientBackdrop(a)
}

@Composable
fun JullBookApp(vm: AppViewModel = viewModel()) {
    val systemDark = isSystemInDarkTheme()
    // Esquema ESTABLE del usuario: lo usa el lector y es la base de Juli Experience.
    val base = resolveScheme(vm.themeId, vm.customBg, vm.customAccent, vm.customText, systemDark)

    // Portada que tiñe la biblioteca según lo que se está viendo.
    val key = vm.seriesKey
    val series = key?.let { vm.library.series[it] }
    val reading = vm.reading
    val libCover = vm.library.recent.firstOrNull()?.book?.coverPath
    val ambientPath: String? = when {
        vm.surpriseShow && vm.surprise != null -> vm.surprise?.book?.coverPath
        series != null -> series.coverPath ?: series.volumes.firstOrNull()?.book?.coverPath
        reading != null && !vm.readerVisible -> reading.coverPath
        vm.tab == Tab.HOME -> vm.ambientPath ?: libCover
        else -> libCover
    }
    val readerFront = reading != null && vm.readerVisible
    val (derived, amb) = rememberAmbient(
        ambientPath = ambientPath,
        baseScheme = base,
        enabled = vm.expEnabled,
        style = ExpStyle.of(vm.expStyle),
        intensity = vm.expIntensity,
        animating = !readerFront
    )
    val scheme = if (readerFront) base else derived

    // Iconos de la barra de estado legibles según el fondo actual.
    val view = LocalView.current
    val darkBg = scheme.background.luminance() < 0.5f
    SideEffect {
        val w = view.context.activityOf()?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !darkBg
            c.isAppearanceLightNavigationBars = !darkBg
        }
    }

    JullTheme(scheme) {
        CompositionLocalProvider(LocalAmbient provides amb) {
            val pickBooks = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                if (uri != null) vm.setFolder(true, uri)
            }
            val pick = { pickBooks.launch(null) }

            BackHandler(
                enabled = vm.reading != null || vm.showStats || vm.selection.isNotEmpty() || vm.seriesKey != null ||
                    vm.surpriseShow || vm.tab != Tab.HOME
            ) { vm.back() }

            val overlay = series != null || vm.showStats
            val mini = vm.reading != null && !vm.readerVisible

            Box(Modifier.fillMaxSize().screenBg()) {
                when {
                    !vm.loaded -> {}
                    !vm.onboarded -> OnboardingScreen(vm)
                    else -> Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = {
                            Column {
                                if (!overlay) MiniReader(vm)
                                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.94f)) {
                                    val colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.primaryContainer)
                                    NavigationBarItem(
                                        selected = vm.tab == Tab.HOME,
                                        onClick = { vm.tab = Tab.HOME },
                                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                                        label = { Text("Inicio") },
                                        colors = colors
                                    )
                                    NavigationBarItem(
                                        selected = vm.tab == Tab.LIBRARY,
                                        onClick = { vm.tab = Tab.LIBRARY },
                                        icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = null) },
                                        label = { Text("Biblioteca") },
                                        colors = colors
                                    )
                                    NavigationBarItem(
                                        selected = vm.tab == Tab.ACHIEVEMENTS,
                                        onClick = { vm.tab = Tab.ACHIEVEMENTS },
                                        icon = { Icon(Icons.Default.Star, contentDescription = null) },
                                        label = { Text("Logros") },
                                        colors = colors
                                    )
                                    NavigationBarItem(
                                        selected = vm.tab == Tab.SETTINGS,
                                        onClick = { vm.tab = Tab.SETTINGS },
                                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                        label = { Text("Ajustes") },
                                        colors = colors
                                    )
                                }
                            }
                        }
                    ) { pad ->
                        AnimatedContent(
                            targetState = vm.tab,
                            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                            label = "tab"
                        ) { t ->
                            when (t) {
                                Tab.HOME -> HomeScreen(vm, pick, Modifier.padding(pad))
                                Tab.LIBRARY -> LibraryScreen(vm, pick, Modifier.padding(pad))
                                Tab.ACHIEVEMENTS -> AchievementsScreen(vm, Modifier.padding(pad).statusBarsPadding())
                                Tab.SETTINGS -> SettingsScreen(vm, Modifier.padding(pad).statusBarsPadding())
                            }
                        }
                    }
                }

                if (series != null) {
                    Box(Modifier.fillMaxSize().screenBg().pointerInput(Unit) {}) {
                        SeriesScreen(series, vm, onBack = { vm.back() })
                    }
                }

                if (vm.showStats) {
                    Box(Modifier.fillMaxSize().screenBg().pointerInput(Unit) {}) {
                        StatsScreen(vm, onBack = { vm.back() })
                    }
                }

                if (mini && overlay) {
                    MiniReader(vm, Modifier.align(Alignment.BottomCenter).navigationBarsPadding())
                }

                // Lector: siempre con el esquema estable del usuario y sin luz ambiental.
                // Minimizado sigue compuesto (posición exacta intacta), solo se desliza fuera de pantalla.
                if (reading != null) {
                    val t by animateFloatAsState(if (vm.readerVisible) 0f else 1f, tween(320), label = "reader")
                    JullTheme(base) {
                        CompositionLocalProvider(LocalAmbient provides null) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        translationY = t * size.height
                                        alpha = if (t >= 1f) 0f else 1f
                                    }
                                    .background(base.background)
                                    .pointerInput(Unit) {}
                            ) {
                                key(reading.id) {
                                    ReaderHost(reading, vm, onBack = { vm.back() })
                                    FinishedPrompt(vm, reading, Modifier.align(Alignment.BottomCenter))
                                }
                            }
                        }
                    }
                }

                if (vm.reading == null || !vm.readerVisible) {
                    NoticeHost(vm, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (mini) 150.dp else 80.dp))
                }

                if (vm.onboarded && vm.loaded && (vm.reading == null || !vm.readerVisible)) {
                    SurpriseOverlay(vm)
                    JuliBubbleHost(vm, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (mini) 160.dp else 92.dp))
                }
                ConfettiOverlay(vm.confetti)
                AchievementToast(vm.achToast, onDone = { vm.dismissAch() }, modifier = Modifier.align(Alignment.TopCenter))

                OrgDialogs(vm)
            }
        }
    }
}
