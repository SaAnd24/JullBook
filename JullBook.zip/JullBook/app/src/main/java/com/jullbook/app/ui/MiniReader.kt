package com.jullbook.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.SurpriseEngine
import com.jullbook.app.data.pctText

/** "Tu lectura actual": barra persistente tipo reproductor mientras el lector está minimizado. */
@Composable
fun MiniReader(vm: AppViewModel, modifier: Modifier = Modifier) {
    val show = vm.reading != null && !vm.readerVisible
    AnimatedVisibility(
        visible = show,
        modifier = modifier,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
    ) {
        val b = vm.reading ?: return@AnimatedVisibility
        val title = SurpriseEngine.displayTitle(b, vm.library.bookSeries[b.id])
        val pct = vm.readingPercent
        // Con Juli Experience la tarjeta toma los colores de la portada (el esquema ya viene teñido).
        val a = MaterialTheme.colorScheme.primaryContainer
        val c = MaterialTheme.colorScheme.secondaryContainer
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .shadow(14.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.horizontalGradient(listOf(a, c)))
                .clickable { vm.restoreReader() }
        ) {
            Row(
                Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CoverImage(b.coverPath, b.title, Modifier.size(width = 40.dp, height = 58.dp).clip(RoundedCornerShape(8.dp)), format = b.format)
                Column(Modifier.weight(1f)) {
                    Text("Tu lectura actual", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                    Text(
                        title,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(pctText(pct), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
                IconButton(onClick = { vm.restoreReader() }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Volver al lector", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                IconButton(onClick = { vm.closeReading() }) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar lectura", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            LinearProgressIndicator(
                progress = { pct.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(3.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color0
            )
        }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.Transparent
