package com.jullbook.app.data

import java.text.Normalizer

object SeriesParser {
    class Parsed(val title: String, val series: String?, val key: String?, val number: Int?)

    private const val KW = "(?:vol(?:ume|umen)?\\.?\\s*|v\\.?\\s*|tomo\\.?\\s*|t\\.?\\s*|n[º°o]\\.?\\s*|no\\.?\\s*|issue\\s*|cap(?:[ií]tulo)?\\.?\\s*|ch(?:apter)?\\.?\\s*|ep(?:isode)?\\.?\\s*|#\\s*)"

    // [prefijo + separador (espacio . _ - o antes de #)] [palabra clave opcional] número [(etiquetas) opcionales al final]
    // Grupos: 1 = prefijo, 2 = palabra clave, 3 = número, 4 = etiquetas.
    private val NUM = Regex(
        "^(?:(.*?)(?:[\\s._\\-]+|(?=#)))?(" + KW + ")?(\\d{1,4})((?:\\s*[(\\[][^)\\]]*[)\\]])*)\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val SPACES = Regex("\\s+")
    private val MARKS = Regex("\\p{Mn}+")
    private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]+")

    // Palabras que por sí solas no son un nombre de serie ("Capítulo 12" → se usa la carpeta).
    private val GENERIC = setOf(
        "chapter", "capitulo", "cap", "ch", "volume", "volumen", "vol", "tomo", "issue", "episode", "episodio",
        "ep", "part", "parte", "book", "libro", "page", "pagina", "numero", "no", "num"
    )

    fun keyOf(name: String): String =
        Normalizer.normalize(name, Normalizer.Form.NFD)
            .replace(MARKS, "")
            .lowercase()
            .replace(NON_ALNUM, " ")
            .trim()

    fun parse(fileName: String, folder: String, isComic: Boolean): Parsed {
        val base = fileName.substringBeforeLast('.')
        val clean = base.replace('_', ' ').replace(SPACES, " ").trim()
        val title = clean.ifBlank { fileName }
        val none = Parsed(title, null, null, null)
        if (!isComic) return none
        val m = NUM.matchEntire(clean) ?: return none
        val digits = m.groupValues[3]
        val number = digits.toIntOrNull() ?: return none
        val hasKeyword = m.groupValues[2].isNotBlank()
        // "Batman 1989": un año suelto no es un número de tomo.
        if (!hasKeyword && digits.length == 4 && number in 1900..2100) return none
        var name = (m.groups[1]?.value ?: "").trim().trim('-', '–', '.', ',', ' ')
        if (keyOf(name) in GENERIC) name = ""
        if (name.isEmpty()) name = folder.replace('_', ' ').replace(SPACES, " ").trim()
        if (name.count { it.isLetter() } < 2) return none
        val key = keyOf(name)
        if (key.isEmpty()) return none
        return Parsed(title, name, key, number)
    }
}
