package com.jullbook.app.ui

import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.Tab
import com.jullbook.app.data.ContinueEntry
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.formatLabel
import com.jullbook.app.data.pctText
import com.jullbook.app.data.volLabel

@Composable
fun FolderBanner(onPick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onPick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("No se puede acceder a la carpeta", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
        Text(
            "Tu biblioteca se conserva tal cual. Elige la carpeta de nuevo para actualizarla.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(onClick = onPick) { Text("Elegir carpeta") }
    }
}

@Composable
fun ScanBar(done: Int, total: Int) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(
            if (total > 0) "Preparando biblioteca… $done de $total" else "Buscando libros…",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (total > 0) {
            LinearProgressIndicator(
                progress = { (done.toFloat() / total).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, onPickFolder: () -> Unit, modifier: Modifier = Modifier) {
    val lib = vm.library
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text(
                "JullBook",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
            )
        }
        if (vm.folderLost) item { FolderBanner(onPickFolder) }
        if (vm.scanning) item { ScanBar(vm.scanDone, vm.scanTotal) }

        if (lib.items.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        if (vm.scanning) "Buscando libros en tu carpeta…" else "No hay libros todavía",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (!vm.scanning) {
                        Text(
                            "No se encontraron EPUB, PDF ni CBZ en la carpeta elegida.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = onPickFolder) { Text("Cambiar carpeta") }
                    }
                }
            }
        } else {
            if (lib.cont.isNotEmpty()) {
                item { SectionTitle("Continuar leyendo") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(lib.cont) { e -> ContinueCard(e, vm) }
                    }
                }
            }
            item {
                SectionTitle("Biblioteca") {
                    TextButton(onClick = { vm.tab = Tab.LIBRARY }) { Text("Ver todo") }
                }
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(lib.items.take(12), key = { it.id }) { item ->
                        ItemCard(
                            item,
                            onBook = { vm.openBook(it.book) },
                            onSeries = { vm.openSeries(it.key) },
                            modifier = Modifier.width(112.dp)
                        )
                    }
                }
            }
            item {
                SectionTitle("Tu lectura") {
                    TextButton(onClick = { vm.showStats = true }) { Text("Ver más") }
                }
            }
            item { ReadingSummary(vm) }
            if (lib.recent.isNotEmpty()) {
                item { SectionTitle("Actividad reciente") }
                items(lib.recent) { e -> RecentRow(e, vm) }
            }
        }
    }
}

@Composable
private fun ContinueCard(e: ContinueEntry, vm: AppViewModel) {
    val p = e.progress
    val s = e.series
    BookCard(
        title = s?.name ?: e.book.title,
        subtitle = if (s != null) volLabel(e.book) else (e.book.author ?: formatLabel(e.book.format)),
        caption = when {
            p == null -> null
            s != null -> "${pctText(p.percent)} · serie ${pctText(s.percent)}"
            else -> pctText(p.percent)
        },
        coverPath = e.book.coverPath,
        progress = p?.percent ?: 0f,
        finished = false,
        stack = false,
        onClick = { vm.openBook(e.book) },
        modifier = Modifier.width(128.dp)
    )
}

@Composable
private fun RecentRow(e: ContinueEntry, vm: AppViewModel) {
    val p = e.progress
    val title = if (e.book.alias != null) e.book.alias else e.series?.let { "${it.name} ${volLabel(e.book)}" } ?: e.book.title
    val status = when {
        p == null -> ""
        p.status == ST_FINISHED -> "Terminado"
        else -> pctText(p.percent)
    }
    val whenText = p?.let {
        DateUtils.getRelativeTimeSpanString(it.lastRead, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
    } ?: ""
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { vm.openBook(e.book) }
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        CoverImage(
            e.book.coverPath, title,
            Modifier.size(width = 44.dp, height = 64.dp).clip(RoundedCornerShape(6.dp))
        )
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOf(formatLabel(e.book.format), status, whenText).filter { it.isNotEmpty() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
