package com.jullbook.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import com.jullbook.app.data.PaletteCache
import kotlin.math.cos
import kotlin.math.sin

/** Los tres estilos de mezcla de Juli Experience. */
enum class ExpStyle(val label: String, val blurb: String) {
    LAVA("Lava", "Color líquido, intenso y profundo"),
    AURORA("Aurora", "Mezclas suaves y atmosféricas"),
    GLOW("Glow", "Luz de acento y brillo alrededor");

    companion object {
        fun of(s: String): ExpStyle = entries.firstOrNull { it.name == s } ?: AURORA
    }
}

/** Estado ambiental compartido: colores animados de la portada actual + estilo + intensidad. */
@Stable
class AmbientState(
    val enabled: Boolean,
    val style: ExpStyle,
    val intensity: Float,
    val dark: Boolean,
    val bg: Color,
    /** Colores vivos ya adaptados a fondo claro/oscuro, para dibujar luz. */
    val glow: List<Color>,
    val phase: Animatable<Float, AnimationVector1D>
)

val LocalAmbient = compositionLocalOf<AmbientState?> { null }

private fun hsl(c: Color): FloatArray {
    val a = FloatArray(3)
    ColorUtils.colorToHSL(c.toArgb(), a)
    return a
}

private fun fromHsl(h: Float, s: Float, l: Float): Color =
    Color(ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f))))

/** Color vivo para dibujar luz: nunca apagado ni quemado. */
private fun vivid(c: Color, dark: Boolean): Color {
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceAtLeast(0.55f), if (dark) h[2].coerceIn(0.38f, 0.58f) else h[2].coerceIn(0.62f, 0.80f))
}

/** Acento legible sobre [bg] sacado de un color de portada. */
private fun accentFor(c: Color, bg: Color, dark: Boolean): Color {
    val h = hsl(c)
    val l = if (dark) h[2].coerceIn(0.58f, 0.78f) else h[2].coerceIn(0.28f, 0.42f)
    return ensureContrast(fromHsl(h[0], h[1].coerceIn(0.45f, 0.95f), l), bg, 4.2f)
}

/**
 * Transforma el esquema estable del usuario en uno con los colores de la portada.
 * Fondo, superficies, acentos y contenedores cambian; el texto siempre conserva contraste alto.
 */
fun deriveScheme(base: ColorScheme, dark: Boolean, pal: List<Color>, style: ExpStyle, k: Float): ColorScheme {
    val amt = when (style) {
        ExpStyle.LAVA -> 0.12f + 0.20f * k
        ExpStyle.AURORA -> 0.08f + 0.15f * k
        ExpStyle.GLOW -> 0.03f + 0.07f * k
    }
    val tinted = lerp(base.background, pal[0], amt)
    val th = hsl(tinted)
    val bg = if (dark) fromHsl(th[0], th[1].coerceAtMost(0.55f), th[2].coerceAtMost(0.13f))
    else fromHsl(th[0], th[1].coerceAtMost(0.5f), th[2].coerceAtLeast(0.90f))
    val onBg = ensureContrast(base.onBackground, bg, 8f)
    val a1 = accentFor(pal[0], bg, dark)
    val a2 = accentFor(pal[1 % pal.size], bg, dark)
    val a3 = accentFor(pal[2 % pal.size], bg, dark)
    val tintMix = lerp(onBg, pal[1 % pal.size], 0.5f)
    fun lv(t: Float) = lerp(bg, tintMix, t)
    val container = lerp(bg, a1, if (dark) 0.28f else 0.22f)
    val onAccent = if (a1.luminance() > 0.42f) Color(0xFF1A1305) else Color.White
    return base.copy(
        primary = a1,
        onPrimary = onAccent,
        primaryContainer = container,
        onPrimaryContainer = ensureContrast(onBg, container, 6f),
        secondary = a2,
        onSecondary = if (a2.luminance() > 0.42f) Color(0xFF1A1305) else Color.White,
        secondaryContainer = lv(if (dark) 0.14f else 0.11f),
        onSecondaryContainer = onBg,
        tertiary = a3,
        onTertiary = if (a3.luminance() > 0.42f) Color(0xFF1A1305) else Color.White,
        background = bg,
        onBackground = onBg,
        surface = bg,
        onSurface = onBg,
        surfaceVariant = lv(if (dark) 0.14f else 0.11f),
        onSurfaceVariant = lerp(onBg, bg, 0.3f),
        surfaceTint = a1,
        surfaceDim = bg,
        surfaceBright = lv(if (dark) 0.16f else 0.0f),
        surfaceContainerLowest = bg,
        surfaceContainerLow = lv(if (dark) 0.035f else 0.025f),
        surfaceContainer = lv(if (dark) 0.06f else 0.05f),
        surfaceContainerHigh = lv(if (dark) 0.10f else 0.08f),
        surfaceContainerHighest = lv(if (dark) 0.15f else 0.12f),
        outline = lv(0.45f),
        outlineVariant = lv(0.2f)
    )
}

/** Colores de la portada actual, con transición suave al cambiar de portada. */
@Composable
fun rememberAmbient(
    ambientPath: String?,
    baseScheme: ColorScheme,
    enabled: Boolean,
    style: ExpStyle,
    intensity: Float,
    animating: Boolean
): Pair<ColorScheme, AmbientState> {
    val dark = baseScheme.background.luminance() < 0.5f
    val neutral = remember(baseScheme) {
        val h = hsl(baseScheme.primary)
        listOf(
            baseScheme.primary,
            fromHsl(h[0] + 35f, h[1], h[2]),
            fromHsl(h[0] - 35f, h[1], h[2]),
            fromHsl(h[0] + 150f, h[1] * 0.8f, h[2])
        )
    }
    var target by remember { mutableStateOf<List<Color>?>(null) }
    LaunchedEffect(ambientPath, enabled) {
        if (!enabled) return@LaunchedEffect
        val p = if (ambientPath == null) null else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { PaletteCache.get(ambientPath) }
        if (p != null) target = p.colors.map { Color(it) }
    }
    val t = target ?: neutral
    val spec = tween<Color>(durationMillis = 900)
    val c0 by animateColorAsState(t[0], spec, label = "amb0")
    val c1 by animateColorAsState(t[1], spec, label = "amb1")
    val c2 by animateColorAsState(t[2], spec, label = "amb2")
    val c3 by animateColorAsState(t[3], spec, label = "amb3")

    val phase = remember { Animatable(0f) }
    LaunchedEffect(animating && enabled) {
        if (animating && enabled) {
            while (true) {
                phase.animateTo(phase.value + 1f, tween(32000, easing = LinearEasing))
            }
        }
    }

    val k = intensity.coerceIn(0f, 1f)
    val pal = listOf(c0, c1, c2, c3)
    val scheme = if (enabled) deriveScheme(baseScheme, dark, pal, style, k) else baseScheme
    val state = AmbientState(
        enabled = enabled,
        style = style,
        intensity = k,
        dark = dark,
        bg = scheme.background,
        glow = pal.map { vivid(it, dark) },
        phase = phase
    )
    return scheme to state
}

private const val TAU = 6.2831853f

private fun DrawScope.drawAmbient(a: AmbientState) {
    val w = size.width
    val h = size.height
    val p = a.phase.value * TAU
    val g = a.glow
    val k = a.intensity
    val dark = a.dark
    val damp = if (dark) 1f else 0.72f
    when (a.style) {
        ExpStyle.LAVA -> {
            val cap = (0.20f + 0.45f * k).coerceAtMost(0.62f) * damp
            for (i in 0 until 4) {
                val col = g[i % g.size]
                val cx = w * (0.5f + 0.42f * cos(p * (0.6f + i * 0.23f) + i * 1.9f))
                val cy = h * (0.42f + 0.38f * sin(p * (0.5f + i * 0.19f) + i * 2.4f))
                val r = maxOf(w, h) * (0.55f + 0.10f * i)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(col.copy(alpha = cap), col.copy(alpha = cap * 0.35f), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = r
                    ),
                    radius = r,
                    center = Offset(cx, cy)
                )
            }
            // Velo inferior: da profundidad y mantiene legible lo que hay abajo.
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, a.bg.copy(alpha = 0.6f)), startY = h * 0.45f, endY = h),
                size = Size(w, h)
            )
        }
        ExpStyle.AURORA -> {
            val cap = (0.16f + 0.32f * k).coerceAtMost(0.5f) * damp
            drawRect(
                Brush.linearGradient(
                    listOf(g[0].copy(alpha = cap * 0.4f), Color.Transparent, g[1 % g.size].copy(alpha = cap * 0.4f)),
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                ),
                size = Size(w, h)
            )
            for (i in 0 until 3) {
                val col = g[i % g.size]
                val baseY = h * (0.14f + 0.22f * i) + h * 0.03f * sin(p + i)
                val amp = h * 0.06f
                val thick = h * 0.34f
                val steps = 24
                val path = Path()
                path.moveTo(0f, baseY)
                for (s in 1..steps) {
                    val x = w * s / steps
                    val y = baseY + amp * sin(x / w * TAU * (1f + 0.4f * i) + p * (1f + i * 0.3f))
                    path.lineTo(x, y)
                }
                path.lineTo(w, baseY + thick)
                path.lineTo(0f, baseY + thick)
                path.close()
                drawPath(
                    path,
                    Brush.verticalGradient(
                        listOf(Color.Transparent, col.copy(alpha = cap), Color.Transparent),
                        startY = baseY - amp,
                        endY = baseY + thick + amp
                    )
                )
            }
        }
        ExpStyle.GLOW -> {
            val cap = (0.12f + 0.34f * k).coerceAtMost(0.5f) * damp
            val c0 = g[0]
            val c1 = g[1 % g.size]
            val cx = w * (0.5f + 0.12f * sin(p))
            val cy = h * 0.24f
            drawCircle(
                brush = Brush.radialGradient(listOf(c0.copy(alpha = cap), Color.Transparent), center = Offset(cx, cy), radius = w * 0.95f),
                radius = w * 0.95f,
                center = Offset(cx, cy)
            )
            val cx2 = w * 0.85f
            val cy2 = h * (0.82f + 0.03f * cos(p))
            drawCircle(
                brush = Brush.radialGradient(listOf(c1.copy(alpha = cap * 0.6f), Color.Transparent), center = Offset(cx2, cy2), radius = w * 0.65f),
                radius = w * 0.65f,
                center = Offset(cx2, cy2)
            )
            drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, c0.copy(alpha = cap * 1.2f), Color.Transparent)),
                size = Size(w, 2.dp.toPx())
            )
        }
    }
}

/** Fondo ambiental de Juli Experience (si está desactivado, no dibuja nada). */
fun Modifier.ambientBackdrop(a: AmbientState?): Modifier =
    if (a == null || !a.enabled) this else this.drawBehind { drawAmbient(a) }

/** Halo de luz tras una portada. Más marcado en el estilo Glow. */
fun Modifier.coverGlow(color: Color, strength: Float): Modifier = this.drawBehind {
    val r = size.maxDimension * 0.85f
    drawCircle(
        brush = Brush.radialGradient(listOf(color.copy(alpha = strength.coerceIn(0f, 0.7f)), Color.Transparent), center = center, radius = r),
        radius = r,
        center = center
    )
}

/** Superficie de pantalla completa: color de fondo + luz ambiental. */
@Composable
fun AmbientSurface(modifier: Modifier = Modifier, scheme: ColorScheme, content: @Composable () -> Unit) {
    val a = LocalAmbient.current
    Box(modifier.fillMaxSize().drawBehind { drawRect(scheme.background) }.ambientBackdrop(a)) { content() }
}
