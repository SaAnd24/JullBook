package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Images
import com.jullbook.app.data.Progress
import com.jullbook.app.data.RarNotSupported
import com.jullbook.app.data.SeekableZip
import com.jullbook.app.data.ZEntry
import com.jullbook.app.data.volLabel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable
import kotlin.math.roundToInt

class ComicSource(private val zip: SeekableZip, private val pages: List<ZEntry>) : PageSource, Closeable {
    override val count: Int = pages.size
    private val ratios = mutableStateListOf<Float>().also { l -> repeat(count) { l.add(0.7f) } }
    private val loaded = BooleanArray(count)
    @Volatile private var closed = false

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun ratio(i: Int): Float = ratios[i]

    override fun cached(i: Int, widthPx: Int): Bitmap? = cache.get("$i@$widthPx")

    override suspend fun loadRatio(i: Int) {
        if (closed || i !in 0 until count || loaded[i]) return
        try {
            ratios[i] = Images.pageRatio(zip, pages[i])
            loaded[i] = true
        } catch (ignored: Throwable) {
        }
    }

    override suspend fun bitmap(i: Int, widthPx: Int): Bitmap? {
        if (closed || i !in 0 until count) return null
        val key = "$i@$widthPx"
        cache.get(key)?.let { return it }
        return try {
            val bmp = Images.decodeSampled(zip.read(pages[i]), widthPx, Bitmap.Config.RGB_565)
            if (bmp != null) {
                if (bmp.height > 0) {
                    ratios[i] = bmp.width.toFloat() / bmp.height
                    loaded[i] = true
                }
                cache.put(key, bmp)
            }
            bmp
        } catch (ignored: Throwable) {
            null
        }
    }

    override fun close() {
        closed = true
        zip.close()
    }
}

@Composable
fun ComicReader(book: Book, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var source by remember { mutableStateOf<ComicSource?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(book.id) {
        withContext(Dispatchers.IO) {
            try {
                val z = SeekableZip.open(ctx, Uri.parse(book.uri))
                val imgs = z.images()
                if (imgs.isEmpty()) {
                    z.close()
                    error = "No se encontraron imágenes en este archivo."
                } else {
                    source = ComicSource(z, imgs)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: RarNotSupported) {
                error = "Este archivo usa compresión RAR, que JullBook aún no admite. " +
                    "Conviértelo a CBZ para poder leerlo."
            } catch (ignored: Throwable) {
                error = "No se pudo abrir este cómic. El archivo puede estar dañado."
            }
        }
    }
    DisposableEffect(Unit) { onDispose { source?.close() } }

    val src = source
    val err = error
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            err != null -> ReaderMessage(err, onBack)
            src == null -> ReaderLoading()
            else -> ComicBody(book, src, start, vm, onBack)
        }
    }
}

@Composable
private fun ComicBody(book: Book, src: ComicSource, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val reporter = rememberReporter(book.id, vm)
    val count = src.count
    val zoom = remember { ZoomState() }
    var vertical by remember { mutableStateOf(vm.prefs.comicVertical) }
    var chrome by remember { mutableStateOf(true) }
    var page by remember { mutableIntStateOf((start?.pos ?: 0).coerceIn(0, count - 1)) }
    var fracNow by remember { mutableStateOf(start?.frac ?: 0f) }
    var seek by remember { mutableStateOf<Int?>(null) }

    ReaderWindowEffects(hideBars = !chrome)

    val title = vm.library.books[book.id]?.let { b ->
        val s = b.series
        if (s != null && b.number != null) "$s ${volLabel(b)}" else b.title
    } ?: book.title

    Box(Modifier.fillMaxSize()) {
        key(vertical) {
            if (vertical) {
                PageListReader(
                    source = src,
                    startPage = page,
                    startFrac = fracNow,
                    zoom = zoom,
                    seek = seek,
                    onSeekDone = { seek = null },
                    quality = 1f,
                    spacing = 0.dp,
                    paper = Color(0xFF151515),
                    onTap = { chrome = !chrome },
                    onPos = { p, f, pct ->
                        page = p
                        fracNow = f
                        reporter.update(p, 0, f, pct)
                    }
                )
            } else {
                ComicPaged(
                    source = src,
                    startPage = page,
                    zoom = zoom,
                    seek = seek,
                    onSeekDone = { seek = null },
                    onTap = { chrome = !chrome },
                    onPos = { p ->
                        page = p
                        fracNow = 0f
                        reporter.update(p, 0, 0f, pagePercent(p, 0f, count, false, true))
                    }
                )
            }
        }
        ReaderChrome(
            visible = chrome,
            title = title,
            subtitle = "Página ${page + 1} de $count",
            onBack = onBack,
            bottom = {
                PageSlider(page, count) { seek = it }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    TextButton(onClick = {
                        vertical = !vertical
                        vm.prefs.comicVertical = vertical
                    }) {
                        Text(if (vertical) "Cambiar a modo páginas" else "Cambiar a lectura vertical")
                    }
                }
            }
        )
    }
}

@Composable
private fun ComicPaged(
    source: ComicSource,
    startPage: Int,
    zoom: ZoomState,
    seek: Int?,
    onSeekDone: () -> Unit,
    onTap: () -> Unit,
    onPos: (Int) -> Unit
) {
    val count = source.count
    val pager = rememberPagerState(initialPage = startPage.coerceIn(0, count - 1)) { count }
    val zoomed by remember { derivedStateOf { zoom.scale > 1.01f } }

    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage }.collect { p ->
            zoom.reset()
            onPos(p)
        }
    }
    LaunchedEffect(seek) {
        if (seek != null) {
            pager.scrollToPage(seek.coerceIn(0, count - 1))
            onSeekDone()
        }
    }

    ZoomBox(state = zoom, scrollMode = false, onTap = onTap, onScrollBy = {}) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = (constraints.maxWidth * 1.5f).roundToInt().coerceAtLeast(1)
            HorizontalPager(
                state = pager,
                modifier = Modifier.fillMaxSize(),
                userScrollEnabled = !zoomed,
                beyondViewportPageCount = 1
            ) { i ->
                val bmp by produceState<ImageBitmap?>(source.cached(i, w)?.asImageBitmap(), source, i, w) {
                    if (value == null) {
                        value = withContext(Dispatchers.IO) { source.bitmap(i, w) }?.asImageBitmap()
                    }
                }
                val b = bmp
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            // Efecto suave de pasar página: la que sale se atenúa y se encoge un poco.
                            val off = kotlin.math.abs((pager.currentPage - i) + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                            val sc = 1f - 0.06f * off
                            scaleX = sc
                            scaleY = sc
                            alpha = 1f - 0.35f * off
                        }
                ) {
                    if (b != null) {
                        Image(b, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                }
            }
        }
    }
}
