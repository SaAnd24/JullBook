package com.jullbook.app.ui.reader

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlin.math.roundToInt

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Mantiene la pantalla encendida y, si se pide, oculta las barras del sistema (modo inmersivo). */
@Composable
fun ReaderWindowEffects(hideBars: Boolean) {
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(view, hideBars) {
        val window = view.context.findActivity()?.window
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (hideBars) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { }
    }
    DisposableEffect(view) {
        onDispose {
            val window = view.context.findActivity()?.window
            if (window != null) WindowCompat.getInsetsController(window, view).show(WindowInsetsCompat.Type.systemBars())
        }
    }
}

@Composable
fun BoxScope.ReaderChrome(
    visible: Boolean,
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    bottom: @Composable ColumnScope.() -> Unit = {}
) {
    val scrim = Color(0xE6000000)
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.TopCenter),
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(scrim)
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (subtitle != null) {
                        Text(
                            subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFBBBBBB),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                actions()
            }
        }
    }
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(scrim)
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                bottom()
            }
        }
    }
}

@Composable
fun PageSlider(page: Int, count: Int, onSeek: (Int) -> Unit) {
    if (count <= 1) return
    var drag by remember { mutableStateOf<Float?>(null) }
    val value = drag ?: page.toFloat()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("${value.roundToInt() + 1}", style = MaterialTheme.typography.labelMedium)
        Slider(
            value = value.coerceIn(0f, (count - 1).toFloat()),
            onValueChange = { drag = it },
            onValueChangeFinished = {
                drag?.let { onSeek(it.roundToInt()) }
                drag = null
            },
            valueRange = 0f..(count - 1).toFloat(),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        Text("$count", style = MaterialTheme.typography.labelMedium)
    }
}

/** Guarda la posición en memoria y la escribe en la BD cada 3 s, al pausar y al cerrar el lector. */
class Reporter(private val bookId: Long, private val sink: (Progress) -> Unit) {
    @Volatile
    private var pending: Progress? = null

    fun update(pos: Int, sub: Int, frac: Float, percent: Float) {
        val pc = percent.coerceIn(0f, 1f)
        pending = Progress(
            bookId, pos, sub, frac.coerceIn(0f, 1f), pc,
            System.currentTimeMillis(),
            if (pc >= 0.995f) ST_FINISHED else ST_READING
        )
    }

    fun flush() {
        val p = pending ?: return
        pending = null
        sink(p)
    }
}

@Composable
fun rememberReporter(bookId: Long, vm: AppViewModel): Reporter {
    val r = remember(bookId) { Reporter(bookId) { vm.saveProgress(it) } }
    LaunchedEffect(r) {
        while (true) {
            delay(3000)
            r.flush()
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(r, owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) r.flush() }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            r.flush()
        }
    }
    return r
}

@Composable
fun ReaderMessage(text: String, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, color = Color.White, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onBack) { Text("Volver") }
        }
    }
}

@Composable
fun ReaderLoading(text: String? = null) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            if (text != null) {
                Spacer(Modifier.height(16.dp))
                Text(text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

/** Posición de lectura de una lista de páginas. */
data class ListPos(val index: Int, val frac: Float, val atEnd: Boolean)

fun LazyListState.listPos(count: Int): ListPos? {
    val info = layoutInfo
    val vis = info.visibleItemsInfo
    val first = vis.firstOrNull() ?: return null
    val last = vis.last()
    val frac = (-first.offset.toFloat() / first.size.coerceAtLeast(1)).coerceIn(0f, 1f)
    val atEnd = last.index >= count - 1 && last.offset + last.size <= info.viewportEndOffset + 2
    return ListPos(first.index, frac, atEnd)
}

fun pagePercent(pos: Int, frac: Float, count: Int, atEnd: Boolean, paged: Boolean): Float {
    if (count <= 0) return 0f
    if (atEnd) return 1f
    return if (paged) ((pos + 1f) / count).coerceIn(0f, 1f) else ((pos + frac) / count).coerceIn(0f, 1f)
}

/** Recoloca la lista en (index, frac) cuando el elemento ya está medido. */
suspend fun LazyListState.restoreTo(index: Int, frac: Float) {
    if (frac <= 0f) return
    val item = androidx.compose.runtime.snapshotFlow {
        layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
    }.filterNotNull().first()
    scrollToItem(index, (frac * item.size).roundToInt())
}
