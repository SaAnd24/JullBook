package com.jullbook.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.OrgDialog
import com.jullbook.app.data.Format
import com.jullbook.app.data.naturalCompare

/** Diálogos de organización manual. Solo cambian metadatos de la app; los archivos nunca se tocan. */
@Composable
fun OrgDialogs(vm: AppViewModel) {
    val d = vm.dialog ?: return
    val close = { vm.dialog = null }
    when (d) {
        is OrgDialog.CreateSaga -> NameDialog("Crear saga", close) { vm.createSaga(it); close() }
        is OrgDialog.NewSagaFor -> NameDialog("Nueva saga", close) { vm.createSaga(it, d.bookIds); close() }
        is OrgDialog.BookActions -> BookActionsDialog(vm, d.bookId, close)
        is OrgDialog.MoveTo -> MoveToDialog(vm, d, close)
        is OrgDialog.EditNumber -> NumberDialog(vm, d.bookId, close)
        is OrgDialog.AddVolumes -> AddVolumesDialog(vm, d.seriesKey, close)
        is OrgDialog.DeleteSaga -> {
            val name = vm.library.series[d.seriesKey]?.name ?: ""
            AlertDialog(
                onDismissRequest = close,
                title = { Text("Eliminar saga") },
                text = {
                    Text("Se eliminará la saga \"$name\". Los archivos no se borran: los tomos vuelven a la agrupación automática.")
                },
                confirmButton = { TextButton(onClick = { vm.deleteSaga(d.seriesKey); close() }) { Text("Eliminar") } },
                dismissButton = { TextButton(onClick = close) { Text("Cancelar") } }
            )
        }
    }
}

@Composable
private fun NameDialog(title: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(60) },
                singleLine = true,
                label = { Text("Nombre de la saga") }
            )
        },
        confirmButton = {
            TextButton(onClick = { onOk(name) }, enabled = name.isNotBlank()) { Text("Crear") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun BookActionsDialog(vm: AppViewModel, bookId: Long, onDismiss: () -> Unit) {
    val lib = vm.library
    val book = lib.books[bookId]
    if (book == null || book.format != Format.COMIC) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    val inSeries = lib.bookSeries[bookId]
    val overridden = bookId in lib.overridden
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(book.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                ActionRow(if (inSeries != null) "Mover a otra saga…" else "Añadir a saga…") {
                    vm.dialog = OrgDialog.MoveTo(listOf(bookId))
                }
                if (inSeries != null) {
                    ActionRow("Quitar de la saga") { vm.removeFromSaga(listOf(bookId)); onDismiss() }
                }
                ActionRow("Corregir número…") { vm.dialog = OrgDialog.EditNumber(bookId) }
                if (overridden) {
                    ActionRow("Restablecer organización") { vm.resetOrganization(bookId); onDismiss() }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
private fun ActionRow(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp)
    )
}

@Composable
private fun MoveToDialog(vm: AppViewModel, d: OrgDialog.MoveTo, onDismiss: () -> Unit) {
    val lib = vm.library
    val currentKeys = d.bookIds.mapNotNull { lib.bookSeries[it]?.key }.toSet()
    val targets = lib.series.values
        .filter { it.key !in currentKeys || currentKeys.size > 1 }
        .sortedWith { a, b -> naturalCompare(a.name, b.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mover a saga") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                item {
                    ActionRow("+ Nueva saga…") { vm.dialog = OrgDialog.NewSagaFor(d.bookIds) }
                }
                items(targets, key = { it.key }) { s ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.moveToSeries(s.key, d.bookIds); onDismiss() }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(s.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            (if (s.isManual) "Saga manual · " else "") + "${s.volumes.size} tomos",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun NumberDialog(vm: AppViewModel, bookId: Long, onDismiss: () -> Unit) {
    val book = vm.library.books[bookId]
    if (book == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    var text by remember { mutableStateOf(book.number?.toString() ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Corregir número") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { v -> text = v.filter { it.isDigit() }.take(4) },
                    singleLine = true,
                    label = { Text("Número de tomo") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text(
                    "Déjalo vacío para volver al número detectado.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.setBookNumber(bookId, text.toIntOrNull()); onDismiss() }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddVolumesDialog(vm: AppViewModel, seriesKey: String, onDismiss: () -> Unit) {
    val lib = vm.library
    val series = lib.series[seriesKey]
    if (series == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    val all = remember(lib) {
        lib.books.values
            .filter { it.format == Format.COMIC && lib.bookSeries[it.id]?.key != seriesKey }
            .sortedWith { a, b -> naturalCompare(a.fileName, b.fileName) }
    }
    val q = query.trim().lowercase()
    val list = if (q.isEmpty()) all else all.filter { it.fileName.lowercase().contains(q) || it.title.lowercase().contains(q) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir a ${series.name}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    label = { Text("Buscar") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (list.isEmpty()) {
                    Text(
                        "No hay cómics disponibles.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
                LazyColumn(Modifier.heightIn(max = 340.dp).padding(top = 8.dp)) {
                    items(list, key = { it.id }) { b ->
                        val on = b.id in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected = if (on) selected - b.id else selected + b.id },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Checkbox(checked = on, onCheckedChange = { selected = if (on) selected - b.id else selected + b.id })
                            Column(Modifier.weight(1f)) {
                                Text(b.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val other = lib.bookSeries[b.id]?.name
                                if (other != null) {
                                    Text(
                                        "En: $other",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { vm.moveToSeries(seriesKey, selected.toList()); onDismiss() },
                enabled = selected.isNotEmpty()
            ) { Text("Añadir (${selected.size})") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
