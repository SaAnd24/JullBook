package com.jullbook.app.data

import kotlin.random.Random

/** Situaciones en las que Juli puede decir algo. Todo el texto vive en la app: nada de internet. */
enum class JuliCtx {
    SURPRISE_UNREAD, SURPRISE_ABANDONED, SURPRISE_SERIES, SURPRISE_LONG, SURPRISE_CURRENT,
    START, FINISH_BOOK, FINISH_VOLUME, FINISH_COLLECTION, FINISH_SAGA,
    RETURN_LONG, REREAD_VOLUME, REREAD_COLLECTION, BINGE, STREAK, NEW_READ, RESUME, DISCOVER,
    REREAD_COUNT, TIME_MILESTONE, BIG_LIBRARY, MANY_PENDING, RARE, GREETING
}

/** Datos con los que se rellenan los marcadores del comentario. */
class JuliParams(
    val title: String? = null,
    val coll: String? = null,
    val n: Int = 0,
    val days: Int = 0,
    val hours: Int = 0,
    val vols: Int = 0,
    val volWord: String = "tomos",
    val times: Int = 0,
    val name: String = ""
)

object Juli {
    private val ALL: Map<JuliCtx, List<String>> = SURPRISE_LINES + SITUATION_LINES
    private const val HISTORY_MAX = 120

    val surpriseTotal: Int get() = SURPRISE_LINES.values.sumOf { it.size }
    val situationTotal: Int get() = SITUATION_LINES.values.sumOf { it.size }

    private fun usable(text: String, p: JuliParams): Boolean =
        (!text.contains("{t}") || p.title != null) &&
            (!text.contains("{c}") || p.coll != null) &&
            (!text.contains("{d}") || p.days > 0) &&
            (!text.contains("{h}") || p.hours > 0) &&
            (!text.contains("{v}") || p.vols > 0) &&
            (!text.contains("{x}") || p.times > 0) &&
            (!text.contains("{n}") || p.n > 0)

    fun format(text: String, p: JuliParams): String {
        val days = if (p.days == 1) "1 día" else "${p.days} días"
        val hours = if (p.hours == 1) "1 hora" else "${p.hours} horas"
        val word = if (p.vols == 1) p.volWord.removeSuffix("s") else p.volWord
        val times = if (p.times == 1) "1 vez" else "${p.times} veces"
        return text
            .replace("{t}", p.title ?: "esto")
            .replace("{c}", p.coll ?: "la colección")
            .replace("{name}", p.name.ifBlank { "lector" })
            .replace("{d}", days)
            .replace("{h}", hours)
            .replace("{v}", "${p.vols} $word")
            .replace("{x}", times)
            .replace("{n}", "${p.n}")
    }

    /**
     * Elige un comentario del contexto evitando los usados hace poco (el historial se guarda en el dispositivo).
     * Devuelve null si el contexto no tiene líneas.
     */
    fun pick(ctx: JuliCtx, p: JuliParams, prefs: Prefs, rnd: Random = Random.Default): String? {
        val pool = ALL[ctx] ?: return null
        if (pool.isEmpty()) return null
        val hist = prefs.juliHistory.split(',').filter { it.isNotEmpty() }
        val recent = hist.toHashSet()
        val own = hist.filter { it.startsWith(ctx.name + ":") }

        fun candidates(avoid: Set<String>): List<Int> =
            pool.indices.filter { usable(pool[it], p) && (ctx.name + ":" + it) !in avoid }

        var c = candidates(recent)
        if (c.isEmpty()) c = candidates(own.takeLast((pool.size / 2).coerceAtLeast(1)).toSet())
        if (c.isEmpty()) c = pool.indices.filter { usable(pool[it], p) }
        if (c.isEmpty()) c = pool.indices.toList()
        val i = c[rnd.nextInt(c.size)]
        val id = ctx.name + ":" + i
        prefs.juliHistory = (hist + id).takeLast(HISTORY_MAX).joinToString(",")
        return format(pool[i], p)
    }

    /** ¿Puede Juli hablar ahora? Las celebraciones ([high]) siempre, salvo que esté en silencio. */
    fun mayTalk(prefs: Prefs, high: Boolean, now: Long): Boolean {
        if (prefs.juliTalk <= 0) return false
        if (high) return true
        val gap = if (prefs.juliTalk >= 2) 2 * 60_000L else 8 * 60_000L
        return now - prefs.lastSpoke > gap
    }
}
