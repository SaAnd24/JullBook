package com.jullbook.app.ui

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullbook.app.AppViewModel
import com.jullbook.app.discover.DiscoverViewModel
import com.jullbook.app.discover.DlStatus
import com.jullbook.app.discover.DownloadRequest
import com.jullbook.app.discover.FolderRequest
import com.jullbook.app.discover.Lang
import com.jullbook.app.discover.SearchResult
import com.jullbook.app.discover.SearchStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Pantalla secundaria de búsqueda y descarga (se abre desde el final de Inicio; "atrás" vuelve a Inicio). */
@Composable
fun DiscoverScreen(app: AppViewModel, onBack: () -> Unit) {
    val dvm: DiscoverViewModel = viewModel()
    val listState = rememberLazyListState()
    var sourcesOpen by remember { mutableStateOf(false) }
    val sel = dvm.selected
    // Con el lector abierto encima, "atrás" es del lector (lo gestiona la app); aquí solo cierra la ficha.
    val readerOpen = app.reading != null && app.readerVisible
    BackHandler(enabled = sel != null && !readerOpen) { dvm.closeDetail() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) dvm.onFolderPicked(app, uri)
    }

    Box(Modifier.fillMaxSize()) {
        if (sel == null) {
            SearchPane(dvm, app, listState, onBack, onSources = { sourcesOpen = true })
        } else {
            DetailPane(dvm, app)
        }
    }

    val fr = dvm.folderRequest
    if (fr != null) {
        FolderDialog(fr, onPick = { picker.launch(fr.expected?.let { Uri.parse(it) }) }, onCancel = { dvm.cancelFolderRequest() })
    }
    if (sourcesOpen) SourcesDialog(dvm) { sourcesOpen = false }
}

// ---------------------------------------------------------------------------------------------
// Búsqueda
// ---------------------------------------------------------------------------------------------

@Composable
private fun SearchPane(
    dvm: DiscoverViewModel,
    app: AppViewModel,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onBack: () -> Unit,
    onSources: () -> Unit
) {
    val focus = LocalFocusManager.current
    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") }
                Text(
                    "Buscar libros y cómics",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = dvm.text,
                    onValueChange = { dvm.text = it },
                    singleLine = true,
                    placeholder = { Text("Buscar libros, autores, cómics…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (dvm.text.isNotEmpty()) {
                            IconButton(onClick = { dvm.text = "" }) { Icon(Icons.Default.Close, contentDescription = "Borrar") }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        focus.clearFocus()
                        dvm.search()
                    }),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    var menu by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { menu = true }) {
                            Text("Idioma: ${dvm.lang?.label ?: "Todos"}")
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Todos") }, onClick = { dvm.selectLang(null); menu = false })
                            for (l in Lang.entries) {
                                DropdownMenuItem(text = { Text(l.label) }, onClick = { dvm.selectLang(l); menu = false })
                            }
                        }
                    }
                    val active = dvm.sourceList.count { it.enabled }
                    TextButton(onClick = onSources) { Text("Fuentes ($active)") }
                }
                Button(onClick = { focus.clearFocus(); dvm.search() }, modifier = Modifier.fillMaxWidth()) { Text("Buscar") }
            }
        }
        item { StatusBlock(dvm) }
        items(dvm.results, key = { it.sourceId + "|" + it.id }) { r -> ResultRow(dvm, app, r) }
        if (dvm.status == SearchStatus.DONE && dvm.hasMore) {
            item {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    if (dvm.loadingMore) CircularProgressIndicator(Modifier.size(28.dp))
                    else OutlinedButton(onClick = { dvm.loadMore() }) { Text("Cargar más") }
                }
            }
        }
        if (dvm.status == SearchStatus.DONE && dvm.warnings.isNotEmpty()) {
            item {
                Text(
                    "No se pudo consultar: " + dvm.warnings.joinToString("; "),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun StatusBlock(dvm: DiscoverViewModel) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (dvm.status) {
            SearchStatus.IDLE -> Text(
                "Escribe un título, un autor o una palabra clave, o elige un idioma para descubrir contenido.",
                style = MaterialTheme.typography.bodyMedium, color = muted
            )
            SearchStatus.LOADING -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Text("Buscando…", style = MaterialTheme.typography.bodyMedium, color = muted)
            }
            SearchStatus.OFFLINE -> {
                Text("Sin conexión. Conéctate a Internet para buscar y descargar.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                OutlinedButton(onClick = { dvm.search() }) { Text("Reintentar") }
            }
            SearchStatus.FAILED -> {
                Text("No se pudo consultar la fuente.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                for (w in dvm.warnings) Text(w, style = MaterialTheme.typography.labelMedium, color = muted)
                OutlinedButton(onClick = { dvm.search() }) { Text("Reintentar") }
            }
            SearchStatus.DONE -> {
                if (dvm.results.isEmpty()) {
                    val q = dvm.lastQuery
                    val ql = q?.lang
                    val qt = q?.text ?: ""
                    val msg = if (ql != null) {
                        val forText = if (qt.isNotEmpty()) " para «$qt»" else ""
                        if (dvm.hiddenByLang > 0) "No hay resultados en ${ql.label}$forText. Hay ${dvm.hiddenByLang} en otros idiomas o sin idioma indicado."
                        else "No hay resultados en ${ql.label}$forText."
                    } else {
                        "Sin resultados para «$qt»."
                    }
                    Text(msg, style = MaterialTheme.typography.bodyMedium, color = muted)
                } else if (dvm.hiddenByLang > 0) {
                    Text(
                        "Se ocultaron ${dvm.hiddenByLang} resultados de otros idiomas o sin idioma indicado.",
                        style = MaterialTheme.typography.labelMedium, color = muted
                    )
                }
            }
        }
    }
}

private fun langLabel(r: SearchResult): String {
    if (r.langs.isNotEmpty()) {
        return r.langs.take(2).joinToString(" · ") { l ->
            if (l == Lang.OTHER) "🌐 Otro idioma (${r.languageRaw?.trim()?.take(24)?.uppercase() ?: "?"})" else l.flag + " " + l.label
        }
    }
    val f = r.langFromFilter
    if (f != null) return f.flag + " " + f.label + " (según la fuente)"
    return "Idioma no especificado"
}

@Composable
private fun RemoteCover(dvm: DiscoverViewModel, r: SearchResult, modifier: Modifier, big: Boolean) {
    val url = if (big) (r.coverUrl ?: r.thumbUrl) else (r.thumbUrl ?: r.coverUrl)
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = if (url == null) null else withContext(Dispatchers.IO) { dvm.loadCover(r.sourceId, url)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = r.title, modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        GenericCover(r.title, r.downloads.firstOrNull()?.format?.libFormat, false, modifier)
    }
}

@Composable
private fun ResultRow(dvm: DiscoverViewModel, app: AppViewModel, r: SearchResult) {
    Row(
        Modifier.fillMaxWidth().clickable { dvm.open(r) }.padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        RemoteCover(dvm, r, Modifier.size(width = 72.dp, height = 104.dp).clip(RoundedCornerShape(8.dp)), false)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                r.title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            r.author?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(langLabel(r), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.genres.isNotEmpty()) {
                Text(
                    r.genres.take(2).joinToString(" · "), style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            val fmts = r.downloads.joinToString(" · ") { if (it.textOnly) "EPUB (texto)" else it.format.label }
            Text(
                listOf(fmts, r.sourceName).filter { it.isNotEmpty() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(6.dp))
            val only = r.downloads.singleOrNull()
            if (only != null) {
                DownloadBlock(dvm, app, DownloadRequest(r.sourceId, r.title, r.author, only.format, only.url, only.size, only.textOnly))
            } else {
                OutlinedButton(onClick = { dvm.open(r) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) { Text("Descargar") }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Descarga (botón, progreso y estado)
// ---------------------------------------------------------------------------------------------

@Composable
private fun DownloadBlock(dvm: DiscoverViewModel, app: AppViewModel, req: DownloadRequest) {
    val ctx = LocalContext.current
    val st = dvm.downloads[req.key]
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    if (st == null || st.status == DlStatus.CANCELLED) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (st != null) Text("Descarga cancelada", style = MaterialTheme.typography.labelMedium, color = muted)
            Button(onClick = { dvm.download(app, req) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) { Text("Descargar") }
        }
        return
    }
    when {
        st.isActive -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val label = when (st.status) {
                DlStatus.CONNECTING -> "Conectando…"
                DlStatus.SAVING -> "Guardando en tu biblioteca…"
                else -> "Descargando…"
            }
            if (st.total > 0 && st.status != DlStatus.CONNECTING) {
                val frac = (st.done.toFloat() / st.total).coerceIn(0f, 1f)
                Text("$label ${(frac * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground)
                LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
                Text(
                    Formatter.formatShortFileSize(ctx, st.done) + " / " + Formatter.formatShortFileSize(ctx, st.total),
                    style = MaterialTheme.typography.labelSmall, color = muted
                )
            } else {
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground)
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
                if (st.done > 0) {
                    Text(Formatter.formatShortFileSize(ctx, st.done), style = MaterialTheme.typography.labelSmall, color = muted)
                }
            }
            if (st.status != DlStatus.SAVING) {
                TextButton(onClick = { dvm.cancelDownload(req.key) }) { Text("Cancelar") }
            }
        }
        st.status == DlStatus.FAILED -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(st.message ?: "Descarga fallida", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
            OutlinedButton(onClick = { dvm.download(app, req) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) { Text("Reintentar") }
        }
        else -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val name = st.fileName
            val book = if (name == null) null else app.library.books.values.firstOrNull { it.fileName.equals(name, ignoreCase = true) }
            Text(
                if (st.status == DlStatus.DONE) "Descarga completada" else (st.message ?: "Ya está en tu biblioteca"),
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
            )
            if (book != null) {
                Button(onClick = { app.openBook(book) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) { Text("Leer") }
            } else if (st.status == DlStatus.DONE) {
                Text("Añadiéndolo a la biblioteca…", style = MaterialTheme.typography.labelSmall, color = muted)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Ficha
// ---------------------------------------------------------------------------------------------

@Composable
private fun DetailPane(dvm: DiscoverViewModel, app: AppViewModel) {
    val ctx = LocalContext.current
    val r = dvm.selected ?: return
    val d = dvm.detail
    val res = d?.result ?: r
    val downloads = d?.downloads ?: res.downloads
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { dvm.closeDetail() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver a los resultados") }
                Text("Ficha", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                RemoteCover(dvm, res, Modifier.size(width = 120.dp, height = 176.dp).clip(RoundedCornerShape(10.dp)), true)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(res.title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                    res.author?.let { Text(it, style = MaterialTheme.typography.bodyLarge, color = muted) }
                    Text(langLabel(res), style = MaterialTheme.typography.bodyMedium, color = muted)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (res.genres.isNotEmpty()) FactLine("Género", res.genres.joinToString(", "))
                res.year?.let { FactLine("Año", it) }
                FactLine("Fuente", res.sourceName)
            }
        }
        res.description?.let { desc ->
            item {
                Text(
                    desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
        }
        item { SectionTitle("Descargar") }
        if (dvm.detailLoading) {
            item {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Cargando formatos…", style = MaterialTheme.typography.bodyMedium, color = muted)
                }
            }
        } else if (downloads.isEmpty()) {
            item {
                Text(
                    if (d?.error != null) "No se pudo cargar la ficha: ${d.error}"
                    else "Esta fuente no ofrece un formato compatible (EPUB, PDF, CBZ o CBR) para este elemento.",
                    style = MaterialTheme.typography.bodyMedium, color = muted,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
        } else {
            items(downloads, key = { it.format.name + it.textOnly }) { dl ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val sz = dl.size?.let { " · ≈ " + Formatter.formatShortFileSize(ctx, it) } ?: ""
                    Text(
                        dl.format.label + (if (dl.textOnly) " · solo texto (ligero)" else "") + sz,
                        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground
                    )
                    if (dl.textOnly) {
                        Text(
                            "Sin imágenes ni maquetación: texto reconocido por OCR, puede tener errores. Pesa una fracción.",
                            style = MaterialTheme.typography.bodySmall, color = muted
                        )
                    }
                    DownloadBlock(dvm, app, DownloadRequest(res.sourceId, res.title, res.author, dl.format, dl.url, dl.size, dl.textOnly))
                }
            }
        }
    }
}

@Composable
private fun FactLine(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(64.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
    }
}

// ---------------------------------------------------------------------------------------------
// Diálogos
// ---------------------------------------------------------------------------------------------

@Composable
private fun FolderDialog(fr: FolderRequest, onPick: () -> Unit, onCancel: () -> Unit) {
    val what = if (fr.isBooks) "libros" else "cómics"
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(if (fr.expected == null) "Elige una carpeta" else "Permiso para guardar") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (fr.expected == null) {
                        "Para guardar la descarga, JullBook necesita una carpeta de $what. El archivo se guardará ahí y aparecerá en tu biblioteca."
                    } else {
                        "Para guardar la descarga en tu carpeta de $what, JullBook necesita permiso de escritura. Elige la misma carpeta que ya usas en tu biblioteca."
                    }
                )
                fr.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = { TextButton(onClick = onPick) { Text("Elegir carpeta") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancelar") } }
    )
}

private fun hostOf(url: String): String = runCatching { java.net.URL(url.replace("{searchTerms}", "x")).host }.getOrDefault(url)

@Composable
private fun SourcesDialog(dvm: DiscoverViewModel, onClose: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Fuentes") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (row in dvm.sourceList) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = row.enabled, onCheckedChange = { dvm.toggleSource(row.cfg.id, it) })
                        Column(Modifier.weight(1f)) {
                            Text(row.cfg.name, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                if (row.cfg.builtIn) (row.cfg.note ?: "Catálogo público") else hostOf(row.cfg.url),
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!row.cfg.builtIn) {
                            IconButton(onClick = { dvm.removeSource(row.cfg.id) }) { Icon(Icons.Default.Delete, contentDescription = "Quitar fuente") }
                        }
                    }
                }
                Text(
                    "Puedes añadir cualquier catálogo OPDS (https) al que tengas acceso: tu propio servidor, Calibre-Web, Komga, Kavita o una biblioteca autorizada.",
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(onClick = { adding = true }) { Text("Añadir fuente") }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Listo") } }
    )
    if (adding) AddSourceDialog(dvm) { adding = false }
}

@Composable
private fun AddSourceDialog(dvm: DiscoverViewModel, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Añadir fuente") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, singleLine = true, label = { Text("Nombre") })
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, singleLine = true,
                    label = { Text("Catálogo OPDS (https://…)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                OutlinedTextField(value = user, onValueChange = { user = it }, singleLine = true, label = { Text("Usuario (opcional)") })
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true,
                    label = { Text("Contraseña (opcional)") },
                    visualTransformation = PasswordVisualTransformation()
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = dvm.addSource(name, url, user, pass)
                if (e == null) onClose() else err = e
            }) { Text("Añadir") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancelar") } }
    )
}
