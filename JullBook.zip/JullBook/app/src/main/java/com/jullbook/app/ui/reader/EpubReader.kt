package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Block
import com.jullbook.app.data.Book
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.Images
import com.jullbook.app.data.ImageBlock
import com.jullbook.app.data.Progress
import com.jullbook.app.data.TextBlock
import com.jullbook.app.data.pctText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.withContext

internal class EpubTheme(val bg: Color, val fg: Color)

private val EPUB_THEMES = listOf(
    EpubTheme(Color(0xFFFAF8F3), Color(0xFF1C1B19)), // Claro
    EpubTheme(Color(0xFF000000), Color(0xFFC8C4BA)), // Oscuro
    EpubTheme(Color(0xFFF1E6CC), Color(0xFF4B3B2A))  // Sepia
)

private val MARGINS = listOf(12, 24, 40)

@Composable
fun EpubReader(book: Book, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var session by remember { mutableStateOf<EpubSession?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(book.id) {
        withContext(Dispatchers.IO) {
            try {
                session = EpubSession.open(ctx, Uri.parse(book.uri))
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                error = "No se pudo abrir este EPUB. El archivo puede estar dañado."
            }
        }
    }
    DisposableEffect(Unit) { onDispose { session?.close() } }

    val s = session
    val err = error
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            err != null -> ReaderMessage(err, onBack)
            s == null -> ReaderLoading()
            s.info.spine.isEmpty() -> ReaderMessage("Este EPUB no tiene contenido legible.", onBack)
            else -> EpubBody(book, s, start, vm, onBack)
        }
    }
}

@Composable
private fun EpubBody(book: Book, s: EpubSession, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val prefs = vm.prefs
    val reporter = rememberReporter(book.id, vm)
    val tick = rememberPageTick()
    var lastPageKey by remember { mutableStateOf<Long?>(null) }
    val chapters = s.info.spine.size
    val density = LocalDensity.current
    val measurer = rememberTextMeasurer(cacheSize = 8)
    val pag = remember(s) { EpubPaginator(s, measurer) }
    val anchor = remember { Anchor(start?.sub ?: 0, start?.frac ?: 0f) }

    var target by remember { mutableIntStateOf((start?.pos ?: 0).coerceIn(0, chapters - 1)) }
    var shown by remember { mutableStateOf<Shown?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var fontSize by remember { mutableFloatStateOf(prefs.epubFont) }
    var margin by remember { mutableIntStateOf(prefs.epubMargin.coerceIn(0, 2)) }
    var themeSel by remember { mutableIntStateOf(prefs.epubTheme) }
    var chrome by remember { mutableStateOf(true) }
    var sheet by remember { mutableIntStateOf(0) }
    var percent by remember { mutableFloatStateOf(start?.percent ?: 0f) }

    // "Auto" usa el tema que eligió el usuario en JullBook (estable: Juli Experience nunca llega al lector).
    val scheme = MaterialTheme.colorScheme
    val theme = if (themeSel in 0..2) EPUB_THEMES[themeSel] else EpubTheme(scheme.background, scheme.onBackground)

    ReaderWindowEffects(hideBars = !chrome && sheet == 0)

    // Configuración de paginación: tamaño real de la pantalla, fuente y márgenes.
    val cfg = remember(size, fontSize, margin, density) {
        if (size.width <= 0 || size.height <= 0) {
            null
        } else {
            val top = with(density) { PAGE_TOP_DP.dp.toPx() }.roundToInt()
            val bottom = with(density) { PAGE_BOTTOM_DP.dp.toPx() }.roundToInt()
            PageCfg(size.width, size.height - top - bottom, fontSize, with(density) { MARGINS[margin].dp.toPx() }.roundToInt(), density)
        }
    }

    // Pagina el capítulo pedido. Al cambiar fuente/márgenes se espera un instante (el deslizador no repagina en cada tick)
    // y se conserva la página actual hasta que la nueva paginación está lista.
    LaunchedEffect(target, cfg) {
        val c = cfg ?: return@LaunchedEffect
        val cached = pag.peek(target, c)
        val pages = cached ?: run {
            if (shown?.ch == target) delay(200)
            pag.get(target, c)
        }
        shown = Shown(target, c, pages)
    }

    fun goTo(i: Int, atEnd: Boolean = false) {
        sheet = 0
        val t = i.coerceIn(0, chapters - 1)
        if (t == target) return
        anchor.sub = 0
        anchor.frac = 0f
        anchor.atEnd = atEnd
        target = t
    }

    val cur = shown?.ch ?: target

    Box(Modifier.fillMaxSize().background(theme.bg).onSizeChanged { size = it }) {
        val sh = shown
        if (sh == null) {
            ReaderLoading()
        } else {
            key(sh) {
                val prevPage by produceState<EpubPage?>(if (sh.ch > 0) pag.peek(sh.ch - 1, sh.cfg)?.lastOrNull() else null) {
                    if (value == null && sh.ch > 0) value = pag.get(sh.ch - 1, sh.cfg).lastOrNull()
                }
                val nextPage by produceState<EpubPage?>(if (sh.ch < chapters - 1) pag.peek(sh.ch + 1, sh.cfg)?.firstOrNull() else null) {
                    if (value == null && sh.ch < chapters - 1) value = pag.get(sh.ch + 1, sh.cfg).firstOrNull()
                }
                ChapterPager(
                    session = s,
                    shown = sh,
                    prev = prevPage,
                    next = nextPage,
                    initial = remember { pageIndexFor(sh.pages, anchor) },
                    theme = theme,
                    onTap = { chrome = !chrome },
                    onPage = { i, count, page ->
                        val pk = sh.ch * 100_000L + i
                        if (lastPageKey != null && lastPageKey != pk) tick()
                        lastPageKey = pk
                        anchor.sub = page.sub
                        anchor.frac = page.frac
                        anchor.atEnd = false
                        val pct = s.percentAt(sh.ch, (i + 1f) / count.coerceAtLeast(1))
                        percent = pct
                        reporter.update(sh.ch, page.sub, page.frac, pct)
                    },
                    onSwap = { dir -> goTo(sh.ch + dir, atEnd = dir < 0) }
                )
            }
        }
        ReaderChrome(
            visible = chrome,
            title = book.title,
            subtitle = s.info.titleFor(cur),
            onBack = onBack,
            actions = {
                IconButton(onClick = { sheet = 1 }) {
                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Capítulos")
                }
                IconButton(onClick = { sheet = 2 }) {
                    Icon(Icons.Default.Settings, contentDescription = "Ajustes de lectura")
                }
            },
            bottom = {
                Text(
                    "${pctText(percent)} · Capítulo ${cur + 1} de $chapters",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        )
        if (sheet != 0) {
            EpubSheet(
                kind = sheet,
                session = s,
                cur = cur,
                fontSize = fontSize,
                onFont = { fontSize = it },
                onFontDone = { prefs.epubFont = fontSize },
                margin = margin,
                onMargin = { margin = it; prefs.epubMargin = it },
                themeSel = themeSel,
                onTheme = { themeSel = it; prefs.epubTheme = it },
                onJump = { goTo(it) },
                onDismiss = { sheet = 0 }
            )
        }
    }
}

internal fun toAnnotated(sp: Spanned, base: Float): AnnotatedString = buildAnnotatedString {
    append(sp.toString().replace('\uFFFC', ' '))
    for (span in sp.getSpans(0, sp.length, Any::class.java)) {
        val s = sp.getSpanStart(span)
        val e = sp.getSpanEnd(span)
        if (s < 0 || e <= s) continue
        val style: SpanStyle? = when (span) {
            is StyleSpan -> when (span.style) {
                Typeface.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                Typeface.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                Typeface.BOLD_ITALIC -> SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                else -> null
            }
            is UnderlineSpan -> SpanStyle(textDecoration = TextDecoration.Underline)
            is StrikethroughSpan -> SpanStyle(textDecoration = TextDecoration.LineThrough)
            is RelativeSizeSpan -> SpanStyle(fontSize = (base * span.sizeChange).sp)
            is SuperscriptSpan -> SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = (base * 0.75f).sp)
            is SubscriptSpan -> SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = (base * 0.75f).sp)
            is TypefaceSpan -> if (span.family == "monospace") SpanStyle(fontFamily = FontFamily.Monospace) else null
            else -> null
        }
        if (style != null) addStyle(style, s, e)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EpubSheet(
    kind: Int,
    session: EpubSession,
    cur: Int,
    fontSize: Float,
    onFont: (Float) -> Unit,
    onFontDone: () -> Unit,
    margin: Int,
    onMargin: (Int) -> Unit,
    themeSel: Int,
    onTheme: (Int) -> Unit,
    onJump: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        if (kind == 1) {
            val toc = session.info.toc
            LazyColumn(Modifier.heightIn(max = 480.dp).navigationBarsPadding()) {
                items(toc.size) { i ->
                    val t = toc[i]
                    val active = t.spine == cur
                    Text(
                        t.title,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onJump(t.spine) }
                            .padding(start = (20 + 16 * t.level.coerceIn(0, 4)).dp, end = 20.dp, top = 12.dp, bottom = 12.dp)
                    )
                }
            }
        } else {
            Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
                Text("Tamaño de letra", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = fontSize,
                    onValueChange = onFont,
                    onValueChangeFinished = onFontDone,
                    valueRange = 12f..32f
                )
                Spacer(Modifier.height(8.dp))
                Text("Márgenes", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Estrechos", "Medios", "Anchos").forEachIndexed { i, label ->
                        FilterChip(selected = margin == i, onClick = { onMargin(i) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Tema", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(-1 to "Auto", 0 to "Claro", 1 to "Oscuro", 2 to "Sepia").forEach { (v, label) ->
                        FilterChip(selected = themeSel == v, onClick = { onTheme(v) }, label = { Text(label) })
                    }
                }
            }
        }
    }
}
