package com.jullbook.app.data

import kotlin.random.Random

enum class SurpriseReason(val label: String, val ctx: JuliCtx, val weight: Int) {
    UNREAD("Algo que aún no has leído", JuliCtx.SURPRISE_UNREAD, 3),
    ABANDONED("Una lectura que dejaste a medias", JuliCtx.SURPRISE_ABANDONED, 3),
    SERIES("Retomar una colección", JuliCtx.SURPRISE_SERIES, 3),
    LONG("Hace mucho que no lo abres", JuliCtx.SURPRISE_LONG, 2),
    CURRENT("Sigue con tu lectura actual", JuliCtx.SURPRISE_CURRENT, 2)
}

class Surprise(
    val book: Book,
    val progress: Progress?,
    val series: SeriesItem?,
    val reason: SurpriseReason,
    val comment: String,
    val nonce: Long = System.nanoTime()
)

/** Sorpréndeme: elige algo de la biblioteca LOCAL. Nunca usa internet ni recomendaciones externas. */
object SurpriseEngine {
    private const val DAY = 86_400_000L

    private class Cand(val book: Book, val prog: Progress?, val series: SeriesItem?, val reason: SurpriseReason)

    fun displayTitle(b: Book, s: SeriesItem?): String =
        if (s != null && b.alias == null && !s.isUnnamed) "${s.name} ${volLabel(b)}" else b.title

    private fun volName(b: Book, s: SeriesItem): String =
        b.alias ?: b.number?.let { (if (s.isBooks) "libro " else "tomo ") + it } ?: b.title

    fun pick(lib: Library, prefs: Prefs, exclude: Set<Long>, now: Long, rnd: Random = Random.Default): Surprise? {
        val by = HashMap<SurpriseReason, MutableList<Cand>>()
        fun add(c: Cand) { by.getOrPut(c.reason) { ArrayList() }.add(c) }

        for (item in lib.items) {
            when (item) {
                is SingleItem -> {
                    val p = item.progress
                    val b = item.book
                    if (p == null) add(Cand(b, null, null, SurpriseReason.UNREAD))
                    else if (p.status == ST_READING && p.percent in 0.02f..0.97f) {
                        if (now - p.lastRead > 14 * DAY) add(Cand(b, p, null, SurpriseReason.ABANDONED))
                        else add(Cand(b, p, null, SurpriseReason.CURRENT))
                    } else if (p.status == ST_FINISHED && now - p.lastRead > 90 * DAY) {
                        add(Cand(b, p, null, SurpriseReason.LONG))
                    }
                }
                is SeriesItem -> {
                    val t = item.target()
                    when (LibraryView.statusOf(item)) {
                        StatusFilter.UNSTARTED -> add(Cand(item.volumes.first().book, null, item, SurpriseReason.UNREAD))
                        StatusFilter.READING -> {
                            if (t == null) continue
                            val tp = t.progress
                            if (tp == null) add(Cand(t.book, null, item, SurpriseReason.SERIES))
                            else if (now - tp.lastRead > 14 * DAY) add(Cand(t.book, tp, item, SurpriseReason.ABANDONED))
                            else add(Cand(t.book, tp, item, SurpriseReason.CURRENT))
                        }
                        StatusFilter.FINISHED -> {
                            val first = item.volumes.first()
                            if (item.lastRead > 0 && now - item.lastRead > 90 * DAY) {
                                add(Cand(first.book, first.progress, item, SurpriseReason.LONG))
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
        if (by.isEmpty()) return null

        // Evita repetir lo último sugerido, salvo que no quede otra cosa.
        val filtered = HashMap<SurpriseReason, List<Cand>>()
        for ((r, l) in by) {
            val f = l.filter { it.book.id !in exclude }
            if (f.isNotEmpty()) filtered[r] = f
        }
        val pool: Map<SurpriseReason, List<Cand>> = if (filtered.isNotEmpty()) filtered else by

        val total = pool.keys.sumOf { it.weight }
        var roll = rnd.nextInt(total)
        var reason = pool.keys.first()
        for (r in SurpriseReason.entries) {
            if (!pool.containsKey(r)) continue
            if (roll < r.weight) { reason = r; break }
            roll -= r.weight
        }
        val list = pool.getValue(reason)
        val c = list[rnd.nextInt(list.size)]
        val last = c.prog?.lastRead ?: c.series?.lastRead ?: 0L
        val days = if (last > 0) ((now - last) / DAY).toInt().coerceAtLeast(1) else 0
        val title = if (reason == SurpriseReason.SERIES && c.series != null) volName(c.book, c.series)
        else displayTitle(c.book, c.series)
        val params = JuliParams(
            title = title,
            coll = c.series?.name,
            days = days,
            vols = c.series?.volumes?.size ?: 0,
            volWord = if (c.series?.isBooks == true) "libros" else "tomos",
            name = prefs.userName
        )
        val text = Juli.pick(reason.ctx, params, prefs, rnd) ?: return null
        return Surprise(c.book, c.prog, c.series, reason, text)
    }
}
