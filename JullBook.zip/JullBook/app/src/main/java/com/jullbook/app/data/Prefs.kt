package com.jullbook.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_prefs", Context.MODE_PRIVATE)

    var treeUri: String?
        get() = sp.getString("tree", null)
        set(v) { sp.edit().putString("tree", v).apply() }

    var comicVertical: Boolean
        get() = sp.getBoolean("comic_vertical", false)
        set(v) { sp.edit().putBoolean("comic_vertical", v).apply() }

    var epubFont: Float
        get() = sp.getFloat("epub_font", 18f)
        set(v) { sp.edit().putFloat("epub_font", v).apply() }

    var epubMargin: Int
        get() = sp.getInt("epub_margin", 1)
        set(v) { sp.edit().putInt("epub_margin", v).apply() }

    /** -1 = automático (sigue el tema del sistema). 0 claro, 1 oscuro, 2 sepia. */
    var epubTheme: Int
        get() = sp.getInt("epub_theme", -1)
        set(v) { sp.edit().putInt("epub_theme", v).apply() }

    /** Biblioteca: última pestaña, orden, filtro, vista y posición de desplazamiento (por pestaña). */
    var libTab: String
        get() = sp.getString("lib_tab", "BOOKS") ?: "BOOKS"
        set(v) { sp.edit().putString("lib_tab", v).apply() }

    var libSort: String
        get() = sp.getString("lib_sort", "NAME") ?: "NAME"
        set(v) { sp.edit().putString("lib_sort", v).apply() }

    var libFilter: String
        get() = sp.getString("lib_filter", "ALL") ?: "ALL"
        set(v) { sp.edit().putString("lib_filter", v).apply() }

    var libList: Boolean
        get() = sp.getBoolean("lib_list", false)
        set(v) { sp.edit().putBoolean("lib_list", v).apply() }

    var seriesSort: String
        get() = sp.getString("series_sort", "NUMBER") ?: "NUMBER"
        set(v) { sp.edit().putString("series_sort", v).apply() }

    fun scrollIndex(tab: String): Int = sp.getInt("scroll_${tab}_i", 0)
    fun scrollOffset(tab: String): Int = sp.getInt("scroll_${tab}_o", 0)
    fun saveScroll(tab: String, index: Int, offset: Int) {
        sp.edit().putInt("scroll_${tab}_i", index).putInt("scroll_${tab}_o", offset).apply()
    }

    /** Búsqueda opcional de portadas faltantes por internet. Desactivada por defecto. */
    var onlineCovers: Boolean
        get() = sp.getBoolean("online_covers", false)
        set(v) { sp.edit().putBoolean("online_covers", v).apply() }
}
