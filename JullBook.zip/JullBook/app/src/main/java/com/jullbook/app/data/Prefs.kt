package com.jullbook.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_prefs", Context.MODE_PRIVATE)

    var treeUri: String?
        get() = sp.getString("tree", null)
        set(v) { sp.edit().putString("tree", v).apply() }

    var comicVertical: Boolean
        get() = sp.getBoolean("comic_vertical", false)
        set(v) { sp.edit().putBoolean("comic_vertical", v).apply() }

    var epubFont: Float
        get() = sp.getFloat("epub_font", 18f)
        set(v) { sp.edit().putFloat("epub_font", v).apply() }

    var epubMargin: Int
        get() = sp.getInt("epub_margin", 1)
        set(v) { sp.edit().putInt("epub_margin", v).apply() }

    /** -1 = automático (sigue el tema del sistema). 0 claro, 1 oscuro, 2 sepia. */
    var epubTheme: Int
        get() = sp.getInt("epub_theme", -1)
        set(v) { sp.edit().putInt("epub_theme", v).apply() }

    /** Biblioteca: última pestaña, orden, filtro, vista y posición de desplazamiento (por pestaña). */
    var libTab: String
        get() = sp.getString("lib_tab", "BOOKS") ?: "BOOKS"
        set(v) { sp.edit().putString("lib_tab", v).apply() }

    var libSort: String
        get() = sp.getString("lib_sort", "NAME") ?: "NAME"
        set(v) { sp.edit().putString("lib_sort", v).apply() }

    var libFilter: String
        get() = sp.getString("lib_filter", "ALL") ?: "ALL"
        set(v) { sp.edit().putString("lib_filter", v).apply() }

    var libList: Boolean
        get() = sp.getBoolean("lib_list", false)
        set(v) { sp.edit().putBoolean("lib_list", v).apply() }

    var seriesSort: String
        get() = sp.getString("series_sort", "NUMBER") ?: "NUMBER"
        set(v) { sp.edit().putString("series_sort", v).apply() }

    fun scrollIndex(tab: String): Int = sp.getInt("scroll_${tab}_i", 0)
    fun scrollOffset(tab: String): Int = sp.getInt("scroll_${tab}_o", 0)
    fun saveScroll(tab: String, index: Int, offset: Int) {
        sp.edit().putInt("scroll_${tab}_i", index).putInt("scroll_${tab}_o", offset).apply()
    }

    /** Búsqueda opcional de portadas faltantes por internet. Desactivada por defecto. */
    var onlineCovers: Boolean
        get() = sp.getBoolean("online_covers", false)
        set(v) { sp.edit().putBoolean("online_covers", v).apply() }

    // ---- JullBook 1.0: perfil, carpetas, tema, Juli Experience, Juli y logros ----

    var userName: String
        get() = sp.getString("user_name", "") ?: ""
        set(v) { sp.edit().putString("user_name", v.trim()).apply() }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    /** Carpeta de cómics (la de libros sigue siendo [treeUri]). */
    var comicsUri: String?
        get() = sp.getString("tree_comics", null)
        set(v) { sp.edit().putString("tree_comics", v).apply() }

    /** "auto", id de un tema predefinido o "custom". */
    var themeId: String
        get() = sp.getString("theme_id", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme_id", v).apply() }

    var customBg: Int
        get() = sp.getInt("custom_bg", 0xFF14110C.toInt())
        set(v) { sp.edit().putInt("custom_bg", v).apply() }

    var customAccent: Int
        get() = sp.getInt("custom_accent", 0xFFE8A93C.toInt())
        set(v) { sp.edit().putInt("custom_accent", v).apply() }

    var customText: Int
        get() = sp.getInt("custom_text", 0xFFEDE6DA.toInt())
        set(v) { sp.edit().putInt("custom_text", v).apply() }

    var expEnabled: Boolean
        get() = sp.getBoolean("exp_enabled", true)
        set(v) { sp.edit().putBoolean("exp_enabled", v).apply() }

    /** LAVA, AURORA o GLOW. */
    var expStyle: String
        get() = sp.getString("exp_style", "AURORA") ?: "AURORA"
        set(v) { sp.edit().putString("exp_style", v).apply() }

    var expIntensity: Float
        get() = sp.getFloat("exp_intensity", 0.55f)
        set(v) { sp.edit().putFloat("exp_intensity", v).apply() }

    /** 0 = Juli en silencio, 1 = normal, 2 = más habladora. */
    var juliTalk: Int
        get() = sp.getInt("juli_talk", 1)
        set(v) { sp.edit().putInt("juli_talk", v).apply() }

    var juliHistory: String
        get() = sp.getString("juli_hist", "") ?: ""
        set(v) { sp.edit().putString("juli_hist", v).apply() }

    var homeNote: String
        get() = sp.getString("home_note", "") ?: ""
        set(v) { sp.edit().putString("home_note", v).apply() }

    var homeNoteAt: Long
        get() = sp.getLong("home_note_at", 0L)
        set(v) { sp.edit().putLong("home_note_at", v).apply() }

    var lastSpoke: Long
        get() = sp.getLong("juli_last_spoke", 0L)
        set(v) { sp.edit().putLong("juli_last_spoke", v).apply() }

    /** Logros desbloqueados: id -> momento. */
    fun unlockedAchievements(): Map<String, Long> {
        val out = HashMap<String, Long>()
        for (e in sp.getStringSet("ach", emptySet()) ?: emptySet()) {
            val i = e.indexOf('|')
            if (i > 0) out[e.substring(0, i)] = e.substring(i + 1).toLongOrNull() ?: 0L
        }
        return out
    }

    fun unlockAchievement(id: String, at: Long) {
        val cur = HashSet(sp.getStringSet("ach", emptySet()) ?: emptySet())
        if (cur.any { it.startsWith("$id|") }) return
        cur.add("$id|$at")
        sp.edit().putStringSet("ach", cur).apply()
    }

    // ---- JullBook 1.1: Sorpréndeme (cooldowns y recientes) ----

    /** "No me interesa ahora": id de libro -> hasta cuándo no se vuelve a sugerir. Se limpian solos al caducar. */
    fun cooldowns(now: Long): Map<Long, Long> {
        val out = HashMap<Long, Long>()
        for (e in (sp.getString("surprise_cd", "") ?: "").split(',')) {
            val i = e.indexOf(':')
            if (i <= 0) continue
            val id = e.substring(0, i).toLongOrNull() ?: continue
            val until = e.substring(i + 1).toLongOrNull() ?: continue
            if (until > now) out[id] = until
        }
        return out
    }

    fun addCooldown(id: Long, until: Long, now: Long) {
        val m = HashMap(cooldowns(now))
        m[id] = until
        val s = m.entries.sortedByDescending { it.value }.take(200).joinToString(",") { "${it.key}:${it.value}" }
        sp.edit().putString("surprise_cd", s).apply()
    }

    /** Últimas sugerencias mostradas (persisten entre sesiones para no repetirse). */
    fun surpriseRecent(): List<Long> =
        (sp.getString("surprise_recent", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }

    fun pushSurpriseRecent(id: Long) {
        val l = (surpriseRecent().filter { it != id } + id).takeLast(12)
        sp.edit().putString("surprise_recent", l.joinToString(",")).apply()
    }

    fun eggs(): Set<String> = HashSet(sp.getStringSet("eggs", emptySet()) ?: emptySet())

    /** true si es la primera vez que se descubre. */
    fun discoverEgg(id: String): Boolean {
        val cur = eggs()
        if (id in cur) return false
        sp.edit().putStringSet("eggs", cur + id).apply()
        return true
    }

    fun themesTried(): Set<String> = HashSet(sp.getStringSet("themes_tried", emptySet()) ?: emptySet())

    fun addThemeTried(id: String) {
        sp.edit().putStringSet("themes_tried", themesTried() + id).apply()
    }

    /** Contadores sencillos para logros y secretos. */
    fun counter(key: String): Long = sp.getLong("c_$key", 0L)

    fun bump(key: String, by: Long = 1L): Long {
        val v = counter(key) + by
        sp.edit().putLong("c_$key", v).apply()
        return v
    }

    fun setCounter(key: String, v: Long) {
        sp.edit().putLong("c_$key", v).apply()
    }

    fun setCounterMax(key: String, v: Long) {
        if (v > counter(key)) sp.edit().putLong("c_$key", v).apply()
    }
}
