package com.jullbook.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.volLabel

/** Aviso breve; si el cambio se puede deshacer (mover elementos), ofrece "Deshacer". */
@Composable
fun NoticeHost(vm: AppViewModel, modifier: Modifier = Modifier) {
    val host = remember { SnackbarHostState() }
    val haptic = LocalHapticFeedback.current
    val n = vm.notice
    LaunchedEffect(n?.id) {
        val notice = n ?: return@LaunchedEffect
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val result = host.showSnackbar(
            message = notice.message,
            actionLabel = if (notice.snapshot != null) "Deshacer" else null,
            duration = SnackbarDuration.Long
        )
        if (result == SnackbarResult.ActionPerformed) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            vm.undoLast()
        } else {
            vm.clearNotice(notice.id)
        }
    }
    SnackbarHost(host, modifier)
}

/** Al terminar una lectura: volver a su colección o a la Biblioteca (o seguir en el lector). */
@Composable
fun FinishedPrompt(vm: AppViewModel, book: Book, modifier: Modifier = Modifier) {
    val show = vm.finishedPrompt == book.id
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(show) {
        if (show) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    AnimatedVisibility(
        visible = show,
        modifier = modifier,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 }
    ) {
        val series = vm.library.bookSeries[book.id]
        Surface(
            modifier = Modifier.navigationBarsPadding().padding(16.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    "Lectura terminada",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    if (series != null && book.alias == null) "${series.name} ${volLabel(book)}" else book.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                if (series != null) {
                    Button(onClick = { vm.finishToCollection(book.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Volver a ${series.name}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = { vm.finishToLibrary(book.id) },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) { Text("Ir a la Biblioteca") }
                } else {
                    Button(onClick = { vm.finishToLibrary(book.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Volver a la Biblioteca")
                    }
                }
                TextButton(onClick = { vm.dismissFinished() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Seguir aquí", textAlign = TextAlign.Center)
                }
            }
        }
    }
}
