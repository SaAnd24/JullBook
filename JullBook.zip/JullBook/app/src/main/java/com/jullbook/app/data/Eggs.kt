package com.jullbook.app.data

/**
 * Easter eggs de Juli: se descubren con condiciones muy concretas. No son logros: no tienen barra de progreso
 * ni aparecen listados hasta que los encuentras. Cada uno trae una sorpresa (comentario especial, evento o tema oculto).
 */
class Egg(val id: String, val title: String, val line: String, val confetti: Boolean = false, val unlocksTheme: String? = null)

object Eggs {
    val ALL: List<Egg> = listOf(
        Egg("tap7", "Cosquillas", "¡Ay! Ya, ya, que me haces cosquillas. Toma confeti y un tema que guardaba para ti.", true, "rosa_juli"),
        Egg("name_juli", "Tocayas", "¿Te llamas igual que yo? Qué casualidad tan sospechosa. Nos turnaremos para leer.", true),
        Egg("search_juli", "Me has buscado", "¿Me buscas? Aquí estoy. Siempre estoy, aunque no hable mucho."),
        Egg("search_42", "La respuesta", "Cuarenta y dos. La respuesta a todo, aunque no te dirá qué leer hoy."),
        Egg("night_333", "Hora de las brujas", "Las 3:33. Hora de brujas y de lectores. Aquí no pasa nada raro. Todavía. Te dejo un tema nocturno.", false, "madrugada"),
        Egg("surprise_x5", "Indecisión", "¿Indecisa? Cinco sorpresas seguidas. Elige una y quédate con ella, anda.", true),
        Egg("theme_flip", "Probando looks", "¿Te decides con el tema? Tranquilo, todos te quedan bien. Prueba este, que estaba escondido.", false, "neon"),
        Egg("minimize_spam", "Escondite", "Si quieres jugar al escondite con el lector, avisa y me escondo yo también."),
        Egg("empty_stats", "Lienzo en blanco", "Aquí no hay nada todavía. Qué limpio. Qué vacío. Qué oportunidad."),
        Egg("title_hold", "Saludo largo", "Mantener pulsado el saludo no hace nada. Bueno, casi nada: acabas de mover mi mano."),
        Egg("date_0423", "Día del Libro", "Hoy es 23 de abril: Día del Libro. Hoy mi opinión importa menos que la tuya. Lee lo que quieras.", true),
        Egg("date_1031", "Noche de brujas", "31 de octubre. Los libros de terror hoy leen más fuerte. O eso dicen.", false),
        Egg("date_1225", "Navidad", "Feliz Navidad. El mejor regalo es una buena lectura. Y silencio, a poder ser.", true),
        Egg("date_0101", "Año nuevo", "Año nuevo, pila nueva de pendientes. Promete leer menos de lo que compras. Sé realista.", true),
        Egg("date_0214", "San Valentín", "San Valentín. Tu biblioteca nunca te deja plantado. Yo tampoco.", false)
    )

    fun byId(id: String): Egg? = ALL.firstOrNull { it.id == id }

    /** Id del easter egg de fecha especial de hoy, si lo hay. */
    fun todayDateEgg(month: Int, day: Int): String? = when {
        month == 4 && day == 23 -> "date_0423"
        month == 10 && day == 31 -> "date_1031"
        month == 12 && day == 25 -> "date_1225"
        month == 1 && day == 1 -> "date_0101"
        month == 2 && day == 14 -> "date_0214"
        else -> null
    }
}
