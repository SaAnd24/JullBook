package com.jullbook.app.data

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Búsqueda OPCIONAL de portadas faltantes (solo si el usuario la activa).
 * Usa Open Library y, como respaldo, Google Books. Sin dependencias, solo HTTPS.
 * La portada se guarda en local y se registra el intento para no repetir descargas.
 */
object CoverFetcher {
    private const val RETRY_AFTER_MS = 30L * 24 * 60 * 60 * 1000
    private const val UA = "JullBook/1.0 (lector local)"

    sealed interface Result {
        class Found(val path: String) : Result
        object NotFound : Result
        object Offline : Result
    }

    /** Libros ya procesados, sin portada y sin intento reciente. */
    fun pending(db: Db, books: List<Book>): List<Book> {
        val recent = db.recentLookups(System.currentTimeMillis() - RETRY_AFTER_MS)
        return books.filter { it.processed && it.coverPath == null && it.format != Format.COMIC && it.uri !in recent }
    }

    fun fetch(ctx: Context, db: Db, b: Book): Result {
        return try {
            val bytes = lookup(b)
            val bmp = bytes?.let { Images.decodeSampled(it, 300, Bitmap.Config.ARGB_8888) }
            if (bmp != null && bmp.width >= 60 && bmp.height >= 80) {
                val path = Covers.save(ctx, b, bmp)
                if (path != null) {
                    db.updateCover(b.id, path)
                    db.markLookup(b.uri, System.currentTimeMillis())
                    return Result.Found(path)
                }
            }
            db.markLookup(b.uri, System.currentTimeMillis())
            Result.NotFound
        } catch (e: IOException) {
            Result.Offline
        } catch (e: Throwable) {
            db.markLookup(b.uri, System.currentTimeMillis())
            Result.NotFound
        }
    }

    // ---- Búsqueda ----

    private fun lookup(b: Book): ByteArray? {
        val isbn = b.isbn
        if (isbn != null) {
            image("https://covers.openlibrary.org/b/isbn/$isbn-L.jpg?default=false")?.let { return it }
            googleBooks("isbn:$isbn", null, null)?.let { return it }
        }
        val title = cleanTitle(b.series ?: b.title)
        if (title.length < 3 || b.format == Format.COMIC) return null
        openLibrary(title, b.author)?.let { return it }
        return googleBooks("intitle:" + title, b.author, title)
    }

    private fun openLibrary(title: String, author: String?): ByteArray? {
        var url = "https://openlibrary.org/search.json?limit=5&fields=title,cover_i&title=" + enc(title)
        if (!author.isNullOrBlank()) url += "&author=" + enc(author)
        val json = text(url) ?: return null
        val docs = JSONObject(json).optJSONArray("docs") ?: return null
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val cover = d.optLong("cover_i", 0L)
            if (cover <= 0L) continue
            if (!similar(title, d.optString("title"))) continue
            image("https://covers.openlibrary.org/b/id/$cover-L.jpg?default=false")?.let { return it }
        }
        return null
    }

    private fun googleBooks(q: String, author: String?, wantedTitle: String?): ByteArray? {
        var query = q
        if (!author.isNullOrBlank() && wantedTitle != null) query += " inauthor:$author"
        val json = text("https://www.googleapis.com/books/v1/volumes?maxResults=5&q=" + enc(query)) ?: return null
        val items = JSONObject(json).optJSONArray("items") ?: return null
        for (i in 0 until items.length()) {
            val info = items.optJSONObject(i)?.optJSONObject("volumeInfo") ?: continue
            if (wantedTitle != null && !similar(wantedTitle, info.optString("title"))) continue
            val links = info.optJSONObject("imageLinks") ?: continue
            val link = (links.optString("thumbnail").ifBlank { links.optString("smallThumbnail") })
            if (link.isBlank()) continue
            val https = link.replace("http://", "https://").replace("&edge=curl", "")
            image(https)?.let { return it }
        }
        return null
    }

    // ---- Utilidades ----

    private val TAGS = Regex("[(\\[][^)\\]]*[)\\]]")

    private fun cleanTitle(t: String): String =
        t.replace(TAGS, " ").replace('_', ' ').replace(Regex("\\s+"), " ").trim()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Coincidencia estricta de títulos para no guardar portadas equivocadas. */
    private fun similar(wanted: String, found: String): Boolean {
        val a = SeriesParser.keyOf(wanted).split(' ').filter { it.isNotEmpty() }.toSet()
        val b = SeriesParser.keyOf(found).split(' ').filter { it.isNotEmpty() }.toSet()
        if (a.isEmpty() || b.isEmpty()) return false
        val common = a.intersect(b).size.toFloat()
        return common / a.size >= 0.8f && common / b.size >= 0.5f
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    /** Devuelve null si el servidor responde sin resultado; lanza IOException si no hay red. */
    private fun text(url: String): String? {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) return null
            return c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    }

    private fun image(url: String): ByteArray? {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) return null
            val type = c.contentType ?: ""
            if (!type.startsWith("image")) return null
            val data = c.inputStream.use { it.readBytes() }
            return if (data.size < 2000) null else data
        } finally {
            c.disconnect()
        }
    }
}
