package com.jullbook.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.LibTab
import com.jullbook.app.OrgDialog
import com.jullbook.app.data.Format
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SingleItem

@Composable
fun LibraryScreen(vm: AppViewModel, onPickFolder: () -> Unit, modifier: Modifier = Modifier) {
    val lib = vm.library
    var menu by remember { mutableStateOf(false) }
    val comics = vm.libTab == LibTab.COMICS
    // Libros (EPUB + PDF) y Cómics (CBZ + CBR) nunca se mezclan.
    val shown = lib.items.filter { item ->
        when (item) {
            is SeriesItem -> comics
            is SingleItem -> (item.book.format == Format.COMIC) == comics
        }
    }
    Box(modifier.fillMaxSize()) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(112.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = if (vm.selection.isNotEmpty()) 88.dp else 24.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Biblioteca", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Más opciones")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (comics) {
                            DropdownMenuItem(
                                text = { Text("Crear colección") },
                                onClick = { menu = false; vm.dialog = OrgDialog.CreateSaga }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Actualizar") },
                            onClick = { menu = false; vm.startScan() }
                        )
                        DropdownMenuItem(
                            text = { Text("Cambiar carpeta") },
                            onClick = { menu = false; onPickFolder() }
                        )
                        DropdownMenuItem(
                            text = { Text("Portadas en línea") },
                            trailingIcon = {
                                if (vm.onlineCovers) Icon(Icons.Default.Check, contentDescription = "Activado")
                            },
                            onClick = { vm.changeOnlineCovers(!vm.onlineCovers) }
                        )
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            TabRow(
                selectedTabIndex = vm.libTab.ordinal,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = !comics,
                    onClick = { vm.clearSelection(); vm.libTab = LibTab.BOOKS },
                    text = { Text("Libros") }
                )
                Tab(
                    selected = comics,
                    onClick = { vm.clearSelection(); vm.libTab = LibTab.COMICS },
                    text = { Text("Cómics") }
                )
            }
        }
        if (vm.folderLost) item(span = { GridItemSpan(maxLineSpan) }) { FolderBanner(onPickFolder) }
        if (vm.scanning) item(span = { GridItemSpan(maxLineSpan) }) { ScanBar(vm.scanDone, vm.scanTotal) }
        if (vm.fetchingCovers) item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "Buscando portadas que faltan…",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (shown.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    when {
                        vm.scanning -> "Buscando libros…"
                        comics -> "No hay cómics (CBZ/CBR) en la carpeta elegida."
                        else -> "No hay libros (EPUB/PDF) en la carpeta elegida."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        }
        items(shown, key = { it.id }) { item ->
            val selecting = vm.selection.isNotEmpty()
            ItemCard(
                item,
                onBook = { if (selecting) vm.toggleSelect(it.id) else vm.openBook(it.book) },
                onSeries = { if (selecting) vm.toggleSelect(it.id) else vm.openSeries(it.key) },
                onLongBook = if (comics) ({ vm.toggleSelect(it.id) }) else null,
                onLongSeries = if (comics) ({ vm.toggleSelect(it.id) }) else null,
                selected = item.id in vm.selection
            )
        }
    }
    SelectionBar(vm, inSeries = false, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
