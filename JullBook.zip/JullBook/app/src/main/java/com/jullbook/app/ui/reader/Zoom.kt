package com.jullbook.app.ui.reader

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt

private const val MAX_ZOOM = 4f

/**
 * Estado de zoom. La escala se aplica con origen (0,0): pantalla = escala * contenido + desplazamiento.
 */
@Stable
class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)

    fun reset() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }

    /**
     * Aplica un zoom relativo alrededor de [focus] más un desplazamiento [pan].
     * En modo scroll el eje Y lo gestiona la lista (se compensa con [scrollBy]).
     */
    fun transform(
        zoom: Float,
        focus: Offset,
        pan: Offset,
        w: Float,
        h: Float,
        scrollMode: Boolean,
        scrollBy: (Float) -> Unit
    ) {
        val s0 = scale
        val s1 = (s0 * zoom).coerceIn(1f, MAX_ZOOM)
        if (s1 <= 1.001f) {
            if (scrollMode && s0 != 1f) scrollBy(focus.y / s0 - focus.y)
            reset()
            return
        }
        val k = s1 / s0
        val tx = focus.x - (focus.x - offsetX) * k + pan.x
        if (scrollMode) {
            if (s1 != s0 || pan.y != 0f) scrollBy(focus.y / s0 - focus.y / s1 - pan.y / s1)
            offsetY = 0f
        } else {
            val ty = focus.y - (focus.y - offsetY) * k + pan.y
            offsetY = ty.coerceIn(h * (1f - s1), 0f)
        }
        offsetX = tx.coerceIn(w * (1f - s1), 0f)
        scale = s1
    }

    fun panBy(dx: Float, dy: Float, w: Float, h: Float, scrollMode: Boolean) {
        if (scale <= 1.001f) return
        offsetX = (offsetX + dx).coerceIn(w * (1f - scale), 0f)
        if (!scrollMode) offsetY = (offsetY + dy).coerceIn(h * (1f - scale), 0f)
    }
}

/**
 * Contenedor con zoom por pellizco, doble toque y desplazamiento lateral.
 * scrollMode = true: el contenido es una lista vertical que hace su propio scroll en Y.
 * Un toque simple llama a [onTap].
 */
@Composable
fun ZoomBox(
    state: ZoomState,
    scrollMode: Boolean,
    onTap: () -> Unit,
    onScrollBy: (Float) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val scrollByNow by rememberUpdatedState(onScrollBy)
    val tapNow by rememberUpdatedState(onTap)

    LaunchedEffect(boxSize) { state.reset() }

    Box(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { boxSize = it }
            .pointerInput(scrollMode) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val pressed = event.changes.filter { it.pressed }
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        if (pressed.size >= 2) {
                            val a = pressed[0]
                            val b = pressed[1]
                            val c = (a.position + b.position) / 2f
                            val cp = (a.previousPosition + b.previousPosition) / 2f
                            val d = (a.position - b.position).getDistance()
                            val dp = (a.previousPosition - b.previousPosition).getDistance()
                            val z = if (dp > 0f) d / dp else 1f
                            state.transform(z, c, c - cp, w, h, scrollMode, scrollByNow)
                            event.changes.forEach { it.consume() }
                        } else if (pressed.size == 1 && state.scale > 1.001f) {
                            val ch = pressed[0]
                            val delta = ch.position - ch.previousPosition
                            state.panBy(delta.x, delta.y, w, h, scrollMode)
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(scrollMode) {
                detectTapGestures(
                    onDoubleTap = { p ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        if (state.scale > 1.01f) {
                            state.transform(1f / state.scale, p, Offset.Zero, w, h, scrollMode, scrollByNow)
                        } else {
                            state.transform(2.5f, p, Offset.Zero, w, h, scrollMode, scrollByNow)
                        }
                    },
                    onTap = { tapNow() }
                )
            }
    ) {
        Box(
            Modifier
                .layout { measurable, c ->
                    if (scrollMode) {
                        val h = (c.maxHeight / state.scale).roundToInt().coerceAtLeast(1)
                        val p = measurable.measure(Constraints.fixed(c.maxWidth, h))
                        layout(c.maxWidth, c.maxHeight) { p.place(0, 0) }
                    } else {
                        val p = measurable.measure(c)
                        layout(p.width, p.height) { p.place(0, 0) }
                    }
                }
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = state.scale
                    scaleY = state.scale
                    translationX = state.offsetX
                    translationY = state.offsetY
                }
        ) {
            content()
        }
    }
}

/**
 * Swipe horizontal para pasar de página: izquierda → dir = +1 (siguiente), derecha → dir = -1 (anterior).
 * No actúa si [enabled] es false (p. ej. con zoom), si hubo dos dedos (pellizco) o si otro gesto
 * (scroll vertical, desplazamiento con zoom) ya consumió el movimiento.
 */
@Composable
fun Modifier.swipePages(enabled: () -> Boolean, onSwipe: (dir: Int) -> Unit): Modifier {
    val enabledNow by rememberUpdatedState(enabled)
    val swipeNow by rememberUpdatedState(onSwipe)
    return pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var dx = 0f
            var dy = 0f
            var multi = false
            do {
                val event = awaitPointerEvent()
                if (event.changes.count { it.pressed } > 1) multi = true
                for (c in event.changes) {
                    if (!c.isConsumed) {
                        val d = c.positionChange()
                        dx += d.x
                        dy += d.y
                    }
                }
            } while (event.changes.any { it.pressed })
            val threshold = 56.dp.toPx()
            if (!multi && enabledNow() && kotlin.math.abs(dx) > threshold && kotlin.math.abs(dx) > 2f * kotlin.math.abs(dy)) {
                swipeNow(if (dx < 0f) 1 else -1)
            }
        }
    }
}
