package com.jullbook.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NewBook(
    val uri: String,
    val fileName: String,
    val format: Format,
    val title: String,
    val series: String?,
    val seriesKey: String?,
    val number: Int?,
    val folder: String,
    val size: Long,
    val modified: Long
)

/** Corrección manual de un libro. grp: "" = automático, "-" = suelto, "m:<id>" = saga manual, otro = serie automática forzada. */
class BookOverride(val grp: String, val gname: String?, val number: Int?)

class ManualSeries(val id: Long, val name: String)

const val GRP_NONE = ""
const val GRP_STANDALONE = "-"

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "jullbook.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT UNIQUE NOT NULL, file_name TEXT, " +
                "format TEXT, title TEXT, author TEXT, series TEXT, series_key TEXT, number INTEGER, folder TEXT, " +
                "page_count INTEGER DEFAULT 0, size INTEGER, modified INTEGER, cover TEXT, processed INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE progress(book_id INTEGER PRIMARY KEY, pos INTEGER, sub INTEGER, frac REAL, " +
                "percent REAL, last_read INTEGER, status INTEGER)"
        )
        createV2Tables(db)
        db.execSQL("ALTER TABLE books ADD COLUMN isbn TEXT")
    }

    private fun createV2Tables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS manual_series(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS book_override(uri TEXT PRIMARY KEY, grp TEXT NOT NULL DEFAULT '', " +
                "gname TEXT, number INTEGER)"
        )
        db.execSQL("CREATE TABLE IF NOT EXISTS cover_lookup(uri TEXT PRIMARY KEY, tried_at INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createV2Tables(db)
            try {
                db.execSQL("ALTER TABLE books ADD COLUMN isbn TEXT")
            } catch (ignored: Exception) {
            }
            // Re-analizar nombres de cómics con el parser mejorado.
            db.beginTransaction()
            try {
                val rows = ArrayList<Triple<Long, String, String>>()
                db.rawQuery("SELECT id,file_name,folder FROM books WHERE format='COMIC'", null).use { c ->
                    while (c.moveToNext()) rows.add(Triple(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: ""))
                }
                for ((id, name, folder) in rows) {
                    val pr = SeriesParser.parse(name, folder, true)
                    val cv = ContentValues()
                    cv.put("series", pr.series)
                    cv.put("series_key", pr.key)
                    cv.put("number", pr.number)
                    db.update("books", cv, "id=?", arrayOf(id.toString()))
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    fun allBooks(): List<Book> {
        val out = ArrayList<Book>()
        readableDatabase.rawQuery(
            "SELECT id,uri,file_name,format,title,author,series,series_key,number,folder,page_count,size,modified,cover,processed FROM books",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Book(
                        id = c.getLong(0),
                        uri = c.getString(1),
                        fileName = c.getString(2) ?: "",
                        format = Format.valueOf(c.getString(3)),
                        title = c.getString(4) ?: "",
                        author = c.getString(5),
                        series = c.getString(6),
                        seriesKey = c.getString(7),
                        number = if (c.isNull(8)) null else c.getInt(8),
                        folder = c.getString(9) ?: "",
                        pageCount = c.getInt(10),
                        size = c.getLong(11),
                        modified = c.getLong(12),
                        coverPath = c.getString(13),
                        processed = c.getInt(14) == 1,
                        isbn = c.getString(15)
                    )
                )
            }
        }
        return out
    }

    fun insertBooks(list: List<NewBook>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (b in list) {
                val cv = ContentValues()
                cv.put("uri", b.uri)
                cv.put("file_name", b.fileName)
                cv.put("format", b.format.name)
                cv.put("title", b.title)
                cv.put("series", b.series)
                cv.put("series_key", b.seriesKey)
                cv.put("number", b.number)
                cv.put("folder", b.folder)
                cv.put("size", b.size)
                cv.put("modified", b.modified)
                cv.put("processed", 0)
                db.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetBook(id: Long, size: Long, modified: Long) {
        val cv = ContentValues()
        cv.put("size", size)
        cv.put("modified", modified)
        cv.put("processed", 0)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateParse(id: Long, folder: String, p: SeriesParser.Parsed) {
        val cv = ContentValues()
        cv.put("folder", folder)
        cv.put("series", p.series)
        cv.put("series_key", p.key)
        cv.put("number", p.number)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateCover(id: Long, cover: String) {
        val cv = ContentValues()
        cv.put("cover", cover)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateMeta(id: Long, title: String?, author: String?, pages: Int, cover: String?, isbn: String? = null) {
        val cv = ContentValues()
        cv.put("isbn", isbn)
        if (!title.isNullOrBlank()) cv.put("title", title.trim())
        cv.put("author", author)
        cv.put("page_count", pages)
        cv.put("cover", cover)
        cv.put("processed", 1)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteBooks(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) {
                db.delete("books", "id=?", arrayOf(id.toString()))
                db.delete("progress", "book_id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearAll() {
        val db = writableDatabase
        db.delete("books", null, null)
        db.delete("progress", null, null)
        db.delete("manual_series", null, null)
        db.delete("book_override", null, null)
        db.delete("cover_lookup", null, null)
    }

    // ---- Organización manual (solo metadatos de la app; nunca se tocan los archivos) ----

    fun allOverrides(): Map<String, BookOverride> {
        val out = HashMap<String, BookOverride>()
        readableDatabase.rawQuery("SELECT uri,grp,gname,number FROM book_override", null).use { c ->
            while (c.moveToNext()) {
                out[c.getString(0)] = BookOverride(c.getString(1) ?: GRP_NONE, c.getString(2), if (c.isNull(3)) null else c.getInt(3))
            }
        }
        return out
    }

    fun allManualSeries(): List<ManualSeries> {
        val out = ArrayList<ManualSeries>()
        readableDatabase.rawQuery("SELECT id,name FROM manual_series", null).use { c ->
            while (c.moveToNext()) out.add(ManualSeries(c.getLong(0), c.getString(1) ?: ""))
        }
        return out
    }

    fun createManualSeries(name: String): Long {
        val cv = ContentValues()
        cv.put("name", name.trim())
        return writableDatabase.insert("manual_series", null, cv)
    }

    fun deleteManualSeries(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Los tomos de la saga vuelven a la agrupación automática (conservan su número corregido).
            db.execSQL("UPDATE book_override SET grp='', gname=NULL WHERE grp=?", arrayOf("m:$id"))
            db.delete("manual_series", "id=?", arrayOf(id.toString()))
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun cleanOverrides(db: SQLiteDatabase) {
        db.delete("book_override", "grp='' AND number IS NULL", null)
    }

    fun setGroup(uris: List<String>, grp: String, gname: String?) {
        if (uris.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (u in uris) {
                db.execSQL(
                    "INSERT OR IGNORE INTO book_override(uri,grp,gname,number) VALUES(?,'',NULL,NULL)",
                    arrayOf(u)
                )
                val cv = ContentValues()
                cv.put("grp", grp)
                cv.put("gname", gname)
                db.update("book_override", cv, "uri=?", arrayOf(u))
            }
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun setNumber(uri: String, number: Int?) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("INSERT OR IGNORE INTO book_override(uri,grp,gname,number) VALUES(?,'',NULL,NULL)", arrayOf(uri))
            val cv = ContentValues()
            cv.put("number", number)
            db.update("book_override", cv, "uri=?", arrayOf(uri))
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetOverride(uri: String) {
        writableDatabase.delete("book_override", "uri=?", arrayOf(uri))
    }

    // ---- Búsqueda de portadas en línea (registro de intentos) ----

    fun recentLookups(since: Long): Set<String> {
        val out = HashSet<String>()
        readableDatabase.rawQuery("SELECT uri FROM cover_lookup WHERE tried_at>=?", arrayOf(since.toString())).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    fun markLookup(uri: String, at: Long) {
        val cv = ContentValues()
        cv.put("uri", uri)
        cv.put("tried_at", at)
        writableDatabase.insertWithOnConflict("cover_lookup", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun readProgress(c: android.database.Cursor) = Progress(
        bookId = c.getLong(0),
        pos = c.getInt(1),
        sub = c.getInt(2),
        frac = c.getFloat(3),
        percent = c.getFloat(4),
        lastRead = c.getLong(5),
        status = c.getInt(6)
    )

    fun allProgress(): Map<Long, Progress> {
        val out = HashMap<Long, Progress>()
        readableDatabase.rawQuery("SELECT book_id,pos,sub,frac,percent,last_read,status FROM progress", null).use { c ->
            while (c.moveToNext()) {
                val p = readProgress(c)
                out[p.bookId] = p
            }
        }
        return out
    }

    fun getProgress(id: Long): Progress? =
        readableDatabase.rawQuery(
            "SELECT book_id,pos,sub,frac,percent,last_read,status FROM progress WHERE book_id=?",
            arrayOf(id.toString())
        ).use { c -> if (c.moveToFirst()) readProgress(c) else null }

    fun saveProgress(p: Progress) {
        val cv = ContentValues()
        cv.put("book_id", p.bookId)
        cv.put("pos", p.pos)
        cv.put("sub", p.sub)
        cv.put("frac", p.frac)
        cv.put("percent", p.percent)
        cv.put("last_read", p.lastRead)
        cv.put("status", p.status)
        writableDatabase.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
}
