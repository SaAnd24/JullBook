package com.jullbook.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.jullbook.app.data.Format
import com.jullbook.app.data.LibraryView
import com.jullbook.app.data.StatusFilter
import com.jullbook.app.data.isRereading
import com.jullbook.app.data.lastReadLabel
import com.jullbook.app.data.readsText
import com.jullbook.app.data.seriesCaption
import com.jullbook.app.data.statusCaption
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.data.CoverCache
import com.jullbook.app.data.LibItem
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SingleItem
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.formatLabel
import com.jullbook.app.data.pctText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CoverImage(
    path: String?,
    title: String,
    modifier: Modifier = Modifier,
    format: Format? = null,
    isSeries: Boolean = false
) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = if (path == null) null else withContext(Dispatchers.IO) { CoverCache.get(path)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = title, modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        GenericCover(title, format, isSeries, modifier)
    }
}

/** Portada genérica elegante cuando no hay imagen: color según el tipo (con matiz propio del título), inicial y título. */
@Composable
fun GenericCover(title: String, format: Format?, isSeries: Boolean, modifier: Modifier = Modifier) {
    val label: String
    val baseHue: Float
    when {
        isSeries -> { label = "COLECCIÓN"; baseHue = 38f }
        format == Format.EPUB -> { label = "EPUB"; baseHue = 205f }
        format == Format.PDF -> { label = "PDF"; baseHue = 8f }
        format == Format.COMIC -> { label = "CÓMIC"; baseHue = 285f }
        else -> { label = ""; baseHue = 160f }
    }
    val shift = (title.hashCode() and 0x7fffffff) % 41 - 20
    val hue = (baseHue + shift + 360f) % 360f
    val top = Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.42f, 0.40f)))
    val bottom = Color(android.graphics.Color.HSVToColor(floatArrayOf((hue + 14f) % 360f, 0.55f, 0.18f)))
    val initial = title.firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?"
    BoxWithConstraints(modifier.background(Brush.verticalGradient(listOf(top, bottom)))) {
        val big = maxWidth >= 72.dp
        Box(
            Modifier
                .fillMaxSize()
                .padding(if (big) 8.dp else 3.dp)
                .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(4.dp))
        )
        Column(
            Modifier.fillMaxSize().padding(if (big) 14.dp else 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                initial,
                fontSize = if (big) 40.sp else 22.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Serif,
                color = Color.White.copy(alpha = 0.92f)
            )
            if (big) {
                Spacer(Modifier.height(8.dp))
                Box(Modifier.width(24.dp).height(1.dp).background(Color.White.copy(alpha = 0.35f)))
                Spacer(Modifier.height(8.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.92f),
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (big && label.isNotEmpty()) {
            Text(
                label,
                fontSize = 9.sp,
                letterSpacing = 1.5.sp,
                color = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
            )
        }
    }
}

/** Contador compacto de lecturas completadas ("↻ 2"); se anima al cambiar. */
@Composable
fun ReadsBadge(reads: Int, modifier: Modifier = Modifier, onCover: Boolean = true) {
    AnimatedVisibility(visible = reads > 0, modifier = modifier, enter = fadeIn() + scaleIn(), exit = fadeOut()) {
        val fg = if (onCover) Color.White else MaterialTheme.colorScheme.primary
        val bg = if (onCover) Color(0xB3000000) else MaterialTheme.colorScheme.surfaceContainerHighest
        Row(
            Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(bg)
                .padding(horizontal = 6.dp, vertical = 2.dp)
                .semantics { contentDescription = readsText(reads) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = fg, modifier = Modifier.size(11.dp))
            AnimatedContent(
                targetState = reads,
                transitionSpec = { (fadeIn() + scaleIn()) togetherWith fadeOut() },
                label = "reads"
            ) { n ->
                Text("$n", style = MaterialTheme.typography.labelSmall, color = fg, modifier = Modifier.padding(start = 3.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookCard(
    title: String,
    subtitle: String?,
    caption: String?,
    coverPath: String?,
    progress: Float,
    finished: Boolean,
    stack: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean = false,
    format: Format? = null,
    reads: Int = 0,
    rereading: Boolean = false,
    lastRead: String? = null
) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            if (stack) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = 12.dp, bottom = 12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f))
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = 6.dp, top = 6.dp, bottom = 6.dp, end = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.85f))
                )
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(end = if (stack) 12.dp else 0.dp, top = if (stack) 12.dp else 0.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                CoverImage(coverPath, title, Modifier.fillMaxSize(), format = format, isSeries = stack)
                if (selected) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.28f))
                            .border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                    )
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Seleccionado",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                if (finished) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Terminado",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                } else if (progress > 0.001f) {
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color(0x66000000)
                    )
                }
                ReadsBadge(
                    reads,
                    Modifier.align(Alignment.BottomStart).padding(start = 6.dp, bottom = 8.dp)
                )
            }
        }
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (caption != null) {
            Text(
                caption,
                style = MaterialTheme.typography.labelSmall,
                color = if (rereading) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (lastRead != null) {
            Text(
                lastRead,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.height(4.dp))
    }
}

/** Datos mostrados en la tarjeta / fila de un elemento de la Biblioteca. */
private class CardInfo(
    val title: String,
    val subtitle: String,
    val caption: String?,
    val lastRead: String?,
    val coverPath: String?,
    val progress: Float,
    val finished: Boolean,
    val stack: Boolean,
    val reads: Int,
    val rereading: Boolean,
    val format: Format?
)

private fun cardInfo(item: LibItem): CardInfo = when (item) {
    is SingleItem -> {
        val b = item.book
        val p = item.progress
        CardInfo(
            title = b.title,
            subtitle = b.author ?: formatLabel(b.format),
            caption = statusCaption(b, p),
            lastRead = lastReadLabel(p?.lastRead),
            coverPath = b.coverPath,
            progress = p?.percent ?: 0f,
            finished = p?.status == ST_FINISHED,
            stack = false,
            reads = b.reads,
            rereading = isRereading(b, p),
            format = b.format
        )
    }
    is SeriesItem -> {
        val pct = item.percent
        CardInfo(
            title = item.name,
            subtitle = if (item.volumes.size == 1) "1 elemento" else "${item.volumes.size} " + if (item.isBooks) "libros" else "tomos",
            caption = seriesCaption(item),
            lastRead = lastReadLabel(item.lastRead),
            coverPath = item.coverPath,
            progress = pct,
            finished = LibraryView.statusOf(item) == StatusFilter.FINISHED,
            stack = true,
            reads = item.reads,
            rereading = item.rereading,
            format = item.volumes.firstOrNull()?.book?.format
        )
    }
}

/** Tarjeta de un elemento de la biblioteca (libro suelto o serie apilada). */
@Composable
fun ItemCard(
    item: LibItem,
    onBook: (SingleItem) -> Unit,
    onSeries: (SeriesItem) -> Unit,
    modifier: Modifier = Modifier,
    onLongBook: ((SingleItem) -> Unit)? = null,
    onLongSeries: ((SeriesItem) -> Unit)? = null,
    selected: Boolean = false
) {
    val i = cardInfo(item)
    BookCard(
        title = i.title,
        subtitle = i.subtitle,
        caption = i.caption,
        coverPath = i.coverPath,
        progress = i.progress,
        finished = i.finished,
        stack = i.stack,
        onClick = { if (item is SingleItem) onBook(item) else if (item is SeriesItem) onSeries(item) },
        modifier = modifier,
        onLongClick = when (item) {
            is SingleItem -> onLongBook?.let { f -> { f(item) } }
            is SeriesItem -> onLongSeries?.let { f -> { f(item) } }
        },
        selected = selected,
        format = i.format,
        reads = i.reads,
        rereading = i.rereading,
        lastRead = i.lastRead
    )
}

/** Fila de la vista en lista. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemRow(
    item: LibItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    selected: Boolean,
    modifier: Modifier = Modifier
) {
    val i = cardInfo(item)
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box {
            CoverImage(
                i.coverPath, i.title,
                Modifier.size(width = 56.dp, height = 82.dp).clip(RoundedCornerShape(6.dp)),
                format = i.format, isSeries = i.stack
            )
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = "Seleccionado",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                i.title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                i.subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (i.caption != null || i.reads > 0) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (i.caption != null) {
                        Text(
                            i.caption,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (i.rereading) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    }
                    ReadsBadge(i.reads, onCover = false)
                }
            }
            if (i.lastRead != null) {
                Text(
                    i.lastRead,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            if (!i.finished && i.progress > 0.001f) {
                LinearProgressIndicator(
                    progress = { i.progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(3.dp).clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
            }
        }
        if (i.finished) {
            Box(
                Modifier.size(22.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = "Terminado",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, action: @Composable () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
        action()
    }
}
