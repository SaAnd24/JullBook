package com.jullbook.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.data.CoverCache
import com.jullbook.app.data.LibItem
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SingleItem
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.formatLabel
import com.jullbook.app.data.pctText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CoverImage(path: String?, title: String, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = if (path == null) null else withContext(Dispatchers.IO) { CoverCache.get(path)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = title, modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        Box(
            modifier.background(MaterialTheme.colorScheme.surfaceContainerHighest).padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookCard(
    title: String,
    subtitle: String?,
    caption: String?,
    coverPath: String?,
    progress: Float,
    finished: Boolean,
    stack: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean = false
) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            if (stack) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = 12.dp, bottom = 12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f))
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = 6.dp, top = 6.dp, bottom = 6.dp, end = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.85f))
                )
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(end = if (stack) 12.dp else 0.dp, top = if (stack) 12.dp else 0.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                CoverImage(coverPath, title, Modifier.fillMaxSize())
                if (selected) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.28f))
                            .border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                    )
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Seleccionado",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                if (finished) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Terminado",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                } else if (progress > 0.001f) {
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color(0x66000000)
                    )
                }
            }
        }
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (caption != null) {
            Text(
                caption,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
    }
}

/** Tarjeta de un elemento de la biblioteca (libro suelto o serie apilada). */
@Composable
fun ItemCard(
    item: LibItem,
    onBook: (SingleItem) -> Unit,
    onSeries: (SeriesItem) -> Unit,
    modifier: Modifier = Modifier,
    onLongBook: ((SingleItem) -> Unit)? = null,
    onLongSeries: ((SeriesItem) -> Unit)? = null,
    selected: Boolean = false
) {
    when (item) {
        is SingleItem -> {
            val p = item.progress
            val finished = p?.status == ST_FINISHED
            BookCard(
                title = item.book.title,
                subtitle = item.book.author ?: formatLabel(item.book.format),
                caption = when {
                    p == null -> null
                    finished -> "Terminado"
                    else -> pctText(p.percent)
                },
                coverPath = item.book.coverPath,
                progress = p?.percent ?: 0f,
                finished = finished,
                stack = false,
                onClick = { onBook(item) },
                modifier = modifier,
                onLongClick = onLongBook?.let { f -> { f(item) } },
                selected = selected
            )
        }
        is SeriesItem -> {
            val pct = item.percent
            BookCard(
                title = item.name,
                subtitle = "${item.volumes.size} tomos",
                caption = "${pctText(pct)} completado",
                coverPath = item.coverPath,
                progress = pct,
                finished = pct >= 0.995f,
                stack = true,
                onClick = { onSeries(item) },
                modifier = modifier,
                onLongClick = onLongSeries?.let { f -> { f(item) } },
                selected = selected
            )
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, action: @Composable () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
        action()
    }
}
