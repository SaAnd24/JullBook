package com.jullbook.app

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.data.Book
import com.jullbook.app.data.CoverFetcher
import com.jullbook.app.data.Format
import com.jullbook.app.data.Images
import com.jullbook.app.data.GRP_STANDALONE
import com.jullbook.app.data.Covers
import com.jullbook.app.data.Db
import com.jullbook.app.data.Indexer
import com.jullbook.app.data.Library
import com.jullbook.app.data.OrgSnapshot
import com.jullbook.app.data.SortMode
import com.jullbook.app.data.StatusFilter
import com.jullbook.app.data.Memory
import com.jullbook.app.data.MemoryData
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SeriesParser
import com.jullbook.app.data.LibraryBuilder
import com.jullbook.app.data.LibraryScanner
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

enum class Tab { HOME, LIBRARY }

enum class LibTab { BOOKS, COMICS }

/** Aviso breve con acción opcional de Deshacer (solo organización: nunca toca archivos). */
class Notice(
    val message: String,
    val snapshot: OrgSnapshot? = null,
    val createdSeriesId: Long? = null,
    val id: Long = System.nanoTime()
)

/** Diálogos de organización manual (solo afectan a metadatos de la app, nunca a los archivos). */
sealed interface OrgDialog {
    object CreateSaga : OrgDialog
    class BookActions(val bookId: Long) : OrgDialog
    class MoveTo(val bookIds: List<Long>) : OrgDialog
    class NewSagaFor(val bookIds: List<Long>) : OrgDialog
    class EditNumber(val bookId: Long) : OrgDialog
    class AddVolumes(val seriesKey: String) : OrgDialog
    class DeleteSaga(val seriesKey: String) : OrgDialog

    /** Confirmación antes de reiniciar la lectura de una colección completa. */
    class ResetReading(val seriesKey: String) : OrgDialog

    /** Ofrece renombrar internamente los cómics recién movidos (todos a la vez o uno a uno). */
    class RenameOffer(val bookIds: List<Long>) : OrgDialog
    class RenameReview(val bookIds: List<Long>) : OrgDialog
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val db = Db(app)

    // Un solo hilo para lecturas/escrituras de progreso: mantiene el orden de los guardados.
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val dbDisp = dbExecutor.asCoroutineDispatcher()

    var library by mutableStateOf(Library.EMPTY)
        private set
    var loaded by mutableStateOf(false)
        private set
    var treeUri by mutableStateOf(prefs.treeUri)
        private set
    var tab by mutableStateOf(Tab.HOME)
    var libTab by mutableStateOf(runCatching { LibTab.valueOf(prefs.libTab) }.getOrDefault(LibTab.BOOKS))
        private set
    var libSort by mutableStateOf(SortMode.of(prefs.libSort, SortMode.NAME))
        private set
    var libFilter by mutableStateOf(StatusFilter.of(prefs.libFilter))
        private set
    var libList by mutableStateOf(prefs.libList)
        private set
    var seriesSort by mutableStateOf(SortMode.of(prefs.seriesSort, SortMode.NUMBER))
        private set

    /** Búsqueda de la Biblioteca (no se recuerda entre sesiones). */
    var searchOpen by mutableStateOf(false)
    var query by mutableStateOf("")

    /** Posición de desplazamiento de cada pestaña de la Biblioteca (se recuerda entre sesiones). */
    val gridStates: Map<LibTab, LazyGridState> = LibTab.entries.associateWith {
        LazyGridState(prefs.scrollIndex(it.name), prefs.scrollOffset(it.name))
    }

    var notice by mutableStateOf<Notice?>(null)
    var finishedPrompt by mutableStateOf<Long?>(null)
        private set
    var dialog by mutableStateOf<OrgDialog?>(null)

    /** Multiselección: ids de elemento ("b<id>" libro/cómic, "s<clave>" colección). */
    var selection by mutableStateOf(setOf<String>())
        private set
    var showStats by mutableStateOf(false)
    var onlineCovers by mutableStateOf(prefs.onlineCovers)
        private set
    var fetchingCovers by mutableStateOf(false)
        private set
    var seriesKey by mutableStateOf<String?>(null)
        private set
    var reading by mutableStateOf<Book?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableIntStateOf(0)
        private set
    var scanTotal by mutableIntStateOf(0)
        private set
    var folderLost by mutableStateOf(false)
        private set

    private var sessionId = -1L
    private var scanJob: Job? = null
    private var coverJob: Job? = null

    init {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
            if (treeUri != null) startScan()
        }
    }

    fun selectLibTab(t: LibTab) {
        clearSelection()
        libTab = t
        prefs.libTab = t.name
    }

    fun changeLibSort(m: SortMode) { libSort = m; prefs.libSort = m.name }
    fun changeLibFilter(f: StatusFilter) { libFilter = f; prefs.libFilter = f.name }
    fun toggleLibList() { libList = !libList; prefs.libList = libList }
    fun changeSeriesSort(m: SortMode) { seriesSort = m; prefs.seriesSort = m.name }

    fun closeSearch() { searchOpen = false; query = "" }

    private fun buildLibrary(): Library =
        LibraryBuilder.build(db.allBooks(), db.allProgress(), db.allOverrides(), db.allManualSeries(), db.allAliases(), db.allReads())

    fun reload() {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
        }
    }

    fun chooseFolder(uri: Uri) {
        val ctx = getApplication<Application>()
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (ignored: Throwable) {
        }
        val newStr = uri.toString()
        val oldStr = prefs.treeUri
        if (oldStr == newStr) {
            folderLost = false
            startScan()
            return
        }
        viewModelScope.launch {
            scanJob?.cancelAndJoin()
            coverJob?.cancelAndJoin()
            withContext(dbDisp) { db.clearAll() }
            withContext(Dispatchers.IO) { Covers.deleteAll(ctx) }
            if (oldStr != null) {
                try {
                    ctx.contentResolver.releasePersistableUriPermission(Uri.parse(oldStr), flags)
                } catch (ignored: Throwable) {
                }
            }
            prefs.treeUri = newStr
            treeUri = newStr
            folderLost = false
            library = Library.EMPTY
            seriesKey = null
            tab = Tab.HOME
            startScan()
        }
    }

    fun startScan() {
        val tree = treeUri ?: return
        if (scanJob?.isActive == true) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            scanDone = 0
            scanTotal = 0
            try {
                val uri = Uri.parse(tree)
                val granted = ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
                if (!granted) {
                    folderLost = true
                    return@launch
                }
                val found = LibraryScanner.list(ctx, uri)
                if (found.isEmpty()) {
                    val hadBooks = withContext(dbDisp) { db.allBooks().isNotEmpty() }
                    folderLost = hadBooks
                    return@launch
                }
                folderLost = false
                withContext(dbDisp) { LibraryScanner.sync(ctx, db, found) }
                library = withContext(dbDisp) { buildLibrary() }
                val pending = withContext(dbDisp) { db.allBooks().filter { !it.processed } }
                scanTotal = pending.size
                var last = System.currentTimeMillis()
                for (b in pending) {
                    ensureActive()
                    try {
                        Indexer.process(ctx, db, b)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (ignored: Throwable) {
                    }
                    scanDone++
                    val now = System.currentTimeMillis()
                    if (now - last > 800) {
                        last = now
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                library = withContext(dbDisp) { buildLibrary() }
                if (prefs.onlineCovers) startCoverFetch()
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: SecurityException) {
                folderLost = true
            } catch (ignored: Throwable) {
            } finally {
                scanning = false
            }
        }
    }

    /** Portada de un CBR (RAR) generada al abrirlo por primera vez. */
    fun coverFromReader(bookId: Long, bytes: ByteArray) {
        val b = library.books[bookId] ?: return
        if (b.coverPath != null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = Images.decodeSampled(bytes, 300, Bitmap.Config.ARGB_8888) ?: return@launch
            val path = Covers.save(ctx, b, bmp) ?: return@launch
            library = withContext(dbDisp) {
                db.updateCover(bookId, path)
                buildLibrary()
            }
        }
    }

    // ---- Portadas en línea (opcional) ----

    fun changeOnlineCovers(on: Boolean) {
        prefs.onlineCovers = on
        onlineCovers = on
        if (on) startCoverFetch() else coverJob?.cancel()
    }

    private fun startCoverFetch() {
        if (coverJob?.isActive == true) return
        val ctx = getApplication<Application>()
        coverJob = viewModelScope.launch(Dispatchers.IO) {
            fetchingCovers = true
            try {
                val todo = withContext(dbDisp) { CoverFetcher.pending(db, db.allBooks()) }
                var last = System.currentTimeMillis()
                var changed = false
                for (b in todo) {
                    ensureActive()
                    val r = CoverFetcher.fetch(ctx, db, b)
                    if (r is CoverFetcher.Result.Offline) break
                    if (r is CoverFetcher.Result.Found) changed = true
                    val now = System.currentTimeMillis()
                    if (changed && now - last > 1500) {
                        last = now
                        changed = false
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                if (changed) library = withContext(dbDisp) { buildLibrary() }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
            } finally {
                fetchingCovers = false
            }
        }
    }

    // ---- Organización manual de sagas (carpetas virtuales) ----

    private fun org(after: (() -> Unit)? = null, block: () -> Unit) {
        viewModelScope.launch {
            library = withContext(dbDisp) {
                block()
                buildLibrary()
            }
            after?.invoke()
        }
    }

    /** Como [org], pero guarda el estado previo de [uris] para ofrecer Deshacer. [block] devuelve la colección creada, si hay. */
    private fun orgUndoable(message: String, uris: List<String>, after: (() -> Unit)? = null, block: () -> Long?) {
        viewModelScope.launch {
            var snap: OrgSnapshot? = null
            var created: Long? = null
            library = withContext(dbDisp) {
                snap = db.snapshotOrg(uris)
                created = block()
                buildLibrary()
            }
            snap?.let { notice = Notice(message, it, created) }
            after?.invoke()
        }
    }

    /** Deshace el último movimiento: restaura la organización y los nombres internos previos. */
    fun undoLast() {
        val n = notice ?: return
        val s = n.snapshot ?: return
        notice = null
        viewModelScope.launch {
            library = withContext(dbDisp) {
                db.restoreOrg(s, n.createdSeriesId)
                buildLibrary()
            }
        }
    }

    fun clearNotice(id: Long) {
        if (notice?.id == id) notice = null
    }

    // ---- Selección múltiple ----

    fun toggleSelect(id: String) {
        selection = if (id in selection) selection - id else selection + id
    }

    fun clearSelection() {
        selection = emptySet()
    }

    /** Ids de libro que abarca la selección (una colección seleccionada incluye todos sus tomos). */
    fun selectedBookIds(): List<Long> {
        val out = LinkedHashSet<Long>()
        for (id in selection) {
            if (id.startsWith("b")) id.substring(1).toLongOrNull()?.let { if (library.books.containsKey(it)) out.add(it) }
            else library.series[id.substring(1)]?.volumes?.forEach { out.add(it.book.id) }
        }
        return out.toList()
    }

    // ---- Renombrado interno (nunca toca el archivo real) ----

    /** Nuevo nombre interno propuesto según la colección actual del cómic; null si no trae numeración. */
    fun proposedName(bookId: Long): String? {
        val b = library.books[bookId] ?: return null
        val s = library.bookSeries[bookId] ?: return null
        if (s.isUnnamed) return null
        return SeriesParser.internalName(s.name, b.fileName, b.number)
    }

    fun renameCandidates(ids: List<Long>): List<Long> = ids.filter { proposedName(it) != null }

    fun applyAliases(map: Map<Long, String>) {
        val byUri = HashMap<String, String>()
        for ((id, name) in map) library.books[id]?.uri?.let { byUri[it] = name }
        if (byUri.isEmpty()) return
        org { db.setAliases(byUri) }
    }

    fun restoreNames(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        org { db.clearAliases(uris) }
    }

    private fun offerRename(ids: List<Long>) {
        if (renameCandidates(ids).isNotEmpty()) dialog = OrgDialog.RenameOffer(ids)
    }

    private fun urisOf(ids: List<Long>): List<String> = ids.mapNotNull { library.books[it]?.uri }

    /** Cómic que solo trae numeración en su nombre ("001.cbz"): su nombre interno sigue a la colección donde esté. */
    private fun isUnnamedOrigin(id: Long): Boolean {
        val b = library.books[id] ?: return false
        return b.format == Format.COMIC && SeriesParser.isUnnamed(b.fileName)
    }

    /** Nombres internos "<colección> #<numeración original>" para los cómics sin nombre que se mueven a [collection]. */
    private fun unnamedAliases(ids: List<Long>, collection: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (id in ids) {
            if (!isUnnamedOrigin(id)) continue
            val b = library.books[id] ?: continue
            SeriesParser.internalName(collection, b.fileName, b.number)?.let { out[b.uri] = it }
        }
        return out
    }

    private fun isBookFormat(id: Long): Boolean = library.books[id]?.let { it.format != Format.COMIC } ?: false

    /** Crea una colección (de libros si [bookIds] son libros, o si no hay ids y se está en la pestaña Libros). */
    fun createSaga(name: String, bookIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        val isBooks = if (bookIds.isNotEmpty()) isBookFormat(bookIds[0]) else libTab == LibTab.BOOKS
        val ids = bookIds.filter { isBookFormat(it) == isBooks }
        val uris = urisOf(ids)
        val auto = unnamedAliases(ids, n)
        val toOffer = ids.filter { !isUnnamedOrigin(it) }
        if (ids.isEmpty()) {
            // Colección vacía: no se muestra en la Biblioteca hasta que tenga elementos (aparece al mover algo a ella).
            org { db.createManualSeries(n, isBooks) }
            notice = Notice("Colección «$n» creada. Se mostrará cuando le añadas elementos (Mover a…).")
            clearSelection()
            return
        }
        orgUndoable("Colección «$n» creada", uris, after = { offerRename(toOffer.filter { library.bookSeries.containsKey(it) }) }) {
            val id = db.createManualSeries(n, isBooks)
            if (id > 0) {
                db.setGroup(uris, "m:$id", n)
                db.setAliases(auto)
                id
            } else null
        }
        clearSelection()
    }

    /** Añade o mueve tomos a una colección existente (manual o automática). Libros y cómics no se mezclan. */
    fun moveToSeries(seriesKey: String, bookIds: List<Long>) {
        val s = library.series[seriesKey] ?: return
        val ids = bookIds.filter { isBookFormat(it) == s.isBooks }
        val uris = urisOf(ids)
        val unnamed = ids.filter { isUnnamedOrigin(it) }
        // Los cómics sin nombre toman el nombre de la colección de destino conservando su numeración
        // (y lo pierden si vuelven a "Sin nombre"). Los demás conservan la oferta de renombrado.
        val auto = if (s.isUnnamed) emptyMap() else unnamedAliases(unnamed, s.name)
        val clear = if (s.isUnnamed) urisOf(unnamed) else emptyList()
        val toOffer = if (s.isUnnamed) emptyList() else ids.filter { it !in unnamed }
        val msg = (if (ids.size == 1) "1 elemento movido a «" else "${ids.size} elementos movidos a «") + s.name + "»"
        orgUndoable(msg, uris, after = { offerRename(toOffer) }) {
            db.setGroup(uris, s.key, s.name)
            db.setAliases(auto)
            db.clearAliases(clear)
            null
        }
        clearSelection()
    }

    fun removeFromSaga(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        // Un cómic que vuelve a quedar suelto recupera su nombre con la numeración original.
        val clear = urisOf(bookIds.filter { isUnnamedOrigin(it) })
        orgUndoable(if (bookIds.size == 1) "Quitado de la colección" else "${bookIds.size} elementos quitados de la colección", uris) {
            db.setGroup(uris, GRP_STANDALONE, null)
            db.clearAliases(clear)
            null
        }
        clearSelection()
    }

    fun setBookNumber(bookId: Long, number: Int?) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.setNumber(uri, number) }
        clearSelection()
    }

    fun resetOrganization(bookId: Long) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.resetOverride(uri) }
        clearSelection()
    }

    fun deleteSaga(seriesKey: String) {
        val series = library.series[seriesKey] ?: return
        val id = series.manualId ?: return
        if (seriesKey == this.seriesKey) this.seriesKey = null
        val clear = urisOf(series.volumes.map { it.book.id }.filter { isUnnamedOrigin(it) })
        org {
            db.deleteManualSeries(id)
            db.clearAliases(clear)
        }
    }

    // ---- Relectura: reinicia la lectura ACTUAL; historial, estadísticas y lecturas completadas se conservan ----

    fun resetSeriesReading(seriesKey: String) {
        val s = library.series[seriesKey] ?: return
        val ids = s.volumes.map { it.book.id }
        if (ids.isEmpty()) return
        org { db.resetProgress(ids) }
        notice = Notice("Lectura de «${s.name}» reiniciada")
    }

    /** Hay una lectura en curso (empezada y no reiniciada) de este libro. */
    fun hasProgress(bookId: Long): Boolean =
        library.items.any { it is com.jullbook.app.data.SingleItem && it.book.id == bookId && it.progress != null } ||
            library.bookSeries[bookId]?.volumes?.any { it.book.id == bookId && it.progress != null } == true

    fun resetBookReading(bookId: Long) {
        org { db.resetProgress(listOf(bookId)) }
        notice = Notice("Lectura reiniciada")
    }

    fun openSeries(key: String) {
        clearSelection()
        seriesKey = key
    }

    fun openBook(book: Book) {
        finishedPrompt = null
        notice = null
        reading = book
    }

    /** Devuelve la posición guardada (si la hay) y marca el libro como abierto ahora. */
    suspend fun beginReading(id: Long): Progress? = withContext(dbDisp) {
        val (p, sid) = db.beginReading(id, System.currentTimeMillis())
        sessionId = sid
        p
    }

    /** Suma tiempo de lectura activo (pantalla abierta con el lector delante) a la sesión actual. */
    fun recordReadTime(bookId: Long, deltaMs: Long) {
        if (deltaMs <= 0) return
        val sid = sessionId
        val d = deltaMs.coerceAtMost(10 * 60_000L)
        viewModelScope.launch(dbDisp) { db.addReadTime(bookId, sid, d, System.currentTimeMillis()) }
    }

    /** Memoria de lectura para la pantalla de estadísticas e historial. */
    suspend fun loadMemory(): MemoryData {
        val lib = library
        return withContext(dbDisp) { Memory.build(db, lib) }
    }

    fun saveProgress(p: Progress) {
        viewModelScope.launch(dbDisp) {
            val newlyFinished = db.saveProgress(p)
            if (newlyFinished && reading?.id == p.bookId) finishedPrompt = p.bookId
            if (reading == null) library = buildLibrary()
        }
    }

    fun dismissFinished() {
        finishedPrompt = null
    }

    private fun closeReader() {
        reading = null
        finishedPrompt = null
        viewModelScope.launch {
            delay(300)
            reload()
        }
    }

    /** Tras terminar: vuelve a la colección del libro (si la tiene) o a la Biblioteca. */
    fun finishToCollection(bookId: Long) {
        val s = library.bookSeries[bookId]
        closeReader()
        tab = Tab.LIBRARY
        if (s != null) {
            clearSelection()
            seriesKey = s.key
        } else {
            seriesKey = null
        }
    }

    fun finishToLibrary(bookId: Long) {
        val b = library.books[bookId]
        closeReader()
        seriesKey = null
        tab = Tab.LIBRARY
        if (b != null) {
            val t = if (b.format == Format.COMIC) LibTab.COMICS else LibTab.BOOKS
            libTab = t
            prefs.libTab = t.name
        }
    }

    /** Devuelve true si consumió el gesto de atrás. */
    fun back(): Boolean {
        if (showStats && reading == null) {
            showStats = false
            return true
        }
        if (reading == null && selection.isNotEmpty()) {
            clearSelection()
            return true
        }
        if (reading != null) {
            closeReader()
            return true
        }
        if (seriesKey != null) {
            seriesKey = null
            return true
        }
        return false
    }

    override fun onCleared() {
        super.onCleared()
        dbExecutor.shutdown()
    }
}
