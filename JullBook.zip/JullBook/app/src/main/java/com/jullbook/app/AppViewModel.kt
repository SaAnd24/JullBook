package com.jullbook.app

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.data.Book
import com.jullbook.app.data.CoverFetcher
import com.jullbook.app.data.Format
import com.jullbook.app.data.Images
import com.jullbook.app.data.GRP_STANDALONE
import com.jullbook.app.data.Covers
import com.jullbook.app.data.Db
import com.jullbook.app.data.Indexer
import com.jullbook.app.data.Library
import com.jullbook.app.data.Memory
import com.jullbook.app.data.MemoryData
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SeriesParser
import com.jullbook.app.data.LibraryBuilder
import com.jullbook.app.data.LibraryScanner
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

enum class Tab { HOME, LIBRARY }

enum class LibTab { BOOKS, COMICS }

/** Diálogos de organización manual (solo afectan a metadatos de la app, nunca a los archivos). */
sealed interface OrgDialog {
    object CreateSaga : OrgDialog
    class BookActions(val bookId: Long) : OrgDialog
    class MoveTo(val bookIds: List<Long>) : OrgDialog
    class NewSagaFor(val bookIds: List<Long>) : OrgDialog
    class EditNumber(val bookId: Long) : OrgDialog
    class AddVolumes(val seriesKey: String) : OrgDialog
    class DeleteSaga(val seriesKey: String) : OrgDialog

    /** Ofrece renombrar internamente los cómics recién movidos (todos a la vez o uno a uno). */
    class RenameOffer(val bookIds: List<Long>) : OrgDialog
    class RenameReview(val bookIds: List<Long>) : OrgDialog
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val db = Db(app)

    // Un solo hilo para lecturas/escrituras de progreso: mantiene el orden de los guardados.
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val dbDisp = dbExecutor.asCoroutineDispatcher()

    var library by mutableStateOf(Library.EMPTY)
        private set
    var loaded by mutableStateOf(false)
        private set
    var treeUri by mutableStateOf(prefs.treeUri)
        private set
    var tab by mutableStateOf(Tab.HOME)
    var libTab by mutableStateOf(LibTab.BOOKS)
    var dialog by mutableStateOf<OrgDialog?>(null)

    /** Multiselección: ids de elemento ("b<id>" libro/cómic, "s<clave>" colección). */
    var selection by mutableStateOf(setOf<String>())
        private set
    var showStats by mutableStateOf(false)
    var onlineCovers by mutableStateOf(prefs.onlineCovers)
        private set
    var fetchingCovers by mutableStateOf(false)
        private set
    var seriesKey by mutableStateOf<String?>(null)
        private set
    var reading by mutableStateOf<Book?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableIntStateOf(0)
        private set
    var scanTotal by mutableIntStateOf(0)
        private set
    var folderLost by mutableStateOf(false)
        private set

    private var sessionId = -1L
    private var scanJob: Job? = null
    private var coverJob: Job? = null

    init {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
            if (treeUri != null) startScan()
        }
    }

    private fun buildLibrary(): Library =
        LibraryBuilder.build(db.allBooks(), db.allProgress(), db.allOverrides(), db.allManualSeries(), db.allAliases())

    fun reload() {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
        }
    }

    fun chooseFolder(uri: Uri) {
        val ctx = getApplication<Application>()
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (ignored: Throwable) {
        }
        val newStr = uri.toString()
        val oldStr = prefs.treeUri
        if (oldStr == newStr) {
            folderLost = false
            startScan()
            return
        }
        viewModelScope.launch {
            scanJob?.cancelAndJoin()
            coverJob?.cancelAndJoin()
            withContext(dbDisp) { db.clearAll() }
            withContext(Dispatchers.IO) { Covers.deleteAll(ctx) }
            if (oldStr != null) {
                try {
                    ctx.contentResolver.releasePersistableUriPermission(Uri.parse(oldStr), flags)
                } catch (ignored: Throwable) {
                }
            }
            prefs.treeUri = newStr
            treeUri = newStr
            folderLost = false
            library = Library.EMPTY
            seriesKey = null
            tab = Tab.HOME
            startScan()
        }
    }

    fun startScan() {
        val tree = treeUri ?: return
        if (scanJob?.isActive == true) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            scanDone = 0
            scanTotal = 0
            try {
                val uri = Uri.parse(tree)
                val granted = ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
                if (!granted) {
                    folderLost = true
                    return@launch
                }
                val found = LibraryScanner.list(ctx, uri)
                if (found.isEmpty()) {
                    val hadBooks = withContext(dbDisp) { db.allBooks().isNotEmpty() }
                    folderLost = hadBooks
                    return@launch
                }
                folderLost = false
                withContext(dbDisp) { LibraryScanner.sync(ctx, db, found) }
                library = withContext(dbDisp) { buildLibrary() }
                val pending = withContext(dbDisp) { db.allBooks().filter { !it.processed } }
                scanTotal = pending.size
                var last = System.currentTimeMillis()
                for (b in pending) {
                    ensureActive()
                    try {
                        Indexer.process(ctx, db, b)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (ignored: Throwable) {
                    }
                    scanDone++
                    val now = System.currentTimeMillis()
                    if (now - last > 800) {
                        last = now
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                library = withContext(dbDisp) { buildLibrary() }
                if (prefs.onlineCovers) startCoverFetch()
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: SecurityException) {
                folderLost = true
            } catch (ignored: Throwable) {
            } finally {
                scanning = false
            }
        }
    }

    /** Portada de un CBR (RAR) generada al abrirlo por primera vez. */
    fun coverFromReader(bookId: Long, bytes: ByteArray) {
        val b = library.books[bookId] ?: return
        if (b.coverPath != null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = Images.decodeSampled(bytes, 300, Bitmap.Config.ARGB_8888) ?: return@launch
            val path = Covers.save(ctx, b, bmp) ?: return@launch
            library = withContext(dbDisp) {
                db.updateCover(bookId, path)
                buildLibrary()
            }
        }
    }

    // ---- Portadas en línea (opcional) ----

    fun changeOnlineCovers(on: Boolean) {
        prefs.onlineCovers = on
        onlineCovers = on
        if (on) startCoverFetch() else coverJob?.cancel()
    }

    private fun startCoverFetch() {
        if (coverJob?.isActive == true) return
        val ctx = getApplication<Application>()
        coverJob = viewModelScope.launch(Dispatchers.IO) {
            fetchingCovers = true
            try {
                val todo = withContext(dbDisp) { CoverFetcher.pending(db, db.allBooks()) }
                var last = System.currentTimeMillis()
                var changed = false
                for (b in todo) {
                    ensureActive()
                    val r = CoverFetcher.fetch(ctx, db, b)
                    if (r is CoverFetcher.Result.Offline) break
                    if (r is CoverFetcher.Result.Found) changed = true
                    val now = System.currentTimeMillis()
                    if (changed && now - last > 1500) {
                        last = now
                        changed = false
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                if (changed) library = withContext(dbDisp) { buildLibrary() }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
            } finally {
                fetchingCovers = false
            }
        }
    }

    // ---- Organización manual de sagas (carpetas virtuales) ----

    private fun org(after: (() -> Unit)? = null, block: () -> Unit) {
        viewModelScope.launch {
            library = withContext(dbDisp) {
                block()
                buildLibrary()
            }
            after?.invoke()
        }
    }

    // ---- Selección múltiple ----

    fun toggleSelect(id: String) {
        selection = if (id in selection) selection - id else selection + id
    }

    fun clearSelection() {
        selection = emptySet()
    }

    /** Ids de libro que abarca la selección (una colección seleccionada incluye todos sus tomos). */
    fun selectedBookIds(): List<Long> {
        val out = LinkedHashSet<Long>()
        for (id in selection) {
            if (id.startsWith("b")) id.substring(1).toLongOrNull()?.let { if (library.books.containsKey(it)) out.add(it) }
            else library.series[id.substring(1)]?.volumes?.forEach { out.add(it.book.id) }
        }
        return out.filter { library.books[it]?.format == Format.COMIC }
    }

    // ---- Renombrado interno (nunca toca el archivo real) ----

    /** Nuevo nombre interno propuesto según la colección actual del cómic; null si no trae numeración. */
    fun proposedName(bookId: Long): String? {
        val b = library.books[bookId] ?: return null
        val s = library.bookSeries[bookId] ?: return null
        return SeriesParser.internalName(s.name, b.fileName, b.number)
    }

    fun renameCandidates(ids: List<Long>): List<Long> = ids.filter { proposedName(it) != null }

    fun applyAliases(map: Map<Long, String>) {
        val byUri = HashMap<String, String>()
        for ((id, name) in map) library.books[id]?.uri?.let { byUri[it] = name }
        if (byUri.isEmpty()) return
        org { db.setAliases(byUri) }
    }

    fun restoreNames(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        org { db.clearAliases(uris) }
    }

    private fun offerRename(ids: List<Long>) {
        if (renameCandidates(ids).isNotEmpty()) dialog = OrgDialog.RenameOffer(ids)
    }

    private fun urisOf(ids: List<Long>): List<String> = ids.mapNotNull { library.books[it]?.uri }

    fun createSaga(name: String, bookIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        val uris = urisOf(bookIds)
        org(after = { if (bookIds.isNotEmpty()) offerRename(bookIds.filter { library.bookSeries.containsKey(it) }) }) {
            val id = db.createManualSeries(n)
            if (id > 0) db.setGroup(uris, "m:$id", n)
        }
        clearSelection()
    }

    /** Añade o mueve tomos a una saga existente (manual o automática). */
    fun moveToSeries(seriesKey: String, bookIds: List<Long>) {
        val s = library.series[seriesKey] ?: return
        val ids = bookIds.filter { library.books[it]?.format == Format.COMIC }
        val uris = urisOf(ids)
        org(after = { offerRename(ids) }) { db.setGroup(uris, s.key, s.name) }
        clearSelection()
    }

    fun removeFromSaga(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        org { db.setGroup(uris, GRP_STANDALONE, null) }
        clearSelection()
    }

    fun setBookNumber(bookId: Long, number: Int?) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.setNumber(uri, number) }
        clearSelection()
    }

    fun resetOrganization(bookId: Long) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.resetOverride(uri) }
        clearSelection()
    }

    fun deleteSaga(seriesKey: String) {
        val id = library.series[seriesKey]?.manualId ?: return
        if (seriesKey == this.seriesKey) this.seriesKey = null
        org { db.deleteManualSeries(id) }
    }

    fun openSeries(key: String) {
        clearSelection()
        seriesKey = key
    }

    fun openBook(book: Book) {
        reading = book
    }

    /** Devuelve la posición guardada (si la hay) y marca el libro como abierto ahora. */
    suspend fun beginReading(id: Long): Progress? = withContext(dbDisp) {
        val (p, sid) = db.beginReading(id, System.currentTimeMillis())
        sessionId = sid
        p
    }

    /** Suma tiempo de lectura activo (pantalla abierta con el lector delante) a la sesión actual. */
    fun recordReadTime(bookId: Long, deltaMs: Long) {
        if (deltaMs <= 0) return
        val sid = sessionId
        val d = deltaMs.coerceAtMost(10 * 60_000L)
        viewModelScope.launch(dbDisp) { db.addReadTime(bookId, sid, d, System.currentTimeMillis()) }
    }

    /** Memoria de lectura para la pantalla de estadísticas e historial. */
    suspend fun loadMemory(): MemoryData {
        val lib = library
        return withContext(dbDisp) { Memory.build(db, lib) }
    }

    fun saveProgress(p: Progress) {
        viewModelScope.launch(dbDisp) {
            db.saveProgress(p)
            if (reading == null) library = buildLibrary()
        }
    }

    /** Devuelve true si consumió el gesto de atrás. */
    fun back(): Boolean {
        if (showStats && reading == null) {
            showStats = false
            return true
        }
        if (reading == null && selection.isNotEmpty()) {
            clearSelection()
            return true
        }
        if (reading != null) {
            reading = null
            viewModelScope.launch {
                delay(300)
                reload()
            }
            return true
        }
        if (seriesKey != null) {
            seriesKey = null
            return true
        }
        return false
    }

    override fun onCleared() {
        super.onCleared()
        dbExecutor.shutdown()
    }
}
