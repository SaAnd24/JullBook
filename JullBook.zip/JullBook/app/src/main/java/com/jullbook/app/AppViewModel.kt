package com.jullbook.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.data.Book
import com.jullbook.app.data.CoverFetcher
import com.jullbook.app.data.Format
import com.jullbook.app.data.GRP_STANDALONE
import com.jullbook.app.data.Covers
import com.jullbook.app.data.Db
import com.jullbook.app.data.Indexer
import com.jullbook.app.data.Library
import com.jullbook.app.data.LibraryBuilder
import com.jullbook.app.data.LibraryScanner
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

enum class Tab { HOME, LIBRARY }

enum class LibTab { BOOKS, COMICS }

/** Diálogos de organización manual (solo afectan a metadatos de la app, nunca a los archivos). */
sealed interface OrgDialog {
    object CreateSaga : OrgDialog
    class BookActions(val bookId: Long) : OrgDialog
    class MoveTo(val bookIds: List<Long>) : OrgDialog
    class NewSagaFor(val bookIds: List<Long>) : OrgDialog
    class EditNumber(val bookId: Long) : OrgDialog
    class AddVolumes(val seriesKey: String) : OrgDialog
    class DeleteSaga(val seriesKey: String) : OrgDialog
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val db = Db(app)

    // Un solo hilo para lecturas/escrituras de progreso: mantiene el orden de los guardados.
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val dbDisp = dbExecutor.asCoroutineDispatcher()

    var library by mutableStateOf(Library.EMPTY)
        private set
    var loaded by mutableStateOf(false)
        private set
    var treeUri by mutableStateOf(prefs.treeUri)
        private set
    var tab by mutableStateOf(Tab.HOME)
    var libTab by mutableStateOf(LibTab.BOOKS)
    var dialog by mutableStateOf<OrgDialog?>(null)
    var onlineCovers by mutableStateOf(prefs.onlineCovers)
        private set
    var fetchingCovers by mutableStateOf(false)
        private set
    var seriesKey by mutableStateOf<String?>(null)
        private set
    var reading by mutableStateOf<Book?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableIntStateOf(0)
        private set
    var scanTotal by mutableIntStateOf(0)
        private set
    var folderLost by mutableStateOf(false)
        private set

    private var scanJob: Job? = null
    private var coverJob: Job? = null

    init {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
            if (treeUri != null) startScan()
        }
    }

    private fun buildLibrary(): Library =
        LibraryBuilder.build(db.allBooks(), db.allProgress(), db.allOverrides(), db.allManualSeries())

    fun reload() {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
        }
    }

    fun chooseFolder(uri: Uri) {
        val ctx = getApplication<Application>()
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (ignored: Throwable) {
        }
        val newStr = uri.toString()
        val oldStr = prefs.treeUri
        if (oldStr == newStr) {
            folderLost = false
            startScan()
            return
        }
        viewModelScope.launch {
            scanJob?.cancelAndJoin()
            coverJob?.cancelAndJoin()
            withContext(dbDisp) { db.clearAll() }
            withContext(Dispatchers.IO) { Covers.deleteAll(ctx) }
            if (oldStr != null) {
                try {
                    ctx.contentResolver.releasePersistableUriPermission(Uri.parse(oldStr), flags)
                } catch (ignored: Throwable) {
                }
            }
            prefs.treeUri = newStr
            treeUri = newStr
            folderLost = false
            library = Library.EMPTY
            seriesKey = null
            tab = Tab.HOME
            startScan()
        }
    }

    fun startScan() {
        val tree = treeUri ?: return
        if (scanJob?.isActive == true) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            scanDone = 0
            scanTotal = 0
            try {
                val uri = Uri.parse(tree)
                val granted = ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
                if (!granted) {
                    folderLost = true
                    return@launch
                }
                val found = LibraryScanner.list(ctx, uri)
                if (found.isEmpty()) {
                    val hadBooks = withContext(dbDisp) { db.allBooks().isNotEmpty() }
                    folderLost = hadBooks
                    return@launch
                }
                folderLost = false
                withContext(dbDisp) { LibraryScanner.sync(ctx, db, found) }
                library = withContext(dbDisp) { buildLibrary() }
                val pending = withContext(dbDisp) { db.allBooks().filter { !it.processed } }
                scanTotal = pending.size
                var last = System.currentTimeMillis()
                for (b in pending) {
                    ensureActive()
                    try {
                        Indexer.process(ctx, db, b)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (ignored: Throwable) {
                    }
                    scanDone++
                    val now = System.currentTimeMillis()
                    if (now - last > 800) {
                        last = now
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                library = withContext(dbDisp) { buildLibrary() }
                if (prefs.onlineCovers) startCoverFetch()
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: SecurityException) {
                folderLost = true
            } catch (ignored: Throwable) {
            } finally {
                scanning = false
            }
        }
    }

    // ---- Portadas en línea (opcional) ----

    fun changeOnlineCovers(on: Boolean) {
        prefs.onlineCovers = on
        onlineCovers = on
        if (on) startCoverFetch() else coverJob?.cancel()
    }

    private fun startCoverFetch() {
        if (coverJob?.isActive == true) return
        val ctx = getApplication<Application>()
        coverJob = viewModelScope.launch(Dispatchers.IO) {
            fetchingCovers = true
            try {
                val todo = withContext(dbDisp) { CoverFetcher.pending(db, db.allBooks()) }
                var last = System.currentTimeMillis()
                var changed = false
                for (b in todo) {
                    ensureActive()
                    val r = CoverFetcher.fetch(ctx, db, b)
                    if (r is CoverFetcher.Result.Offline) break
                    if (r is CoverFetcher.Result.Found) changed = true
                    val now = System.currentTimeMillis()
                    if (changed && now - last > 1500) {
                        last = now
                        changed = false
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                if (changed) library = withContext(dbDisp) { buildLibrary() }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
            } finally {
                fetchingCovers = false
            }
        }
    }

    // ---- Organización manual de sagas (carpetas virtuales) ----

    private fun org(block: () -> Unit) {
        viewModelScope.launch {
            library = withContext(dbDisp) {
                block()
                buildLibrary()
            }
        }
    }

    private fun urisOf(ids: List<Long>): List<String> = ids.mapNotNull { library.books[it]?.uri }

    fun createSaga(name: String, bookIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        val uris = urisOf(bookIds)
        org {
            val id = db.createManualSeries(n)
            if (id > 0) db.setGroup(uris, "m:$id", n)
        }
    }

    /** Añade o mueve tomos a una saga existente (manual o automática). */
    fun moveToSeries(seriesKey: String, bookIds: List<Long>) {
        val s = library.series[seriesKey] ?: return
        val uris = urisOf(bookIds.filter { library.books[it]?.format == Format.COMIC })
        org { db.setGroup(uris, s.key, s.name) }
    }

    fun removeFromSaga(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        org { db.setGroup(uris, GRP_STANDALONE, null) }
    }

    fun setBookNumber(bookId: Long, number: Int?) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.setNumber(uri, number) }
    }

    fun resetOrganization(bookId: Long) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.resetOverride(uri) }
    }

    fun deleteSaga(seriesKey: String) {
        val id = library.series[seriesKey]?.manualId ?: return
        if (seriesKey == this.seriesKey) this.seriesKey = null
        org { db.deleteManualSeries(id) }
    }

    fun openSeries(key: String) {
        seriesKey = key
    }

    fun openBook(book: Book) {
        reading = book
    }

    /** Devuelve la posición guardada (si la hay) y marca el libro como abierto ahora. */
    suspend fun beginReading(id: Long): Progress? = withContext(dbDisp) {
        val p = db.getProgress(id)
        val now = System.currentTimeMillis()
        db.saveProgress(p?.copy(lastRead = now) ?: Progress(id, 0, 0, 0f, 0f, now, ST_READING))
        p
    }

    fun saveProgress(p: Progress) {
        viewModelScope.launch(dbDisp) {
            db.saveProgress(p)
            if (reading == null) library = buildLibrary()
        }
    }

    /** Devuelve true si consumió el gesto de atrás. */
    fun back(): Boolean {
        if (reading != null) {
            reading = null
            viewModelScope.launch {
                delay(300)
                reload()
            }
            return true
        }
        if (seriesKey != null) {
            seriesKey = null
            return true
        }
        return false
    }

    override fun onCleared() {
        super.onCleared()
        dbExecutor.shutdown()
    }
}
