package com.jullbook.app

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.data.Achievement
import com.jullbook.app.data.Achievements
import com.jullbook.app.data.Book
import com.jullbook.app.data.Eggs
import com.jullbook.app.data.Juli
import com.jullbook.app.data.JuliCtx
import com.jullbook.app.data.JuliParams
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.ST_UNREAD
import com.jullbook.app.data.Surprise
import com.jullbook.app.data.SurpriseEngine
import com.jullbook.app.data.AchSnapshot
import android.provider.DocumentsContract
import java.util.Calendar
import kotlin.random.Random
import com.jullbook.app.data.CoverFetcher
import com.jullbook.app.data.Format
import com.jullbook.app.data.Images
import com.jullbook.app.data.GRP_STANDALONE
import com.jullbook.app.data.Covers
import com.jullbook.app.data.Db
import com.jullbook.app.data.Indexer
import com.jullbook.app.data.Library
import com.jullbook.app.data.OrgSnapshot
import com.jullbook.app.data.SortMode
import com.jullbook.app.data.StatusFilter
import com.jullbook.app.data.Memory
import com.jullbook.app.data.MemoryData
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SeriesParser
import com.jullbook.app.data.LibraryBuilder
import com.jullbook.app.data.LibraryScanner
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

enum class Tab { HOME, LIBRARY, ACHIEVEMENTS, SETTINGS }

enum class LibTab { BOOKS, COMICS }

/** Comentario breve de Juli que se muestra como burbuja. */
class JuliMsg(val text: String, val title: String? = null, val id: Long = System.nanoTime())

/** Aviso breve con acción opcional de Deshacer (solo organización: nunca toca archivos). */
class Notice(
    val message: String,
    val snapshot: OrgSnapshot? = null,
    val createdSeriesId: Long? = null,
    val id: Long = System.nanoTime()
)

/** Diálogos de organización manual (solo afectan a metadatos de la app, nunca a los archivos). */
sealed interface OrgDialog {
    object CreateSaga : OrgDialog
    class BookActions(val bookId: Long) : OrgDialog
    class MoveTo(val bookIds: List<Long>) : OrgDialog
    class NewSagaFor(val bookIds: List<Long>) : OrgDialog
    class EditNumber(val bookId: Long) : OrgDialog
    class AddVolumes(val seriesKey: String) : OrgDialog
    class DeleteSaga(val seriesKey: String) : OrgDialog

    /** Confirmación antes de reiniciar la lectura de una colección completa. */
    class ResetReading(val seriesKey: String) : OrgDialog

    /** Ofrece renombrar internamente los cómics recién movidos (todos a la vez o uno a uno). */
    class RenameOffer(val bookIds: List<Long>) : OrgDialog
    class RenameReview(val bookIds: List<Long>) : OrgDialog
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val db = Db(app)

    // Un solo hilo para lecturas/escrituras de progreso: mantiene el orden de los guardados.
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val dbDisp = dbExecutor.asCoroutineDispatcher()

    var library by mutableStateOf(Library.EMPTY)
        private set
    var loaded by mutableStateOf(false)
        private set
    var treeUri by mutableStateOf(prefs.treeUri)
        private set
    var tab by mutableStateOf(Tab.HOME)
    var libTab by mutableStateOf(runCatching { LibTab.valueOf(prefs.libTab) }.getOrDefault(LibTab.BOOKS))
        private set
    var libSort by mutableStateOf(SortMode.of(prefs.libSort, SortMode.NAME))
        private set
    var libFilter by mutableStateOf(StatusFilter.of(prefs.libFilter))
        private set
    var libList by mutableStateOf(prefs.libList)
        private set
    var seriesSort by mutableStateOf(SortMode.of(prefs.seriesSort, SortMode.NUMBER))
        private set

    /** Búsqueda de la Biblioteca (no se recuerda entre sesiones). */
    var searchOpen by mutableStateOf(false)
    var query by mutableStateOf("")

    /** Posición de desplazamiento de cada pestaña de la Biblioteca (se recuerda entre sesiones). */
    val gridStates: Map<LibTab, LazyGridState> = LibTab.entries.associateWith {
        LazyGridState(prefs.scrollIndex(it.name), prefs.scrollOffset(it.name))
    }

    var notice by mutableStateOf<Notice?>(null)
    var finishedPrompt by mutableStateOf<Long?>(null)
        private set
    var dialog by mutableStateOf<OrgDialog?>(null)

    /** Multiselección: ids de elemento ("b<id>" libro/cómic, "s<clave>" colección). */
    var selection by mutableStateOf(setOf<String>())
        private set
    var showStats by mutableStateOf(false)
    var onlineCovers by mutableStateOf(prefs.onlineCovers)
        private set
    var fetchingCovers by mutableStateOf(false)
        private set
    var seriesKey by mutableStateOf<String?>(null)
        private set
    var reading by mutableStateOf<Book?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableIntStateOf(0)
        private set
    var scanTotal by mutableIntStateOf(0)
        private set
    var folderLost by mutableStateOf(false)
        private set

    // ---- JullBook 1.0 ----
    var onboarded by mutableStateOf(prefs.onboarded || prefs.treeUri != null)
        private set
    var userName by mutableStateOf(prefs.userName)
        private set
    var comicsUri by mutableStateOf(prefs.comicsUri)
        private set
    var themeId by mutableStateOf(prefs.themeId)
        private set
    var customBg by mutableIntStateOf(prefs.customBg)
        private set
    var customAccent by mutableIntStateOf(prefs.customAccent)
        private set
    var customText by mutableIntStateOf(prefs.customText)
        private set
    var expEnabled by mutableStateOf(prefs.expEnabled)
        private set
    var expStyle by mutableStateOf(prefs.expStyle)
        private set
    var expIntensity by mutableStateOf(prefs.expIntensity)
        private set
    var juliTalk by mutableIntStateOf(prefs.juliTalk)
        private set

    /** Portada que Juli Experience usa para teñir la biblioteca (la fijan las pantallas que se están viendo). */
    var ambientPath by mutableStateOf<String?>(null)

    var memory by mutableStateOf(MemoryData.EMPTY)
        private set

    /** false = lector minimizado (sigue vivo en segundo plano con su posición exacta). */
    var readerVisible by mutableStateOf(true)
        private set
    var readingPercent by mutableStateOf(0f)
        private set

    var surprise by mutableStateOf<Surprise?>(null)
        private set
    var surpriseShow by mutableStateOf(false)
        private set
    var bubble by mutableStateOf<JuliMsg?>(null)
        private set
    var homeNote by mutableStateOf(prefs.homeNote)
        private set
    var finishedComment by mutableStateOf<String?>(null)
        private set
    var achToast by mutableStateOf<Achievement?>(null)
        private set
    var confetti by mutableIntStateOf(0)
        private set
    var waveSpin by mutableIntStateOf(0)
        private set
    var eggs by mutableStateOf(prefs.eggs())
        private set

    private val achQueue = ArrayList<Achievement>()
    private val recentSurprise = ArrayList<Long>()
    private val surpriseTimes = ArrayList<Long>()
    private val themeTimes = ArrayList<Long>()
    private val minimizeTimes = ArrayList<Long>()
    private var tapCount = 0
    private var lastTap = 0L
    private var curSessionMs = 0L
    private var longSessionSaid = false

    private var sessionId = -1L
    private var scanJob: Job? = null
    private var coverJob: Job? = null

    init {
        if (!prefs.onboarded && prefs.treeUri != null) prefs.onboarded = true
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
            if (roots().isNotEmpty()) startScan()
            val cal = Calendar.getInstance()
            Eggs.todayDateEgg(cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))?.let { discoverEgg(it) }
            refreshMeta(appStart = true)
        }
    }

    private fun roots(): List<String> = listOfNotNull(prefs.treeUri, prefs.comicsUri).distinct()

    fun selectLibTab(t: LibTab) {
        clearSelection()
        libTab = t
        prefs.libTab = t.name
    }

    fun changeLibSort(m: SortMode) { libSort = m; prefs.libSort = m.name }
    fun changeLibFilter(f: StatusFilter) { libFilter = f; prefs.libFilter = f.name }
    fun toggleLibList() { libList = !libList; prefs.libList = libList }
    fun changeSeriesSort(m: SortMode) { seriesSort = m; prefs.seriesSort = m.name }

    fun closeSearch() { searchOpen = false; query = "" }

    private fun buildLibrary(): Library =
        LibraryBuilder.build(db.allBooks(), db.allProgress(), db.allOverrides(), db.allManualSeries(), db.allAliases(), db.allReads())

    fun reload() {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
        }
    }

    fun persistRead(uri: Uri) {
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Throwable) {
        }
    }

    private fun releaseRead(old: String?) {
        if (old == null || old in roots()) return
        try {
            getApplication<Application>().contentResolver.releasePersistableUriPermission(Uri.parse(old), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Throwable) {
        }
    }

    /** Carpeta de libros (isBooks) o de cómics. Solo cambia dónde se busca: no se pierde progreso de lo que sigue en las carpetas. */
    fun setFolder(isBooks: Boolean, uri: Uri) {
        persistRead(uri)
        val new = uri.toString()
        val old = if (isBooks) prefs.treeUri else prefs.comicsUri
        if (isBooks) { prefs.treeUri = new; treeUri = new } else { prefs.comicsUri = new; comicsUri = new }
        releaseRead(old)
        folderLost = false
        rescan()
    }

    /** Relanza el escaneo esperando a que termine el anterior (si lo hay). */
    private fun rescan() {
        viewModelScope.launch {
            scanJob?.cancelAndJoin()
            startScan()
        }
    }

    fun clearComicsFolder() {
        val old = prefs.comicsUri
        prefs.comicsUri = null
        comicsUri = null
        releaseRead(old)
        rescan()
    }

    /** Compatibilidad: la carpeta elegida desde un aviso es la de libros. */
    fun chooseFolder(uri: Uri) = setFolder(true, uri)

    /** Cierra el onboarding: guarda el nombre y las carpetas y entra al nuevo Inicio escaneando. */
    fun finishOnboarding(name: String, books: Uri?, comics: Uri?) {
        setUserName(name)
        books?.let { persistRead(it); prefs.treeUri = it.toString(); treeUri = it.toString() }
        comics?.let { persistRead(it); prefs.comicsUri = it.toString(); comicsUri = it.toString() }
        prefs.onboarded = true
        onboarded = true
        tab = Tab.HOME
        folderLost = false
        startScan()
    }

    fun startScan() {
        val rootList = roots()
        if (rootList.isEmpty()) return
        if (scanJob?.isActive == true) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            scanDone = 0
            scanTotal = 0
            try {
                val uris = rootList.map { Uri.parse(it) }
                val perms = ctx.contentResolver.persistedUriPermissions
                if (uris.any { u -> perms.none { it.uri == u && it.isReadPermission } }) {
                    folderLost = true
                    return@launch
                }
                val existing = withContext(dbDisp) { db.allBooks() }
                val found = ArrayList<LibraryScanner.Found>()
                val seen = HashSet<String>()
                var lost = false
                for (u in uris) {
                    val part = LibraryScanner.list(ctx, u)
                    // Una carpeta que antes tenía libros y ahora devuelve 0: probablemente no está disponible. No se borra nada.
                    if (part.isEmpty() && existing.any { it.uri.startsWith(u.toString() + "/document/") }) lost = true
                    for (f in part) {
                        val key = (f.uri.authority ?: "") + "|" + (runCatching { DocumentsContract.getDocumentId(f.uri) }.getOrNull() ?: f.uri.toString())
                        if (seen.add(key)) found.add(f)
                    }
                }
                if (lost) {
                    folderLost = true
                    return@launch
                }
                if (found.isEmpty()) {
                    folderLost = existing.isNotEmpty()
                    return@launch
                }
                folderLost = false
                withContext(dbDisp) { LibraryScanner.sync(ctx, db, found) }
                library = withContext(dbDisp) { buildLibrary() }
                val pending = withContext(dbDisp) { db.allBooks().filter { !it.processed } }
                scanTotal = pending.size
                var last = System.currentTimeMillis()
                for (b in pending) {
                    ensureActive()
                    try {
                        Indexer.process(ctx, db, b)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (ignored: Throwable) {
                    }
                    scanDone++
                    val now = System.currentTimeMillis()
                    if (now - last > 800) {
                        last = now
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                library = withContext(dbDisp) { buildLibrary() }
                if (prefs.onlineCovers) startCoverFetch()
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: SecurityException) {
                folderLost = true
            } catch (ignored: Throwable) {
            } finally {
                scanning = false
                refreshMeta()
            }
        }
    }

    /** Portada de un CBR (RAR) generada al abrirlo por primera vez. */
    fun coverFromReader(bookId: Long, bytes: ByteArray) {
        val b = library.books[bookId] ?: return
        if (b.coverPath != null) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val bmp = Images.decodeSampled(bytes, 300, Bitmap.Config.ARGB_8888) ?: return@launch
            val path = Covers.save(ctx, b, bmp) ?: return@launch
            library = withContext(dbDisp) {
                db.updateCover(bookId, path)
                buildLibrary()
            }
        }
    }

    // ---- Portadas en línea (opcional) ----

    fun changeOnlineCovers(on: Boolean) {
        prefs.onlineCovers = on
        onlineCovers = on
        if (on) startCoverFetch() else coverJob?.cancel()
    }

    private fun startCoverFetch() {
        if (coverJob?.isActive == true) return
        val ctx = getApplication<Application>()
        coverJob = viewModelScope.launch(Dispatchers.IO) {
            fetchingCovers = true
            try {
                val todo = withContext(dbDisp) { CoverFetcher.pending(db, db.allBooks()) }
                var last = System.currentTimeMillis()
                var changed = false
                for (b in todo) {
                    ensureActive()
                    val r = CoverFetcher.fetch(ctx, db, b)
                    if (r is CoverFetcher.Result.Offline) break
                    if (r is CoverFetcher.Result.Found) changed = true
                    val now = System.currentTimeMillis()
                    if (changed && now - last > 1500) {
                        last = now
                        changed = false
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                if (changed) library = withContext(dbDisp) { buildLibrary() }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
            } finally {
                fetchingCovers = false
            }
        }
    }

    // ---- Organización manual de sagas (carpetas virtuales) ----

    private fun org(after: (() -> Unit)? = null, block: () -> Unit) {
        viewModelScope.launch {
            library = withContext(dbDisp) {
                block()
                buildLibrary()
            }
            after?.invoke()
        }
    }

    /** Como [org], pero guarda el estado previo de [uris] para ofrecer Deshacer. [block] devuelve la colección creada, si hay. */
    private fun orgUndoable(message: String, uris: List<String>, after: (() -> Unit)? = null, block: () -> Long?) {
        viewModelScope.launch {
            var snap: OrgSnapshot? = null
            var created: Long? = null
            library = withContext(dbDisp) {
                snap = db.snapshotOrg(uris)
                created = block()
                buildLibrary()
            }
            snap?.let { notice = Notice(message, it, created) }
            after?.invoke()
        }
    }

    /** Deshace el último movimiento: restaura la organización y los nombres internos previos. */
    fun undoLast() {
        val n = notice ?: return
        val s = n.snapshot ?: return
        notice = null
        viewModelScope.launch {
            library = withContext(dbDisp) {
                db.restoreOrg(s, n.createdSeriesId)
                buildLibrary()
            }
        }
    }

    fun clearNotice(id: Long) {
        if (notice?.id == id) notice = null
    }

    // ---- Selección múltiple ----

    fun toggleSelect(id: String) {
        selection = if (id in selection) selection - id else selection + id
    }

    fun clearSelection() {
        selection = emptySet()
    }

    /** Ids de libro que abarca la selección (una colección seleccionada incluye todos sus tomos). */
    fun selectedBookIds(): List<Long> {
        val out = LinkedHashSet<Long>()
        for (id in selection) {
            if (id.startsWith("b")) id.substring(1).toLongOrNull()?.let { if (library.books.containsKey(it)) out.add(it) }
            else library.series[id.substring(1)]?.volumes?.forEach { out.add(it.book.id) }
        }
        return out.toList()
    }

    // ---- Renombrado interno (nunca toca el archivo real) ----

    /** Nuevo nombre interno propuesto según la colección actual del cómic; null si no trae numeración. */
    fun proposedName(bookId: Long): String? {
        val b = library.books[bookId] ?: return null
        val s = library.bookSeries[bookId] ?: return null
        if (s.isUnnamed) return null
        return SeriesParser.internalName(s.name, b.fileName, b.number)
    }

    fun renameCandidates(ids: List<Long>): List<Long> = ids.filter { proposedName(it) != null }

    fun applyAliases(map: Map<Long, String>) {
        val byUri = HashMap<String, String>()
        for ((id, name) in map) library.books[id]?.uri?.let { byUri[it] = name }
        if (byUri.isEmpty()) return
        org { db.setAliases(byUri) }
    }

    fun restoreNames(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        org { db.clearAliases(uris) }
    }

    private fun offerRename(ids: List<Long>) {
        if (renameCandidates(ids).isNotEmpty()) dialog = OrgDialog.RenameOffer(ids)
    }

    private fun urisOf(ids: List<Long>): List<String> = ids.mapNotNull { library.books[it]?.uri }

    /** Cómic que solo trae numeración en su nombre ("001.cbz"): su nombre interno sigue a la colección donde esté. */
    private fun isUnnamedOrigin(id: Long): Boolean {
        val b = library.books[id] ?: return false
        return b.format == Format.COMIC && SeriesParser.isUnnamed(b.fileName)
    }

    /** Nombres internos "<colección> #<numeración original>" para los cómics sin nombre que se mueven a [collection]. */
    private fun unnamedAliases(ids: List<Long>, collection: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (id in ids) {
            if (!isUnnamedOrigin(id)) continue
            val b = library.books[id] ?: continue
            SeriesParser.internalName(collection, b.fileName, b.number)?.let { out[b.uri] = it }
        }
        return out
    }

    private fun isBookFormat(id: Long): Boolean = library.books[id]?.let { it.format != Format.COMIC } ?: false

    /** Crea una colección (de libros si [bookIds] son libros, o si no hay ids y se está en la pestaña Libros). */
    fun createSaga(name: String, bookIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        val isBooks = if (bookIds.isNotEmpty()) isBookFormat(bookIds[0]) else libTab == LibTab.BOOKS
        val ids = bookIds.filter { isBookFormat(it) == isBooks }
        val uris = urisOf(ids)
        val auto = unnamedAliases(ids, n)
        val toOffer = ids.filter { !isUnnamedOrigin(it) }
        if (ids.isEmpty()) {
            // Colección vacía: no se muestra en la Biblioteca hasta que tenga elementos (aparece al mover algo a ella).
            org { db.createManualSeries(n, isBooks) }
            notice = Notice("Colección «$n» creada. Se mostrará cuando le añadas elementos (Mover a…).")
            clearSelection()
            return
        }
        orgUndoable("Colección «$n» creada", uris, after = { offerRename(toOffer.filter { library.bookSeries.containsKey(it) }) }) {
            val id = db.createManualSeries(n, isBooks)
            if (id > 0) {
                db.setGroup(uris, "m:$id", n)
                db.setAliases(auto)
                id
            } else null
        }
        clearSelection()
    }

    /** Añade o mueve tomos a una colección existente (manual o automática). Libros y cómics no se mezclan. */
    fun moveToSeries(seriesKey: String, bookIds: List<Long>) {
        val s = library.series[seriesKey] ?: return
        val ids = bookIds.filter { isBookFormat(it) == s.isBooks }
        val uris = urisOf(ids)
        val unnamed = ids.filter { isUnnamedOrigin(it) }
        // Los cómics sin nombre toman el nombre de la colección de destino conservando su numeración
        // (y lo pierden si vuelven a "Sin nombre"). Los demás conservan la oferta de renombrado.
        val auto = if (s.isUnnamed) emptyMap() else unnamedAliases(unnamed, s.name)
        val clear = if (s.isUnnamed) urisOf(unnamed) else emptyList()
        val toOffer = if (s.isUnnamed) emptyList() else ids.filter { it !in unnamed }
        val msg = (if (ids.size == 1) "1 elemento movido a «" else "${ids.size} elementos movidos a «") + s.name + "»"
        orgUndoable(msg, uris, after = { offerRename(toOffer) }) {
            db.setGroup(uris, s.key, s.name)
            db.setAliases(auto)
            db.clearAliases(clear)
            null
        }
        clearSelection()
    }

    fun removeFromSaga(bookIds: List<Long>) {
        val uris = urisOf(bookIds)
        // Un cómic que vuelve a quedar suelto recupera su nombre con la numeración original.
        val clear = urisOf(bookIds.filter { isUnnamedOrigin(it) })
        orgUndoable(if (bookIds.size == 1) "Quitado de la colección" else "${bookIds.size} elementos quitados de la colección", uris) {
            db.setGroup(uris, GRP_STANDALONE, null)
            db.clearAliases(clear)
            null
        }
        clearSelection()
    }

    fun setBookNumber(bookId: Long, number: Int?) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.setNumber(uri, number) }
        clearSelection()
    }

    fun resetOrganization(bookId: Long) {
        val uri = library.books[bookId]?.uri ?: return
        org { db.resetOverride(uri) }
        clearSelection()
    }

    fun deleteSaga(seriesKey: String) {
        val series = library.series[seriesKey] ?: return
        val id = series.manualId ?: return
        if (seriesKey == this.seriesKey) this.seriesKey = null
        val clear = urisOf(series.volumes.map { it.book.id }.filter { isUnnamedOrigin(it) })
        org {
            db.deleteManualSeries(id)
            db.clearAliases(clear)
        }
    }

    // ---- Relectura: reinicia la lectura ACTUAL; historial, estadísticas y lecturas completadas se conservan ----

    fun resetSeriesReading(seriesKey: String) {
        val s = library.series[seriesKey] ?: return
        val ids = s.volumes.map { it.book.id }
        if (ids.isEmpty()) return
        org { db.resetProgress(ids) }
        notice = Notice("Lectura de «${s.name}» reiniciada")
    }

    /** Hay una lectura en curso (empezada y no reiniciada) de este libro. */
    fun hasProgress(bookId: Long): Boolean =
        library.items.any { it is com.jullbook.app.data.SingleItem && it.book.id == bookId && it.progress != null } ||
            library.bookSeries[bookId]?.volumes?.any { it.book.id == bookId && it.progress != null } == true

    fun resetBookReading(bookId: Long) {
        org { db.resetProgress(listOf(bookId)) }
        notice = Notice("Lectura reiniciada")
    }

    fun openSeries(key: String) {
        clearSelection()
        seriesKey = key
    }

    fun openBook(book: Book) {
        finishedPrompt = null
        finishedComment = null
        notice = null
        if (reading?.id != book.id) {
            reading = book
            readingPercent = progressOf(book.id)?.percent ?: 0f
            curSessionMs = 0L
            longSessionSaid = false
        }
        readerVisible = true
    }

    fun progressOf(id: Long): Progress? {
        for (it in library.items) {
            if (it is com.jullbook.app.data.SingleItem && it.book.id == id) return it.progress
            if (it is SeriesItem) it.volumes.firstOrNull { v -> v.book.id == id }?.let { v -> return v.progress }
        }
        return null
    }

    /** Minimiza el lector (como un reproductor de música): sigue vivo con su posición exacta. */
    fun minimizeReader() {
        if (reading == null || !readerVisible) return
        readerVisible = false
        prefs.bump("minimizes")
        trackWindow(minimizeTimes, 5, 12_000L)?.let { discoverEgg("minimize_spam") }
        viewModelScope.launch {
            delay(350)
            library = withContext(dbDisp) { buildLibrary() }
            refreshMeta()
        }
    }

    fun restoreReader() {
        if (reading == null) return
        readerVisible = true
        trackWindow(minimizeTimes, 5, 12_000L)?.let { discoverEgg("minimize_spam") }
    }

    /** Cierra la lectura minimizada o en curso. */
    fun closeReading() = closeReader()

    /** Registra un instante y devuelve non-null si hubo [n] eventos dentro de [windowMs]. */
    private fun trackWindow(list: MutableList<Long>, n: Int, windowMs: Long): Boolean? {
        val now = System.currentTimeMillis()
        list.add(now)
        while (list.size > n) list.removeAt(0)
        return if (list.size >= n && now - list.first() <= windowMs) true else null
    }

    /** Devuelve la posición guardada (si la hay) y marca el libro como abierto ahora. */
    suspend fun beginReading(id: Long): Progress? {
        val old = withContext(dbDisp) {
            val (p, sid) = db.beginReading(id, System.currentTimeMillis())
            sessionId = sid
            p
        }
        onOpened(id, old)
        return old
    }

    /** Suma tiempo de lectura activo (pantalla abierta con el lector delante) a la sesión actual. */
    fun recordReadTime(bookId: Long, deltaMs: Long) {
        if (deltaMs <= 0) return
        val sid = sessionId
        val d = deltaMs.coerceAtMost(10 * 60_000L)
        curSessionMs += d
        prefs.setCounterMax("longest_session", curSessionMs)
        if (curSessionMs >= 2 * 3_600_000L && !longSessionSaid) {
            longSessionSaid = true
            juliSay(JuliCtx.RARE, jp(), high = true)
        }
        viewModelScope.launch(dbDisp) { db.addReadTime(bookId, sid, d, System.currentTimeMillis()) }
    }

    /** Memoria de lectura para la pantalla de estadísticas e historial. */
    suspend fun loadMemory(): MemoryData {
        val lib = library
        return withContext(dbDisp) { Memory.build(db, lib) }
    }

    fun saveProgress(p: Progress) {
        viewModelScope.launch(dbDisp) {
            val newlyFinished = db.saveProgress(p)
            if (reading?.id == p.bookId) readingPercent = p.percent
            if (newlyFinished) {
                val comment = onFinished(p.bookId)
                if (reading?.id == p.bookId) {
                    finishedComment = comment
                    finishedPrompt = p.bookId
                }
            }
            if (reading == null || !readerVisible) library = buildLibrary()
        }
    }

    fun dismissFinished() {
        finishedPrompt = null
    }

    private fun closeReader() {
        reading = null
        readerVisible = true
        finishedPrompt = null
        finishedComment = null
        viewModelScope.launch {
            delay(300)
            library = withContext(dbDisp) { buildLibrary() }
            refreshMeta()
        }
    }

    /** Tras terminar: vuelve a la colección del libro (si la tiene) o a la Biblioteca. */
    fun finishToCollection(bookId: Long) {
        val s = library.bookSeries[bookId]
        closeReader()
        tab = Tab.LIBRARY
        if (s != null) {
            clearSelection()
            seriesKey = s.key
        } else {
            seriesKey = null
        }
    }

    fun finishToLibrary(bookId: Long) {
        val b = library.books[bookId]
        closeReader()
        seriesKey = null
        tab = Tab.LIBRARY
        if (b != null) {
            val t = if (b.format == Format.COMIC) LibTab.COMICS else LibTab.BOOKS
            libTab = t
            prefs.libTab = t.name
        }
    }

    /** Devuelve true si consumió el gesto de atrás. */
    fun back(): Boolean {
        if (surpriseShow) {
            surpriseShow = false
            return true
        }
        if (reading != null && readerVisible) {
            minimizeReader()
            return true
        }
        if (showStats) {
            showStats = false
            return true
        }
        if (selection.isNotEmpty()) {
            clearSelection()
            return true
        }
        if (seriesKey != null) {
            seriesKey = null
            return true
        }
        if (tab != Tab.HOME) {
            tab = Tab.HOME
            return true
        }
        return false
    }

    // ---------------------------------------------------------------------------------------------
    // JullBook 1.0: Juli, Sorpréndeme, logros, secretos, tema y ajustes. Todo local.
    // ---------------------------------------------------------------------------------------------

    private fun jp(
        title: String? = null,
        coll: String? = null,
        n: Int = 0,
        days: Int = 0,
        hours: Int = 0,
        vols: Int = 0,
        volWord: String = "tomos",
        times: Int = 0
    ) = JuliParams(title, coll, n, days, hours, vols, volWord, times, userName)

    /** Juli dice algo breve. Las celebraciones ([high]) siempre; lo demás respeta la frecuencia elegida. */
    private fun juliSay(ctx: JuliCtx, p: JuliParams, high: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!Juli.mayTalk(prefs, high, now)) return
        val text = Juli.pick(ctx, p, prefs) ?: return
        prefs.lastSpoke = now
        bubble = JuliMsg(text)
    }

    fun dismissBubble(id: Long) {
        if (bubble?.id == id) bubble = null
    }

    /** Al abrir una lectura: comienzo, regreso tras mucho tiempo, relectura, retomar algo abandonado… */
    private fun onOpened(id: Long, old: Progress?) {
        val lib = library
        val b = lib.books[id] ?: return
        val s = lib.bookSeries[id]
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        if (hour in 0..4) prefs.bump("night_opens")
        if (hour == 3 && cal.get(Calendar.MINUTE) == 33) discoverEgg("night_333")
        val day = 86_400_000L
        val gap = if (old != null) ((now - old.lastRead) / day).toInt() else 0
        if (old != null && gap >= 60 && old.status == ST_READING && old.percent > 0.03f) prefs.bump("resumed_old")
        val title = SurpriseEngine.displayTitle(b, s)
        val p = jp(
            title = title, coll = s?.name, days = gap, n = b.reads + 1, times = b.reads + 1,
            vols = s?.volumes?.size ?: 0, volWord = if (s?.isBooks == true) "libros" else "tomos"
        )
        var ctx: JuliCtx? = when {
            old == null -> if (lib.books.size > 5 && Random.nextFloat() < 0.35f) JuliCtx.DISCOVER else JuliCtx.START
            old.status == ST_UNREAD && b.reads > 0 ->
                if (s != null && s.volumes.first().book.id == id && s.volumes.all { it.book.reads > 0 }) JuliCtx.REREAD_COLLECTION
                else JuliCtx.REREAD_VOLUME
            old.status == ST_FINISHED -> null
            gap >= 30 && old.percent > 0f -> JuliCtx.RETURN_LONG
            gap >= 14 && old.percent in 0.02f..0.95f -> JuliCtx.RESUME
            else -> null
        }
        if (ctx == null && hour in 0..4 && now - prefs.counter("rare_at") > 12 * 3_600_000L) {
            prefs.setCounter("rare_at", now)
            ctx = JuliCtx.RARE
        }
        if (ctx != null) {
            val high = ctx == JuliCtx.REREAD_COLLECTION || ctx == JuliCtx.REREAD_VOLUME || ctx == JuliCtx.RETURN_LONG ||
                ctx == JuliCtx.RESUME || ctx == JuliCtx.RARE
            juliSay(ctx, p, high)
        }
    }

    /** Al terminar algo (la biblioteca aún no se ha reconstruido): devuelve el comentario de Juli para la tarjeta final. */
    private fun onFinished(bookId: Long): String? {
        val lib = library
        val b = lib.books[bookId] ?: return null
        val s = lib.bookSeries[bookId]
        val prev = b.reads
        val cal = Calendar.getInstance()
        val dayKey = cal.get(Calendar.YEAR) * 400L + cal.get(Calendar.DAY_OF_YEAR)
        val cnt: Int
        if (prefs.counter("fin_day") == dayKey) {
            cnt = prefs.bump("fin_day_count").toInt()
        } else {
            prefs.setCounter("fin_day", dayKey)
            prefs.setCounter("fin_day_count", 1L)
            cnt = 1
        }
        prefs.setCounterMax("max_fin_day", cnt.toLong())
        val completes = s != null && !s.isUnnamed && s.volumes.size >= 2 &&
            s.volumes.all { it.book.id == bookId || it.progress?.status == ST_FINISHED }
        val word = if (b.format == Format.COMIC) "tomos" else "libros"
        val p = jp(
            title = SurpriseEngine.displayTitle(b, s), coll = s?.name, n = prev + 1, times = prev + 1,
            vols = if (completes) s!!.volumes.size else cnt, volWord = if (completes && s!!.isBooks) "libros" else word
        )
        val ctx = when {
            completes && s!!.volumes.size >= 5 -> JuliCtx.FINISH_SAGA
            completes -> JuliCtx.FINISH_COLLECTION
            cnt >= 3 -> JuliCtx.BINGE
            prev >= 1 -> JuliCtx.REREAD_COUNT
            cnt == 2 && Random.nextFloat() < 0.6f -> JuliCtx.RARE
            s != null -> JuliCtx.FINISH_VOLUME
            Random.nextFloat() < 0.3f -> JuliCtx.NEW_READ
            else -> JuliCtx.FINISH_BOOK
        }
        val now = System.currentTimeMillis()
        if (!Juli.mayTalk(prefs, true, now)) return null
        prefs.lastSpoke = now
        return Juli.pick(ctx, p, prefs)
    }

    /** Memoria, logros y nota de Juli en Inicio. Se calcula tras cambios de biblioteca y nunca durante un escaneo. */
    fun refreshMeta(appStart: Boolean = false) {
        viewModelScope.launch {
            val lib = library
            val mem = withContext(dbDisp) { Memory.build(db, lib) }
            memory = mem
            if (scanning || lib.books.isEmpty()) return@launch
            val now = System.currentTimeMillis()
            val (snap, fresh) = withContext(dbDisp) {
                val sn = Achievements.snapshot(lib, mem, prefs)
                sn to Achievements.evaluate(sn, prefs, now)
            }
            if (fresh.isNotEmpty()) enqueueAch(fresh)
            updateHomeNote(snap, appStart, now)
        }
    }

    private fun updateHomeNote(snap: AchSnapshot, appStart: Boolean, now: Long) {
        if (prefs.juliTalk <= 0) {
            homeNote = ""
            return
        }
        val lastOpen = prefs.counter("last_open")
        val away = if (lastOpen > 0) ((now - lastOpen) / 86_400_000L).toInt() else 0
        if (appStart) prefs.setCounter("last_open", now)
        val cooldown = if (prefs.juliTalk >= 2) 3_600_000L else 3 * 3_600_000L
        val stale = prefs.homeNote.isBlank() || now - prefs.homeNoteAt >= cooldown
        val returning = appStart && away >= 7
        if (!stale && !returning) {
            homeNote = prefs.homeNote
            return
        }
        val stats = memory.stats
        var ctx: JuliCtx? = null
        var p = jp()
        val streakMs = intArrayOf(3, 7, 14, 30, 60, 100, 200, 365).lastOrNull { stats.streak >= it }
        val hoursMs = intArrayOf(1, 5, 10, 25, 50, 100, 250, 500, 1000).lastOrNull { snap.readHours >= it }
        val bigMs = intArrayOf(50, 100, 250, 500, 1000).lastOrNull { snap.totalBooks >= it }
        when {
            returning -> { ctx = JuliCtx.RETURN_LONG; p = jp(days = away) }
            streakMs != null && prefs.counter("ann_streak") < streakMs -> {
                prefs.setCounter("ann_streak", streakMs.toLong())
                ctx = JuliCtx.STREAK
                p = jp(days = stats.streak)
            }
            hoursMs != null && prefs.counter("ann_hours") < hoursMs -> {
                prefs.setCounter("ann_hours", hoursMs.toLong())
                ctx = JuliCtx.TIME_MILESTONE
                p = jp(hours = hoursMs)
            }
            bigMs != null && prefs.counter("ann_big") < bigMs -> {
                prefs.setCounter("ann_big", bigMs.toLong())
                ctx = JuliCtx.BIG_LIBRARY
                p = jp(n = snap.totalBooks)
            }
            else -> {
                val options = ArrayList<Pair<JuliCtx, JuliParams>>()
                options.add(JuliCtx.GREETING to jp())
                options.add(JuliCtx.GREETING to jp())
                if (snap.unstarted >= 25) {
                    options.add(JuliCtx.MANY_PENDING to jp(n = snap.unstarted))
                    options.add(JuliCtx.MANY_PENDING to jp(n = snap.unstarted))
                }
                if (snap.totalBooks >= 150) options.add(JuliCtx.BIG_LIBRARY to jp(n = snap.totalBooks))
                if (stats.streak >= 2) options.add(JuliCtx.STREAK to jp(days = stats.streak))
                val stale21 = library.cont.firstOrNull { e -> e.progress != null && now - e.progress.lastRead > 21 * 86_400_000L }
                if (stale21 != null) {
                    val t = SurpriseEngine.displayTitle(stale21.book, stale21.series)
                    options.add(JuliCtx.RESUME to jp(title = t, days = ((now - stale21.progress!!.lastRead) / 86_400_000L).toInt()))
                    options.add(JuliCtx.RESUME to jp(title = t, days = ((now - stale21.progress.lastRead) / 86_400_000L).toInt()))
                }
                val pick = options[Random.nextInt(options.size)]
                ctx = pick.first
                p = pick.second
            }
        }
        val text = Juli.pick(ctx!!, p, prefs) ?: return
        prefs.homeNote = text
        prefs.homeNoteAt = now
        homeNote = text
    }

    // ---- Logros ----

    private fun enqueueAch(list: List<Achievement>) {
        achQueue.addAll(list)
        if (achToast == null && achQueue.isNotEmpty()) achToast = achQueue.removeAt(0)
    }

    fun dismissAch() {
        achToast = if (achQueue.isNotEmpty()) achQueue.removeAt(0) else null
    }

    // ---- Easter eggs ----

    fun discoverEgg(id: String) {
        if (!prefs.discoverEgg(id)) return
        val egg = Eggs.byId(id) ?: return
        eggs = prefs.eggs()
        bubble = JuliMsg(egg.line, title = "Secreto de Juli")
        if (egg.confetti) confetti++
    }

    fun themeUnlocked(id: String): Boolean {
        val t = com.jullbook.app.ui.themeById(id) ?: return false
        if (!t.hidden) return true
        return Eggs.ALL.any { it.unlocksTheme == id && it.id in eggs }
    }

    /** Toques sobre el avatar de Juli: siete seguidos y se ríe. */
    fun onJuliTap() {
        val now = System.currentTimeMillis()
        tapCount = if (now - lastTap > 1500L) 1 else tapCount + 1
        lastTap = now
        if (tapCount >= 7) {
            tapCount = 0
            discoverEgg("tap7")
        }
    }

    fun onGreetingHold() {
        waveSpin++
        discoverEgg("title_hold")
    }

    fun onSearchQuery(q: String) {
        val t = q.trim().lowercase()
        if (t == "42") discoverEgg("search_42")
        if (t.contains("juli")) discoverEgg("search_juli")
    }

    fun onStatsOpened() {
        if (loaded && !scanning && library.books.isNotEmpty() && memory.stats.totalMs == 0L && memory.stats.sessions == 0) discoverEgg("empty_stats")
    }

    // ---- Sorpréndeme ----

    fun surpriseMe() {
        val now = System.currentTimeMillis()
        val s = SurpriseEngine.pick(library, prefs, recentSurprise.toSet(), now)
        if (s == null) {
            notice = Notice("Todavía no hay nada que sugerir: añade libros o cómics a tus carpetas.")
            return
        }
        recentSurprise.add(s.book.id)
        while (recentSurprise.size > 6) recentSurprise.removeAt(0)
        prefs.bump("surprises")
        surprise = s
        surpriseShow = true
        trackWindow(surpriseTimes, 5, 25_000L)?.let { discoverEgg("surprise_x5") }
        viewModelScope.launch { refreshMeta() }
    }

    fun closeSurprise() {
        surpriseShow = false
    }

    fun openSurprise() {
        val s = surprise ?: return
        surpriseShow = false
        openBook(s.book)
    }

    // ---- Perfil, tema y ajustes ----

    fun setUserName(n: String) {
        val v = n.trim().take(24)
        prefs.userName = v
        userName = v
        if (v.equals("juli", ignoreCase = true)) discoverEgg("name_juli")
    }

    fun setTheme(id: String) {
        themeId = id
        prefs.themeId = id
        prefs.addThemeTried(id)
        trackWindow(themeTimes, 6, 40_000L)?.let { discoverEgg("theme_flip") }
    }

    fun saveCustomTheme(bg: Int, accent: Int, text: Int) {
        prefs.customBg = bg
        prefs.customAccent = accent
        prefs.customText = text
        customBg = bg
        customAccent = accent
        customText = text
        prefs.bump("custom_made")
        setTheme("custom")
        refreshMeta()
    }

    fun changeExpEnabled(on: Boolean) { expEnabled = on; prefs.expEnabled = on }
    fun changeExpStyle(style: String) { expStyle = style; prefs.expStyle = style }
    fun changeExpIntensity(v: Float) { expIntensity = v; prefs.expIntensity = v }

    fun changeJuliTalk(v: Int) {
        juliTalk = v
        prefs.juliTalk = v
        if (v <= 0) homeNote = "" else homeNote = prefs.homeNote
    }

    override fun onCleared() {
        super.onCleared()
        dbExecutor.shutdown()
    }
}
