package com.jullbook.app.data

import java.util.Calendar

class ReadingStats(
    val totalMs: Long,
    val todayMs: Long,
    val weekMs: Long,
    /** Tiempo leído de los últimos 7 días (el último es hoy). */
    val days: List<Long>,
    val streak: Int,
    val sessions: Int,
    val finished: Int,
    val reading: Int,
    val unstarted: Int
)

class HistoryEntry(val session: SessionRec, val book: Book?, val series: String?)

class MemoryData(
    val stats: ReadingStats,
    /** Libros con memoria de lectura, el más reciente primero. */
    val books: List<Pair<Book, Progress>>,
    val history: List<HistoryEntry>
) {
    companion object {
        val EMPTY = MemoryData(ReadingStats(0, 0, 0, List(7) { 0L }, 0, 0, 0, 0, 0), emptyList(), emptyList())
    }
}

object Memory {
    private const val DAY = 86_400_000L

    private fun startOfDay(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun build(db: Db, lib: Library, now: Long = System.currentTimeMillis()): MemoryData {
        val prog = db.allProgress().filterKeys { lib.books.containsKey(it) }
        val sessions = db.allSessions()
        val today = startOfDay(now)
        val days = LongArray(7)
        val withReading = HashSet<Long>()
        for (s in sessions) {
            val d = startOfDay(s.start)
            val idx = 6 - ((today - d) / DAY).toInt()
            if (idx in 0..6) days[idx] += s.duration
            withReading.add(d)
        }
        // Racha: días consecutivos con lectura (hoy cuenta si ya hay lectura; si no, se parte de ayer).
        var streak = 0
        var d = if (today in withReading) today else today - DAY
        while (d in withReading) {
            streak++
            d -= DAY
        }
        val stats = ReadingStats(
            totalMs = prog.values.sumOf { it.readMs },
            todayMs = days[6],
            weekMs = days.sum(),
            days = days.toList(),
            streak = streak,
            sessions = sessions.size,
            finished = prog.values.count { it.status == ST_FINISHED },
            reading = prog.values.count { it.status != ST_FINISHED },
            unstarted = (lib.books.size - prog.size).coerceAtLeast(0)
        )
        val books = prog.values
            .sortedByDescending { it.lastRead }
            .mapNotNull { p -> lib.books[p.bookId]?.let { it to p } }
            .take(40)
        val history = sessions.take(40).map { s ->
            HistoryEntry(s, lib.books[s.bookId], lib.bookSeries[s.bookId]?.name)
        }
        return MemoryData(stats, books, history)
    }
}
