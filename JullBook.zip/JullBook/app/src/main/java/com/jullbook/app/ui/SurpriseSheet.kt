package com.jullbook.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.SurpriseEngine
import com.jullbook.app.data.formatLabel
import com.jullbook.app.data.pctText

/** Resultado de Sorpréndeme: portada protagonista, motivo y comentario de Juli. */
@Composable
fun SurpriseOverlay(vm: AppViewModel) {
    AnimatedVisibility(
        visible = vm.surpriseShow && vm.surprise != null,
        enter = fadeIn(tween(250)),
        exit = fadeOut(tween(200))
    ) {
        val s = vm.surprise ?: return@AnimatedVisibility
        val amb = LocalAmbient.current
        val glow = amb?.glow?.firstOrNull() ?: MaterialTheme.colorScheme.primary
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.closeSurprise() },
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visibleState = remember { MutableTransitionState(false).apply { targetState = true } },
                enter = scaleIn(tween(350), initialScale = 0.85f) + fadeIn(tween(300)),
                exit = scaleOut() + fadeOut()
            ) {
                Column(
                    Modifier
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(20.dp)
                        .shadow(24.dp, RoundedCornerShape(32.dp))
                        .clip(RoundedCornerShape(32.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                        .verticalScroll(rememberScrollState())
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(s.reason.label.uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Box(Modifier.coverGlow(glow, 0.35f + 0.3f * (amb?.intensity ?: 0.5f))) {
                        CoverImage(
                            s.book.coverPath, s.book.title,
                            Modifier.size(width = 150.dp, height = 225.dp).shadow(16.dp, RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)),
                            format = s.book.format
                        )
                    }
                    val title = SurpriseEngine.displayTitle(s.book, s.series)
                    Text(
                        title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        listOfNotNull(
                            s.series?.let { sr -> sr.name.takeIf { !sr.isUnnamed && it != title } },
                            s.book.author,
                            formatLabel(s.book.format),
                            s.progress?.let { pctText(it.percent) }
                        ).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    JuliNote(s.comment, Modifier.padding(top = 4.dp))
                    Button(onClick = { vm.openSurprise() }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (s.progress == null) "Empezar a leer" else "Continuar leyendo")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { vm.surpriseMe() }, modifier = Modifier.weight(1f)) { Text("🎲 Otra") }
                        TextButton(onClick = { vm.closeSurprise() }, modifier = Modifier.weight(1f)) { Text("Ahora no") }
                    }
                }
            }
        }
    }
}
