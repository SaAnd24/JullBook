package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.ImageBlock
import com.jullbook.app.data.Images
import com.jullbook.app.data.TextBlock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Espacio reservado arriba/abajo de cada página (las barras del lector se superponen a él). */
const val PAGE_TOP_DP = 56
const val PAGE_BOTTOM_DP = 64

/** Todo lo que afecta a la paginación: si cambia, se vuelve a paginar. widthPx incluye los márgenes. */
data class PageCfg(val widthPx: Int, val heightPx: Int, val fontSize: Float, val marginPx: Int, val density: Density)

/** Fragmento de un bloque dentro de una página: un trozo de texto (por líneas completas) o una imagen. */
class Chunk(
    val block: Int,
    /** Posición (carácter) donde empieza este fragmento dentro del bloque y longitud total del bloque. */
    val start: Int,
    val total: Int,
    val text: AnnotatedString?,
    val src: TextBlock?,
    val image: String?,
    val imageH: Int,
    val topPx: Int,
    val bottomPx: Int,
    val quotePx: Int
)

class EpubPage(val chunks: List<Chunk>) {
    val sub: Int get() = chunks.firstOrNull()?.block ?: 0
    val frac: Float get() = chunks.firstOrNull()?.let { it.start.toFloat() / it.total.coerceAtLeast(1) } ?: 0f
}

/** Capítulo ya paginado que se está mostrando. */
class Shown(val ch: Int, val cfg: PageCfg, val pages: List<EpubPage>)

/** Punto de lectura (bloque + fracción dentro del bloque), el mismo formato que el progreso guardado. */
class Anchor(var sub: Int, var frac: Float, var atEnd: Boolean = false)

fun pageIndexFor(pages: List<EpubPage>, a: Anchor): Int {
    if (pages.isEmpty()) return 0
    if (a.atEnd) return pages.lastIndex
    var idx = 0
    for ((i, p) in pages.withIndex()) {
        if (p.chunks.isEmpty()) continue
        if (p.sub < a.sub || (p.sub == a.sub && p.frac <= a.frac + 0.0005f)) idx = i else break
    }
    return idx
}

/**
 * Divide cada capítulo en páginas del tamaño exacto de la pantalla. Los párrafos largos se cortan por líneas
 * completas; las imágenes se ajustan a la página. Mantiene una pequeña caché por capítulo y configuración.
 */
class EpubPaginator(private val session: EpubSession, private val measurer: TextMeasurer) {
    private val mutex = Mutex()
    private val cache = object : LinkedHashMap<Pair<Int, PageCfg>, List<EpubPage>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Pair<Int, PageCfg>, List<EpubPage>>?): Boolean = size > 10
    }

    @Synchronized
    fun peek(ch: Int, cfg: PageCfg): List<EpubPage>? = cache[ch to cfg]

    @Synchronized
    private fun store(ch: Int, cfg: PageCfg, pages: List<EpubPage>) {
        cache[ch to cfg] = pages
    }

    suspend fun get(ch: Int, cfg: PageCfg): List<EpubPage> {
        peek(ch, cfg)?.let { return it }
        return mutex.withLock {
            peek(ch, cfg) ?: withContext(Dispatchers.Default) { build(ch, cfg) }.also { store(ch, cfg, it) }
        }
    }

    private suspend fun build(ch: Int, cfg: PageCfg): List<EpubPage> {
        val blocks = try {
            EpubText.parse(session.zip, session.info.spine[ch])
        } catch (e: CancellationException) {
            throw e
        } catch (ignored: Throwable) {
            emptyList()
        }
        val d = cfg.density
        fun dp(v: Float): Int = with(d) { v.dp.toPx() }.roundToInt()
        val textW = (cfg.widthPx - 2 * cfg.marginPx).coerceAtLeast(120)
        val pageH = cfg.heightPx.coerceAtLeast(200)
        val lineH = with(d) { (cfg.fontSize * 1.55f).sp.toPx() }
        val pages = ArrayList<EpubPage>()
        var cur = ArrayList<Chunk>()
        var used = 0
        fun flush() {
            if (cur.isNotEmpty()) {
                pages.add(EpubPage(cur))
                cur = ArrayList()
                used = 0
            }
        }

        for ((i, b) in blocks.withIndex()) {
            currentCoroutineContext().ensureActive()
            when (b) {
                is TextBlock -> {
                    val base = toAnnotated(b.sp, cfg.fontSize)
                    val text = if (b.bullet) buildAnnotatedString { append("•  "); append(base) } else base
                    val quote = if (b.quote) dp(14f) else 0
                    val style = TextStyle(
                        fontSize = cfg.fontSize.sp,
                        lineHeight = (cfg.fontSize * 1.55f).sp,
                        textAlign = b.align ?: TextAlign.Start,
                        fontWeight = if (b.heading) FontWeight.Bold else null
                    )
                    val lay = measurer.measure(
                        text = text,
                        style = style,
                        constraints = Constraints(maxWidth = (textW - quote).coerceAtLeast(60)),
                        skipCache = true
                    )
                    val topSp = if (b.heading) dp(14f) else 0
                    val botSp = if (b.heading) dp(14f) else dp(10f)
                    val n = lay.lineCount
                    var line = 0
                    while (line < n) {
                        val top = if (line == 0) topSp else 0
                        val avail = pageH - used - top
                        val y0 = lay.getLineTop(line)
                        var end = line
                        while (end < n && lay.getLineBottom(end) - y0 <= avail) end++
                        if (end == line) {
                            if (used > 0) {
                                flush()
                                continue
                            }
                            end = line + 1 // línea más alta que la página: se fuerza para no bloquearse
                        }
                        if (used > 0 && line == 0) {
                            // Un título no se queda solo al final de la página.
                            val left = avail - (lay.getLineBottom(end - 1) - y0)
                            if (b.heading && end == n && left < 2 * lineH) {
                                flush()
                                continue
                            }
                            // Ni una sola línea de un párrafo al final de la página.
                            if (end < n && end - line == 1) {
                                flush()
                                continue
                            }
                        }
                        // Ni una sola línea suelta al principio de la página siguiente.
                        if (end < n && n - end == 1 && end - line >= 2) end--
                        val whole = end == n
                        val a = lay.getLineStart(line)
                        val z = lay.getLineEnd(end - 1)
                        val h = (lay.getLineBottom(end - 1) - y0).roundToInt()
                        val bottom = if (whole) botSp else 0
                        cur.add(Chunk(i, a, text.length, text.subSequence(a, z), b, null, 0, top, bottom, quote))
                        used += top + h + bottom
                        if (!whole) flush()
                        line = end
                    }
                }
                is ImageBlock -> {
                    val e = session.zip.entry(b.path) ?: continue
                    val raw: Float = try {
                        Images.pageRatio(session.zip, e)
                    } catch (ex: CancellationException) {
                        throw ex
                    } catch (ignored: Throwable) {
                        0.7f
                    }
                    val ratio = raw.coerceIn(0.05f, 20f)
                    val pad = dp(8f)
                    val h = (textW / ratio).roundToInt().coerceAtMost(pageH - 2 * pad).coerceAtLeast(40)
                    if (used > 0 && used + h + 2 * pad > pageH) flush()
                    cur.add(Chunk(i, 0, 1, null, null, b.path, h, pad, pad, 0))
                    used += h + 2 * pad
                }
            }
        }
        flush()
        if (pages.isEmpty()) pages.add(EpubPage(emptyList()))
        return pages
    }
}

/**
 * Páginas de un capítulo en un pager horizontal que sigue al dedo. Antes y después del capítulo hay una página
 * "puente" (última del anterior / primera del siguiente): al asentarse sobre ella se cambia de capítulo sin
 * salto visible, así el gesto continúa directamente en el capítulo contiguo.
 */
@Composable
internal fun ChapterPager(
    session: EpubSession,
    shown: Shown,
    prev: EpubPage?,
    next: EpubPage?,
    initial: Int,
    theme: EpubTheme,
    onTap: () -> Unit,
    onPage: (index: Int, count: Int, page: EpubPage) -> Unit,
    onSwap: (dir: Int) -> Unit
) {
    val hasPrev = shown.ch > 0
    val hasNext = shown.ch < session.info.spine.size - 1
    val off = if (hasPrev) 1 else 0
    val pages = shown.pages
    val count = off + pages.size + (if (hasNext) 1 else 0)
    val state = rememberPagerState(initialPage = off + initial.coerceIn(0, pages.lastIndex.coerceAtLeast(0))) { count }

    LaunchedEffect(state) {
        snapshotFlow { state.settledPage }
            .distinctUntilChanged()
            .collect { w ->
                when {
                    hasPrev && w == 0 -> onSwap(-1)
                    hasNext && w == count - 1 -> onSwap(1)
                    else -> {
                        val i = (w - off).coerceIn(0, pages.lastIndex)
                        onPage(i, pages.size, pages[i])
                    }
                }
            }
    }

    HorizontalPager(
        state = state,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
        beyondViewportPageCount = 1,
        flingBehavior = PagerDefaults.flingBehavior(state = state, snapPositionalThreshold = 0.35f)
    ) { w ->
        val page = when {
            hasPrev && w == 0 -> prev
            hasNext && w == count - 1 -> next
            else -> pages[(w - off).coerceIn(0, pages.lastIndex)]
        }
        PageContent(session, page, shown.cfg, theme)
    }
}

@Composable
private fun PageContent(session: EpubSession, page: EpubPage?, cfg: PageCfg, theme: EpubTheme) {
    val density = LocalDensity.current
    Box(Modifier.fillMaxSize().background(theme.bg).clipToBounds()) {
        if (page == null) return@Box
        Column(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .padding(
                    start = with(density) { cfg.marginPx.toDp() },
                    end = with(density) { cfg.marginPx.toDp() },
                    top = PAGE_TOP_DP.dp,
                    bottom = PAGE_BOTTOM_DP.dp
                )
        ) {
            for (c in page.chunks) {
                val topDp = with(density) { c.topPx.toDp() }
                val botDp = with(density) { c.bottomPx.toDp() }
                if (c.text != null && c.src != null) {
                    val b = c.src
                    val style = TextStyle(
                        fontSize = cfg.fontSize.sp,
                        lineHeight = (cfg.fontSize * 1.55f).sp,
                        color = theme.fg,
                        textAlign = b.align ?: TextAlign.Start,
                        fontWeight = if (b.heading) FontWeight.Bold else null
                    )
                    val quoteColor = theme.fg.copy(alpha = 0.35f)
                    var m = Modifier.fillMaxWidth().padding(top = topDp, bottom = botDp)
                    if (b.quote) {
                        m = m
                            .drawBehind { drawRect(quoteColor, size = Size(3.dp.toPx(), size.height)) }
                            .padding(start = 14.dp)
                    }
                    Text(text = c.text, style = style, modifier = m)
                } else if (c.image != null) {
                    PageImage(session, c.image, with(density) { c.imageH.toDp() }, Modifier.padding(top = topDp, bottom = botDp))
                }
            }
        }
    }
}

@Composable
private fun PageImage(session: EpubSession, path: String, height: androidx.compose.ui.unit.Dp, modifier: Modifier) {
    val widthPx = androidx.compose.ui.platform.LocalContext.current.resources.displayMetrics.widthPixels
    val bmp by produceState<ImageBitmap?>(null, session, path) {
        value = withContext(Dispatchers.IO) {
            try {
                val e = session.zip.entry(path)
                if (e == null) null else Images.decodeSampled(session.zip.read(e), widthPx, Bitmap.Config.ARGB_8888)
            } catch (ex: CancellationException) {
                throw ex
            } catch (ignored: Throwable) {
                null
            }
        }?.asImageBitmap()
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = null, modifier = modifier.fillMaxWidth().height(height), contentScale = ContentScale.Fit)
    } else {
        Box(modifier.fillMaxWidth().height(height))
    }
}
