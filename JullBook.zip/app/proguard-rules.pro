# Sin reglas adicionales: la app no usa reflexión ni librerías externas pesadas.
