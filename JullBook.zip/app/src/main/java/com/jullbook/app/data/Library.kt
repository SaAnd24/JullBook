package com.jullbook.app.data

class Vol(val book: Book, val progress: Progress?)

sealed interface LibItem {
    val id: String
    val sortName: String
}

class SingleItem(val book: Book, val progress: Progress?) : LibItem {
    override val id: String get() = "b${book.id}"
    override val sortName: String get() = book.title
}

class SeriesItem(val key: String, val name: String, val volumes: List<Vol>) : LibItem {
    override val id: String get() = "s$key"
    override val sortName: String get() = name

    /** Progreso general: media del avance de todos los tomos. */
    val percent: Float
        get() {
            if (volumes.isEmpty()) return 0f
            var sum = 0.0
            for (v in volumes) {
                val p = v.progress
                sum += if (p == null) 0.0 else if (p.status == ST_FINISHED) 1.0 else p.percent.toDouble()
            }
            return (sum / volumes.size).toFloat()
        }

    val coverPath: String? get() = volumes.firstNotNullOfOrNull { it.book.coverPath }

    /** Tomo actual: el último leído si no está terminado; si no, el siguiente sin terminar. */
    fun target(): Vol? {
        val last = volumes.filter { it.progress != null }.maxByOrNull { it.progress!!.lastRead }
        if (last != null && last.progress!!.status != ST_FINISHED) return last
        val start = if (last == null) 0 else volumes.indexOfFirst { it.book.id == last.book.id } + 1
        return volumes.drop(start).firstOrNull { it.progress?.status != ST_FINISHED }
            ?: volumes.firstOrNull { it.progress?.status != ST_FINISHED }
    }
}

class ContinueEntry(val book: Book, val progress: Progress?, val series: SeriesItem?)

class Library(
    val items: List<LibItem>,
    val cont: List<ContinueEntry>,
    val recent: List<ContinueEntry>,
    val books: Map<Long, Book>,
    val series: Map<String, SeriesItem>
) {
    companion object {
        val EMPTY = Library(emptyList(), emptyList(), emptyList(), emptyMap(), emptyMap())
    }
}

object LibraryBuilder {
    fun build(books: List<Book>, prog: Map<Long, Progress>): Library {
        val seriesMap = HashMap<String, SeriesItem>()
        val bookSeries = HashMap<Long, SeriesItem>()
        val groups = books.filter { it.format == Format.COMIC && it.seriesKey != null }.groupBy { it.seriesKey!! }
        for ((key, list) in groups) {
            if (list.size < 2) continue
            val sorted = list.sortedWith(Comparator { a, b ->
                val c = (a.number ?: 0).compareTo(b.number ?: 0)
                if (c != 0) c else naturalCompare(a.fileName, b.fileName)
            })
            val name = list.groupingBy { it.series ?: "" }.eachCount().maxByOrNull { it.value }?.key ?: key
            val s = SeriesItem(key, name, sorted.map { Vol(it, prog[it.id]) })
            seriesMap[key] = s
            for (b in list) bookSeries[b.id] = s
        }

        val items = ArrayList<LibItem>()
        items.addAll(seriesMap.values)
        for (b in books) if (!bookSeries.containsKey(b.id)) items.add(SingleItem(b, prog[b.id]))
        items.sortWith(Comparator { a, b -> naturalCompare(a.sortName, b.sortName) })

        val byId = books.associateBy { it.id }
        val byRead = prog.values.sortedByDescending { it.lastRead }

        val cont = ArrayList<ContinueEntry>()
        val seen = HashSet<String>()
        for (p in byRead) {
            val b = byId[p.bookId] ?: continue
            val s = bookSeries[b.id]
            if (s != null) {
                if (!seen.add(s.key)) continue
                val t = s.target() ?: continue
                cont.add(ContinueEntry(t.book, t.progress, s))
            } else if (p.status != ST_FINISHED && seen.add("b${b.id}")) {
                cont.add(ContinueEntry(b, p, null))
            }
            if (cont.size >= 12) break
        }

        val recent = ArrayList<ContinueEntry>()
        for (p in byRead) {
            val b = byId[p.bookId] ?: continue
            recent.add(ContinueEntry(b, p, bookSeries[b.id]))
            if (recent.size >= 8) break
        }
        return Library(items, cont, recent, byId, seriesMap)
    }
}
