package com.jullbook.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.DocumentsContract

object LibraryScanner {
    class Found(val uri: Uri, val name: String, val size: Long, val modified: Long, val folder: String)

    private val EXT = setOf("epub", "pdf", "cbz", "cbr")

    fun formatOf(name: String): Format? = when (name.substringAfterLast('.', "").lowercase()) {
        "epub" -> Format.EPUB
        "pdf" -> Format.PDF
        "cbz", "cbr" -> Format.COMIC
        else -> null
    }

    /** Recorre la carpeta elegida (solo lectura, sin tocar nada). */
    fun list(ctx: Context, tree: Uri): List<Found> {
        val resolver = ctx.contentResolver
        val out = ArrayList<Found>()
        fun walk(docId: String, folderName: String) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_SIZE
            )
            resolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    if (name.startsWith(".")) continue
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        walk(id, name)
                    } else if (name.substringAfterLast('.', "").lowercase() in EXT) {
                        out.add(Found(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, c.getLong(4), c.getLong(3), folderName))
                    }
                }
            }
        }
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        walk(rootId, rootId.substringAfterLast(':').substringAfterLast('/'))
        return out
    }

    fun sync(ctx: Context, db: Db, found: List<Found>) {
        val existing = db.allBooks().associateBy { it.uri }
        val foundUris = HashSet<String>(found.size)
        val toInsert = ArrayList<NewBook>()
        for (f in found) {
            val u = f.uri.toString()
            foundUris.add(u)
            val ex = existing[u]
            if (ex == null) {
                val fmt = formatOf(f.name) ?: continue
                val parsed = SeriesParser.parse(f.name, f.folder, fmt == Format.COMIC)
                toInsert.add(NewBook(u, f.name, fmt, parsed.title, parsed.series, parsed.key, parsed.number, f.folder, f.size, f.modified))
            } else if (ex.size != f.size || ex.modified != f.modified) {
                db.resetBook(ex.id, f.size, f.modified)
            }
        }
        // Si la carpeta devuelve 0 archivos pero había biblioteca, probablemente no está disponible: no borrar nada.
        if (found.isNotEmpty()) {
            val removed = existing.values.filter { it.uri !in foundUris }
            removed.forEach { b -> b.coverPath?.let { java.io.File(it).delete() } }
            db.deleteBooks(removed.map { it.id })
        }
        db.insertBooks(toInsert)
    }
}

object Indexer {
    private const val COVER_W = 300

    fun process(ctx: Context, db: Db, b: Book) {
        var title: String? = null
        var author: String? = null
        var pages = 0
        var bmp: Bitmap? = null
        try {
            val uri = Uri.parse(b.uri)
            when (b.format) {
                Format.COMIC -> SeekableZip.open(ctx, uri).use { z ->
                    val imgs = z.images()
                    pages = imgs.size
                    if (imgs.isNotEmpty()) bmp = Images.decodeSampled(z.read(imgs[0]), COVER_W, Bitmap.Config.ARGB_8888)
                }
                Format.EPUB -> SeekableZip.open(ctx, uri).use { z ->
                    val info = EpubParser.parse(z)
                    title = info.title
                    author = info.author
                    pages = info.spine.size
                    val ce = info.cover?.let { z.entry(it) }
                    if (ce != null) bmp = Images.decodeSampled(z.read(ce), COVER_W, Bitmap.Config.ARGB_8888)
                }
                Format.PDF -> ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    PdfRenderer(pfd).use { r ->
                        pages = r.pageCount
                        if (pages > 0) r.openPage(0).use { pg ->
                            val h = (COVER_W * pg.height.toFloat() / pg.width).toInt().coerceAtLeast(1)
                            val bm = Bitmap.createBitmap(COVER_W, h, Bitmap.Config.ARGB_8888)
                            bm.eraseColor(Color.WHITE)
                            pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp = bm
                        }
                    }
                }
            }
        } catch (ignored: Throwable) {
            // Archivo dañado o no soportado: se indexa igualmente, sin portada.
        }
        val cover = bmp?.let { Covers.save(ctx, b, it) }
        db.updateMeta(b.id, title, author, pages, cover)
    }
}
