package com.jullbook.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullbook.app.data.Book
import com.jullbook.app.data.Covers
import com.jullbook.app.data.Db
import com.jullbook.app.data.Indexer
import com.jullbook.app.data.Library
import com.jullbook.app.data.LibraryBuilder
import com.jullbook.app.data.LibraryScanner
import com.jullbook.app.data.Prefs
import com.jullbook.app.data.Progress
import com.jullbook.app.data.ST_READING
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

enum class Tab { HOME, LIBRARY }

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = Prefs(app)
    private val db = Db(app)

    // Un solo hilo para lecturas/escrituras de progreso: mantiene el orden de los guardados.
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val dbDisp = dbExecutor.asCoroutineDispatcher()

    var library by mutableStateOf(Library.EMPTY)
        private set
    var loaded by mutableStateOf(false)
        private set
    var treeUri by mutableStateOf(prefs.treeUri)
        private set
    var tab by mutableStateOf(Tab.HOME)
    var seriesKey by mutableStateOf<String?>(null)
        private set
    var reading by mutableStateOf<Book?>(null)
        private set
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableIntStateOf(0)
        private set
    var scanTotal by mutableIntStateOf(0)
        private set
    var folderLost by mutableStateOf(false)
        private set

    private var scanJob: Job? = null

    init {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
            if (treeUri != null) startScan()
        }
    }

    private fun buildLibrary(): Library = LibraryBuilder.build(db.allBooks(), db.allProgress())

    fun reload() {
        viewModelScope.launch {
            library = withContext(dbDisp) { buildLibrary() }
            loaded = true
        }
    }

    fun chooseFolder(uri: Uri) {
        val ctx = getApplication<Application>()
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (ignored: Throwable) {
        }
        val newStr = uri.toString()
        val oldStr = prefs.treeUri
        if (oldStr == newStr) {
            folderLost = false
            startScan()
            return
        }
        viewModelScope.launch {
            scanJob?.cancelAndJoin()
            withContext(dbDisp) { db.clearAll() }
            withContext(Dispatchers.IO) { Covers.deleteAll(ctx) }
            if (oldStr != null) {
                try {
                    ctx.contentResolver.releasePersistableUriPermission(Uri.parse(oldStr), flags)
                } catch (ignored: Throwable) {
                }
            }
            prefs.treeUri = newStr
            treeUri = newStr
            folderLost = false
            library = Library.EMPTY
            seriesKey = null
            tab = Tab.HOME
            startScan()
        }
    }

    fun startScan() {
        val tree = treeUri ?: return
        if (scanJob?.isActive == true) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            scanDone = 0
            scanTotal = 0
            try {
                val uri = Uri.parse(tree)
                val granted = ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
                if (!granted) {
                    folderLost = true
                    return@launch
                }
                val found = LibraryScanner.list(ctx, uri)
                if (found.isEmpty()) {
                    val hadBooks = withContext(dbDisp) { db.allBooks().isNotEmpty() }
                    folderLost = hadBooks
                    return@launch
                }
                folderLost = false
                withContext(dbDisp) { LibraryScanner.sync(ctx, db, found) }
                library = withContext(dbDisp) { buildLibrary() }
                val pending = withContext(dbDisp) { db.allBooks().filter { !it.processed } }
                scanTotal = pending.size
                var last = System.currentTimeMillis()
                for (b in pending) {
                    ensureActive()
                    try {
                        Indexer.process(ctx, db, b)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (ignored: Throwable) {
                    }
                    scanDone++
                    val now = System.currentTimeMillis()
                    if (now - last > 800) {
                        last = now
                        library = withContext(dbDisp) { buildLibrary() }
                    }
                }
                library = withContext(dbDisp) { buildLibrary() }
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: SecurityException) {
                folderLost = true
            } catch (ignored: Throwable) {
            } finally {
                scanning = false
            }
        }
    }

    fun openSeries(key: String) {
        seriesKey = key
    }

    fun openBook(book: Book) {
        reading = book
    }

    /** Devuelve la posición guardada (si la hay) y marca el libro como abierto ahora. */
    suspend fun beginReading(id: Long): Progress? = withContext(dbDisp) {
        val p = db.getProgress(id)
        val now = System.currentTimeMillis()
        db.saveProgress(p?.copy(lastRead = now) ?: Progress(id, 0, 0, 0f, 0f, now, ST_READING))
        p
    }

    fun saveProgress(p: Progress) {
        viewModelScope.launch(dbDisp) {
            db.saveProgress(p)
            if (reading == null) library = buildLibrary()
        }
    }

    /** Devuelve true si consumió el gesto de atrás. */
    fun back(): Boolean {
        if (reading != null) {
            reading = null
            viewModelScope.launch {
                delay(300)
                reload()
            }
            return true
        }
        if (seriesKey != null) {
            seriesKey = null
            return true
        }
        return false
    }

    override fun onCleared() {
        super.onCleared()
        dbExecutor.shutdown()
    }
}
