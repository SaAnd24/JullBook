package com.jullbook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Amber = Color(0xFFE8A93C)

private val DarkColors = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF241700),
    primaryContainer = Color(0xFF3A2A08),
    onPrimaryContainer = Color(0xFFFFDDA0),
    secondary = Color(0xFFD2BFA0),
    background = Color(0xFF000000),
    onBackground = Color(0xFFEDE6DA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFEDE6DA),
    surfaceVariant = Color(0xFF1B1A18),
    onSurfaceVariant = Color(0xFFB9B1A3),
    surfaceContainer = Color(0xFF0F0E0D),
    surfaceContainerHigh = Color(0xFF191817),
    surfaceContainerHighest = Color(0xFF242321),
    outline = Color(0xFF5A554C),
    outlineVariant = Color(0xFF2E2B27)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF8A5A00),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE2B0),
    onPrimaryContainer = Color(0xFF2C1B00),
    secondary = Color(0xFF6B5B3E),
    background = Color(0xFFFBF8F3),
    onBackground = Color(0xFF1D1B17),
    surface = Color(0xFFFBF8F3),
    onSurface = Color(0xFF1D1B17),
    surfaceVariant = Color(0xFFEDE5D8),
    onSurfaceVariant = Color(0xFF4D463A),
    surfaceContainer = Color(0xFFF4EEE4),
    surfaceContainerHigh = Color(0xFFEEE7DA),
    surfaceContainerHighest = Color(0xFFE8E0D2),
    outline = Color(0xFF7F7667),
    outlineVariant = Color(0xFFD3C9B8)
)

@Composable
fun JullTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
