package com.jullbook.app.data

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.Closeable
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.zip.Inflater

class RarNotSupported : IOException("RAR no soportado")

class ZEntry(val name: String, val method: Int, val csize: Long, val size: Long, val localOffset: Long)

/**
 * Lector ZIP de solo lectura con acceso aleatorio sobre un descriptor de archivo (sin copiar el archivo).
 * Sirve para CBZ y EPUB.
 */
class SeekableZip private constructor(
    private val pfd: ParcelFileDescriptor,
    private val fis: FileInputStream,
    private val ch: FileChannel,
    val entries: List<ZEntry>
) : Closeable {

    private val byName: Map<String, ZEntry> = entries.associateBy { it.name }

    fun entry(name: String): ZEntry? = byName[name]

    fun images(): List<ZEntry> =
        entries.filter { isImage(it.name) }.sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })

    fun readText(name: String): String? = entry(name)?.let { String(read(it), Charsets.UTF_8) }

    fun read(e: ZEntry, limit: Int = Int.MAX_VALUE): ByteArray {
        val hdr = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN)
        readFully(ch, hdr, e.localOffset)
        if (hdr.getInt(0) != 0x04034b50) throw IOException("Cabecera local inválida")
        val nl = hdr.getShort(26).toInt() and 0xFFFF
        val el = hdr.getShort(28).toInt() and 0xFFFF
        val dataStart = e.localOffset + 30 + nl + el
        val full = limit == Int.MAX_VALUE
        return when (e.method) {
            0 -> readAt(dataStart, (if (full) e.csize else minOf(e.csize, limit.toLong())).toInt())
            8 -> {
                val inLen = (if (full) e.csize else minOf(e.csize, limit.toLong())).toInt()
                val comp = readAt(dataStart, inLen)
                inflate(comp, (if (full) e.size else minOf(e.size, limit.toLong())).toInt())
            }
            else -> throw IOException("Método de compresión no soportado: ${e.method}")
        }
    }

    private fun readAt(pos: Long, n: Int): ByteArray {
        val buf = ByteBuffer.allocate(n)
        readFully(ch, buf, pos)
        return buf.array()
    }

    private fun inflate(comp: ByteArray, outSize: Int): ByteArray {
        val inf = Inflater(true)
        try {
            inf.setInput(comp)
            val out = ByteArray(outSize)
            var n = 0
            while (n < outSize && !inf.finished()) {
                val r = inf.inflate(out, n, outSize - n)
                if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break
                n += r
            }
            return if (n == outSize) out else out.copyOf(n)
        } finally {
            inf.end()
        }
    }

    override fun close() {
        try { ch.close() } catch (ignored: Exception) {}
        try { fis.close() } catch (ignored: Exception) {}
        try { pfd.close() } catch (ignored: Exception) {}
    }

    companion object {
        private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

        fun isImage(name: String): Boolean {
            if (name.contains("__MACOSX")) return false
            val file = name.substringAfterLast('/')
            if (file.startsWith(".")) return false
            return file.substringAfterLast('.', "").lowercase() in IMG_EXT
        }

        private fun readFully(ch: FileChannel, buf: ByteBuffer, pos: Long) {
            var p = pos
            while (buf.hasRemaining()) {
                val n = ch.read(buf, p)
                if (n < 0) throw IOException("Fin de archivo inesperado")
                p += n
            }
        }

        fun open(ctx: Context, uri: Uri): SeekableZip {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("No se pudo abrir el archivo")
            try {
                val fis = FileInputStream(pfd.fileDescriptor)
                val ch = fis.channel
                val size = ch.size()
                if (size < 22) throw IOException("Archivo vacío o dañado")
                val tailLen = minOf(size, 65557L).toInt()
                val tail = ByteBuffer.allocate(tailLen).order(ByteOrder.LITTLE_ENDIAN)
                readFully(ch, tail, size - tailLen)
                var p = tailLen - 22
                while (p >= 0 && tail.getInt(p) != 0x06054b50) p--
                if (p < 0) {
                    val head = ByteBuffer.allocate(4)
                    readFully(ch, head, 0)
                    if (head.get(0) == 0x52.toByte() && head.get(1) == 0x61.toByte() &&
                        head.get(2) == 0x72.toByte() && head.get(3) == 0x21.toByte()
                    ) throw RarNotSupported()
                    throw IOException("El archivo no es un ZIP válido")
                }
                val total = tail.getShort(p + 10).toInt() and 0xFFFF
                val cdSize = tail.getInt(p + 12).toLong() and 0xFFFFFFFFL
                val cdOff = tail.getInt(p + 16).toLong() and 0xFFFFFFFFL
                if (total == 0xFFFF || cdSize == 0xFFFFFFFFL || cdOff == 0xFFFFFFFFL) throw IOException("ZIP64 no soportado")
                val cd = ByteBuffer.allocate(cdSize.toInt()).order(ByteOrder.LITTLE_ENDIAN)
                readFully(ch, cd, cdOff)
                val list = ArrayList<ZEntry>(total)
                var o = 0
                while (o + 46 <= cd.capacity() && cd.getInt(o) == 0x02014b50) {
                    val method = cd.getShort(o + 10).toInt() and 0xFFFF
                    val csize = cd.getInt(o + 20).toLong() and 0xFFFFFFFFL
                    val usize = cd.getInt(o + 24).toLong() and 0xFFFFFFFFL
                    val nl = cd.getShort(o + 28).toInt() and 0xFFFF
                    val el = cd.getShort(o + 30).toInt() and 0xFFFF
                    val cl = cd.getShort(o + 32).toInt() and 0xFFFF
                    val lo = cd.getInt(o + 42).toLong() and 0xFFFFFFFFL
                    val nameBytes = ByteArray(nl)
                    cd.position(o + 46)
                    cd.get(nameBytes)
                    val name = String(nameBytes, Charsets.UTF_8)
                    if (!name.endsWith("/")) list.add(ZEntry(name, method, csize, usize, lo))
                    o += 46 + nl + el + cl
                }
                return SeekableZip(pfd, fis, ch, list)
            } catch (e: Throwable) {
                try { pfd.close() } catch (ignored: Exception) {}
                throw e
            }
        }
    }
}
