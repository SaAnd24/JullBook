package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.SubscriptSpan
import android.text.style.SuperscriptSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Block
import com.jullbook.app.data.Book
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.Images
import com.jullbook.app.data.ImageBlock
import com.jullbook.app.data.Progress
import com.jullbook.app.data.TextBlock
import com.jullbook.app.data.pctText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.withContext

private class EpubTheme(val bg: Color, val fg: Color)

private val EPUB_THEMES = listOf(
    EpubTheme(Color(0xFFFAF8F3), Color(0xFF1C1B19)), // Claro
    EpubTheme(Color(0xFF000000), Color(0xFFC8C4BA)), // Oscuro
    EpubTheme(Color(0xFFF1E6CC), Color(0xFF4B3B2A))  // Sepia
)

private val MARGINS = listOf(12, 24, 40)

@Composable
fun EpubReader(book: Book, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var session by remember { mutableStateOf<EpubSession?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(book.id) {
        withContext(Dispatchers.IO) {
            try {
                session = EpubSession.open(ctx, Uri.parse(book.uri))
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                error = "No se pudo abrir este EPUB. El archivo puede estar dañado."
            }
        }
    }
    DisposableEffect(Unit) { onDispose { session?.close() } }

    val s = session
    val err = error
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            err != null -> ReaderMessage(err, onBack)
            s == null -> ReaderLoading()
            s.info.spine.isEmpty() -> ReaderMessage("Este EPUB no tiene contenido legible.", onBack)
            else -> EpubBody(book, s, start, vm, onBack)
        }
    }
}

@Composable
private fun EpubBody(book: Book, s: EpubSession, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val prefs = vm.prefs
    val reporter = rememberReporter(book.id, vm)
    val chapters = s.info.spine.size

    var cur by remember { mutableIntStateOf((start?.pos ?: 0).coerceIn(0, chapters - 1)) }
    var startSub by remember { mutableIntStateOf(start?.sub ?: 0) }
    var startFrac by remember { mutableFloatStateOf(start?.frac ?: 0f) }
    var fontSize by remember { mutableFloatStateOf(prefs.epubFont) }
    var margin by remember { mutableIntStateOf(prefs.epubMargin.coerceIn(0, 2)) }
    var themeSel by remember { mutableIntStateOf(prefs.epubTheme) }
    var chrome by remember { mutableStateOf(true) }
    var sheet by remember { mutableIntStateOf(0) }
    var percent by remember { mutableFloatStateOf(start?.percent ?: 0f) }

    val dark = isSystemInDarkTheme()
    val theme = EPUB_THEMES[if (themeSel in 0..2) themeSel else if (dark) 1 else 0]

    ReaderWindowEffects(hideBars = !chrome && sheet == 0)

    fun goTo(i: Int) {
        cur = i.coerceIn(0, chapters - 1)
        startSub = 0
        startFrac = 0f
        sheet = 0
    }

    Box(Modifier.fillMaxSize().background(theme.bg)) {
        key(cur) {
            ChapterView(
                session = s,
                chapter = cur,
                startSub = startSub,
                startFrac = startFrac,
                theme = theme,
                fontSize = fontSize,
                margin = MARGINS[margin],
                hasPrev = cur > 0,
                hasNext = cur < chapters - 1,
                onPrev = { goTo(cur - 1) },
                onNext = { goTo(cur + 1) },
                onTap = { chrome = !chrome },
                onPos = { sub, frac, chapterFrac ->
                    val pct = if (cur == chapters - 1 && chapterFrac >= 1f) 1f else s.percentAt(cur, chapterFrac)
                    percent = pct
                    reporter.update(cur, sub, frac, pct)
                }
            )
        }
        ReaderChrome(
            visible = chrome,
            title = book.title,
            subtitle = s.info.titleFor(cur),
            onBack = onBack,
            actions = {
                IconButton(onClick = { sheet = 1 }) {
                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Capítulos")
                }
                IconButton(onClick = { sheet = 2 }) {
                    Icon(Icons.Default.Settings, contentDescription = "Ajustes de lectura")
                }
            },
            bottom = {
                Text(
                    "${pctText(percent)} · Capítulo ${cur + 1} de $chapters",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        )
        if (sheet != 0) {
            EpubSheet(
                kind = sheet,
                session = s,
                cur = cur,
                fontSize = fontSize,
                onFont = { fontSize = it },
                onFontDone = { prefs.epubFont = fontSize },
                margin = margin,
                onMargin = { margin = it; prefs.epubMargin = it },
                themeSel = themeSel,
                onTheme = { themeSel = it; prefs.epubTheme = it },
                onJump = { goTo(it) },
                onDismiss = { sheet = 0 }
            )
        }
    }
}

@Composable
private fun ChapterView(
    session: EpubSession,
    chapter: Int,
    startSub: Int,
    startFrac: Float,
    theme: EpubTheme,
    fontSize: Float,
    margin: Int,
    hasPrev: Boolean,
    hasNext: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onTap: () -> Unit,
    onPos: (sub: Int, frac: Float, chapterFrac: Float) -> Unit
) {
    var blocks by remember { mutableStateOf<List<Block>?>(null) }
    LaunchedEffect(chapter) {
        blocks = withContext(Dispatchers.IO) {
            try {
                EpubText.parse(session.zip, session.info.spine[chapter])
            } catch (e: CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                emptyList()
            }
        }
    }
    val list = blocks
    if (list == null) {
        ReaderLoading()
        return
    }

    val sub = startSub.coerceIn(0, (list.size - 1).coerceAtLeast(0))
    val state = rememberLazyListState(sub)
    var restored by remember { mutableStateOf(startFrac <= 0f || list.isEmpty()) }

    LaunchedEffect(Unit) {
        if (!restored) {
            state.restoreTo(sub, startFrac)
            restored = true
        }
    }
    LaunchedEffect(restored) {
        if (restored) {
            snapshotFlow { state.listPos(list.size + 1) }
                .filterNotNull()
                .distinctUntilChanged()
                .collect { p ->
                    val total = list.size.coerceAtLeast(1)
                    val chapterFrac = if (p.atEnd) 1f else ((p.index + p.frac) / total).coerceIn(0f, 1f)
                    onPos(p.index.coerceAtMost((list.size - 1).coerceAtLeast(0)), p.frac, chapterFrac)
                }
        }
    }

    LazyColumn(
        state = state,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
        contentPadding = PaddingValues(start = margin.dp, end = margin.dp, top = 56.dp, bottom = 72.dp)
    ) {
        items(list.size) { i ->
            when (val b = list[i]) {
                is TextBlock -> TextBlockView(b, theme, fontSize)
                is ImageBlock -> EpubImage(session, b.path)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(top = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = onPrev, enabled = hasPrev, modifier = Modifier.weight(1f)) {
                    Text("Anterior", color = theme.fg.copy(alpha = if (hasPrev) 1f else 0.4f))
                }
                OutlinedButton(onClick = onNext, enabled = hasNext, modifier = Modifier.weight(1f)) {
                    Text("Siguiente", color = theme.fg.copy(alpha = if (hasNext) 1f else 0.4f))
                }
            }
        }
    }
}

private fun toAnnotated(sp: Spanned, base: Float): AnnotatedString = buildAnnotatedString {
    append(sp.toString().replace('\uFFFC', ' '))
    for (span in sp.getSpans(0, sp.length, Any::class.java)) {
        val s = sp.getSpanStart(span)
        val e = sp.getSpanEnd(span)
        if (s < 0 || e <= s) continue
        val style: SpanStyle? = when (span) {
            is StyleSpan -> when (span.style) {
                Typeface.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                Typeface.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                Typeface.BOLD_ITALIC -> SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                else -> null
            }
            is UnderlineSpan -> SpanStyle(textDecoration = TextDecoration.Underline)
            is StrikethroughSpan -> SpanStyle(textDecoration = TextDecoration.LineThrough)
            is RelativeSizeSpan -> SpanStyle(fontSize = (base * span.sizeChange).sp)
            is SuperscriptSpan -> SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = (base * 0.75f).sp)
            is SubscriptSpan -> SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = (base * 0.75f).sp)
            is TypefaceSpan -> if (span.family == "monospace") SpanStyle(fontFamily = FontFamily.Monospace) else null
            else -> null
        }
        if (style != null) addStyle(style, s, e)
    }
}

@Composable
private fun TextBlockView(b: TextBlock, theme: EpubTheme, fontSize: Float) {
    val text = remember(b, fontSize) {
        val t = toAnnotated(b.sp, fontSize)
        if (b.bullet) buildAnnotatedString { append("•  "); append(t) } else t
    }
    val style = TextStyle(
        fontSize = fontSize.sp,
        lineHeight = (fontSize * 1.55f).sp,
        color = theme.fg,
        textAlign = b.align ?: TextAlign.Start,
        fontWeight = if (b.heading) FontWeight.Bold else null
    )
    val quoteColor = theme.fg.copy(alpha = 0.35f)
    var m = Modifier
        .fillMaxWidth()
        .padding(top = if (b.heading) 14.dp else 0.dp, bottom = if (b.heading) 14.dp else 10.dp)
    if (b.quote) {
        m = m
            .drawBehind { drawRect(quoteColor, size = Size(3.dp.toPx(), size.height)) }
            .padding(start = 14.dp)
    }
    Text(text = text, style = style, modifier = m)
}

@Composable
private fun EpubImage(session: EpubSession, path: String) {
    val widthPx = LocalContext.current.resources.displayMetrics.widthPixels
    val bmp by produceState<ImageBitmap?>(null, session, path) {
        value = withContext(Dispatchers.IO) {
            try {
                val e = session.zip.entry(path)
                if (e == null) null else Images.decodeSampled(session.zip.read(e), widthPx, Bitmap.Config.ARGB_8888)
            } catch (ex: CancellationException) {
                throw ex
            } catch (ignored: Throwable) {
                null
            }
        }?.asImageBitmap()
    }
    val b = bmp
    if (b != null) {
        Image(
            b,
            contentDescription = null,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            contentScale = ContentScale.FillWidth
        )
    } else {
        Spacer(Modifier.height(120.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EpubSheet(
    kind: Int,
    session: EpubSession,
    cur: Int,
    fontSize: Float,
    onFont: (Float) -> Unit,
    onFontDone: () -> Unit,
    margin: Int,
    onMargin: (Int) -> Unit,
    themeSel: Int,
    onTheme: (Int) -> Unit,
    onJump: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        if (kind == 1) {
            val toc = session.info.toc
            LazyColumn(Modifier.heightIn(max = 480.dp).navigationBarsPadding()) {
                items(toc.size) { i ->
                    val t = toc[i]
                    val active = t.spine == cur
                    Text(
                        t.title,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onJump(t.spine) }
                            .padding(start = (20 + 16 * t.level.coerceIn(0, 4)).dp, end = 20.dp, top = 12.dp, bottom = 12.dp)
                    )
                }
            }
        } else {
            Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
                Text("Tamaño de letra", style = MaterialTheme.typography.titleSmall)
                Slider(
                    value = fontSize,
                    onValueChange = onFont,
                    onValueChangeFinished = onFontDone,
                    valueRange = 12f..32f
                )
                Spacer(Modifier.height(8.dp))
                Text("Márgenes", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Estrechos", "Medios", "Anchos").forEachIndexed { i, label ->
                        FilterChip(selected = margin == i, onClick = { onMargin(i) }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Tema", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(-1 to "Auto", 0 to "Claro", 1 to "Oscuro", 2 to "Sepia").forEach { (v, label) ->
                        FilterChip(selected = themeSel == v, onClick = { onTheme(v) }, label = { Text(label) })
                    }
                }
            }
        }
    }
}
