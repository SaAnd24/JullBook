package com.jullbook.app.data

enum class Format { EPUB, PDF, COMIC }

const val ST_UNREAD = 0
const val ST_READING = 1
const val ST_FINISHED = 2

data class Book(
    val id: Long,
    val uri: String,
    val fileName: String,
    val format: Format,
    val title: String,
    val author: String?,
    val series: String?,
    val seriesKey: String?,
    val number: Int?,
    val folder: String,
    val pageCount: Int,
    val size: Long,
    val modified: Long,
    val coverPath: String?,
    val processed: Boolean
)

/** pos = página / capítulo, sub = bloque dentro del capítulo (EPUB), frac = desplazamiento dentro del elemento. */
data class Progress(
    val bookId: Long,
    val pos: Int,
    val sub: Int,
    val frac: Float,
    val percent: Float,
    val lastRead: Long,
    val status: Int
)
