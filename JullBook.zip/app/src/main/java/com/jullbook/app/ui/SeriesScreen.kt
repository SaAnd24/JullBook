package com.jullbook.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.pctText
import com.jullbook.app.data.volLabel

@Composable
fun SeriesScreen(series: SeriesItem, vm: AppViewModel, onBack: () -> Unit) {
    val target = series.target()
    LazyVerticalGrid(
        columns = GridCells.Adaptive(92.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.fillMaxWidth().statusBarsPadding()) {
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
                Text(
                    series.name.uppercase(),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${series.volumes.size} tomos · ${pctText(series.percent)} completado",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )
                if (target != null) {
                    Button(onClick = { vm.openBook(target.book) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Text(
                            (if (target.progress == null) "Empezar " else "Continuar ") + volLabel(target.book),
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
                Text(
                    "Tomos",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
                )
            }
        }
        items(series.volumes, key = { it.book.id }) { v ->
            val p = v.progress
            val finished = p?.status == ST_FINISHED
            BookCard(
                title = volLabel(v.book),
                subtitle = null,
                caption = when {
                    p == null -> null
                    finished -> "Terminado"
                    else -> pctText(p.percent)
                },
                coverPath = v.book.coverPath,
                progress = p?.percent ?: 0f,
                finished = finished,
                stack = false,
                onClick = { vm.openBook(v.book) }
            )
        }
    }
}
