package com.jullbook.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_prefs", Context.MODE_PRIVATE)

    var treeUri: String?
        get() = sp.getString("tree", null)
        set(v) { sp.edit().putString("tree", v).apply() }

    var comicVertical: Boolean
        get() = sp.getBoolean("comic_vertical", false)
        set(v) { sp.edit().putBoolean("comic_vertical", v).apply() }

    var epubFont: Float
        get() = sp.getFloat("epub_font", 18f)
        set(v) { sp.edit().putFloat("epub_font", v).apply() }

    var epubMargin: Int
        get() = sp.getInt("epub_margin", 1)
        set(v) { sp.edit().putInt("epub_margin", v).apply() }

    /** -1 = automático (sigue el tema del sistema). 0 claro, 1 oscuro, 2 sepia. */
    var epubTheme: Int
        get() = sp.getInt("epub_theme", -1)
        set(v) { sp.edit().putInt("epub_theme", v).apply() }
}
