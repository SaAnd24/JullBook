package com.jullbook.app.ui.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Progress
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.IOException
import kotlin.math.roundToInt

class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) : PageSource, Closeable {

    override val count: Int = renderer.pageCount
    private val ratios = mutableStateListOf<Float>().also { l -> repeat(count) { l.add(0.707f) } }
    private val loaded = BooleanArray(count)
    private val mutex = Mutex()
    @Volatile private var closed = false
    private var released = false

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 5).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    override fun ratio(i: Int): Float = ratios[i]

    override fun cached(i: Int, widthPx: Int): Bitmap? = cache.get("$i@$widthPx")

    override suspend fun loadRatio(i: Int) {
        if (i !in 0 until count || loaded[i]) return
        mutex.withLock {
            if (closed || loaded[i]) return
            try {
                renderer.openPage(i).use { p ->
                    if (p.height > 0) ratios[i] = p.width.toFloat() / p.height
                }
                loaded[i] = true
            } catch (ignored: Throwable) {
            } finally {
                if (closed) releaseNow()
            }
        }
    }

    override suspend fun bitmap(i: Int, widthPx: Int): Bitmap? {
        if (i !in 0 until count) return null
        val key = "$i@$widthPx"
        cache.get(key)?.let { return it }
        val bmp = mutex.withLock {
            if (closed) return@withLock null
            try {
                renderer.openPage(i).use { p ->
                    if (p.width <= 0 || p.height <= 0) return@use null
                    ratios[i] = p.width.toFloat() / p.height
                    loaded[i] = true
                    val h = (widthPx * p.height.toFloat() / p.width).roundToInt().coerceIn(1, 7000)
                    val b = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(AColor.WHITE)
                    p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    b
                }
            } catch (ignored: Throwable) {
                null
            } finally {
                if (closed) releaseNow()
            }
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    private fun releaseNow() {
        if (released) return
        released = true
        try { renderer.close() } catch (ignored: Throwable) {}
        try { pfd.close() } catch (ignored: Throwable) {}
    }

    override fun close() {
        closed = true
        if (mutex.tryLock()) {
            try {
                releaseNow()
            } finally {
                mutex.unlock()
            }
        }
    }

    companion object {
        fun open(ctx: Context, uri: Uri): PdfDoc {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("No se pudo abrir el archivo")
            try {
                return PdfDoc(pfd, PdfRenderer(pfd))
            } catch (e: Throwable) {
                try { pfd.close() } catch (ignored: Throwable) {}
                throw e
            }
        }
    }
}

@Composable
fun PdfReader(book: Book, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var doc by remember { mutableStateOf<PdfDoc?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(book.id) {
        withContext(Dispatchers.IO) {
            try {
                val d = PdfDoc.open(ctx, Uri.parse(book.uri))
                if (d.count == 0) {
                    d.close()
                    error = "Este PDF no tiene páginas."
                } else {
                    doc = d
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                error = "Este PDF está protegido con contraseña o no se puede leer."
            } catch (ignored: Throwable) {
                error = "No se pudo abrir este PDF."
            }
        }
    }
    DisposableEffect(Unit) { onDispose { doc?.close() } }

    val d = doc
    val err = error
    Box(Modifier.fillMaxSize().background(Color(0xFF101010))) {
        when {
            err != null -> ReaderMessage(err, onBack)
            d == null -> ReaderLoading()
            else -> PdfBody(book, d, start, vm, onBack)
        }
    }
}

@Composable
private fun PdfBody(book: Book, doc: PdfDoc, start: Progress?, vm: AppViewModel, onBack: () -> Unit) {
    val reporter = rememberReporter(book.id, vm)
    val zoom = remember { ZoomState() }
    var chrome by remember { mutableStateOf(true) }
    var page by remember { mutableIntStateOf((start?.pos ?: 0).coerceIn(0, doc.count - 1)) }
    var seek by remember { mutableStateOf<Int?>(null) }

    ReaderWindowEffects(hideBars = !chrome)

    Box(Modifier.fillMaxSize()) {
        PageListReader(
            source = doc,
            startPage = page,
            startFrac = start?.frac ?: 0f,
            zoom = zoom,
            seek = seek,
            onSeekDone = { seek = null },
            quality = 1.5f,
            spacing = 4.dp,
            paper = Color.White,
            onTap = { chrome = !chrome },
            onPos = { p, f, pct ->
                page = p
                reporter.update(p, 0, f, pct)
            }
        )
        ReaderChrome(
            visible = chrome,
            title = book.title,
            subtitle = "Página ${page + 1} de ${doc.count}",
            onBack = onBack,
            bottom = { PageSlider(page, doc.count) { seek = it } }
        )
    }
}
