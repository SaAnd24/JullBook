package com.jullbook.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullbook.app.AppViewModel
import com.jullbook.app.Tab
import com.jullbook.app.ui.reader.ReaderHost

@Composable
fun JullBookApp(vm: AppViewModel = viewModel()) {
    JullTheme {
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) vm.chooseFolder(uri)
        }
        val pick = { picker.launch(null) }
        val bg = MaterialTheme.colorScheme.background

        BackHandler(enabled = vm.reading != null || vm.seriesKey != null) { vm.back() }

        Box(Modifier.fillMaxSize().background(bg)) {
            when {
                !vm.loaded -> {}
                vm.treeUri == null -> WelcomeScreen(onPick = pick)
                else -> Scaffold(
                    containerColor = bg,
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                            NavigationBarItem(
                                selected = vm.tab == Tab.HOME,
                                onClick = { vm.tab = Tab.HOME },
                                icon = { Icon(Icons.Default.Home, contentDescription = null) },
                                label = { Text("Inicio") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                            NavigationBarItem(
                                selected = vm.tab == Tab.LIBRARY,
                                onClick = { vm.tab = Tab.LIBRARY },
                                icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = null) },
                                label = { Text("Biblioteca") },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }
                ) { pad ->
                    when (vm.tab) {
                        Tab.HOME -> HomeScreen(vm, pick, Modifier.padding(pad))
                        Tab.LIBRARY -> LibraryScreen(vm, pick, Modifier.padding(pad))
                    }
                }
            }

            val key = vm.seriesKey
            val series = key?.let { vm.library.series[it] }
            if (series != null) {
                Box(Modifier.fillMaxSize().background(bg).pointerInput(Unit) {}) {
                    SeriesScreen(series, vm, onBack = { vm.back() })
                }
            }

            val book = vm.reading
            if (book != null) {
                Box(Modifier.fillMaxSize().background(bg).pointerInput(Unit) {}) {
                    ReaderHost(book, vm, onBack = { vm.back() })
                }
            }
        }
    }
}
