package com.jullbook.app.ui.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Format
import com.jullbook.app.data.Progress

@Composable
fun ReaderHost(book: Book, vm: AppViewModel, onBack: () -> Unit) {
    var loaded by remember(book.id) { mutableStateOf(false) }
    var start by remember(book.id) { mutableStateOf<Progress?>(null) }
    LaunchedEffect(book.id) {
        start = vm.beginReading(book.id)
        loaded = true
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!loaded) {
            ReaderLoading()
        } else {
            when (book.format) {
                Format.EPUB -> EpubReader(book, start, vm, onBack)
                Format.PDF -> PdfReader(book, start, vm, onBack)
                Format.COMIC -> ComicReader(book, start, vm, onBack)
            }
        }
    }
}
