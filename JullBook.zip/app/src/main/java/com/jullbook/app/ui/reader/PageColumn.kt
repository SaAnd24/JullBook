package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Origen de páginas como imágenes (PDF o cómic). */
interface PageSource {
    val count: Int
    fun ratio(i: Int): Float
    fun cached(i: Int, widthPx: Int): Bitmap?
    suspend fun loadRatio(i: Int)
    suspend fun bitmap(i: Int, widthPx: Int): Bitmap?
}

@Composable
private fun PageItem(source: PageSource, i: Int, widthPx: Int, paper: Color) {
    val ratio = source.ratio(i).coerceIn(0.1f, 10f)
    val bmp by produceState<ImageBitmap?>(source.cached(i, widthPx)?.asImageBitmap(), source, i, widthPx) {
        if (value == null) {
            value = withContext(Dispatchers.IO) { source.bitmap(i, widthPx) }?.asImageBitmap()
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .background(paper)
    ) {
        val b = bmp
        if (b != null) {
            Image(b, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
    }
}

/**
 * Lector de páginas en columna vertical con zoom (PDF y cómic en modo vertical).
 * Restaura la posición exacta (página + desplazamiento) y la informa mediante [onPos].
 */
@Composable
fun PageListReader(
    source: PageSource,
    startPage: Int,
    startFrac: Float,
    zoom: ZoomState,
    seek: Int?,
    onSeekDone: () -> Unit,
    quality: Float,
    spacing: Dp,
    paper: Color,
    onTap: () -> Unit,
    onPos: (page: Int, frac: Float, percent: Float) -> Unit
) {
    val count = source.count
    val start = startPage.coerceIn(0, (count - 1).coerceAtLeast(0))
    var ready by remember { mutableStateOf(false) }

    LaunchedEffect(source) {
        withContext(Dispatchers.IO) {
            for (i in start..minOf(start + 2, count - 1)) source.loadRatio(i)
        }
        ready = true
        withContext(Dispatchers.IO) {
            for (i in 0 until count) source.loadRatio(i)
        }
    }

    if (!ready) {
        ReaderLoading()
        return
    }

    val listState = rememberLazyListState(start)
    var restored by remember { mutableStateOf(startFrac <= 0f) }

    LaunchedEffect(Unit) {
        if (!restored) {
            listState.restoreTo(start, startFrac)
            restored = true
        }
    }
    LaunchedEffect(restored) {
        if (restored) {
            snapshotFlow { listState.listPos(count) }
                .filterNotNull()
                .distinctUntilChanged()
                .collect { p -> onPos(p.index, p.frac, pagePercent(p.index, p.frac, count, p.atEnd, false)) }
        }
    }
    LaunchedEffect(seek) {
        if (seek != null) {
            listState.scrollToItem(seek.coerceIn(0, count - 1))
            onSeekDone()
        }
    }

    ZoomBox(
        state = zoom,
        scrollMode = true,
        onTap = onTap,
        onScrollBy = { listState.dispatchRawDelta(it) }
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val reqW = (constraints.maxWidth * quality).roundToInt().coerceAtLeast(1)
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(spacing)
            ) {
                items(count) { i -> PageItem(source, i, reqW, paper) }
            }
        }
    }
}
