package com.jullbook.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NewBook(
    val uri: String,
    val fileName: String,
    val format: Format,
    val title: String,
    val series: String?,
    val seriesKey: String?,
    val number: Int?,
    val folder: String,
    val size: Long,
    val modified: Long
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "jullbook.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT UNIQUE NOT NULL, file_name TEXT, " +
                "format TEXT, title TEXT, author TEXT, series TEXT, series_key TEXT, number INTEGER, folder TEXT, " +
                "page_count INTEGER DEFAULT 0, size INTEGER, modified INTEGER, cover TEXT, processed INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE progress(book_id INTEGER PRIMARY KEY, pos INTEGER, sub INTEGER, frac REAL, " +
                "percent REAL, last_read INTEGER, status INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun allBooks(): List<Book> {
        val out = ArrayList<Book>()
        readableDatabase.rawQuery(
            "SELECT id,uri,file_name,format,title,author,series,series_key,number,folder,page_count,size,modified,cover,processed FROM books",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Book(
                        id = c.getLong(0),
                        uri = c.getString(1),
                        fileName = c.getString(2) ?: "",
                        format = Format.valueOf(c.getString(3)),
                        title = c.getString(4) ?: "",
                        author = c.getString(5),
                        series = c.getString(6),
                        seriesKey = c.getString(7),
                        number = if (c.isNull(8)) null else c.getInt(8),
                        folder = c.getString(9) ?: "",
                        pageCount = c.getInt(10),
                        size = c.getLong(11),
                        modified = c.getLong(12),
                        coverPath = c.getString(13),
                        processed = c.getInt(14) == 1
                    )
                )
            }
        }
        return out
    }

    fun insertBooks(list: List<NewBook>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (b in list) {
                val cv = ContentValues()
                cv.put("uri", b.uri)
                cv.put("file_name", b.fileName)
                cv.put("format", b.format.name)
                cv.put("title", b.title)
                cv.put("series", b.series)
                cv.put("series_key", b.seriesKey)
                cv.put("number", b.number)
                cv.put("folder", b.folder)
                cv.put("size", b.size)
                cv.put("modified", b.modified)
                cv.put("processed", 0)
                db.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetBook(id: Long, size: Long, modified: Long) {
        val cv = ContentValues()
        cv.put("size", size)
        cv.put("modified", modified)
        cv.put("processed", 0)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateMeta(id: Long, title: String?, author: String?, pages: Int, cover: String?) {
        val cv = ContentValues()
        if (!title.isNullOrBlank()) cv.put("title", title.trim())
        cv.put("author", author)
        cv.put("page_count", pages)
        cv.put("cover", cover)
        cv.put("processed", 1)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteBooks(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) {
                db.delete("books", "id=?", arrayOf(id.toString()))
                db.delete("progress", "book_id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearAll() {
        val db = writableDatabase
        db.delete("books", null, null)
        db.delete("progress", null, null)
    }

    private fun readProgress(c: android.database.Cursor) = Progress(
        bookId = c.getLong(0),
        pos = c.getInt(1),
        sub = c.getInt(2),
        frac = c.getFloat(3),
        percent = c.getFloat(4),
        lastRead = c.getLong(5),
        status = c.getInt(6)
    )

    fun allProgress(): Map<Long, Progress> {
        val out = HashMap<Long, Progress>()
        readableDatabase.rawQuery("SELECT book_id,pos,sub,frac,percent,last_read,status FROM progress", null).use { c ->
            while (c.moveToNext()) {
                val p = readProgress(c)
                out[p.bookId] = p
            }
        }
        return out
    }

    fun getProgress(id: Long): Progress? =
        readableDatabase.rawQuery(
            "SELECT book_id,pos,sub,frac,percent,last_read,status FROM progress WHERE book_id=?",
            arrayOf(id.toString())
        ).use { c -> if (c.moveToFirst()) readProgress(c) else null }

    fun saveProgress(p: Progress) {
        val cv = ContentValues()
        cv.put("book_id", p.bookId)
        cv.put("pos", p.pos)
        cv.put("sub", p.sub)
        cv.put("frac", p.frac)
        cv.put("percent", p.percent)
        cv.put("last_read", p.lastRead)
        cv.put("status", p.status)
        writableDatabase.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
}
