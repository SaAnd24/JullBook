package com.jullbook.app.data

import java.text.Normalizer

object SeriesParser {
    class Parsed(val title: String, val series: String?, val key: String?, val number: Int?)

    private const val KW = "(?:vol(?:ume|umen)?\\.?\\s*|v\\.?\\s*|tomo\\.?\\s*|t\\.?\\s*|n[º°o]\\.?\\s*|no\\.?\\s*|issue\\s*|cap(?:[ií]tulo)?\\.?\\s*|ch(?:apter)?\\.?\\s*|ep(?:isode)?\\.?\\s*|#\\s*)"

    // [prefijo + separador] [palabra clave opcional] número [(etiquetas) opcionales al final]
    private val NUM = Regex(
        "^(?:(.*?)[\\s._\\-]+)?(?:" + KW + ")?(\\d{1,4})((?:\\s*[(\\[][^)\\]]*[)\\]])*)\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val SPACES = Regex("\\s+")
    private val MARKS = Regex("\\p{Mn}+")
    private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]+")

    fun keyOf(name: String): String =
        Normalizer.normalize(name, Normalizer.Form.NFD)
            .replace(MARKS, "")
            .lowercase()
            .replace(NON_ALNUM, " ")
            .trim()

    fun parse(fileName: String, folder: String, isComic: Boolean): Parsed {
        val base = fileName.substringBeforeLast('.')
        val clean = base.replace('_', ' ').replace(SPACES, " ").trim()
        val title = clean.ifBlank { fileName }
        if (!isComic) return Parsed(title, null, null, null)
        val m = NUM.matchEntire(clean) ?: return Parsed(title, null, null, null)
        val number = m.groupValues[2].toIntOrNull() ?: return Parsed(title, null, null, null)
        var name = (m.groups[1]?.value ?: "").trim().trim('-', '–', '.', ',', ' ')
        if (name.isEmpty()) name = folder.replace('_', ' ').replace(SPACES, " ").trim()
        if (name.count { it.isLetter() } < 2) return Parsed(title, null, null, null)
        val key = keyOf(name)
        if (key.isEmpty()) return Parsed(title, null, null, null)
        return Parsed(title, name, key, number)
    }
}
