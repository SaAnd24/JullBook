package com.jullbook.app.data

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.Closeable

class TocItem(val title: String, val spine: Int, val level: Int)

class EpubInfo(
    val title: String?,
    val author: String?,
    val spine: List<String>,
    val toc: List<TocItem>,
    val cover: String?
) {
    fun titleFor(i: Int): String = toc.firstOrNull { it.spine == i }?.title ?: "Capítulo ${i + 1}"
}

class EpubSession(val zip: SeekableZip, val info: EpubInfo) : Closeable {
    private val weights = DoubleArray(info.spine.size) { i ->
        (zip.entry(info.spine[i])?.size ?: 1L).coerceAtLeast(1L).toDouble()
    }
    private val before = DoubleArray(info.spine.size).also { b ->
        var acc = 0.0
        for (i in b.indices) { b[i] = acc; acc += weights[i] }
    }
    private val total = weights.sum().coerceAtLeast(1.0)

    fun percentAt(chapter: Int, chapterFrac: Float): Float {
        if (chapter !in weights.indices) return 0f
        return ((before[chapter] + chapterFrac * weights[chapter]) / total).toFloat().coerceIn(0f, 1f)
    }

    override fun close() = zip.close()

    companion object {
        fun open(ctx: Context, uri: Uri): EpubSession {
            val z = SeekableZip.open(ctx, uri)
            try {
                return EpubSession(z, EpubParser.parse(z))
            } catch (e: Throwable) {
                z.close()
                throw e
            }
        }
    }
}

object EpubParser {
    private class Item(val id: String, val href: String, val type: String, val props: String)

    private fun xml(bytes: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ByteArrayInputStream(bytes), null)
        for ((k, v) in listOf("nbsp" to "\u00A0", "copy" to "\u00A9", "mdash" to "\u2014", "ndash" to "\u2013",
            "hellip" to "\u2026", "rsquo" to "\u2019", "lsquo" to "\u2018", "rdquo" to "\u201D", "ldquo" to "\u201C")) {
            try { p.defineEntityReplacementText(k, v) } catch (ignored: Exception) {}
        }
        return p
    }

    private fun dirOf(path: String) = path.substringBeforeLast('/', "")

    fun parse(zip: SeekableZip): EpubInfo {
        val container = zip.readText("META-INF/container.xml") ?: throw IllegalStateException("EPUB sin container.xml")
        val opfPath = Regex("full-path\\s*=\\s*[\"']([^\"']+)[\"']").find(container)?.groupValues?.get(1)
            ?: throw IllegalStateException("EPUB sin OPF")
        val opfEntry = zip.entry(opfPath) ?: throw IllegalStateException("OPF no encontrado")
        val opfDir = dirOf(opfPath)

        var title: String? = null
        var author: String? = null
        var coverId: String? = null
        var tocId: String? = null
        val manifest = LinkedHashMap<String, Item>()
        val spineIds = ArrayList<String>()

        val p = xml(zip.read(opfEntry))
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "title" -> if (title == null) title = p.nextText().trim()
                    "creator" -> if (author == null) author = p.nextText().trim()
                    "meta" -> if (p.getAttributeValue(null, "name") == "cover") coverId = p.getAttributeValue(null, "content")
                    "item" -> {
                        val id = p.getAttributeValue(null, "id") ?: ""
                        val href = p.getAttributeValue(null, "href") ?: ""
                        if (id.isNotEmpty() && href.isNotEmpty()) {
                            manifest[id] = Item(
                                id,
                                resolvePath(opfDir, Uri.decode(href.substringBefore('#'))),
                                p.getAttributeValue(null, "media-type") ?: "",
                                p.getAttributeValue(null, "properties") ?: ""
                            )
                        }
                    }
                    "spine" -> tocId = p.getAttributeValue(null, "toc")
                    "itemref" -> p.getAttributeValue(null, "idref")?.let { spineIds.add(it) }
                }
            }
            ev = p.next()
        }

        val spine = spineIds.mapNotNull { manifest[it]?.href }.filter { zip.entry(it) != null }
        val spineIndex = HashMap<String, Int>()
        spine.forEachIndexed { i, s -> if (!spineIndex.containsKey(s)) spineIndex[s] = i }

        val cover = (coverId?.let { manifest[it] } ?: manifest.values.firstOrNull { it.props.contains("cover-image") })
            ?.href?.takeIf { zip.entry(it) != null }

        var toc: List<TocItem> = emptyList()
        try {
            val ncx = (tocId?.let { manifest[it] } ?: manifest.values.firstOrNull { it.type == "application/x-dtbncx+xml" })
            if (ncx != null) toc = parseNcx(zip, ncx.href, spineIndex)
            if (toc.isEmpty()) {
                val nav = manifest.values.firstOrNull { it.props.split(' ').contains("nav") }
                if (nav != null) toc = parseNav(zip, nav.href, spineIndex)
            }
        } catch (ignored: Throwable) {
            toc = emptyList()
        }
        if (toc.isEmpty()) toc = spine.indices.map { TocItem("Capítulo ${it + 1}", it, 0) }
        return EpubInfo(title?.takeIf { it.isNotBlank() }, author?.takeIf { it.isNotBlank() }, spine, toc, cover)
    }

    private fun parseNcx(zip: SeekableZip, path: String, spineIndex: Map<String, Int>): List<TocItem> {
        val e = zip.entry(path) ?: return emptyList()
        val dir = dirOf(path)
        val out = ArrayList<TocItem>()
        val p = xml(zip.read(e))
        val labels = ArrayList<String>()
        var depth = 0
        var inMap = false
        var inLabel = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "navMap" -> inMap = true
                    "navPoint" -> { depth++; labels.add("") }
                    "navLabel" -> inLabel = true
                    "text" -> if (inMap && inLabel && labels.isNotEmpty()) labels[labels.size - 1] = p.nextText().trim()
                    "content" -> if (inMap && labels.isNotEmpty()) {
                        val src = p.getAttributeValue(null, "src") ?: ""
                        val idx = spineIndex[resolvePath(dir, Uri.decode(src.substringBefore('#')))]
                        if (idx != null) out.add(TocItem(labels.last().ifBlank { "Capítulo ${idx + 1}" }, idx, depth - 1))
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "navLabel" -> inLabel = false
                    "navPoint" -> { depth--; if (labels.isNotEmpty()) labels.removeAt(labels.size - 1) }
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun parseNav(zip: SeekableZip, path: String, spineIndex: Map<String, Int>): List<TocItem> {
        val e = zip.entry(path) ?: return emptyList()
        val dir = dirOf(path)
        val out = ArrayList<TocItem>()
        val p = xml(zip.read(e))
        var inToc = false
        var ol = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "nav" -> if ((p.getAttributeValue(null, "epub:type") ?: "").contains("toc")) inToc = true
                    "ol" -> if (inToc) ol++
                    "a" -> if (inToc) {
                        val href = p.getAttributeValue(null, "href") ?: ""
                        val sb = StringBuilder()
                        var d = 1
                        while (d > 0) {
                            when (p.next()) {
                                XmlPullParser.TEXT -> sb.append(p.text)
                                XmlPullParser.START_TAG -> d++
                                XmlPullParser.END_TAG -> d--
                                XmlPullParser.END_DOCUMENT -> d = 0
                            }
                        }
                        val idx = spineIndex[resolvePath(dir, Uri.decode(href.substringBefore('#')))]
                        if (idx != null) out.add(TocItem(sb.toString().trim().replace(Regex("\\s+"), " ").ifBlank { "Capítulo ${idx + 1}" }, idx, (ol - 1).coerceAtLeast(0)))
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "ol" -> if (inToc) ol--
                    "nav" -> inToc = false
                }
            }
            ev = p.next()
        }
        return out
    }
}
