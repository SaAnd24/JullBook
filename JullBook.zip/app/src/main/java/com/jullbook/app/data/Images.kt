package com.jullbook.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream

object Images {
    /** Decodifica reduciendo por potencias de 2; el ancho resultante queda cerca de targetW. */
    fun decodeSampled(bytes: ByteArray, targetW: Int, config: Bitmap.Config): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= targetW * 0.75f) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        o2.inPreferredConfig = config
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }

    /** ancho/alto o null si no se pudo leer. */
    fun ratio(bytes: ByteArray): Float? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        return if (o.outWidth > 0 && o.outHeight > 0) o.outWidth.toFloat() / o.outHeight else null
    }

    fun pageRatio(zip: SeekableZip, e: ZEntry): Float {
        val head = zip.read(e, 262144)
        return ratio(head) ?: ratio(zip.read(e)) ?: 0.7f
    }
}

object Covers {
    fun save(ctx: Context, b: Book, src: Bitmap): String? {
        return try {
            val dir = File(ctx.filesDir, "covers")
            dir.mkdirs()
            b.coverPath?.let { File(it).delete() }
            var bmp = src
            if (bmp.height > bmp.width * 3 / 2) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.width * 3 / 2)
            val f = File(dir, "${b.id}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            f.absolutePath
        } catch (ignored: Throwable) {
            null
        }
    }

    fun deleteAll(ctx: Context) {
        File(ctx.filesDir, "covers").deleteRecursively()
    }
}

object CoverCache {
    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        val bmp = BitmapFactory.decodeFile(path) ?: return null
        cache.put(path, bmp)
        return bmp
    }
}
