package com.jullbook.app.data

import java.util.Locale

fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        val ca = a[i]
        val cb = b[j]
        if (ca.isDigit() && cb.isDigit()) {
            var ei = i
            while (ei < a.length && a[ei].isDigit()) ei++
            var ej = j
            while (ej < b.length && b[ej].isDigit()) ej++
            val na = a.substring(i, ei).trimStart('0')
            val nb = b.substring(j, ej).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ei
            j = ej
        } else {
            val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

fun resolvePath(baseDir: String, rel: String): String {
    val full = if (rel.startsWith("/")) rel.removePrefix("/") else if (baseDir.isEmpty()) rel else "$baseDir/$rel"
    val parts = ArrayList<String>()
    for (seg in full.split('/')) {
        when (seg) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
            else -> parts.add(seg)
        }
    }
    return parts.joinToString("/")
}

fun volLabel(b: Book): String = b.number?.let { String.format(Locale.ROOT, "#%03d", it) } ?: b.title

fun pctText(f: Float): String = "${(f * 100f).toInt()}%"

fun formatLabel(f: Format): String = when (f) {
    Format.EPUB -> "EPUB"
    Format.PDF -> "PDF"
    Format.COMIC -> "Cómic"
}
