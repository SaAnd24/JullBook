package com.jullbook.app.translate

import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.TextBlock
import java.util.Locale

class TrLang(val code: String, val label: String)

/** Idiomas disponibles para traducir (ISO 639-1). Para añadir uno basta con una línea. */
object TrLangs {
    val all: List<TrLang> = listOf(
        TrLang("es", "Español"), TrLang("en", "Inglés"), TrLang("fr", "Francés"), TrLang("it", "Italiano"),
        TrLang("de", "Alemán"), TrLang("pt", "Portugués"), TrLang("ca", "Catalán"), TrLang("nl", "Neerlandés"),
        TrLang("pl", "Polaco"), TrLang("ru", "Ruso"), TrLang("tr", "Turco"), TrLang("ar", "Árabe"),
        TrLang("ja", "Japonés"), TrLang("zh", "Chino"), TrLang("ko", "Coreano")
    )

    fun label(code: String): String = all.firstOrNull { it.code == code }?.label ?: code

    private val THREE = mapOf(
        "spa" to "es", "eng" to "en", "fra" to "fr", "fre" to "fr", "ita" to "it", "deu" to "de", "ger" to "de",
        "por" to "pt", "cat" to "ca", "nld" to "nl", "dut" to "nl", "pol" to "pl", "rus" to "ru", "tur" to "tr",
        "ara" to "ar", "jpn" to "ja", "zho" to "zh", "chi" to "zh", "kor" to "ko"
    )

    /** "es-ES", "spa", "Spanish"… -> "es". Null si no se reconoce (nunca se inventa). */
    fun normalize(raw: String?): String? {
        val p = raw?.trim()?.lowercase(Locale.ROOT)?.substringBefore('-')?.substringBefore('_').orEmpty()
        if (p.isEmpty()) return null
        if (p.length == 2) return p.takeIf { c -> all.any { it.code == c } }
        THREE[p]?.let { return it }
        return all.firstOrNull { l ->
            Locale(l.code).getDisplayLanguage(Locale.ENGLISH).lowercase(Locale.ROOT) == p
        }?.code
    }
}

/** Detección local del idioma del libro (sin red): metadatos del EPUB y, si faltan, el propio texto. */
object LangDetect {
    private val WORDS: Map<String, Set<String>> = mapOf(
        "es" to setOf("de", "la", "que", "el", "en", "y", "los", "se", "del", "las", "un", "por", "con", "no", "una", "su", "para", "es", "al", "lo", "como", "más", "pero", "sus", "le", "ya", "este", "sí", "porque", "esta", "entre", "cuando", "muy", "sin", "sobre", "también", "me", "hasta", "hay", "donde", "quien", "desde", "todo", "nos"),
        "en" to setOf("the", "of", "and", "to", "in", "that", "is", "was", "he", "for", "it", "with", "as", "his", "on", "be", "at", "by", "had", "not", "are", "but", "from", "or", "have", "an", "they", "which", "you", "were", "her", "she", "there", "would", "their", "we", "him", "been", "has", "when", "who", "will", "if", "so", "said", "what", "its", "about", "into", "than"),
        "fr" to setOf("le", "la", "les", "de", "des", "du", "un", "une", "et", "est", "en", "que", "qui", "dans", "pour", "pas", "au", "sur", "ne", "se", "ce", "il", "elle", "nous", "vous", "ils", "avec", "son", "sa", "ses", "mais", "ou", "où", "plus", "par", "comme", "était", "je", "tu"),
        "it" to setOf("il", "lo", "la", "i", "gli", "le", "di", "del", "della", "che", "e", "è", "un", "una", "per", "con", "non", "in", "si", "da", "come", "ma", "più", "anche", "sono", "ha", "mi", "ti", "ci", "questo", "quella"),
        "de" to setOf("der", "die", "das", "und", "ist", "nicht", "ein", "eine", "zu", "den", "mit", "von", "sich", "auf", "für", "auch", "es", "dem", "im", "er", "sie", "ich", "war", "als", "aber", "wie", "oder", "nach", "bei", "dass", "wir", "hat"),
        "pt" to setOf("o", "a", "os", "as", "de", "do", "da", "dos", "das", "que", "e", "é", "um", "uma", "para", "com", "não", "em", "se", "na", "no", "por", "mais", "como", "mas", "foi", "ao", "ele", "ela", "seu", "sua", "você", "também"),
        "ca" to setOf("el", "la", "els", "les", "de", "del", "que", "i", "és", "un", "una", "per", "amb", "no", "en", "es", "com", "però", "més", "també", "va", "són", "aquest", "això"),
        "nl" to setOf("de", "het", "een", "en", "van", "in", "is", "dat", "op", "te", "zijn", "met", "voor", "niet", "aan", "er", "maar", "om", "ook", "als", "bij", "of", "ze", "hij", "zij", "ik", "je")
    )
    private val TOKEN = Regex("[\\p{L}']+")

    /** Idioma de un texto, o null si no hay seguridad suficiente. */
    fun detect(text: String): String? {
        if (text.length < 40) return null
        var kana = 0
        var hangul = 0
        var han = 0
        var cyr = 0
        var arab = 0
        var letters = 0
        for (c in text) {
            if (!c.isLetter()) continue
            letters++
            when (c.code) {
                in 0x3040..0x30FF -> kana++
                in 0xAC00..0xD7AF, in 0x1100..0x11FF -> hangul++
                in 0x4E00..0x9FFF -> han++
                in 0x0400..0x04FF -> cyr++
                in 0x0600..0x06FF -> arab++
            }
        }
        if (letters == 0) return null
        val q = letters * 0.3
        if (kana > q) return "ja"
        if (hangul > q) return "ko"
        if (han > q) return if (kana > 0) "ja" else "zh"
        if (cyr > q) return "ru"
        if (arab > q) return "ar"

        val words = TOKEN.findAll(text.lowercase(Locale.ROOT)).map { it.value }.toList()
        if (words.size < 15) return null
        val scores = WORDS.mapValues { (_, set) -> words.count { it in set }.toDouble() / words.size }
        val ranked = scores.entries.sortedByDescending { it.value }
        val best = ranked[0]
        val second = ranked.getOrNull(1)?.value ?: 0.0
        if (best.value < 0.10 || best.value < second * 1.15) return null
        return best.key
    }

    /** Idioma del libro: metadatos del EPUB y, si no sirven, una muestra del texto de los primeros capítulos. */
    fun forBook(session: EpubSession): String? {
        TrLangs.normalize(session.info.language)?.let { return it }
        val sb = StringBuilder()
        for (ch in session.info.spine.indices) {
            if (sb.length >= 4000 || ch > 12) break
            val blocks = try {
                EpubText.parse(session.zip, session.info.spine[ch])
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (ignored: Throwable) {
                continue
            }
            for (b in blocks) {
                if (b is TextBlock) sb.append(b.sp.toString().replace('￼', ' ')).append(' ')
                if (sb.length >= 4000) break
            }
        }
        return detect(sb.toString())
    }
}
