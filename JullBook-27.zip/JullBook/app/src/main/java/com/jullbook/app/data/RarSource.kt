package com.jullbook.app.data

import android.content.Context
import android.net.Uri
import com.github.junrar.Archive
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/** Lectura de CBR (RAR) con junrar. Se extraen las páginas a la caché de la app; el archivo original no se toca. */
object RarSource {
    class Unsupported(val v5: Boolean) : IOException(if (v5) "RAR5 no soportado" else "RAR no soportado")

    private const val KEEP_CACHED = 2

    private fun nameOf(h: Any): String {
        for (m in arrayOf("getFileName", "getFileNameString")) {
            try {
                val r = h.javaClass.getMethod(m).invoke(h) as? String
                if (r != null) return r
            } catch (ignored: Throwable) {
            }
        }
        return ""
    }

    private val SINK = object : OutputStream() {
        override fun write(b: Int) {}
        override fun write(b: ByteArray, off: Int, len: Int) {}
    }

    /** Primera imagen válida del CBR (null si no se pudo) y número de páginas (imágenes) que contiene. */
    class CoverResult(val bytes: ByteArray?, val pages: Int)

    private const val COVER_TRIES = 3

    /**
     * Portada de un CBR sin abrirlo para leer: solo se lee la lista de entradas y se descomprime EN MEMORIA la
     * primera imagen válida (en orden natural). No se extrae el resto del archivo ni se modifica el original.
     * Devuelve null si el archivo no se puede leer (dañado, con contraseña o RAR5).
     */
    fun cover(ctx: Context, uri: Uri): CoverResult? {
        // 1) Sin copiar nada: se lee directamente el descriptor del archivo.
        val pfd = try {
            ctx.contentResolver.openFileDescriptor(uri, "r")
        } catch (t: Throwable) {
            null
        }
        if (pfd != null) {
            try {
                val f = File("/proc/self/fd/${pfd.fd}")
                if (f.isFile && f.canRead()) {
                    return try {
                        readCover(f)
                    } catch (t: Throwable) {
                        null // dañado, con contraseña o RAR5: sin portada
                    }
                }
            } finally {
                try { pfd.close() } catch (ignored: Exception) {}
            }
        }
        // 2) Plan B (poco habitual): copia temporal que se borra siempre.
        val root = File(ctx.cacheDir, "cbr")
        root.mkdirs()
        val tmp = File(root, "cover_${System.nanoTime()}.rar")
        return try {
            val ins = ctx.contentResolver.openInputStream(uri) ?: return null
            ins.use { input -> FileOutputStream(tmp).use { out -> input.copyTo(out, 256 * 1024) } }
            readCover(tmp)
        } catch (t: Throwable) {
            null
        } finally {
            tmp.delete()
        }
    }

    private fun readCover(file: File): CoverResult {
        Archive(file).use { a ->
            val headers = a.fileHeaders
            val imgs = ArrayList<Pair<String, Int>>() // nombre, posición en el archivo
            for (i in 0 until headers.size) {
                val h = headers[i]
                if (h.isDirectory) continue
                val name = nameOf(h).replace('\\', '/')
                if (SeekableZip.isImage(name)) imgs.add(name to i)
            }
            if (imgs.isEmpty()) return CoverResult(null, 0)
            imgs.sortWith(Comparator { x, y -> naturalCompare(x.first, y.first) })
            for (k in 0 until minOf(COVER_TRIES, imgs.size)) {
                val bytes = extractUpTo(a, imgs[k].second)
                if (bytes != null && Images.ratio(bytes) != null) return CoverResult(bytes, imgs.size)
            }
            return CoverResult(null, imgs.size)
        }
    }

    /**
     * Descomprime hasta la entrada [targetIndex] y devuelve solo su contenido. Las anteriores se descartan sin guardarse
     * (en archivos "sólidos" hay que recorrerlas igualmente); lo que viene después no se toca.
     */
    private fun extractUpTo(a: Archive, targetIndex: Int): ByteArray? {
        val headers = a.fileHeaders
        for (i in 0..targetIndex) {
            val h = headers[i]
            if (h.isDirectory) continue
            if (i == targetIndex) {
                val bos = ByteArrayOutputStream()
                a.extractFile(h, bos)
                return bos.toByteArray()
            }
            a.extractFile(h, SINK)
        }
        return null
    }

    /**
     * Devuelve las páginas del CBR ya extraídas (en orden natural). Reutiliza la caché si ya se extrajo.
     * [check] se llama durante el proceso para poder cancelarlo.
     */
    fun prepare(ctx: Context, b: Book, check: () -> Unit): List<File> {
        val root = File(ctx.cacheDir, "cbr")
        root.mkdirs()
        val dir = File(root, "${b.id}_${b.modified}")
        val order = File(dir, "order.txt")
        val done = File(dir, ".done")
        if (done.exists() && order.exists()) {
            val files = order.readLines().filter { it.isNotBlank() }.map { File(dir, it) }.filter { it.exists() }
            if (files.isNotEmpty()) {
                dir.setLastModified(System.currentTimeMillis())
                return files
            }
        }
        dir.deleteRecursively()
        trim(root, dir)
        dir.mkdirs()
        val tmp = File(root, "tmp_${b.id}.rar")
        try {
            val ins = ctx.contentResolver.openInputStream(Uri.parse(b.uri)) ?: throw IOException("No se pudo abrir el archivo")
            ins.use { input ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        check()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            val extracted = ArrayList<Pair<String, File>>()
            Archive(tmp).use { a ->
                var n = 0
                for (h in a.fileHeaders) {
                    check()
                    if (h.isDirectory) continue
                    val name = nameOf(h).replace('\\', '/')
                    if (SeekableZip.isImage(name)) {
                        val ext = name.substringAfterLast('.', "jpg").lowercase().filter { it.isLetterOrDigit() }.take(5).ifEmpty { "jpg" }
                        val f = File(dir, "p${n++}.$ext")
                        FileOutputStream(f).use { a.extractFile(h, it) }
                        extracted.add(name to f)
                    } else {
                        // En archivos "sólidos" hay que descomprimir también lo que no se usa.
                        a.extractFile(h, SINK)
                    }
                }
            }
            if (extracted.isEmpty()) throw IOException("El archivo no contiene imágenes")
            val sorted = extracted.sortedWith(Comparator { x, y -> naturalCompare(x.first, y.first) })
            order.writeText(sorted.joinToString("\n") { it.second.name })
            done.writeText("ok")
            return sorted.map { it.second }
        } catch (t: Throwable) {
            dir.deleteRecursively()
            val label = t.javaClass.simpleName + " " + (t.message ?: "")
            if (label.contains("V5", ignoreCase = true) || label.contains("RAR5", ignoreCase = true)) throw Unsupported(true)
            throw t
        } finally {
            tmp.delete()
        }
    }

    /** Conserva solo los últimos cómics extraídos para no llenar el almacenamiento. */
    private fun trim(root: File, current: File) {
        root.listFiles()?.forEach { if (it.isFile) it.delete() }
        val dirs = (root.listFiles() ?: emptyArray())
            .filter { it.isDirectory && it != current }
            .sortedByDescending { it.lastModified() }
        dirs.drop(KEEP_CACHED).forEach { it.deleteRecursively() }
    }
}
