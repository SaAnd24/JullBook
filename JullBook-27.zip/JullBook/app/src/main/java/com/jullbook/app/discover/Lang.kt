package com.jullbook.app.discover

import java.text.Normalizer
import java.util.Locale

/**
 * Idiomas que se pueden filtrar en la búsqueda. Para ampliar la lista basta con añadir una entrada
 * (antes de OTHER): código ISO 639-1, nombre, bandera y los nombres/códigos con que lo escriben las fuentes.
 */
enum class Lang(val code: String?, val label: String, val flag: String, private val names: Set<String>) {
    ES("es", "Español", "🇪🇸", setOf("es", "spa", "esp", "spanish", "espanol", "castellano", "castilian", "spanisch", "espagnol", "spagnolo", "espanhol")),
    EN("en", "Inglés", "🇬🇧", setOf("en", "eng", "english", "ingles", "anglais", "englisch", "inglese")),
    FR("fr", "Francés", "🇫🇷", setOf("fr", "fra", "fre", "french", "frances", "francais", "franzosisch", "francese")),
    IT("it", "Italiano", "🇮🇹", setOf("it", "ita", "italian", "italiano", "italien", "italienisch")),
    DE("de", "Alemán", "🇩🇪", setOf("de", "deu", "ger", "german", "aleman", "deutsch", "allemand", "tedesco")),
    PT("pt", "Portugués", "🇵🇹", setOf("pt", "por", "portuguese", "portugues", "portugais", "portoghese", "portugiesisch")),
    JA("ja", "Japonés", "🇯🇵", setOf("ja", "jpn", "japanese", "japones", "japonais", "giapponese", "japanisch", "nihongo")),

    /** Idioma identificado por la fuente pero fuera de la lista anterior. */
    OTHER(null, "Otros", "🌐", emptySet());

    companion object {
        private val UNKNOWN = setOf(
            "", "und", "zxx", "mul", "mis", "unknown", "n/a", "na", "none", "null", "desconocido", "undetermined"
        )
        private val MARKS = Regex("\\p{M}+")

        private fun norm(s: String): String =
            Normalizer.normalize(s.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(MARKS, "")

        /**
         * Normaliza lo que diga la fuente ("es", "es-ES", "spa", "Spanish", "Español"…).
         * Lista vacía = idioma NO indicado (nunca se inventa). Un idioma reconocido pero fuera de la lista da [OTHER].
         */
        fun parseAll(raw: String?): List<Lang> {
            if (raw == null) return emptyList()
            val out = LinkedHashSet<Lang>()
            for (piece in raw.split(';', ',', '/', '|')) {
                val p = norm(piece)
                val base = p.substringBefore('-').substringBefore('_').trim()
                if (p in UNKNOWN || base in UNKNOWN) continue
                val hit = Lang.entries.firstOrNull { l -> p in l.names || base in l.names }
                out.add(hit ?: OTHER)
            }
            return out.toList()
        }
    }
}
