package com.jullbook.app.discover

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.IOException

/** Guarda archivos en la carpeta SAF que ya usa la biblioteca (la misma que escanea JullBook). */
object Saf {
    private fun rootDoc(tree: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))

    fun hasWrite(ctx: Context, tree: Uri): Boolean =
        ctx.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }

    /** ¿Ya hay un archivo con ese nombre en la raíz de la carpeta? */
    fun exists(ctx: Context, tree: Uri, name: String): Boolean {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        ctx.contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (name.equals(c.getString(0), ignoreCase = true)) return true
            }
        }
        return false
    }

    /** Copia [src] a la carpeta como [name]. Si algo falla a medias, no deja un archivo incompleto. */
    fun save(ctx: Context, tree: Uri, name: String, mime: String, src: File) {
        val r = ctx.contentResolver
        val doc = DocumentsContract.createDocument(r, rootDoc(tree), mime, name)
            ?: throw IOException("No se pudo crear el archivo en la carpeta")
        try {
            val out = r.openOutputStream(doc, "w") ?: throw IOException("No se pudo escribir en la carpeta")
            out.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
        } catch (e: Throwable) {
            runCatching { DocumentsContract.deleteDocument(r, doc) }
            throw e
        }
    }
}
