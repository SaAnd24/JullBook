package com.jullbook.app.data

import kotlin.random.Random

enum class SurpriseReason(val label: String, val ctx: JuliCtx, val weight: Int) {
    UNREAD("Algo que aún no has leído", JuliCtx.SURPRISE_UNREAD, 3),
    ABANDONED("Una lectura que dejaste a medias", JuliCtx.SURPRISE_ABANDONED, 3),
    SERIES("Retomar una colección", JuliCtx.SURPRISE_SERIES, 3),
    LONG("Hace mucho que no lo abres", JuliCtx.SURPRISE_LONG, 2),
    CURRENT("Sigue con tu lectura actual", JuliCtx.SURPRISE_CURRENT, 2),

    // JullBook 1.1
    SHORT("Algo corto", JuliCtx.SURPRISE_SHORT, 2),
    FORGOTTEN("Una colección olvidada", JuliCtx.SURPRISE_FORGOTTEN, 2),
    ALMOST("Casi terminado", JuliCtx.SURPRISE_ALMOST, 2),
    RANDOM("Selección aleatoria", JuliCtx.SURPRISE_RANDOM, 1)
}

class Surprise(
    val book: Book,
    val progress: Progress?,
    val series: SeriesItem?,
    val reason: SurpriseReason,
    val comment: String,
    /** Detalle breve del motivo ("Hace 20 días", "Te falta un 8%"…). Vacío si no aporta nada. */
    val why: String = "",
    val nonce: Long = System.nanoTime()
)

/** Sorpréndeme: elige algo de la biblioteca LOCAL. Nunca usa internet ni recomendaciones externas. */
object SurpriseEngine {
    private const val DAY = 86_400_000L

    /** Cuánto tarda en volver a sugerirse algo marcado con "No me interesa ahora". */
    const val COOLDOWN_MS = 14 * DAY

    private class Cand(val book: Book, val prog: Progress?, val series: SeriesItem?, val reason: SurpriseReason)

    fun displayTitle(b: Book, s: SeriesItem?): String =
        if (s != null && b.alias == null && !s.isUnnamed) "${s.name} ${volLabel(b)}" else b.title

    private fun volName(b: Book, s: SeriesItem): String =
        b.alias ?: b.number?.let { (if (s.isBooks) "libro " else "tomo ") + it } ?: b.title

    /** Lectura corta según lo que se sabe del archivo: pocas páginas (PDF/cómic) o pocos capítulos (EPUB). */
    private fun isShort(b: Book): Boolean = when {
        b.pageCount <= 0 -> false
        b.format == Format.COMIC -> b.pageCount <= 60
        b.format == Format.PDF -> b.pageCount <= 100
        else -> b.pageCount <= 10
    }

    fun pick(lib: Library, prefs: Prefs, exclude: Set<Long>, now: Long, rnd: Random = Random.Default): Surprise? {
        val cooling = prefs.cooldowns(now).keys
        val by = HashMap<SurpriseReason, MutableList<Cand>>()
        fun add(c: Cand) {
            if (c.book.id in cooling) return
            by.getOrPut(c.reason) { ArrayList() }.add(c)
        }

        for (item in lib.items) {
            when (item) {
                is SingleItem -> {
                    val p = item.progress
                    val b = item.book
                    if (p == null) {
                        if (isShort(b)) add(Cand(b, null, null, SurpriseReason.SHORT))
                        add(Cand(b, null, null, SurpriseReason.UNREAD))
                    } else if (p.status == ST_READING && p.percent >= 0.85f && p.percent < 0.995f) {
                        add(Cand(b, p, null, SurpriseReason.ALMOST))
                    } else if (p.status == ST_READING && p.percent in 0.02f..0.97f) {
                        if (now - p.lastRead > 14 * DAY) add(Cand(b, p, null, SurpriseReason.ABANDONED))
                        else add(Cand(b, p, null, SurpriseReason.CURRENT))
                    } else if (p.status == ST_FINISHED && now - p.lastRead > 90 * DAY) {
                        add(Cand(b, p, null, SurpriseReason.LONG))
                    }
                }
                is SeriesItem -> {
                    val t = item.target()
                    when (LibraryView.statusOf(item)) {
                        StatusFilter.UNSTARTED -> {
                            val first = item.volumes.first()
                            add(Cand(first.book, null, item, if (item.isUnnamed) SurpriseReason.UNREAD else SurpriseReason.FORGOTTEN))
                        }
                        StatusFilter.READING -> {
                            if (t == null) continue
                            val tp = t.progress
                            if (tp == null) add(Cand(t.book, null, item, SurpriseReason.SERIES))
                            else if (tp.status == ST_READING && tp.percent >= 0.85f && tp.percent < 0.995f) add(Cand(t.book, tp, item, SurpriseReason.ALMOST))
                            else if (now - tp.lastRead > 14 * DAY) add(Cand(t.book, tp, item, SurpriseReason.ABANDONED))
                            else add(Cand(t.book, tp, item, SurpriseReason.CURRENT))
                        }
                        StatusFilter.FINISHED -> {
                            val first = item.volumes.first()
                            if (item.lastRead > 0 && now - item.lastRead > 90 * DAY) {
                                add(Cand(first.book, first.progress, item, SurpriseReason.LONG))
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
        // Selección aleatoria: cualquier elemento visible de la biblioteca (que no esté en pausa por "No me interesa").
        val anyItems = lib.items.filter { LibraryView.visible(it) }
        if (anyItems.isNotEmpty()) {
            val it = anyItems[rnd.nextInt(anyItems.size)]
            when (it) {
                is SingleItem -> add(Cand(it.book, it.progress, null, SurpriseReason.RANDOM))
                is SeriesItem -> {
                    val t = it.target() ?: it.volumes.first()
                    add(Cand(t.book, t.progress, it, SurpriseReason.RANDOM))
                }
            }
        }
        if (by.isEmpty()) return null

        // Evita repetir sugerencias recientes (de esta sesión y de las anteriores), salvo que no quede otra cosa.
        val avoid = exclude + prefs.surpriseRecent()
        val filtered = HashMap<SurpriseReason, List<Cand>>()
        for ((r, l) in by) {
            val f = l.filter { it.book.id !in avoid }
            if (f.isNotEmpty()) filtered[r] = f
        }
        val pool: Map<SurpriseReason, List<Cand>> = if (filtered.isNotEmpty()) filtered else by

        val total = pool.keys.sumOf { it.weight }
        var roll = rnd.nextInt(total)
        var reason = pool.keys.first()
        for (r in SurpriseReason.entries) {
            if (!pool.containsKey(r)) continue
            if (roll < r.weight) { reason = r; break }
            roll -= r.weight
        }
        val list = pool.getValue(reason)
        val c = list[rnd.nextInt(list.size)]
        val last = c.prog?.lastRead ?: c.series?.lastRead ?: 0L
        val days = if (last > 0) ((now - last) / DAY).toInt().coerceAtLeast(1) else 0
        val title = if (reason == SurpriseReason.SERIES && c.series != null) volName(c.book, c.series)
        else displayTitle(c.book, c.series)
        val left = c.prog?.let { ((1f - it.percent) * 100).toInt().coerceIn(1, 99) } ?: 0
        val unopenedVols = c.series?.volumes?.size ?: 0
        val word = if (c.series?.isBooks == true) "libros" else "tomos"
        val params = JuliParams(
            title = title,
            coll = c.series?.name,
            n = if (reason == SurpriseReason.ALMOST) left else 0,
            days = days,
            vols = unopenedVols,
            volWord = word,
            name = prefs.userName
        )
        val why = when (reason) {
            SurpriseReason.UNREAD -> "Sin abrir todavía"
            SurpriseReason.ABANDONED -> if (days > 0) "La dejaste hace ${if (days == 1) "1 día" else "$days días"}" else ""
            SurpriseReason.SERIES -> c.series?.let { "${pctText(it.percent)} de la colección" } ?: ""
            SurpriseReason.LONG -> if (days > 0) "Sin abrir desde hace ${if (days == 1) "1 día" else "$days días"}" else ""
            SurpriseReason.CURRENT -> c.prog?.let { "Vas por el ${pctText(it.percent)}" } ?: ""
            SurpriseReason.SHORT -> shortWhy(c.book)
            SurpriseReason.FORGOTTEN -> "$unopenedVols $word sin abrir"
            SurpriseReason.ALMOST -> "Te falta un $left%"
            SurpriseReason.RANDOM -> "Elegido al azar"
        }
        val text = Juli.pick(reason.ctx, params, prefs, rnd) ?: return null
        return Surprise(c.book, c.prog, c.series, reason, text, why)
    }

    private fun shortWhy(b: Book): String = when (b.format) {
        Format.EPUB -> "${b.pageCount} capítulos"
        else -> "${b.pageCount} páginas"
    }
}
