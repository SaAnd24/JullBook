package com.jullbook.app.data

/** Rango [s, e) dentro de un texto. */
class Sent(val s: Int, val e: Int)

/** Divide el texto en frases (para narrar y para resaltar) y lo prepara para que la voz suene natural. */
object Sentences {
    private val ABBR = setOf(
        "sr", "sra", "srta", "dr", "dra", "ud", "uds", "vd", "vds", "mr", "mrs", "ms", "st", "etc", "pág", "págs", "pag",
        "núm", "num", "vol", "cap", "av", "avda", "aprox", "art", "ej", "tel", "dpto", "gral", "cía", "lic", "ing", "prof",
        "fig", "vs", "jr", "no", "pp", "ed", "eds", "cf", "mt", "lt", "cnel", "gob", "pres", "sto", "sta", "mons", "fr"
    )
    private const val CLOSERS = "\"'”’»)]”"
    private const val MAX_LEN = 320

    fun split(t: String): List<Sent> {
        val raw = ArrayList<Sent>()
        val n = t.length
        var start = 0
        var i = 0

        fun push(a: Int, b: Int) {
            var s = a
            var e = b
            while (s < e && t[s].isWhitespace()) s++
            while (e > s && t[e - 1].isWhitespace()) e--
            if (e > s) raw.add(Sent(s, e))
        }

        while (i < n) {
            val c = t[i]
            if (c == '\n') {
                push(start, i)
                start = i + 1
                i++
                continue
            }
            if (c == '.' || c == '!' || c == '?' || c == '…') {
                var j = i + 1
                while (j < n && (t[j] == '.' || t[j] == '!' || t[j] == '?' || t[j] == '…')) j++
                while (j < n && CLOSERS.indexOf(t[j]) >= 0) j++
                if (j >= n || t[j].isWhitespace()) {
                    var k = j
                    while (k < n && t[k].isWhitespace()) k++
                    val nextLower = k < n && t[k].isLetter() && t[k].isLowerCase()
                    val abbr = c == '.' && j == i + 1 && isAbbreviation(t, i)
                    if (!abbr && !(nextLower && c != '…')) {
                        push(start, j)
                        start = j
                        i = j
                        continue
                    }
                }
                i = j
                continue
            }
            i++
        }
        push(start, n)

        // Las frases muy largas se parten en comas, punto y coma o dos puntos.
        val out = ArrayList<Sent>()
        for (s in raw) {
            var a = s.s
            while (s.e - a > MAX_LEN) {
                var cut = -1
                var p = a + MAX_LEN
                while (p > a + MAX_LEN / 2) {
                    val ch = t[p]
                    if (ch == ',' || ch == ';' || ch == ':' || ch == '—') { cut = p + 1; break }
                    p--
                }
                if (cut < 0) {
                    p = a + MAX_LEN
                    while (p > a + MAX_LEN / 2) {
                        if (t[p].isWhitespace()) { cut = p; break }
                        p--
                    }
                }
                if (cut < 0) cut = a + MAX_LEN
                out.add(Sent(a, cut))
                a = cut
                while (a < s.e && t[a].isWhitespace()) a++
            }
            if (a < s.e) out.add(Sent(a, s.e))
        }
        return out
    }

    private fun isAbbreviation(t: String, dot: Int): Boolean {
        var b = dot
        while (b > 0 && (t[b - 1].isLetter() || t[b - 1] == '.')) b--
        val word = t.substring(b, dot).lowercase()
        if (word.isEmpty()) return false
        if (word.length == 1 && word[0].isLetter()) return true // inicial: "J. K. Rowling"
        if (word.contains('.')) return true                       // "EE.UU", "p.ej"
        return word in ABBR
    }

    /** La frase que contiene la posición [pos]. */
    fun at(t: String, pos: Int): Sent? {
        val all = split(t)
        if (all.isEmpty()) return null
        return all.firstOrNull { pos >= it.s && pos < it.e } ?: all.lastOrNull { it.s <= pos } ?: all.first()
    }

    /** Texto que se le pasa a la voz: sin símbolos que se leerían mal y con pausas donde un lector humano las haría. */
    fun speakable(raw: String): String {
        var s = raw
            .replace("\u00AD", "")
            .replace('\u00A0', ' ')
            .replace('\uFFFC', ' ')
            .replace(Regex("\\[\\d{1,3}]"), "")
            .replace(Regex("[*#_~^|]+"), " ")
        s = s.trim()
        // Diálogos con raya: "—Hola —dijo ella." se lee "Hola, dijo ella."
        s = s.removePrefix("—").removePrefix("–").trim()
        s = s.replace(Regex("\\s[—–]\\s?"), ", ").replace(Regex("[—–]"), ", ")
        s = s.replace(Regex("\\s{2,}"), " ").replace(Regex(",\\s*,"), ",").trim()
        return if (s.any { it.isLetterOrDigit() }) s else ""
    }
}
