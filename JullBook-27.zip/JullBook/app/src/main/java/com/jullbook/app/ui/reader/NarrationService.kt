package com.jullbook.app.ui.reader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Servicio en primer plano: mantiene viva la narración con la pantalla apagada y muestra los controles. */
class NarrationService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> NarrationHub.narrator?.toggle()
            ACTION_STOP -> {
                NarrationHub.narrator?.stop()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        val n = NarrationHub.narrator
        if (n == null && intent?.action != null) {
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(this, ID, build(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    companion object {
        private const val ID = 4417
        private const val CHANNEL = "narration"
        const val ACTION_TOGGLE = "com.jullbook.app.NARR_TOGGLE"
        const val ACTION_STOP = "com.jullbook.app.NARR_STOP"

        @Volatile
        private var running = false

        fun refresh(ctx: Context) {
            if (!running) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(ID, build(ctx))
        }

        private fun build(ctx: Context): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Narración", NotificationManager.IMPORTANCE_LOW))
            val n = NarrationHub.narrator
            val playing = n?.state == NarrState.PLAYING
            fun action(a: String, code: Int) = PendingIntent.getService(
                ctx, code, Intent(ctx, NarrationService::class.java).setAction(a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let {
                PendingIntent.getActivity(ctx, 0, it, PendingIntent.FLAG_IMMUTABLE)
            }
            return NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(n?.bookTitle ?: "JullBook")
                .setContentText(if (playing) "Narrando…" else "Narración en pausa")
                .setContentIntent(open)
                .setOngoing(true)
                .setSilent(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    if (playing) "Pausa" else "Continuar",
                    action(ACTION_TOGGLE, 1)
                )
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", action(ACTION_STOP, 2))
                .build()
        }
    }
}
