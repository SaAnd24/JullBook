package com.jullbook.app.data

import java.util.Calendar

class ReadingStats(
    val totalMs: Long,
    val todayMs: Long,
    val weekMs: Long,
    /** Tiempo leído de los últimos 7 días (el último es hoy). */
    val days: List<Long>,
    val streak: Int,
    val sessions: Int,
    val finished: Int,
    val reading: Int,
    val unstarted: Int,
    /** Lecturas completadas en total (cada relectura terminada cuenta). */
    val completions: Int = 0,
    /** Racha máxima calculada con las sesiones guardadas. */
    val bestStreak: Int = 0,
    /** Día de la semana (0 = domingo) y mes (0 = enero) con más tiempo de lectura; -1 si no hay datos. */
    val topWeekday: Int = -1,
    val topMonth: Int = -1,
    /** Tiempo leído en los últimos 30 días, separado por libros y cómics. */
    val recentBookMs: Long = 0L,
    val recentComicMs: Long = 0L
)

class HistoryEntry(val session: SessionRec, val book: Book?, val series: String?)

class MemoryData(
    val stats: ReadingStats,
    /** Libros con memoria de lectura, el más reciente primero. */
    val books: List<Pair<Book, Progress>>,
    val history: List<HistoryEntry>
) {
    companion object {
        val EMPTY = MemoryData(ReadingStats(0, 0, 0, List(7) { 0L }, 0, 0, 0, 0, 0), emptyList(), emptyList())
    }
}

object Memory {
    private const val DAY = 86_400_000L

    private fun startOfDay(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun build(db: Db, lib: Library, now: Long = System.currentTimeMillis()): MemoryData {
        val prog = db.allProgress().filterKeys { lib.books.containsKey(it) }
        val sessions = db.allSessions()
        val today = startOfDay(now)
        val days = LongArray(7)
        val withReading = HashSet<Long>()
        val byWeekday = LongArray(7)
        val byMonth = LongArray(12)
        var recentBook = 0L
        var recentComic = 0L
        val cal = Calendar.getInstance()
        for (s in sessions) {
            val d = startOfDay(s.start)
            val idx = 6 - ((today - d) / DAY).toInt()
            if (idx in 0..6) days[idx] += s.duration
            withReading.add(d)
            cal.timeInMillis = s.start
            byWeekday[cal.get(Calendar.DAY_OF_WEEK) - 1] += s.duration
            byMonth[cal.get(Calendar.MONTH)] += s.duration
            if (now - s.start <= 30 * DAY) {
                val f = lib.books[s.bookId]?.format
                if (f == Format.COMIC) recentComic += s.duration else if (f != null) recentBook += s.duration
            }
        }
        // Mejor racha: la serie de días consecutivos más larga entre las sesiones guardadas.
        var best = 0
        var run = 0
        var prev = -1L
        for (day in withReading.sorted()) {
            run = if (prev >= 0 && Math.abs(day - prev - DAY) < 4_000_000L) run + 1 else 1
            if (run > best) best = run
            prev = day
        }
        fun top(a: LongArray): Int {
            var bi = -1
            var bv = 0L
            for (i in a.indices) if (a[i] > bv) { bv = a[i]; bi = i }
            return bi
        }
        // Racha: días consecutivos con lectura (hoy cuenta si ya hay lectura; si no, se parte de ayer).
        var streak = 0
        var d = if (today in withReading) today else today - DAY
        while (d in withReading) {
            streak++
            d -= DAY
        }
        val stats = ReadingStats(
            totalMs = prog.values.sumOf { it.readMs },
            todayMs = days[6],
            weekMs = days.sum(),
            days = days.toList(),
            streak = streak,
            sessions = sessions.size,
            // Terminados: títulos leídos completos al menos una vez (se conservan aunque se reinicie la lectura).
            finished = prog.values.count { it.status == ST_FINISHED || (lib.books[it.bookId]?.reads ?: 0) > 0 },
            reading = prog.values.count { it.status == ST_READING },
            unstarted = (lib.books.size - prog.values.count { it.status != ST_UNREAD }).coerceAtLeast(0),
            completions = lib.books.values.sumOf { it.reads },
            bestStreak = best,
            topWeekday = top(byWeekday),
            topMonth = top(byMonth),
            recentBookMs = recentBook,
            recentComicMs = recentComic
        )
        val books = prog.values
            .sortedByDescending { it.lastRead }
            .mapNotNull { p -> lib.books[p.bookId]?.let { it to p } }
            .take(40)
        val history = sessions.take(40).map { s ->
            HistoryEntry(s, lib.books[s.bookId], lib.bookSeries[s.bookId]?.name)
        }
        return MemoryData(stats, books, history)
    }
}
