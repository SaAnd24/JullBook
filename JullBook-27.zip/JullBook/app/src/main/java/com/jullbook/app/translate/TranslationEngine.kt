package com.jullbook.app.translate

import android.net.Uri
import com.jullbook.app.discover.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/** Error de traducción con mensaje para el usuario. [fatal] = reintentar no sirve (límite diario, configuración…). */
class TrError(message: String, val fatal: Boolean = false) : Exception(message)

/**
 * Un motor de traducción. Para añadir otro (p. ej. uno sin conexión) basta con implementar esta interfaz
 * y registrarlo en [TrEngines]; caché, lector y narración no cambian.
 */
interface TranslationEngine {
    val id: String
    val label: String

    /** Súbela si cambias el comportamiento del motor: invalida solo SUS traducciones en caché. */
    val version: Int

    /** Identifica el motor en la caché (dos servidores distintos no comparten traducciones). */
    val cacheKey: String get() = "$id-v$version"

    val maxBatchItems: Int
    val maxBatchChars: Int

    /** A dónde viaja el texto (se muestra al usuario). */
    val destination: String

    /** Prepara el motor para este par de idiomas (p. ej. descarga el modelo la primera vez). Por defecto no hace nada. */
    suspend fun prepare(from: String, to: String) {}

    /** Traduce [texts] (mismo orden). [from] puede ser "auto". */
    suspend fun translate(texts: List<String>, from: String, to: String): List<String>
}

object TrEngines {
    const val MLKIT = "mlkit"
    const val MYMEMORY = "mymemory"
    const val LIBRE = "libre"
    val all: List<Pair<String, String>> = listOf(
        MLKIT to "Google ML Kit (en el teléfono, sin conexión)",
        MYMEMORY to "MyMemory (gratis, con límite diario)",
        LIBRE to "LibreTranslate (tu servidor)"
    )

    fun label(id: String): String = all.firstOrNull { it.first == id }?.second ?: id

    fun create(id: String, libreUrl: String, libreKey: String): TranslationEngine =
        when (id) {
            LIBRE -> LibreTranslateEngine(libreUrl, libreKey)
            MYMEMORY -> MyMemoryEngine()
            else -> MlKitEngine()
        }
}

/** MyMemory: servicio público sin clave, con límite diario de caracteres. */
class MyMemoryEngine : TranslationEngine {
    override val id = TrEngines.MYMEMORY
    override val label = "MyMemory"
    override val version = 1
    override val maxBatchItems = 4
    override val maxBatchChars = 1800
    override val destination = "api.mymemory.translated.net"

    override suspend fun translate(texts: List<String>, from: String, to: String): List<String> =
        withContext(Dispatchers.IO) {
            val out = ArrayList<String>(texts.size)
            for (t in texts) {
                coroutineContext.ensureActive()
                out.add(splitBytes(t, 450).joinToString(" ") { call(it, from, to) })
            }
            out
        }

    private fun code(c: String): String = when (c) {
        "auto" -> "Autodetect"
        "zh" -> "zh-CN"
        else -> c
    }

    private fun call(q: String, from: String, to: String): String {
        val url = "https://api.mymemory.translated.net/get?q=" + Uri.encode(q) +
            "&langpair=" + Uri.encode(code(from) + "|" + code(to))
        val body = try {
            val c = Http.open(url, null, "application/json", 20000)
            try {
                String(c.inputStream.use { it.readBytes() }, Charsets.UTF_8)
            } finally {
                c.disconnect()
            }
        } catch (e: Http.HttpFail) {
            if (e.code == 429) throw TrError("MyMemory: límite diario alcanzado. Inténtalo mañana o usa otro motor.", true)
            throw TrError("MyMemory respondió con el error ${e.code}.")
        } catch (e: IOException) {
            throw TrError("No hay conexión con el motor de traducción.")
        }
        try {
            val o = JSONObject(body)
            val status = o.opt("responseStatus")?.toString()?.toIntOrNull() ?: 200
            val text = o.optJSONObject("responseData")?.optString("translatedText", "").orEmpty()
            if (status == 429 || text.startsWith("MYMEMORY WARNING", ignoreCase = true) || o.optBoolean("quotaFinished", false)) {
                throw TrError("MyMemory: límite diario alcanzado. Inténtalo mañana o usa otro motor.", true)
            }
            if (status != 200) throw TrError("MyMemory no pudo traducir (${o.optString("responseDetails", status.toString())}).")
            return text.replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
        } catch (e: org.json.JSONException) {
            throw TrError("Respuesta inesperada de MyMemory.")
        }
    }

    /** Parte [s] en trozos de como máximo [max] bytes UTF-8, cortando en espacios cuando se puede. */
    private fun splitBytes(s: String, max: Int): List<String> {
        if (s.toByteArray(Charsets.UTF_8).size <= max) return listOf(s)
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (w in s.split(' ')) {
            val add = if (cur.isEmpty()) w else " $w"
            if (cur.isNotEmpty() && (cur.toString() + add).toByteArray(Charsets.UTF_8).size > max) {
                out.add(cur.toString())
                cur.setLength(0)
                cur.append(w)
            } else {
                cur.append(add)
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}

/** LibreTranslate (o compatible): servidor propio o público con clave. Admite lotes de frases. */
class LibreTranslateEngine(url: String, private val apiKey: String) : TranslationEngine {
    private val base = url.trim().trimEnd('/')
    private val host: String = runCatching { URL(base).host }.getOrDefault("")
    override val id = TrEngines.LIBRE
    override val label = "LibreTranslate"
    override val version = 1
    override val cacheKey: String get() = "$id-v$version-" + host.replace(Regex("[^A-Za-z0-9.-]"), "_")
    override val maxBatchItems = 25
    override val maxBatchChars = 4000
    override val destination: String get() = host.ifBlank { "(servidor sin configurar)" }

    override suspend fun translate(texts: List<String>, from: String, to: String): List<String> =
        withContext(Dispatchers.IO) {
            if (!base.startsWith("https://")) throw TrError("Configura la dirección del servidor (debe empezar por https://).", true)
            val body = JSONObject()
                .put("q", JSONArray(texts))
                .put("source", from)
                .put("target", to)
                .put("format", "text")
            if (apiKey.isNotBlank()) body.put("api_key", apiKey)
            val resp = post("$base/translate", body.toString())
            try {
                val o = JSONObject(resp)
                val t = o.opt("translatedText")
                val list = when (t) {
                    is JSONArray -> (0 until t.length()).map { t.getString(it) }
                    is String -> listOf(t)
                    else -> throw TrError(o.optString("error", "Respuesta inesperada del servidor."), true)
                }
                if (list.size != texts.size) throw TrError("El servidor devolvió una respuesta incompleta.")
                list
            } catch (e: org.json.JSONException) {
                throw TrError("Respuesta inesperada del servidor de traducción.")
            }
        }

    private fun post(url: String, json: String): String {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 10000
                c.readTimeout = 30000
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "application/json")
                c.setRequestProperty("User-Agent", Http.UA)
                c.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val ok = code in 200..299
                val stream = if (ok) c.inputStream else c.errorStream
                val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) }.orEmpty()
                if (ok) return text
                val msg = runCatching { JSONObject(text).optString("error") }.getOrDefault("").ifBlank { "error $code" }
                throw TrError("El servidor de traducción respondió: $msg", code in 400..499)
            } finally {
                c.disconnect()
            }
        } catch (e: IOException) {
            throw TrError("No hay conexión con el servidor de traducción.")
        }
    }
}
