package com.jullbook.app.data

/** Foto de todo lo que cuenta para los logros. Se calcula a partir de datos reales y locales. */
class AchSnapshot(
    val booksFinished: Int,
    val comicsFinished: Int,
    val totalBooks: Int,
    val touched: Int,
    val unstarted: Int,
    val collectionsDone: Int,
    val sagasDone: Int,
    val collectionRereads: Int,
    val maxReads: Int,
    val rereadTotal: Int,
    val formatsFinished: Int,
    val streak: Int,
    val bestStreak: Int,
    val readMs: Long,
    val sessions: Int,
    val surprises: Int,
    val themesTried: Int,
    val customTheme: Int,
    val nightOpens: Int,
    val resumedOld: Int,
    val maxFinishDay: Int,
    val longestSessionMs: Long,
    val minimizes: Int,
    val nameSet: Int,
    val eggs: Int,
    /** Veces que se volvió tras 180 días o más sin abrir la app. */
    val returned180: Int = 0
) {
    val exploredPct: Int get() = if (totalBooks <= 0) 0 else (touched * 100 / totalBooks)
    val readHours: Int get() = (readMs / 3_600_000L).toInt()
}

class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val desc: String,
    val goal: Int,
    val secret: Boolean = false,
    val hint: String = "",
    /** Extremadamente raro: se gana con comportamientos poco comunes y celebra con confeti. */
    val rare: Boolean = false,
    val value: (AchSnapshot) -> Int
)

object Achievements {
    val ALL: List<Achievement> = listOf(
        // Primeras lecturas
        Achievement("first_open", "📖", "Primera página", "Empieza tu primera lectura.", 1) { it.touched },
        Achievement("first_book", "🔖", "Punto final", "Termina tu primer libro.", 1) { it.booksFinished },
        Achievement("first_comic", "💥", "Viñeta final", "Termina tu primer cómic o tomo.", 1) { it.comicsFinished },
        Achievement("all_formats", "🎒", "Todoterreno", "Termina un EPUB, un PDF y un cómic.", 3, true, "Que ningún formato se te resista.") { it.formatsFinished },

        // Terminados
        Achievement("books_5", "📚", "Lector constante", "Termina 5 libros.", 5) { it.booksFinished },
        Achievement("books_25", "🏛️", "Rata de biblioteca", "Termina 25 libros.", 25) { it.booksFinished },
        Achievement("books_100", "👑", "Bibliotecario honorario", "Termina 100 libros.", 100) { it.booksFinished },
        Achievement("comics_10", "🦸", "Aficionado a las viñetas", "Termina 10 cómics o tomos.", 10) { it.comicsFinished },
        Achievement("comics_50", "🗂️", "Tomo tras tomo", "Termina 50 cómics o tomos.", 50) { it.comicsFinished },
        Achievement("comics_150", "🌌", "Universo propio", "Termina 150 cómics o tomos.", 150) { it.comicsFinished },

        // Colecciones y sagas
        Achievement("coll_1", "🧩", "Colección cerrada", "Completa una colección de 2 o más elementos.", 1) { it.collectionsDone },
        Achievement("coll_5", "🔁", "Cerrando ciclos", "Completa 5 colecciones.", 5) { it.collectionsDone },
        Achievement("saga_1", "🐉", "Saga completa", "Completa una saga de 5 o más elementos.", 1) { it.sagasDone },
        Achievement("saga_3", "⚔️", "Maratón de sagas", "Completa 3 sagas.", 3) { it.sagasDone },

        // Rachas
        Achievement("streak_3", "🔥", "Tres en raya", "Lee 3 días seguidos.", 3) { it.bestStreak },
        Achievement("streak_7", "📆", "Semana redonda", "Lee 7 días seguidos.", 7) { it.bestStreak },
        Achievement("streak_30", "🌙", "Hábito formado", "Lee 30 días seguidos.", 30) { it.bestStreak },
        Achievement("streak_100", "☄️", "Centenario", "Lee 100 días seguidos.", 100) { it.bestStreak },

        // Relecturas
        Achievement("reread_1", "↻", "Otra vez, por favor", "Termina el mismo título dos veces.", 2) { it.maxReads },
        Achievement("reread_5", "🌀", "Obsesión sana", "Termina el mismo título 5 veces.", 5) { it.maxReads },
        Achievement("reread_coll", "🔂", "Vuelta al principio", "Lee una colección completa dos veces.", 1) { it.collectionRereads },
        Achievement("reread_10", "🕰️", "Nostálgico profesional", "Suma 10 relecturas en total.", 10) { it.rereadTotal },

        // Tiempo
        Achievement("time_1", "⏱️", "Entrando en calor", "Acumula 1 hora de lectura.", 1) { it.readHours },
        Achievement("time_10", "☕", "Diez horas de páginas", "Acumula 10 horas de lectura.", 10) { it.readHours },
        Achievement("time_50", "🔭", "Medio centenar", "Acumula 50 horas de lectura.", 50) { it.readHours },
        Achievement("time_200", "⏳", "Vida entre líneas", "Acumula 200 horas de lectura.", 200) { it.readHours },
        Achievement("sessions_50", "🪑", "Siempre a mano", "Abre 50 sesiones de lectura.", 50) { it.sessions },

        // Exploración
        Achievement("explore_25", "🧭", "Explorador", "Abre al menos el 25% de tu biblioteca.", 25) { it.exploredPct },
        Achievement("explore_60", "🗺️", "Cartógrafo", "Abre al menos el 60% de tu biblioteca.", 60) { it.exploredPct },
        Achievement("explore_100", "💡", "Sin rincones oscuros", "Abre todo lo que hay en tu biblioteca.", 100) { if (it.totalBooks >= 5) it.exploredPct else 0 },
        Achievement("surprise_1", "🎲", "Dejándome llevar", "Usa Sorpréndeme por primera vez.", 1) { it.surprises },
        Achievement("surprise_15", "🎰", "Fan de las sorpresas", "Usa Sorpréndeme 15 veces.", 15) { it.surprises },
        Achievement("big_100", "🏙️", "Biblioteca seria", "Ten 100 elementos en tu biblioteca.", 100) { it.totalBooks },
        Achievement("big_500", "🏰", "Casi Alejandría", "Ten 500 elementos en tu biblioteca.", 500) { it.totalBooks },
        Achievement("decorator", "🎨", "Decorador de interiores", "Prueba 4 temas distintos.", 4) { it.themesTried },
        Achievement("own_theme", "🖌️", "Hecho a mi medida", "Crea tu propio tema.", 1) { it.customTheme },

        // Secretos
        Achievement("night_owl", "🦉", "Búho", "Abre una lectura de madrugada tres veces.", 3, true, "Hay quien lee cuando el resto duerme.") { it.nightOpens },
        Achievement("second_chance", "🌱", "Segundas oportunidades", "Retoma algo que llevaba más de 60 días abandonado.", 1, true, "Algunas historias saben esperar.") { it.resumedOld },
        Achievement("double_day", "✌️", "Doble sesión", "Termina dos lecturas en un mismo día.", 2, true, "Un día, dos finales.") { it.maxFinishDay },
        Achievement("marathon", "🏃", "Maratón", "Lee 3 horas seguidas en una sola sesión.", 3, true, "Sin levantarte, sin mirar el reloj.") { (it.longestSessionMs / 3_600_000L).toInt() },
        Achievement("pile_shame", "🗻", "Pila de la vergüenza", "Ten 100 cosas sin empezar.", 100, true, "Comprar es más fácil que leer.") { it.unstarted },
        Achievement("multitask", "🎧", "Multitarea", "Minimiza tu lectura 10 veces.", 10, true, "Leer y navegar a la vez.") { it.minimizes },
        Achievement("juli_knows", "💌", "Juli te conoce", "Pon tu nombre y descubre un secreto de Juli.", 2, true, "A Juli le gusta saber con quién habla.") { it.nameSet + it.eggs.coerceAtMost(1) },

        // Rarísimos (JullBook 1.1): pocos y a propósito difíciles.
        Achievement("rare_return", "🕯️", "Siempre vuelves", "Regresa tras 6 meses sin abrir JullBook.", 1, true, "Algunas bibliotecas esperan medio año.", rare = true) { it.returned180 },
        Achievement("rare_session6", "🌠", "Sin mirar el reloj", "Lee 6 horas seguidas en una sola sesión.", 6, true, "Más allá de un maratón.", rare = true) { (it.longestSessionMs / 3_600_000L).toInt() },
        Achievement("rare_five_day", "🎆", "Día de finales", "Termina cinco lecturas en un mismo día.", 5, true, "Un día para cerrar muchas puertas.", rare = true) { it.maxFinishDay },
        Achievement("rare_reread10", "📿", "Libro de cabecera", "Termina el mismo título 10 veces.", 10, true, "Hay historias que no se agotan.", rare = true) { it.maxReads }
    )

    fun byId(id: String): Achievement? = ALL.firstOrNull { it.id == id }

    fun snapshot(lib: Library, mem: MemoryData, prefs: Prefs): AchSnapshot {
        var booksDone = 0
        var comicsDone = 0
        val formats = HashSet<Format>()
        var maxReads = 0
        var rereadTotal = 0
        for (b in lib.books.values) {
            if (b.reads > 0) {
                if (b.format == Format.COMIC) comicsDone++ else booksDone++
                formats.add(b.format)
            }
            if (b.reads > maxReads) maxReads = b.reads
            if (b.reads > 1) rereadTotal += b.reads - 1
        }
        var touched = 0
        fun seen(v: Vol): Boolean = v.progress != null || v.book.reads > 0
        var collDone = 0
        var sagaDone = 0
        var collRereads = 0
        for (item in lib.items) {
            when (item) {
                is SingleItem -> if (item.progress != null || item.book.reads > 0) touched++
                is SeriesItem -> {
                    touched += item.volumes.count { seen(it) }
                    val n = item.volumes.size
                    if (!item.isUnnamed && n >= 2 && item.volumes.all { it.book.reads > 0 || it.progress?.status == ST_FINISHED }) {
                        collDone++
                        if (n >= 5) sagaDone++
                    }
                    if (!item.isUnnamed && n >= 2 && item.reads >= 2) collRereads++
                }
            }
        }
        val total = lib.books.size
        prefs.setCounterMax("best_streak", mem.stats.streak.toLong())
        return AchSnapshot(
            booksFinished = booksDone,
            comicsFinished = comicsDone,
            totalBooks = total,
            touched = touched,
            unstarted = (total - touched).coerceAtLeast(0),
            collectionsDone = collDone,
            sagasDone = sagaDone,
            collectionRereads = collRereads,
            maxReads = maxReads,
            rereadTotal = rereadTotal,
            formatsFinished = formats.size,
            streak = mem.stats.streak,
            bestStreak = prefs.counter("best_streak").toInt(),
            readMs = mem.stats.totalMs,
            sessions = mem.stats.sessions,
            surprises = prefs.counter("surprises").toInt(),
            themesTried = prefs.themesTried().size,
            customTheme = if (prefs.counter("custom_made") > 0) 1 else 0,
            nightOpens = prefs.counter("night_opens").toInt(),
            resumedOld = prefs.counter("resumed_old").toInt(),
            maxFinishDay = prefs.counter("max_fin_day").toInt(),
            longestSessionMs = prefs.counter("longest_session"),
            minimizes = prefs.counter("minimizes").toInt(),
            nameSet = if (prefs.userName.isNotBlank()) 1 else 0,
            eggs = prefs.eggs().size,
            returned180 = prefs.counter("returned_180").toInt()
        )
    }

    /**
     * Desbloquea lo que ya se cumple y devuelve lo recién desbloqueado.
     * La primera evaluación (por ejemplo al actualizar desde v0.4.1) es silenciosa para no inundar de avisos.
     */
    fun evaluate(s: AchSnapshot, prefs: Prefs, now: Long): List<Achievement> {
        val have = prefs.unlockedAchievements()
        val fresh = ArrayList<Achievement>()
        for (a in ALL) {
            if (a.id in have) continue
            if (a.value(s) >= a.goal) {
                prefs.unlockAchievement(a.id, now)
                fresh.add(a)
            }
        }
        if (prefs.counter("ach_init") == 0L) {
            prefs.bump("ach_init")
            return emptyList()
        }
        return fresh
    }
}
