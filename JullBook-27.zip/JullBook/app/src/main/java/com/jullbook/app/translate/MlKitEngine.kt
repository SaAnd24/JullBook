package com.jullbook.app.translate

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { c.resume(it) }
    addOnFailureListener { c.resumeWithException(it) }
    addOnCanceledListener { c.cancel() }
}

/** Traductores de ML Kit ya creados (uno por par de idiomas). */
internal object MlKitHub {
    private val map = HashMap<String, Translator>()

    @Synchronized
    fun get(from: String, to: String): Translator = map.getOrPut("$from>$to") {
        Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build()
        )
    }

    @Synchronized
    fun closeAll() {
        for (t in map.values) runCatching { t.close() }
        map.clear()
    }
}

/**
 * Traducción local con Google ML Kit (la librería de traducción en el dispositivo de Google Translate).
 * El texto NUNCA sale del teléfono: solo se descarga el modelo de cada idioma la primera vez (unos 30 MB) y
 * después funciona sin conexión. No traduce con origen "auto": se usa el idioma detectado o el elegido a mano.
 */
class MlKitEngine : TranslationEngine {
    override val id = TrEngines.MLKIT
    override val label = "Google ML Kit"
    override val version = 1
    override val maxBatchItems = 20
    override val maxBatchChars = 3000
    override val destination = "este teléfono (sin enviar texto a Internet)"

    private fun tag(code: String): String {
        if (code == "auto") throw TrError("No se pudo detectar el idioma del libro. Elige el idioma de origen a mano.", true)
        return TranslateLanguage.fromLanguageTag(code)
            ?: throw TrError("El idioma «$code» no está disponible para traducir en el teléfono.", true)
    }

    override suspend fun prepare(from: String, to: String) {
        val t = MlKitHub.get(tag(from), tag(to))
        try {
            t.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitTask()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            throw TrError("No se pudo descargar el modelo de idioma. Conéctate a Internet una vez para descargarlo; después funciona sin conexión.", true)
        }
    }

    override suspend fun translate(texts: List<String>, from: String, to: String): List<String> {
        val t = MlKitHub.get(tag(from), tag(to))
        val out = ArrayList<String>(texts.size)
        for (s in texts) {
            coroutineContext.ensureActive()
            try {
                out.add(t.translate(s).awaitTask())
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                throw TrError("El traductor del teléfono no pudo traducir este texto.")
            }
        }
        return out
    }
}
