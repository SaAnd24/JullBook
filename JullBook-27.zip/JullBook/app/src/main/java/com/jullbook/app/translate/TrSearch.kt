package com.jullbook.app.translate

import com.jullbook.app.data.SearchHit
import java.text.Normalizer
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

/**
 * Búsqueda dentro de las traducciones ya guardadas (mismas reglas que la del original: sin distinguir mayúsculas
 * ni acentos). Los resultados vienen en coordenadas del TEXTO TRADUCIDO (SearchHit.tr = true).
 */
object TrSearch {
    private fun fold(c: Char): Char {
        if (c.code < 128) return c.lowercaseChar()
        val d = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
        return (if (d.isEmpty()) c else d[0]).lowercaseChar()
    }

    private fun fold(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(fold(c))
        return sb.toString()
    }

    suspend fun run(tm: TranslationManager, query: String, limit: Int = 300): List<SearchHit> {
        val q = fold(query.trim())
        if (q.length < 2) return emptyList()
        val out = ArrayList<SearchHit>()
        for (ch in tm.translated.sorted()) {
            coroutineContext.ensureActive()
            val tc = tm.chapterAny(ch) ?: continue
            for (bi in 0 until tc.size) {
                val m = tc.map(bi) ?: continue
                val text = m.tText
                val f = fold(text)
                var from = 0
                while (out.size < limit) {
                    val at = f.indexOf(q, from)
                    if (at < 0) break
                    val end = at + q.length
                    val b0 = (at - 36).coerceAtLeast(0)
                    val a1 = (end + 70).coerceAtMost(text.length)
                    out.add(
                        SearchHit(
                            ch, bi, (at + m.shift).toFloat() / (text.length + m.shift).coerceAtLeast(1), at, end,
                            (if (b0 > 0) "…" else "") + text.substring(b0, at).replace('\n', ' '),
                            text.substring(at, end),
                            text.substring(end, a1).replace('\n', ' ') + (if (a1 < text.length) "…" else ""),
                            true
                        )
                    )
                    from = end
                }
                if (out.size >= limit) return out
            }
        }
        return out
    }
}
