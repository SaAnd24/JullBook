package com.jullbook.app.discover

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.net.URLEncoder

class OpdsLink(val rel: String?, val type: String?, val href: String, val length: Long?, val title: String?) {
    /** Tiene adquisición indirecta (típico de DRM o de tiendas): no se usa. */
    var indirect = false
}

class OpdsEntry(
    val id: String?,
    val title: String,
    val authors: List<String>,
    val summary: String?,
    val categories: List<String>,
    val language: String?,
    val issued: String?,
    val links: List<OpdsLink>
)

class OpdsDoc(val entries: List<OpdsEntry>, val links: List<OpdsLink>)

/** Lector de catálogos OPDS 1.x (Atom) con el XmlPullParser de Android: sin dependencias. */
object OpdsParser {
    private val SPACES = Regex("[ \\t]+")

    private fun readAll(p: XmlPullParser): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.START_TAG) {
                depth++
                if (sb.isNotEmpty() && !sb.endsWith(" ")) sb.append(' ')
            } else if (ev == XmlPullParser.END_TAG) {
                depth--
            } else if (ev == XmlPullParser.TEXT || ev == XmlPullParser.CDSECT) {
                sb.append(p.text)
            }
        }
        return sb.toString().replace(SPACES, " ").trim()
    }

    fun parse(input: InputStream, base: String): OpdsDoc {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        val entries = ArrayList<OpdsEntry>()
        val feedLinks = ArrayList<OpdsLink>()

        var inEntry = false
        var inAuthor = false
        var id: String? = null
        var title = ""
        var summary: String? = null
        var content: String? = null
        var language: String? = null
        var issued: String? = null
        var authors = ArrayList<String>()
        var cats = ArrayList<String>()
        var links = ArrayList<OpdsLink>()
        var lastLink: OpdsLink? = null

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name.lowercase()
                if (n == "entry") {
                    inEntry = true
                    inAuthor = false
                    id = null
                    title = ""
                    summary = null
                    content = null
                    language = null
                    issued = null
                    authors = ArrayList()
                    cats = ArrayList()
                    links = ArrayList()
                    lastLink = null
                } else if (n == "link") {
                    val href = p.getAttributeValue(null, "href")
                    if (!href.isNullOrBlank()) {
                        val l = OpdsLink(
                            p.getAttributeValue(null, "rel"),
                            p.getAttributeValue(null, "type"),
                            Http.resolve(base, href),
                            p.getAttributeValue(null, "length")?.trim()?.toLongOrNull(),
                            p.getAttributeValue(null, "title")
                        )
                        if (inEntry) links.add(l) else feedLinks.add(l)
                        lastLink = l
                    } else {
                        lastLink = null
                    }
                } else if (n.endsWith("indirectacquisition")) {
                    lastLink?.indirect = true
                } else if (inEntry) {
                    if (n == "id") {
                        id = readAll(p).ifBlank { null }
                    } else if (n == "title") {
                        title = readAll(p)
                    } else if (n == "summary") {
                        summary = readAll(p)
                    } else if (n == "content") {
                        content = readAll(p)
                    } else if (n == "author") {
                        inAuthor = true
                    } else if (n == "name" && inAuthor) {
                        val a = readAll(p)
                        if (a.isNotBlank()) authors.add(a)
                    } else if (n == "dc:creator" || n == "dcterms:creator") {
                        val a = readAll(p)
                        if (a.isNotBlank()) authors.add(a)
                    } else if (n == "category") {
                        val c = (p.getAttributeValue(null, "label") ?: p.getAttributeValue(null, "term"))?.trim()
                        if (!c.isNullOrBlank() && !c.startsWith("http")) cats.add(c)
                    } else if (n == "dc:subject" || n == "dcterms:subject") {
                        val c = readAll(p)
                        if (c.isNotBlank() && !c.startsWith("http")) cats.add(c)
                    } else if (n == "language" || n.endsWith(":language")) {
                        if (language == null) language = readAll(p).ifBlank { null }
                    } else if (n == "dc:issued" || n == "dcterms:issued" || n == "dc:date" || n == "dcterms:date") {
                        if (issued == null) issued = readAll(p).ifBlank { null }
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                val n = p.name.lowercase()
                if (n == "entry" && inEntry) {
                    val desc = summary?.takeIf { it.isNotBlank() } ?: content?.takeIf { it.isNotBlank() }
                    entries.add(
                        OpdsEntry(
                            id, title.ifBlank { "Sin título" }, authors, desc?.take(3000),
                            cats, language, issued, links
                        )
                    )
                    inEntry = false
                } else if (n == "author") {
                    inAuthor = false
                } else if (n == "link") {
                    lastLink = null
                }
            }
            ev = p.next()
        }
        return OpdsDoc(entries, feedLinks)
    }

    /** Plantilla de búsqueda de una descripción OpenSearch (se prefiere la que devuelve Atom/OPDS). */
    fun openSearchTemplate(input: InputStream): String? {
        val p = Xml.newPullParser()
        p.setInput(input, null)
        var first: String? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name.lowercase()
                if (n == "url" || n.endsWith(":url")) {
                    val tpl = p.getAttributeValue(null, "template")
                    val type = (p.getAttributeValue(null, "type") ?: "").lowercase()
                    if (!tpl.isNullOrBlank()) {
                        if (type.contains("atom") || type.contains("opds")) return tpl
                        if (first == null) first = tpl
                    }
                }
            }
            ev = p.next()
        }
        return first
    }
}

/** Configuración de una fuente (catálogo OPDS). */
class SourceConfig(
    val id: String,
    val name: String,
    /** Plantilla con {searchTerms} o dirección del catálogo (se descubre su búsqueda). Solo https. */
    val url: String,
    val user: String?,
    val pass: String?,
    /** Cómo pedir un idioma en la propia consulta, p. ej. "l.{code}"; null = la fuente no filtra por idioma. */
    val langTerm: String?,
    val builtIn: Boolean,
    /** Tipo de fuente: "opds" (catálogo OPDS) o una API propia ("archive", "openlibrary", "google", "wikisource"). */
    val kind: String = "opds",
    /** Texto corto que se muestra bajo el nombre en la lista de fuentes. */
    val note: String? = null
)

/** Fuente genérica OPDS: catálogos públicos, bibliotecas autorizadas, servidores personales. */
class OpdsSource(private val cfg: SourceConfig) : Source {
    override val id: String get() = cfg.id
    override val name: String get() = cfg.name

    private val auth: Http.Auth? = if (!cfg.user.isNullOrBlank()) {
        val host = runCatching { java.net.URL(cfg.url.replace("{searchTerms}", "x")).host }.getOrDefault("")
        Http.Auth(cfg.user, cfg.pass ?: "", host)
    } else null

    @Volatile
    private var template: String? = if (cfg.url.contains("{searchTerms}")) cfg.url else null

    override fun authOrNull(): Http.Auth? = auth

    override fun filtersLanguage(lang: Lang?): Boolean = lang?.code != null && cfg.langTerm != null

    private fun fetch(url: String): OpdsDoc {
        val c = Http.open(url, auth, "application/atom+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5")
        try {
            val ct = (c.contentType ?: "").lowercase()
            if (ct.contains("json")) throw SourceException("Esta fuente usa OPDS 2 (JSON), que todavía no es compatible")
            return c.inputStream.use { OpdsParser.parse(it, url) }
        } catch (e: XmlPullParserException) {
            throw SourceException("La fuente no devolvió un catálogo OPDS válido")
        } finally {
            c.disconnect()
        }
    }

    private fun searchTemplate(): String {
        template?.let { return it }
        val root = fetch(cfg.url)
        val sl = root.links.firstOrNull { it.rel == "search" }
            ?: throw SourceException("Esta dirección no es un catálogo OPDS con búsqueda")
        val t: String = if ((sl.type ?: "").contains("opensearchdescription", ignoreCase = true)) {
            val bytes = Http.bytes(sl.href, auth)
            val parsed: String? = try {
                OpdsParser.openSearchTemplate(ByteArrayInputStream(bytes))
            } catch (e: XmlPullParserException) {
                null
            }
            val tpl = parsed ?: throw SourceException("La fuente no describe cómo buscar")
            Http.resolve(sl.href, tpl)
        } else {
            sl.href
        }
        if (!t.contains("{searchTerms}")) throw SourceException("La fuente no describe cómo buscar")
        template = t
        return t
    }

    private fun urlFor(q: SearchQuery): String {
        var terms = q.text.trim()
        val code = q.lang?.code
        val lt = cfg.langTerm
        if (code != null && lt != null) terms = (terms + " " + lt.replace("{code}", code)).trim()
        val tpl = searchTemplate()
        val qi = tpl.indexOf('?')
        val ti = tpl.indexOf("{searchTerms}")
        val enc = URLEncoder.encode(terms, "UTF-8")
        // En una ruta el espacio va como %20; en la cadena de consulta, como +.
        val safe = if (qi in 0 until ti) enc else enc.replace("+", "%20")
        return tpl.replace("{searchTerms}", safe).replace(OPTIONAL, "").replace(LEFTOVER, "")
    }

    override fun search(q: SearchQuery, cursor: String?): SearchPage {
        val url = cursor ?: urlFor(q)
        val doc = fetch(url)
        val out = ArrayList<SearchResult>()
        for (e in doc.entries) toResult(e, true)?.let { out.add(it) }
        val next = doc.links.firstOrNull { it.rel == "next" }?.href
        return SearchPage(out, next)
    }

    private class Found(val prefix: String?, val entry: OpdsEntry)

    private fun hasAcq(e: OpdsEntry): Boolean = e.links.any { isAcquisition(it) }

    /** Enlace a un catálogo hijo (serie, tomo…). */
    private fun navUrl(e: OpdsEntry): String? = e.links.firstOrNull { l ->
        (l.type ?: "").contains("atom+xml", ignoreCase = true) && ((l.rel ?: "alternate") in DETAIL_RELS)
    }?.href

    /** Todas las entradas de un catálogo, siguiendo sus páginas. */
    private fun fetchAll(url: String): List<OpdsEntry> {
        var doc = fetch(url)
        val all = ArrayList<OpdsEntry>(doc.entries)
        var pages = 1
        while (pages < MAX_PAGES && all.size < MAX_ENTRIES) {
            val next = doc.links.firstOrNull { it.rel == "next" }?.href ?: break
            doc = fetch(next)
            all.addAll(doc.entries)
            pages++
        }
        return all
    }

    override fun details(r: SearchResult): BookDetails {
        val url = r.detailUrl
        if (r.downloads.isNotEmpty() || url == null) return BookDetails(r, r.downloads)
        val top = fetchAll(url)
        val found = ArrayList<Found>()
        for (e in top) if (hasAcq(e)) found.add(Found(null, e))
        if (found.isEmpty()) {
            // Catálogo de navegación (serie → tomos → capítulos): se bajan hasta dos niveles.
            var budget = MAX_SUBFEEDS
            outer@ for (e in top) {
                val u = navUrl(e) ?: continue
                if (budget-- <= 0) break
                val sub = try { fetchAll(u) } catch (ex: Exception) { continue }
                val direct = sub.filter { hasAcq(it) }
                if (direct.isNotEmpty()) {
                    for (x in direct) found.add(Found(e.title, x))
                    continue
                }
                for (e2 in sub) {
                    val u2 = navUrl(e2) ?: continue
                    if (budget-- <= 0) break@outer
                    val sub2 = try { fetchAll(u2) } catch (ex: Exception) { continue }
                    for (x in sub2) if (hasAcq(x)) found.add(Found(e.title + " - " + e2.title, x))
                }
            }
        }
        val chosen = found.firstOrNull()?.entry ?: top.firstOrNull() ?: return BookDetails(r, emptyList())
        val d = toResult(chosen, false) ?: return BookDetails(r, emptyList())
        val episodes = ArrayList<Episode>()
        if (found.size > 1) {
            for (f in found) {
                val x = toResult(f.entry, false) ?: continue
                if (x.downloads.isEmpty()) continue
                val p = f.prefix
                val t = if (p == null || x.title.startsWith(p, ignoreCase = true)) x.title else p + " - " + x.title
                episodes.add(Episode(t, x.downloads))
            }
        }
        val series = episodes.size > 1
        val dls = if (series) emptyList<DownloadInfo>() else d.downloads
        val merged = SearchResult(
            r.sourceId, r.sourceName, r.id, r.title,
            r.author ?: d.author,
            d.coverUrl ?: r.coverUrl,
            d.thumbUrl ?: r.thumbUrl,
            d.description ?: r.description,
            d.genres.ifEmpty { r.genres },
            d.languageRaw ?: r.languageRaw,
            d.year ?: r.year,
            dls,
            r.detailUrl,
            r.langFromFilter
        )
        return BookDetails(merged, dls, null, if (series) episodes else emptyList())
    }

    /**
     * [strict]: en una lista de resultados se descartan las entradas que no parecen un libro
     * (carpetas de navegación, listas de autores…). Un libro sin enlaces de descarga se queda
     * si apunta a su ficha y trae portada, autor o es una ficha OPDS de tipo "entry".
     */
    private fun toResult(e: OpdsEntry, strict: Boolean): SearchResult? {
        val dl = ArrayList<DownloadInfo>()
        for (l in e.links) {
            if (!isAcquisition(l) || l.indirect) continue
            val f = DlFormat.detect(l.type, l.href, l.title) ?: continue
            if (dl.none { it.format == f }) dl.add(DownloadInfo(f, l.href, l.length?.takeIf { it > 0 }))
        }
        val cover = e.links.firstOrNull { it.rel == REL_IMAGE }?.href
        val thumb = e.links.firstOrNull { it.rel == REL_THUMB || it.rel == "x-stanza-cover-image-thumbnail" }?.href
        val detail = e.links.firstOrNull { l ->
            (l.type ?: "").contains("atom+xml", ignoreCase = true) && ((l.rel ?: "alternate") in DETAIL_RELS)
        }?.href
        val typeEntry = e.links.any { (it.type ?: "").contains("type=entry", ignoreCase = true) }
        val author = e.authors.joinToString(", ").ifBlank { null }
        if (strict && dl.isEmpty()) {
            val looksLikeBook = detail != null && (cover != null || thumb != null || author != null || typeEntry ||
                e.summary != null || e.categories.isNotEmpty() || e.language != null || e.issued != null)
            if (!looksLikeBook) return null
        }
        return SearchResult(
            sourceId = cfg.id,
            sourceName = cfg.name,
            id = e.id ?: detail ?: dl.firstOrNull()?.url ?: e.title,
            title = e.title,
            author = author,
            coverUrl = cover,
            thumbUrl = thumb,
            description = e.summary,
            genres = e.categories.distinct().take(4),
            languageRaw = e.language,
            year = e.issued?.let { YEAR.find(it)?.value },
            downloads = dl,
            detailUrl = detail
        )
    }

    private fun isAcquisition(l: OpdsLink): Boolean =
        l.rel == "http://opds-spec.org/acquisition" || l.rel == "http://opds-spec.org/acquisition/open-access"

    companion object {
        private const val MAX_PAGES = 100
        private const val MAX_ENTRIES = 2000
        private const val MAX_SUBFEEDS = 60
        private const val REL_IMAGE = "http://opds-spec.org/image"
        private const val REL_THUMB = "http://opds-spec.org/image/thumbnail"
        private val DETAIL_RELS = setOf("alternate", "subsection")
        private val YEAR = Regex("(1\\d{3}|20\\d{2})")
        private val OPTIONAL = Regex("\\{[^}]*\\?\\}")
        private val LEFTOVER = Regex("\\{[^}]*\\}")
    }
}
