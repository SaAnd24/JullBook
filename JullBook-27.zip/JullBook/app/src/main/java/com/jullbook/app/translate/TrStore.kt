package com.jullbook.app.translate

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Ajustes de traducción (SharedPreferences propio: no toca los ajustes ni la base de datos existentes). */
class TrSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_translate", Context.MODE_PRIVATE)

    var engine: String
        get() = sp.getString("engine", TrEngines.MLKIT) ?: TrEngines.MLKIT
        set(v) { sp.edit().putString("engine", v).apply() }

    var libreUrl: String
        get() = sp.getString("libre_url", "") ?: ""
        set(v) { sp.edit().putString("libre_url", v).apply() }

    var libreKey: String
        get() = sp.getString("libre_key", "") ?: ""
        set(v) { sp.edit().putString("libre_key", v).apply() }

    var to: String
        get() = sp.getString("to", null) ?: Locale.getDefault().language.takeIf { c -> TrLangs.all.any { it.code == c } } ?: "es"
        set(v) { sp.edit().putString("to", v).apply() }

    fun from(bookId: Long): String = sp.getString("from_$bookId", "auto") ?: "auto"
    fun setFrom(bookId: Long, v: String) { sp.edit().putString("from_$bookId", v).apply() }

    fun showing(bookId: Long): Boolean = sp.getBoolean("show_$bookId", false)
    fun setShowing(bookId: Long, v: Boolean) { sp.edit().putBoolean("show_$bookId", v).apply() }

    fun detected(bookId: Long): String? = sp.getString("det_$bookId", null)
    fun setDetected(bookId: Long, v: String) { sp.edit().putString("det_$bookId", v).apply() }
}

/**
 * Caché en disco de UNA combinación libro + motor + idioma origen + idioma destino (una carpeta por combinación):
 * cambiar de motor o idioma usa otra carpeta y no toca las demás. Un archivo por capítulo con la huella de su
 * contenido original (si el EPUB cambia, solo se descartan los capítulos cuya huella ya no coincide).
 */
class TrCache(private val dir: File) {
    class Data(val hash: String, val blocks: List<List<String>?>)

    private fun file(ch: Int) = File(dir, "ch_$ch.json")

    fun read(ch: Int): Data? {
        val f = file(ch)
        if (!f.isFile) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            val a = o.getJSONArray("b")
            Data(
                o.getString("h"),
                (0 until a.length()).map { i ->
                    if (a.isNull(i)) {
                        null
                    } else {
                        val x = a.getJSONArray(i)
                        (0 until x.length()).map { x.getString(it) }
                    }
                }
            )
        } catch (ignored: Exception) {
            null
        }
    }

    fun write(ch: Int, hash: String, blocks: List<List<String>?>) {
        dir.mkdirs()
        val a = JSONArray()
        for (b in blocks) {
            if (b == null) a.put(JSONObject.NULL) else a.put(JSONArray(b))
        }
        val text = JSONObject().put("v", 1).put("h", hash).put("b", a).toString()
        val tmp = File(dir, "ch_$ch.tmp")
        tmp.writeText(text, Charsets.UTF_8)
        val f = file(ch)
        if (!tmp.renameTo(f)) {
            f.writeText(text, Charsets.UTF_8)
            tmp.delete()
        }
    }

    fun delete(ch: Int) {
        file(ch).delete()
    }

    fun chapters(): Set<Int> {
        val names = dir.list() ?: return emptySet()
        val out = HashSet<Int>()
        for (n in names) {
            if (n.startsWith("ch_") && n.endsWith(".json")) n.substring(3, n.length - 5).toIntOrNull()?.let { out.add(it) }
        }
        return out
    }

    // ---- Traducciones sueltas (selección): clave = huella del texto ----

    private var sel: LinkedHashMap<String, String>? = null

    @Synchronized
    private fun loadSel(): LinkedHashMap<String, String> {
        sel?.let { return it }
        val m = LinkedHashMap<String, String>()
        try {
            val f = File(dir, "sel.json")
            if (f.isFile) {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                for (k in o.keys()) m[k] = o.getString(k)
            }
        } catch (ignored: Exception) {
        }
        sel = m
        return m
    }

    @Synchronized
    fun selGet(key: String): String? = loadSel()[key]

    @Synchronized
    fun selPut(key: String, value: String) {
        val m = loadSel()
        m.remove(key)
        m[key] = value
        while (m.size > 400) m.remove(m.keys.first())
        try {
            dir.mkdirs()
            val o = JSONObject()
            for ((k, v) in m) o.put(k, v)
            File(dir, "sel.json").writeText(o.toString(), Charsets.UTF_8)
        } catch (ignored: Exception) {
        }
    }
}
