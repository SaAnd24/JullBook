package com.jullbook.app.data

import android.text.format.DateUtils
import java.util.Locale

fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        val ca = a[i]
        val cb = b[j]
        if (ca.isDigit() && cb.isDigit()) {
            var ei = i
            while (ei < a.length && a[ei].isDigit()) ei++
            var ej = j
            while (ej < b.length && b[ej].isDigit()) ej++
            val na = a.substring(i, ei).trimStart('0')
            val nb = b.substring(j, ej).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ei
            j = ej
        } else {
            val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

fun resolvePath(baseDir: String, rel: String): String {
    val full = if (rel.startsWith("/")) rel.removePrefix("/") else if (baseDir.isEmpty()) rel else "$baseDir/$rel"
    val parts = ArrayList<String>()
    for (seg in full.split('/')) {
        when (seg) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
            else -> parts.add(seg)
        }
    }
    return parts.joinToString("/")
}

fun volLabel(b: Book): String =
    b.alias ?: b.number?.let { String.format(Locale.ROOT, "#%03d", it) } ?: b.title

fun durText(ms: Long): String {
    val m = ms / 60_000
    return when {
        ms <= 0 -> "0 min"
        m < 1 -> "<1 min"
        m < 60 -> "$m min"
        else -> if (m % 60 == 0L) "${m / 60} h" else "${m / 60} h ${m % 60} min"
    }
}

fun statusText(p: Progress?): String = when {
    p == null -> "No iniciado"
    p.status == ST_UNREAD -> "Reiniciado"
    p.status == ST_FINISHED -> "Terminado"
    else -> "Leyendo"
}

/** Lectura en curso de algo que ya se había terminado alguna vez. */
fun isRereading(b: Book, p: Progress?): Boolean = p != null && p.status != ST_FINISHED && p.status != ST_UNREAD && b.reads > 0

fun statusLabel(b: Book, p: Progress?): String = when {
    p == null -> "No iniciado"
    p.status == ST_UNREAD -> "Reiniciado"
    p.status == ST_FINISHED -> "Terminado"
    isRereading(b, p) -> "Releyendo"
    else -> "Leyendo"
}

/** Estado + progreso para tarjetas; null si todavía no se ha empezado. */
fun statusCaption(b: Book, p: Progress?): String? = when {
    p == null || p.status == ST_UNREAD -> null
    p.status == ST_FINISHED -> "Terminado"
    isRereading(b, p) -> "Releyendo · ${pctText(p.percent)}"
    else -> "Leyendo · ${pctText(p.percent)}"
}

/** Estado + progreso de una colección; null si todavía no se ha empezado ninguno de sus tomos. */
fun seriesCaption(s: SeriesItem): String? = when (LibraryView.statusOf(s)) {
    StatusFilter.UNSTARTED -> null
    StatusFilter.FINISHED -> "Terminada"
    else -> (if (s.rereading) "Releyendo" else "Leyendo") + " · " + pctText(s.percent)
}

/** "Leído hoy", "Leído ayer", "Leído hace 2 d"…; null si no hay fecha. */
fun lastReadLabel(t: Long?): String? = lastReadText(t)?.let { "Leído " + it.replaceFirstChar { c -> c.lowercase() } }

fun readsText(n: Int): String = when {
    n <= 0 -> ""
    n == 1 -> "1 lectura"
    else -> "$n lecturas"
}

/** "Hoy", "Ayer", "hace 3 d"…; null si no hay fecha. */
fun lastReadText(t: Long?): String? {
    if (t == null || t <= 0L) return null
    return DateUtils.getRelativeTimeSpanString(
        t, System.currentTimeMillis(), DateUtils.DAY_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE
    ).toString()
}

fun pctText(f: Float): String = "${(f * 100f).toInt()}%"

fun formatLabel(f: Format): String = when (f) {
    Format.EPUB -> "EPUB"
    Format.PDF -> "PDF"
    Format.COMIC -> "Cómic"
}
