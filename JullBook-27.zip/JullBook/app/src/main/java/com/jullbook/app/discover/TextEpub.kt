package com.jullbook.app.discover

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.zip.ZipOutputStream

/**
 * Convierte un texto plano (el OCR de Internet Archive) en un EPUB sencillo: junta las líneas en párrafos,
 * une las palabras partidas por guion y reparte el texto en capítulos de tamaño cómodo.
 */
object TextEpub {
    private const val CHUNK = 30_000
    private const val MAX_BYTES = 40L * 1024 * 1024
    private val CTRL = Regex("[\\u0000-\\u0008\\u000B\\u000E-\\u001F\\uFFFE\\uFFFF]")
    private const val ENDS = ".!?…:;»”\"')]"

    fun build(txt: File, title: String, author: String?, dst: File, check: () -> Unit) {
        if (txt.length() > MAX_BYTES) throw SourceException("El texto es demasiado grande")
        val raw = txt.readText(Charsets.UTF_8)
        val paras = paragraphs(raw)
        if (paras.isEmpty()) throw SourceException("El texto está vacío")

        // Capítulos de ~CHUNK caracteres, cortando siempre entre párrafos.
        val chunks = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        var len = 0
        for (p in paras) {
            cur.add(p)
            len += p.length
            if (len >= CHUNK) {
                chunks.add(cur)
                cur = ArrayList()
                len = 0
            }
        }
        if (cur.isNotEmpty()) chunks.add(cur)

        val uid = "urn:uuid:" + UUID.randomUUID()
        val stamp = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'").withZone(ZoneOffset.UTC).format(Instant.now())
        val t = esc(title.ifBlank { "Libro" })

        ZipOutputStream(BufferedOutputStream(FileOutputStream(dst))).use { zo ->
            fun put(name: String, text: String) = EpubSlim.write(zo, name, text.toByteArray(Charsets.UTF_8))
            put("mimetype", "application/epub+zip")
            put(
                "META-INF/container.xml",
                """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>"""
            )
            put("OEBPS/style.css", "body{margin:0 4%;line-height:1.5;text-align:justify}p{margin:0 0 .8em 0;text-indent:1em}h1{font-size:1.3em;text-align:center;margin:1em 0}")

            val manifest = StringBuilder()
            val spine = StringBuilder()
            val navItems = StringBuilder()
            val ncxItems = StringBuilder()
            for ((i, ch) in chunks.withIndex()) {
                check()
                val n = i + 1
                val file = "ch%03d.xhtml".format(n)
                val head = if (chunks.size == 1) title.ifBlank { "Libro" } else "Parte $n"
                val body = StringBuilder()
                for (p in ch) body.append("<p>").append(esc(p)).append("</p>\n")
                put(
                    "OEBPS/$file",
                    """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta charset="utf-8"/><title>${esc(head)}</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body><h1>${esc(head)}</h1>
$body</body></html>"""
                )
                manifest.append("<item id=\"c$n\" href=\"$file\" media-type=\"application/xhtml+xml\"/>\n")
                spine.append("<itemref idref=\"c$n\"/>\n")
                navItems.append("<li><a href=\"$file\">${esc(head)}</a></li>\n")
                ncxItems.append(
                    "<navPoint id=\"n$n\" playOrder=\"$n\"><navLabel><text>${esc(head)}</text></navLabel><content src=\"$file\"/></navPoint>\n"
                )
            }
            put(
                "OEBPS/nav.xhtml",
                """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><meta charset="utf-8"/><title>$t</title></head><body><nav epub:type="toc"><ol>
$navItems</ol></nav></body></html>"""
            )
            put(
                "OEBPS/toc.ncx",
                """<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="$uid"/></head><docTitle><text>$t</text></docTitle><navMap>
$ncxItems</navMap></ncx>"""
            )
            val creator = if (author.isNullOrBlank()) "" else "<dc:creator>${esc(author)}</dc:creator>"
            put(
                "OEBPS/content.opf",
                """<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bid">$uid</dc:identifier><dc:title>$t</dc:title>$creator<dc:language>und</dc:language><meta property="dcterms:modified">$stamp</meta></metadata>
<manifest>
<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
<item id="css" href="style.css" media-type="text/css"/>
$manifest</manifest>
<spine toc="ncx">
$spine</spine></package>"""
            )
        }
    }

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun paragraphs(raw: String): List<String> {
        val t = CTRL.replace(raw.replace("\r\n", "\n").replace('\r', '\n').replace('\u000C', '\n'), "")
        val paras = ArrayList<String>()
        val cur = StringBuilder()
        for (line in t.split('\n')) {
            val l = line.trim()
            if (l.isEmpty()) {
                if (cur.isNotEmpty()) {
                    paras.add(cur.toString())
                    cur.setLength(0)
                }
                continue
            }
            if (cur.isNotEmpty()) {
                // Palabra partida por guion al final de línea: se une con la siguiente.
                if (cur.endsWith("-") && cur.length >= 2 && cur[cur.length - 2].isLetter() && l[0].isLowerCase()) {
                    cur.setLength(cur.length - 1)
                } else {
                    cur.append(' ')
                }
            }
            cur.append(l)
        }
        if (cur.isNotEmpty()) paras.add(cur.toString())
        // Un salto de página en mitad de una frase no separa párrafos.
        val merged = ArrayList<String>()
        for (p in paras) {
            val last = merged.lastOrNull()
            if (last != null && p[0].isLowerCase() && last.last() !in ENDS) {
                merged[merged.size - 1] = last + " " + p
            } else {
                merged.add(p)
            }
        }
        return merged
    }
}
