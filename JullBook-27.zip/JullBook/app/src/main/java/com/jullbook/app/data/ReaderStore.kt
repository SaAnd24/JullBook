package com.jullbook.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Resaltado (con nota opcional) de un fragmento de texto de un capítulo. s/e son posiciones dentro del texto del bloque. */
class Mark(
    val id: Long,
    val ch: Int,
    val block: Int,
    val s: Int,
    val e: Int,
    val color: Int,
    val note: String,
    val text: String,
    val at: Long,
    /** Posición aproximada del fragmento dentro del bloque (0..1), para saltar a él. */
    val frac: Float = 0f,
    /** true = s/e están en el texto traducido (solo resultados de búsqueda temporales; nunca se guarda). */
    val tr: Boolean = false
) {
    fun copy(color: Int = this.color, note: String = this.note) = Mark(id, ch, block, s, e, color, note, text, at, frac, tr)
}

/** Marcador de página: capítulo + punto de lectura (bloque y fracción), igual que el progreso guardado. */
class Bookmark(
    val id: Long,
    val ch: Int,
    val sub: Int,
    val frac: Float,
    val label: String,
    val percent: Float,
    val at: Long
)

/** Guarda marcadores, resaltados y notas por libro (SharedPreferences propio; no toca la base de datos). */
class ReaderStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_reader", Context.MODE_PRIVATE)

    fun marks(bookId: Long): List<Mark> {
        val raw = sp.getString("marks_$bookId", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Mark(
                    o.getLong("id"), o.getInt("ch"), o.getInt("b"), o.getInt("s"), o.getInt("e"),
                    o.getInt("c"), o.optString("n", ""), o.optString("t", ""), o.optLong("at", 0L),
                    o.optDouble("f", 0.0).toFloat()
                )
            }
        } catch (ignored: Exception) {
            emptyList()
        }
    }

    fun saveMarks(bookId: Long, list: List<Mark>) {
        val a = JSONArray()
        for (m in list) {
            a.put(
                JSONObject().put("id", m.id).put("ch", m.ch).put("b", m.block).put("s", m.s).put("e", m.e)
                    .put("c", m.color).put("n", m.note).put("t", m.text).put("at", m.at).put("f", m.frac.toDouble())
            )
        }
        sp.edit().putString("marks_$bookId", a.toString()).apply()
    }

    fun bookmarks(bookId: Long): List<Bookmark> {
        val raw = sp.getString("bm_$bookId", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Bookmark(
                    o.getLong("id"), o.getInt("ch"), o.getInt("sub"), o.getDouble("f").toFloat(),
                    o.optString("l", ""), o.optDouble("p", 0.0).toFloat(), o.optLong("at", 0L)
                )
            }
        } catch (ignored: Exception) {
            emptyList()
        }
    }

    fun saveBookmarks(bookId: Long, list: List<Bookmark>) {
        val a = JSONArray()
        for (b in list) {
            a.put(
                JSONObject().put("id", b.id).put("ch", b.ch).put("sub", b.sub).put("f", b.frac.toDouble())
                    .put("l", b.label).put("p", b.percent.toDouble()).put("at", b.at)
            )
        }
        sp.edit().putString("bm_$bookId", a.toString()).apply()
    }
}
