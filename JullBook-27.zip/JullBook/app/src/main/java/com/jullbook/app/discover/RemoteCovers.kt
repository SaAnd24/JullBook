package com.jullbook.app.discover

import android.graphics.Bitmap
import android.util.LruCache
import com.jullbook.app.data.Images

/** Portadas de resultados (solo en memoria, no se guardan). Únicamente se piden cuando el usuario abre la búsqueda. */
object RemoteCovers {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val failed = HashSet<String>()

    fun load(url: String, auth: Http.Auth?): Bitmap? {
        cache.get(url)?.let { return it }
        synchronized(failed) { if (url in failed) return null }
        val bmp = try {
            val bytes = Http.bytes(url, auth, 3 * 1024 * 1024)
            Images.decodeSampled(bytes, 300, Bitmap.Config.ARGB_8888)
        } catch (e: Throwable) {
            null
        }
        if (bmp == null) {
            synchronized(failed) { failed.add(url) }
            return null
        }
        cache.put(url, bmp)
        return bmp
    }
}
