package com.jullbook.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel

fun folderLabel(uri: String?): String? {
    if (uri == null) return null
    val seg = runCatching { Uri.parse(uri).lastPathSegment }.getOrNull() ?: return uri
    return seg.substringAfterLast(':').ifBlank { seg }
}

@Composable
private fun FolderCard(title: String, subtitle: String, chosen: String?, onPick: () -> Unit, onClear: (() -> Unit)? = null) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
            .clickable(onClick = onPick)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (chosen != null) "📁 $chosen" else "Toca para elegir carpeta",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f),
                maxLines = 1
            )
            if (chosen != null && onClear != null) TextButton(onClick = onClear) { Text("Quitar") }
        }
    }
}

/** Primer inicio: nombre, carpeta de libros y carpeta de cómics (selector de carpetas de Android). */
@Composable
fun OnboardingScreen(vm: AppViewModel) {
    var name by rememberSaveable { mutableStateOf("") }
    var books by rememberSaveable { mutableStateOf<String?>(null) }
    var comics by rememberSaveable { mutableStateOf<String?>(null) }
    val pickBooks = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { vm.persistRead(u); books = u.toString() }
    }
    val pickComics = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { vm.persistRead(u); comics = u.toString() }
    }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            JuliAvatar(size = 56.dp)
            Column {
                Text("JullBook", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
                Text("Mi biblioteca, que además me conoce.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Hola, soy Juli 👋", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onBackground)
        Text(
            "Antes de empezar, dime cómo quieres que te llame.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(24) },
            singleLine = true,
            label = { Text("Tu nombre") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            modifier = Modifier.fillMaxWidth()
        )
        Text("¿Dónde están tus cosas?", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        FolderCard("Libros", "EPUB y PDF", folderLabel(books), { pickBooks.launch(null) }) { books = null }
        FolderCard("Cómics", "CBZ y CBR", folderLabel(comics), { pickComics.launch(null) }) { comics = null }
        Text(
            "JullBook solo lee tus archivos: no los mueve, copia, renombra ni modifica. Todo funciona sin conexión.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = { vm.finishOnboarding(name, books?.let { Uri.parse(it) }, comics?.let { Uri.parse(it) }) },
            enabled = books != null || comics != null,
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("Entrar a mi biblioteca") }
    }
}
