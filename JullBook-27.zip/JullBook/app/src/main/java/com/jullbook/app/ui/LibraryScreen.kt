package com.jullbook.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.LibTab
import com.jullbook.app.OrgDialog
import com.jullbook.app.data.Format
import com.jullbook.app.data.LibItem
import com.jullbook.app.data.LibraryView
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SingleItem
import com.jullbook.app.data.SortMode
import com.jullbook.app.data.StatusFilter
import kotlinx.coroutines.flow.filter

/** Icono de cuadrícula (2x2) dibujado a mano: el set de iconos básico no lo incluye. */
@Composable
private fun GridGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(20.dp)) {
        val gap = size.width * 0.12f
        val cell = (size.width - gap) / 2f
        val r = CornerRadius(cell * 0.22f)
        for (row in 0..1) for (col in 0..1) {
            drawRoundRect(
                color,
                topLeft = Offset(col * (cell + gap), row * (cell + gap)),
                size = Size(cell, cell),
                cornerRadius = r
            )
        }
    }
}

private fun belongs(item: LibItem, comics: Boolean): Boolean = when (item) {
    is SeriesItem -> item.isBooks != comics
    is SingleItem -> (item.book.format == Format.COMIC) == comics
}

@Composable
fun LibraryScreen(vm: AppViewModel, onPickFolder: () -> Unit, modifier: Modifier = Modifier) {
    val lib = vm.library
    val haptic = LocalHapticFeedback.current
    var menu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val comics = vm.libTab == LibTab.COMICS
    val query = vm.query
    val filtering = query.isNotBlank() || vm.libFilter != StatusFilter.ALL

    // Libros (EPUB + PDF) y Cómics (CBZ + CBR) nunca se mezclan. Las colecciones vacías no se muestran.
    val tabItems = remember(lib, comics) { lib.items.filter { belongs(it, comics) } }
    val shown = remember(tabItems, query, vm.libFilter, vm.libSort) {
        LibraryView.apply(tabItems, query, vm.libFilter, vm.libSort)
    }
    val otherCount = remember(lib, comics, query) {
        if (query.isBlank()) 0
        else lib.items.count { !belongs(it, comics) && LibraryView.visible(it) && LibraryView.matches(it, query) }
    }

    Box(modifier.fillMaxSize()) {
        key(vm.libTab) {
            val state = vm.gridStates.getValue(vm.libTab)
            val tabName = vm.libTab.name

            // Recordar la posición de desplazamiento de esta pestaña.
            LaunchedEffect(state) {
                snapshotFlow { state.isScrollInProgress }.filter { !it }.collect {
                    vm.prefs.saveScroll(tabName, state.firstVisibleItemIndex, state.firstVisibleItemScrollOffset)
                }
            }
            DisposableEffect(state) {
                onDispose { vm.prefs.saveScroll(tabName, state.firstVisibleItemIndex, state.firstVisibleItemScrollOffset) }
            }
            // Al cambiar búsqueda, filtro u orden se vuelve arriba (no en la primera composición).
            var skip by remember { mutableStateOf(true) }
            LaunchedEffect(query, vm.libFilter, vm.libSort) {
                if (skip) skip = false else state.scrollToItem(0)
            }

            LazyVerticalGrid(
                columns = if (vm.libList) GridCells.Fixed(1) else GridCells.Adaptive(112.dp),
                state = state,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 20.dp, end = 20.dp, top = 8.dp,
                    bottom = if (vm.selection.isNotEmpty()) 88.dp else 24.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(if (vm.libList) 4.dp else 14.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Biblioteca", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { if (vm.searchOpen) vm.closeSearch() else vm.searchOpen = true }) {
                                Icon(Icons.Default.Search, contentDescription = "Buscar")
                            }
                            IconButton(onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                vm.toggleLibList()
                            }) {
                                if (vm.libList) {
                                    GridGlyph(MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Vista en lista")
                                }
                            }
                            Box {
                                IconButton(onClick = { menu = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Más opciones")
                                }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Crear colección") },
                                        onClick = { menu = false; vm.dialog = OrgDialog.CreateSaga }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Actualizar") },
                                        onClick = { menu = false; vm.startScan() }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Cambiar carpeta") },
                                        onClick = { menu = false; onPickFolder() }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Portadas en línea") },
                                        trailingIcon = {
                                            if (vm.onlineCovers) Icon(Icons.Default.Check, contentDescription = "Activado")
                                        },
                                        onClick = { vm.changeOnlineCovers(!vm.onlineCovers) }
                                    )
                                }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    AnimatedVisibility(
                        visible = vm.searchOpen,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        val focus = remember { FocusRequester() }
                        LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
                        OutlinedTextField(
                            value = vm.query,
                            onValueChange = { vm.query = it; vm.onSearchQuery(it) },
                            singleLine = true,
                            placeholder = { Text("Buscar libros, cómics o colecciones") },
                            trailingIcon = {
                                IconButton(onClick = { vm.closeSearch() }) {
                                    Icon(Icons.Default.Close, contentDescription = "Cerrar búsqueda")
                                }
                            },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).focusRequester(focus)
                        )
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    TabRow(
                        selectedTabIndex = vm.libTab.ordinal,
                        containerColor = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        Tab(
                            selected = !comics,
                            onClick = { vm.selectLibTab(LibTab.BOOKS) },
                            text = { Text("Libros") }
                        )
                        Tab(
                            selected = comics,
                            onClick = { vm.selectLibTab(LibTab.COMICS) },
                            text = { Text("Cómics") }
                        )
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (f in StatusFilter.entries) {
                            FilterChip(
                                selected = vm.libFilter == f,
                                onClick = { vm.changeLibFilter(f) },
                                label = { Text(f.label) }
                            )
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box {
                            TextButton(onClick = { sortMenu = true }) {
                                Text("Ordenar: ${vm.libSort.label}")
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                for (m in SortMode.entries) {
                                    DropdownMenuItem(
                                        text = { Text(m.label) },
                                        trailingIcon = {
                                            if (vm.libSort == m) Icon(Icons.Default.Check, contentDescription = "Activo")
                                        },
                                        onClick = { sortMenu = false; vm.changeLibSort(m) }
                                    )
                                }
                            }
                        }
                        Text(
                            if (shown.size == 1) "1 elemento" else "${shown.size} elementos",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (vm.folderLost) item(span = { GridItemSpan(maxLineSpan) }) { FolderBanner(onPickFolder) }
                if (vm.scanning) item(span = { GridItemSpan(maxLineSpan) }) { ScanBar(vm.scanDone, vm.scanTotal) }
                if (vm.fetchingCovers) item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        "Buscando portadas que faltan…",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (shown.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            when {
                                filtering && tabItems.isNotEmpty() -> "Nada coincide con la búsqueda o el filtro."
                                vm.scanning -> "Buscando libros…"
                                comics -> "No hay cómics (CBZ/CBR) en la carpeta elegida."
                                else -> "No hay libros (EPUB/PDF) en la carpeta elegida."
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 24.dp)
                        )
                    }
                }
                if (otherCount > 0) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        TextButton(onClick = { vm.selectLibTab(if (comics) LibTab.BOOKS else LibTab.COMICS) }) {
                            Text(
                                (if (otherCount == 1) "1 resultado en " else "$otherCount resultados en ") +
                                    if (comics) "Libros" else "Cómics"
                            )
                        }
                    }
                }
                items(shown, key = { it.id }, span = { GridItemSpan(if (vm.libList) maxLineSpan else 1) }) { item ->
                    val selecting = vm.selection.isNotEmpty()
                    val select = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        vm.toggleSelect(item.id)
                    }
                    if (vm.libList) {
                        ItemRow(
                            item,
                            onClick = {
                                if (selecting) vm.toggleSelect(item.id)
                                else when (item) {
                                    is SingleItem -> vm.openBook(item.book)
                                    is SeriesItem -> vm.openSeries(item.key)
                                }
                            },
                            onLongClick = select,
                            selected = item.id in vm.selection,
                            modifier = Modifier.animateItem()
                        )
                    } else {
                        ItemCard(
                            item,
                            onBook = { if (selecting) vm.toggleSelect(it.id) else vm.openBook(it.book) },
                            onSeries = { if (selecting) vm.toggleSelect(it.id) else vm.openSeries(it.key) },
                            onLongBook = { select() },
                            onLongSeries = { select() },
                            selected = item.id in vm.selection,
                            modifier = Modifier.animateItem()
                        )
                    }
                }
            }
        }
        SelectionBar(vm, inSeries = false, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
