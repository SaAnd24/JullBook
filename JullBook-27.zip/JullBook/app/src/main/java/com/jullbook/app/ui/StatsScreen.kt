package com.jullbook.app.ui

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Footprint
import com.jullbook.app.data.MemoryData
import com.jullbook.app.data.Progress
import com.jullbook.app.data.durText
import com.jullbook.app.data.pctText
import com.jullbook.app.data.readsText
import com.jullbook.app.data.statusLabel
import com.jullbook.app.data.volLabel
import java.util.Calendar

private fun dateText(ctx: android.content.Context, t: Long): String =
    DateUtils.formatDateTime(
        ctx, t,
        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_MONTH
    )

private fun bookName(b: Book?, series: String?): String = when {
    b == null -> "Archivo eliminado"
    series != null && b.alias == null -> "$series ${volLabel(b)}"
    else -> if (b.alias != null) b.alias else b.title
}

/** Resumen rápido para Inicio. */
@Composable
fun ReadingSummary(vm: AppViewModel) {
    val mem by produceState(MemoryData.EMPTY, vm.library) { value = vm.loadMemory() }
    val s = mem.stats
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCell("Hoy", durText(s.todayMs), Modifier.weight(1f))
        StatCell("7 días", durText(s.weekMs), Modifier.weight(1f))
        StatCell("Terminados", "${s.finished}", Modifier.weight(1f))
    }
}

@Composable
private fun StatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StatsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val mem by produceState(MemoryData.EMPTY, vm.library) { value = vm.loadMemory() }
    val s = mem.stats
    val facts = remember(vm.library, mem) { Footprint.facts(vm.library, mem, vm.prefs) }
    androidx.compose.runtime.LaunchedEffect(Unit) { vm.onStatsOpened() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver") }
                Text("Tu lectura", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCell("Hoy", durText(s.todayMs), Modifier.weight(1f))
                    StatCell("Últimos 7 días", durText(s.weekMs), Modifier.weight(1f))
                    StatCell("Total", durText(s.totalMs), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCell("Leyendo", "${s.reading}", Modifier.weight(1f))
                    StatCell("Terminados", "${s.finished}", Modifier.weight(1f))
                    StatCell("Sin empezar", "${s.unstarted}", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCell("Sesiones", "${s.sessions}", Modifier.weight(1f))
                    StatCell("Racha", if (s.streak == 1) "1 día" else "${s.streak} días", Modifier.weight(1f))
                    StatCell("Lecturas", "${s.completions}", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCell("Mejor racha", if (facts.bestStreak == 1) "1 día" else "${facts.bestStreak} días", Modifier.weight(1f))
                    StatCell("Páginas", if (facts.pages > 0) "${facts.pages}" else "—", Modifier.weight(1f))
                    StatCell("Descubierto", "${facts.discoveredPct}%", Modifier.weight(1f))
                }
                WeekBars(s.days)
                facts.topCollection?.let { StatLine("Colección más avanzada", "${it.first} · ${it.second}%") }
                facts.mostReread?.let { StatLine("Lo más releído", "${it.first} · ${it.second} veces") }
                facts.topWeekday?.let { StatLine("Día más activo", it.replaceFirstChar { c -> c.uppercase() }) }
                facts.topMonth?.let { StatLine("Mes más activo", it) }
                // Entrada a "Tu huella": la vista personal.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f))
                        .clickable { vm.openFootprint() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Tu huella", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("Cómo usas tu biblioteca, en pocas frases", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f))
                    }
                }
            }
        }
        item { SectionTitle("Libros") }
        if (mem.books.isEmpty()) {
            item { Empty("Aún no has empezado ninguna lectura.") }
        }
        items(mem.books, key = { "bk${it.first.id}" }) { (b, p) ->
            BookMemoryRow(ctx, b, p, vm.library.bookSeries[b.id]?.name)
        }
        item { SectionTitle("Historial") }
        if (mem.history.isEmpty()) {
            item { Empty("Las sesiones de lectura aparecerán aquí.") }
        }
        items(mem.history, key = { "h${it.session.id}" }) { h ->
            val ss = h.session
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
                Text(
                    bookName(h.book, h.series),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${dateText(ctx, ss.start)} · ${durText(ss.duration)} · ${pctText(ss.startPct)} → ${pctText(ss.endPct)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
private fun Empty(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}

@Composable
private fun BookMemoryRow(ctx: android.content.Context, b: Book, p: Progress, series: String?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        CoverImage(b.coverPath, b.title, Modifier.size(width = 40.dp, height = 58.dp).clip(RoundedCornerShape(6.dp)), format = b.format)
        Column(Modifier.weight(1f)) {
            Text(
                bookName(b, series),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOf(
                    statusLabel(b, p),
                    pctText(p.percent),
                    "máx. ${pctText(maxOf(p.maxPercent, p.percent))}",
                    readsText(b.reads)
                ).filter { it.isNotEmpty() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Leído ${durText(p.readMs)} · última sesión ${dateText(ctx, p.lastRead)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun WeekBars(days: List<Long>) {
    val max = (days.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val labels = listOf("D", "L", "M", "X", "J", "V", "S")
    val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
    Row(
        Modifier.fillMaxWidth().height(72.dp).padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        for (i in 0 until 7) {
            val frac = days.getOrElse(i) { 0L }.toFloat() / max
            Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((44f * frac).coerceAtLeast(3f).dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (days.getOrElse(i) { 0L } > 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHighest
                        )
                )
                Text(
                    labels[((today - (6 - i)) % 7 + 7) % 7],
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
