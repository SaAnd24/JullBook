package com.jullbook.app.discover

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Fuentes de búsqueda: varias públicas de serie (Gutenberg, Internet Archive, Open Library, Google Books, Wikisource: solo contenido de descarga libre) más las que añada el usuario
 * (cualquier catálogo OPDS al que tenga acceso: Calibre-Web, Komga, Kavita, biblioteca propia…).
 * Se guarda en su propio archivo de preferencias: no toca los ajustes existentes.
 */
class SourceStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jullbook_discover", Context.MODE_PRIVATE)

    private fun custom(): List<SourceConfig> {
        val raw = sp.getString("sources", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                SourceConfig(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    url = o.optString("url"),
                    user = o.optString("user").ifBlank { null },
                    pass = o.optString("pass").ifBlank { null },
                    langTerm = o.optString("langTerm").ifBlank { null },
                    builtIn = false
                )
            }.filter { it.id.isNotBlank() && it.url.startsWith("https://", ignoreCase = true) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveCustom(list: List<SourceConfig>) {
        val arr = JSONArray()
        for (s in list) {
            arr.put(
                JSONObject()
                    .put("id", s.id).put("name", s.name).put("url", s.url)
                    .put("user", s.user ?: "").put("pass", s.pass ?: "").put("langTerm", s.langTerm ?: "")
            )
        }
        sp.edit().putString("sources", arr.toString()).apply()
    }

    fun all(): List<SourceConfig> = BUILT_IN + custom()

    private fun disabled(): Set<String> = sp.getStringSet("disabled", emptySet()) ?: emptySet()

    fun isEnabled(id: String): Boolean = id !in disabled()

    fun setEnabled(id: String, on: Boolean) {
        val set = HashSet(disabled())
        if (on) set.remove(id) else set.add(id)
        sp.edit().putStringSet("disabled", set).apply()
    }

    fun add(name: String, url: String, user: String?, pass: String?): SourceConfig {
        val cfg = SourceConfig(
            id = "c" + System.currentTimeMillis(),
            name = name.trim(), url = url.trim(),
            user = user?.trim()?.ifBlank { null }, pass = pass?.ifBlank { null },
            langTerm = null, builtIn = false
        )
        saveCustom(custom() + cfg)
        return cfg
    }

    fun remove(id: String) {
        saveCustom(custom().filter { it.id != id })
        setEnabled(id, true)
    }

    companion object {
        /** Catálogo público OPDS de libros de dominio público. Admite pedir el idioma en la propia consulta (l.es). */
        val GUTENBERG = SourceConfig(
            id = "gutenberg",
            name = "Project Gutenberg",
            url = "https://www.gutenberg.org/ebooks/search.opds/?query={searchTerms}",
            user = null, pass = null,
            langTerm = "l.{code}",
            builtIn = true,
            note = "Catálogo público · dominio público"
        )

        val ARCHIVE = SourceConfig(
            id = "archive", name = "Internet Archive", url = "https://archive.org",
            user = null, pass = null, langTerm = null, builtIn = true, kind = "archive",
            note = "Millones de textos · solo descarga libre (sin préstamo)"
        )

        val OPENLIBRARY = SourceConfig(
            id = "openlibrary", name = "Open Library", url = "https://openlibrary.org",
            user = null, pass = null, langTerm = null, builtIn = true, kind = "openlibrary",
            note = "Obras con ejemplar de acceso público"
        )

        val GOOGLE = SourceConfig(
            id = "google", name = "Google Books", url = "https://www.googleapis.com/books/v1",
            user = null, pass = null, langTerm = null, builtIn = true, kind = "google",
            note = "Libros gratuitos con EPUB/PDF descargable"
        )

        val WIKISOURCE = SourceConfig(
            id = "wikisource", name = "Wikisource", url = "https://wikisource.org",
            user = null, pass = null, langTerm = null, builtIn = true, kind = "wikisource",
            note = "Dominio público transcrito · EPUB generado al vuelo"
        )

        val BUILT_IN = listOf(GUTENBERG, ARCHIVE, OPENLIBRARY, GOOGLE, WIKISOURCE)
    }
}
