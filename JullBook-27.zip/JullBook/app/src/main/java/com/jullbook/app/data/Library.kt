package com.jullbook.app.data

class Vol(val book: Book, val progress: Progress?)

sealed interface LibItem {
    val id: String
    val sortName: String
}

class SingleItem(val book: Book, val progress: Progress?) : LibItem {
    override val id: String get() = "b${book.id}"
    override val sortName: String get() = book.title
}

class SeriesItem(val key: String, val name: String, val volumes: List<Vol>, val isBooks: Boolean = false) : LibItem {
    override val id: String get() = "s$key"
    override val sortName: String get() = name

    /** Saga creada a mano (carpeta virtual). */
    val isManual: Boolean get() = key.startsWith("m:")
    val manualId: Long? get() = if (isManual) key.removePrefix("m:").toLongOrNull() else null

    /** Colección virtual de cómics que solo traen numeración. */
    val isUnnamed: Boolean get() = key == UNNAMED_KEY

    /** Progreso general: media del avance de todos los tomos. */
    val percent: Float
        get() {
            if (volumes.isEmpty()) return 0f
            var sum = 0.0
            for (v in volumes) {
                val p = v.progress
                sum += if (p == null) 0.0 else if (p.status == ST_FINISHED) 1.0 else p.percent.toDouble()
            }
            return (sum / volumes.size).toFloat()
        }

    val coverPath: String? get() = volumes.firstNotNullOfOrNull { it.book.coverPath }

    /** Veces que se ha leído la colección completa (el mínimo entre sus tomos). */
    val reads: Int get() = volumes.minOfOrNull { it.book.reads } ?: 0

    /** Algún tomo ya terminado antes está en una nueva lectura. */
    val rereading: Boolean get() = volumes.any { isRereading(it.book, it.progress) }

    /** Última lectura de cualquiera de sus tomos (0 si no hay). */
    val lastRead: Long get() = volumes.maxOfOrNull { it.progress?.lastRead ?: 0L } ?: 0L

    /** Tomo actual: el último leído si no está terminado; si no, el siguiente sin terminar. */
    fun target(): Vol? {
        val last = volumes.filter { it.progress != null }.maxByOrNull { it.progress!!.lastRead }
        if (last != null && last.progress!!.status != ST_FINISHED) return last
        val start = if (last == null) 0 else volumes.indexOfFirst { it.book.id == last.book.id } + 1
        return volumes.drop(start).firstOrNull { it.progress?.status != ST_FINISHED }
            ?: volumes.firstOrNull { it.progress?.status != ST_FINISHED }
    }
}

class ContinueEntry(val book: Book, val progress: Progress?, val series: SeriesItem?)

class Library(
    val items: List<LibItem>,
    val cont: List<ContinueEntry>,
    val recent: List<ContinueEntry>,
    val books: Map<Long, Book>,
    val series: Map<String, SeriesItem>,
    /** Saga a la que pertenece cada libro (por id). */
    val bookSeries: Map<Long, SeriesItem> = emptyMap(),
    /** Libros con corrección manual (saga, suelto o número). */
    val overridden: Set<Long> = emptySet()
) {
    companion object {
        val EMPTY = Library(emptyList(), emptyList(), emptyList(), emptyMap(), emptyMap())
    }
}

object LibraryBuilder {
    private fun volOrder(): Comparator<Book> = Comparator { a, b ->
        val c = (a.number ?: Int.MAX_VALUE).compareTo(b.number ?: Int.MAX_VALUE)
        if (c != 0) c else naturalCompare(a.fileName, b.fileName)
    }

    fun build(
        books: List<Book>,
        progAll: Map<Long, Progress>,
        overrides: Map<String, BookOverride> = emptyMap(),
        manual: List<ManualSeries> = emptyList(),
        aliases: Map<String, String> = emptyMap(),
        reads: Map<Long, Int> = emptyMap()
    ): Library {
        // Lecturas reiniciadas (ST_UNREAD) cuentan como "sin empezar" hasta que se vuelvan a abrir.
        val prog = progAll.filterValues { it.status != ST_UNREAD }
        val manualById = manual.associateBy { it.id }
        val overridden = HashSet<Long>()

        // 1) Libros efectivos: la organización manual tiene prioridad sobre la automática.
        val eff = ArrayList<Book>(books.size)
        val forced = HashMap<String, MutableList<Book>>() // grp automático forzado
        val forcedNames = HashMap<String, String>()
        val manualBooks = HashMap<Long, MutableList<Book>>()
        val natural = ArrayList<Book>()
        for (b in books) {
            val ov = overrides[b.uri]
            var e = b.copy(reads = reads[b.id] ?: 0)
            // Nombre interno elegido por el usuario (solo cómo se muestra; el archivo real no cambia).
            aliases[b.uri]?.let { e = e.copy(title = it, alias = it) }
            if (ov != null) {
                overridden.add(b.id)
                if (ov.number != null) e = e.copy(number = ov.number)
            }
            val comic = b.format == Format.COMIC
            // Libros y cómics se organizan igual, pero los libros solo pueden estar en colecciones manuales.
            val rawGrp = ov?.grp ?: GRP_NONE
            val grp = if (comic || rawGrp == GRP_STANDALONE || rawGrp.startsWith("m:")) rawGrp else GRP_NONE
            when {
                grp == GRP_STANDALONE -> {
                    e = e.copy(series = null, seriesKey = null)
                    eff.add(e)
                }
                grp.startsWith("m:") && manualById.containsKey(grp.removePrefix("m:").toLongOrNull() ?: -1L) -> {
                    val id = grp.removePrefix("m:").toLong()
                    if (e.number == null) SeriesParser.numbersOf(e.fileName)?.let { e = e.copy(number = it.first) }
                    e = e.copy(series = manualById[id]!!.name, seriesKey = grp)
                    eff.add(e)
                    manualBooks.getOrPut(id) { ArrayList() }.add(e)
                }
                grp != GRP_NONE && !grp.startsWith("m:") -> {
                    val nm = ov?.gname ?: grp
                    if (e.number == null) SeriesParser.numbersOf(e.fileName)?.let { e = e.copy(number = it.first) }
                    e = e.copy(series = nm, seriesKey = grp)
                    eff.add(e)
                    forced.getOrPut(grp) { ArrayList() }.add(e)
                    forcedNames[grp] = nm
                }
                else -> {
                    eff.add(e)
                    if (comic && e.seriesKey != null) natural.add(e)
                }
            }
        }

        // 2) Series automáticas (solo cómics). Si hay números repetidos en carpetas distintas, no se mezclan.
        val buckets = LinkedHashMap<String, MutableList<Book>>()
        val names = HashMap<String, String>()
        for ((key, list) in natural.groupBy { it.seriesKey!! }) {
            val dup = list.groupBy { it.number }.any { it.key != null && it.value.size > 1 }
            val folders = list.map { SeriesParser.keyOf(it.folder) }.toSet()
            val parts: Map<String, List<Book>> =
                if (key != UNNAMED_KEY && dup && folders.size > 1) list.groupBy { key + "|" + SeriesParser.keyOf(it.folder) } else mapOf(key to list)
            for ((k, l) in parts) {
                buckets[k] = ArrayList(l)
                names[k] = if (key == UNNAMED_KEY) UNNAMED_NAME
                else l.groupingBy { it.series ?: "" }.eachCount().maxByOrNull { it.value }?.key ?: key
            }
        }
        for ((k, l) in forced) {
            buckets.getOrPut(k) { ArrayList() }.addAll(l)
            if (!names.containsKey(k)) names[k] = if (k == UNNAMED_KEY) UNNAMED_NAME else forcedNames[k] ?: k
        }

        val seriesMap = HashMap<String, SeriesItem>()
        val bookSeries = HashMap<Long, SeriesItem>()
        for ((k, l) in buckets) {
            // "Sin nombre" agrupa siempre, aunque solo haya un cómic o se repitan números.
            if (k != UNNAMED_KEY) {
                if (l.size < 2) continue
                // Agrupación automática dudosa (mismo número repetido, sin numeración distinta): no se agrupa.
                if (k !in forced && l.mapNotNull { it.number }.toSet().size < 2) continue
            }
            val s = SeriesItem(k, names[k] ?: k, l.sortedWith(volOrder()).map { Vol(it, prog[it.id]) })
            seriesMap[k] = s
            for (b in l) bookSeries[b.id] = s
        }
        // Sagas manuales: existen aunque estén vacías o tengan un solo tomo.
        for (m in manual) {
            val key = "m:${m.id}"
            val l = manualBooks[m.id] ?: emptyList<Book>()
            val s = SeriesItem(key, m.name, l.sortedWith(volOrder()).map { Vol(it, prog[it.id]) }, m.isBooks)
            seriesMap[key] = s
            for (b in l) bookSeries[b.id] = s
        }

        val items = ArrayList<LibItem>()
        items.addAll(seriesMap.values.filter { it.volumes.isNotEmpty() })
        for (b in eff) if (!bookSeries.containsKey(b.id)) items.add(SingleItem(b, prog[b.id]))
        items.sortWith(Comparator { a, b -> naturalCompare(a.sortName, b.sortName) })

        val byId = eff.associateBy { it.id }
        val byRead = prog.values.sortedByDescending { it.lastRead }

        val cont = ArrayList<ContinueEntry>()
        val seen = HashSet<String>()
        for (p in byRead) {
            val b = byId[p.bookId] ?: continue
            val s = bookSeries[b.id]
            if (s != null) {
                if (!seen.add(s.key)) continue
                val t = s.target() ?: continue
                cont.add(ContinueEntry(t.book, t.progress, s))
            } else if (p.status != ST_FINISHED && seen.add("b${b.id}")) {
                cont.add(ContinueEntry(b, p, null))
            }
            if (cont.size >= 12) break
        }

        val recent = ArrayList<ContinueEntry>()
        for (p in byRead) {
            val b = byId[p.bookId] ?: continue
            recent.add(ContinueEntry(b, p, bookSeries[b.id]))
            if (recent.size >= 8) break
        }
        return Library(items, cont, recent, byId, seriesMap, bookSeries, overridden)
    }
}
