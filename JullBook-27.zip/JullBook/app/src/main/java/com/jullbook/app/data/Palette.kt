package com.jullbook.app.data

import android.graphics.Bitmap
import android.util.LruCache
import androidx.core.graphics.ColorUtils

/** Paleta de una portada: 4 colores ordenados por presencia. Se calcula una sola vez por imagen y se guarda en memoria. */
class CoverPalette(val colors: List<Int>, val neutral: Boolean)

object PaletteCache {
    private val cache = LruCache<String, CoverPalette>(64)

    fun get(path: String): CoverPalette? {
        cache.get(path)?.let { return it }
        val bmp = CoverCache.get(path) ?: return null
        val p = extract(bmp)
        cache.put(path, p)
        return p
    }

    private fun hsl(argb: Int): FloatArray {
        val a = FloatArray(3)
        ColorUtils.colorToHSL(argb, a)
        return a
    }

    private fun fromHsl(h: Float, s: Float, l: Float): Int =
        ColorUtils.HSLToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f)))

    /** Cubos de matiz (12) ponderados por saturación y brillo; se descartan grises y extremos casi negros/blancos. */
    fun extract(src: Bitmap): CoverPalette {
        val small = Bitmap.createScaledBitmap(src, 24, 36, true)
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== src) small.recycle()

        val bins = 12
        val weight = DoubleArray(bins)
        val sumH = DoubleArray(bins)
        val sumS = DoubleArray(bins)
        val sumL = DoubleArray(bins)
        var nW = 0.0
        var nL = 0.0
        for (i in px.indices) {
            val y = i / w
            val x = i % w
            val hh = hsl(px[i])
            val s = hh[1]
            val l = hh[2]
            // Más peso al centro de la portada (suele ser lo más característico).
            val cx = 1.0 - Math.abs(x - w / 2.0) / (w / 2.0) * 0.4
            val cy = 1.0 - Math.abs(y - h / 2.0) / (h / 2.0) * 0.4
            val pos = cx * cy
            if (s < 0.18f || l < 0.10f || l > 0.93f) {
                nW += pos
                nL += l * pos
                continue
            }
            val wt = (s * (1.0 - Math.abs(l - 0.5) * 1.2)).coerceAtLeast(0.02) * pos
            val b = ((hh[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
            weight[b] += wt
            sumH[b] += hh[0] * wt
            sumS[b] += s * wt
            sumL[b] += l * wt
        }
        val order = (0 until bins).filter { weight[it] > 0.0 }.sortedByDescending { weight[it] }
        val total = weight.sum()
        if (order.isEmpty() || total < 1.5) {
            // Portada casi en blanco y negro: paleta neutra cálida derivada de su luminosidad media.
            val l = if (nW > 0) (nL / nW).toFloat() else 0.4f
            val base = fromHsl(35f, 0.25f, l.coerceIn(0.25f, 0.6f))
            return CoverPalette(listOf(base, fromHsl(30f, 0.2f, 0.35f), fromHsl(45f, 0.3f, 0.5f), fromHsl(20f, 0.15f, 0.28f)), true)
        }
        val picked = ArrayList<Triple<Float, Float, Float>>() // h, s, l
        for (b in order) {
            val hue = (sumH[b] / weight[b]).toFloat()
            // Evita dos colores casi iguales en la paleta.
            if (picked.any { hueDist(it.first, hue) < 28f }) continue
            picked.add(Triple(hue, (sumS[b] / weight[b]).toFloat(), (sumL[b] / weight[b]).toFloat()))
            if (picked.size == 4) break
        }
        // Completa hasta 4 con variaciones del color dominante.
        val dom = picked[0]
        var k = 0
        val shifts = floatArrayOf(28f, -28f, 55f, -55f)
        while (picked.size < 4) {
            picked.add(Triple(dom.first + shifts[k % 4], (dom.second * 0.9f).coerceAtLeast(0.4f), (dom.third + if (k % 2 == 0) 0.08f else -0.08f).coerceIn(0.25f, 0.7f)))
            k++
        }
        val colors = picked.map { fromHsl(it.first, it.second.coerceIn(0.35f, 0.95f), it.third.coerceIn(0.28f, 0.68f)) }
        return CoverPalette(colors, false)
    }

    private fun hueDist(a: Float, b: Float): Float {
        val d = Math.abs(a - b) % 360f
        return if (d > 180f) 360f - d else d
    }
}
