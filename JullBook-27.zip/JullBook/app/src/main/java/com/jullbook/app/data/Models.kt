package com.jullbook.app.data

enum class Format { EPUB, PDF, COMIC }

const val ST_UNREAD = 0
const val ST_READING = 1
const val ST_FINISHED = 2

data class Book(
    val id: Long,
    val uri: String,
    val fileName: String,
    val format: Format,
    val title: String,
    val author: String?,
    val series: String?,
    val seriesKey: String?,
    val number: Int?,
    val folder: String,
    val pageCount: Int,
    val size: Long,
    val modified: Long,
    val coverPath: String?,
    val processed: Boolean,
    val isbn: String? = null,
    /** Nombre interno elegido por el usuario (el archivo real no se toca). */
    val alias: String? = null,
    /** Veces que se ha leído completo (registro de lecturas terminadas). */
    val reads: Int = 0,
    /** Momento en que se añadió a la biblioteca (0 = anterior a JullBook 1.1, desconocido). */
    val added: Long = 0L
)

/** pos = página / capítulo, sub = bloque dentro del capítulo (EPUB), frac = desplazamiento dentro del elemento. */
data class Progress(
    val bookId: Long,
    val pos: Int,
    val sub: Int,
    val frac: Float,
    val percent: Float,
    val lastRead: Long,
    val status: Int,
    val maxPercent: Float = 0f,
    val readMs: Long = 0L,
    val firstRead: Long = 0L,
    val finishedAt: Long = 0L,
    val sessions: Int = 0
)
