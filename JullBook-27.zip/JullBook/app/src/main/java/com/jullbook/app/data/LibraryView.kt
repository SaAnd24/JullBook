package com.jullbook.app.data

/** Ordenación básica de la Biblioteca y de las colecciones. */
enum class SortMode(val label: String) {
    NAME("Nombre"),
    LAST("Última lectura"),
    PROGRESS("Progreso"),
    NUMBER("Número");

    companion object {
        fun of(s: String, def: SortMode): SortMode = entries.firstOrNull { it.name == s } ?: def
    }
}

/** Filtro por estado de lectura. */
enum class StatusFilter(val label: String) {
    ALL("Todos"),
    UNSTARTED("Sin empezar"),
    READING("Leyendo"),
    FINISHED("Terminados");

    companion object {
        fun of(s: String): StatusFilter = entries.firstOrNull { it.name == s } ?: ALL
    }
}

object LibraryView {

    /** Estado de un libro/cómic: sin empezar, leyendo o terminado. */
    fun statusOf(p: Progress?): StatusFilter = when {
        p == null || p.status == ST_UNREAD -> StatusFilter.UNSTARTED
        p.status == ST_FINISHED -> StatusFilter.FINISHED
        else -> StatusFilter.READING
    }

    /** Estado de una colección: terminada si todos sus tomos lo están, sin empezar si ninguno se ha abierto. */
    fun statusOf(s: SeriesItem): StatusFilter {
        if (s.volumes.isEmpty()) return StatusFilter.UNSTARTED
        val states = s.volumes.map { statusOf(it.progress) }
        return when {
            states.all { it == StatusFilter.FINISHED } -> StatusFilter.FINISHED
            states.all { it == StatusFilter.UNSTARTED } -> StatusFilter.UNSTARTED
            else -> StatusFilter.READING
        }
    }

    fun statusOf(item: LibItem): StatusFilter = when (item) {
        is SingleItem -> statusOf(item.progress)
        is SeriesItem -> statusOf(item)
    }

    fun percentOf(item: LibItem): Float = when (item) {
        is SingleItem -> item.progress?.let { if (it.status == ST_FINISHED) 1f else it.percent } ?: 0f
        is SeriesItem -> item.percent
    }

    fun lastReadOf(item: LibItem): Long = when (item) {
        is SingleItem -> item.progress?.lastRead ?: 0L
        is SeriesItem -> item.lastRead
    }

    private fun numberOf(item: LibItem): Int? = when (item) {
        is SingleItem -> item.book.number
        is SeriesItem -> item.volumes.mapNotNull { it.book.number }.minOrNull()
    }

    /** Colecciones sin ningún elemento no se muestran. */
    fun visible(item: LibItem): Boolean = item !is SeriesItem || item.volumes.isNotEmpty()

    /** Texto en el que busca "Buscar": título, autor, archivo, nombre interno y los de los tomos de una colección. */
    private fun haystack(item: LibItem): String = when (item) {
        is SingleItem -> bookText(item.book)
        is SeriesItem -> item.name + " " + item.volumes.joinToString(" ") { bookText(it.book) }
    }

    private fun bookText(b: Book): String =
        listOfNotNull(b.title, b.author, b.fileName, b.alias, b.series).joinToString(" ")

    /** Coincidencia simple sin distinguir mayúsculas ni acentos; todas las palabras deben aparecer. */
    fun matches(item: LibItem, query: String): Boolean {
        val words = SeriesParser.keyOf(query).split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return true
        val h = SeriesParser.keyOf(haystack(item))
        return words.all { h.contains(it) }
    }

    fun nameCompare(a: LibItem, b: LibItem): Int = naturalCompare(a.sortName.lowercase(), b.sortName.lowercase())

    fun comparator(mode: SortMode): Comparator<LibItem> = when (mode) {
        SortMode.NAME -> Comparator { a, b -> nameCompare(a, b) }
        // Lo último leído primero; lo que nunca se ha leído, al final y por nombre.
        SortMode.LAST -> Comparator { a, b ->
            val c = lastReadOf(b).compareTo(lastReadOf(a))
            if (c != 0) c else nameCompare(a, b)
        }
        // Lo más avanzado primero.
        SortMode.PROGRESS -> Comparator { a, b ->
            val c = percentOf(b).compareTo(percentOf(a))
            if (c != 0) c else nameCompare(a, b)
        }
        // Por número; lo que no tiene número, al final y por nombre.
        SortMode.NUMBER -> Comparator { a, b ->
            val c = (numberOf(a) ?: Int.MAX_VALUE).compareTo(numberOf(b) ?: Int.MAX_VALUE)
            if (c != 0) c else nameCompare(a, b)
        }
    }

    /** Aplica ocultar vacías + búsqueda + filtro de estado + orden. */
    fun apply(items: List<LibItem>, query: String, filter: StatusFilter, sort: SortMode): List<LibItem> =
        items
            .filter { visible(it) }
            .filter { matches(it, query) }
            .filter { filter == StatusFilter.ALL || statusOf(it) == filter }
            .sortedWith(comparator(sort))

    // ---- Tomos dentro de una colección ----

    fun volComparator(mode: SortMode): Comparator<Vol> = when (mode) {
        SortMode.NUMBER -> Comparator { a, b ->
            val c = (a.book.number ?: Int.MAX_VALUE).compareTo(b.book.number ?: Int.MAX_VALUE)
            if (c != 0) c else naturalCompare(a.book.fileName, b.book.fileName)
        }
        SortMode.NAME -> Comparator { a, b -> naturalCompare(a.book.title.lowercase(), b.book.title.lowercase()) }
        SortMode.LAST -> Comparator { a, b ->
            val c = (b.progress?.lastRead ?: 0L).compareTo(a.progress?.lastRead ?: 0L)
            if (c != 0) c else naturalCompare(a.book.fileName, b.book.fileName)
        }
        SortMode.PROGRESS -> Comparator { a, b ->
            val c = volPercent(b).compareTo(volPercent(a))
            if (c != 0) c else naturalCompare(a.book.fileName, b.book.fileName)
        }
    }

    fun volPercent(v: Vol): Float = v.progress?.let { if (it.status == ST_FINISHED) 1f else it.percent } ?: 0f
}
