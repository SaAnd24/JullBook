package com.jullbook.app.data

/** Datos reales derivados de la biblioteca y la memoria de lectura. Nada se inventa: lo que no existe queda en null/0. */
class Facts(
    val bestStreak: Int,
    val pages: Long,
    val discoveredPct: Int,
    val touched: Int,
    val total: Int,
    val booksCount: Int,
    val comicsCount: Int,
    val topCollection: Pair<String, Int>?,
    val mostReread: Pair<String, Int>?,
    val topWeekday: String?,
    val topMonth: String?
)

/** Una frase de "Tu huella": [big] es el dato destacado y [text] la frase completa. */
class FootLine(val big: String, val text: String)

object Footprint {
    private val WEEKDAYS = arrayOf("domingos", "lunes", "martes", "miércoles", "jueves", "viernes", "sábados")
    private val MONTHS = arrayOf("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")

    fun facts(lib: Library, mem: MemoryData, prefs: Prefs): Facts {
        val st = mem.stats
        var touched = 0
        var pages = 0L
        fun page(b: Book, p: Progress?) {
            if (b.format == Format.EPUB || b.pageCount <= 0) return
            pages += b.reads.toLong() * b.pageCount
            if (p != null && p.status == ST_READING) pages += (p.percent * b.pageCount).toLong()
        }
        for (item in lib.items) {
            when (item) {
                is SingleItem -> {
                    if (item.progress != null || item.book.reads > 0) touched++
                    page(item.book, item.progress)
                }
                is SeriesItem -> for (v in item.volumes) {
                    if (v.progress != null || v.book.reads > 0) touched++
                    page(v.book, v.progress)
                }
            }
        }
        val total = lib.books.size
        val top = lib.series.values
            .filter { !it.isUnnamed && it.volumes.size >= 2 && LibraryView.statusOf(it) == StatusFilter.READING }
            .maxByOrNull { it.percent }
            ?.takeIf { it.percent >= 0.05f }
            ?.let { it.name to (it.percent * 100).toInt() }
        val reread = lib.books.values.filter { it.reads >= 2 }.maxByOrNull { it.reads }
            ?.let { SurpriseEngine.displayTitle(it, lib.bookSeries[it.id]) to it.reads }
        val enough = st.sessions >= 5
        return Facts(
            bestStreak = maxOf(st.bestStreak, prefs.counter("best_streak").toInt(), st.streak),
            pages = pages,
            discoveredPct = if (total <= 0) 0 else touched * 100 / total,
            touched = touched,
            total = total,
            booksCount = lib.books.values.count { it.format != Format.COMIC },
            comicsCount = lib.books.values.count { it.format == Format.COMIC },
            topCollection = top,
            mostReread = reread,
            topWeekday = if (enough && st.topWeekday >= 0) WEEKDAYS[st.topWeekday] else null,
            topMonth = if (st.sessions >= 10 && st.topMonth >= 0) MONTHS[st.topMonth] else null
        )
    }

    /** Reglas locales: cada frase solo aparece si el dato existe. */
    fun lines(lib: Library, mem: MemoryData, prefs: Prefs): List<FootLine> {
        val st = mem.stats
        val f = facts(lib, mem, prefs)
        val out = ArrayList<FootLine>()
        if (st.finished > 0) out.add(FootLine("${st.finished}", "Has terminado ${st.finished} " + if (st.finished == 1) "título." else "títulos."))
        val unopened = f.total - f.touched
        if (unopened > 0) out.add(FootLine("$unopened", "Tienes $unopened " + (if (unopened == 1) "título que todavía no has abierto." else "títulos que todavía no has abierto.")))
        val cm = st.recentComicMs
        val bm = st.recentBookMs
        if (cm + bm >= 30 * 60_000L) {
            if (cm >= bm * 1.5) out.add(FootLine("📚", "Últimamente lees más cómics que libros."))
            else if (bm >= cm * 1.5) out.add(FootLine("📖", "Últimamente lees más libros que cómics."))
        }
        if (st.totalMs >= 60_000L) out.add(FootLine(durText(st.totalMs), "Llevas ${durText(st.totalMs)} de lectura en ${st.sessions} " + (if (st.sessions == 1) "sesión." else "sesiones.")))
        if (f.bestStreak >= 2) out.add(FootLine("${f.bestStreak}", "Tu mejor racha es de ${f.bestStreak} días seguidos."))
        f.topWeekday?.let { out.add(FootLine("📅", "Los $it son tus días más lectores.")) }
        f.topMonth?.let { out.add(FootLine("🗓️", "$it es tu mes más activo.")) }
        f.topCollection?.let { out.add(FootLine("${it.second}%", "«${it.first}» es tu colección más avanzada.")) }
        f.mostReread?.let { out.add(FootLine("${it.second}×", "«${it.first}» es lo que más has releído: ${it.second} veces.")) }
        if (f.touched > 0 && f.total > 0) out.add(FootLine("${f.discoveredPct}%", "Has abierto el ${f.discoveredPct}% de tu biblioteca."))
        if (f.pages >= 50) out.add(FootLine("${f.pages}", "Has pasado unas ${f.pages} páginas de PDF y cómics."))
        if (f.total > 0) out.add(FootLine("${f.total}", "Tu biblioteca tiene ${f.total} títulos: ${f.booksCount} libros y ${f.comicsCount} cómics."))
        return out
    }
}
