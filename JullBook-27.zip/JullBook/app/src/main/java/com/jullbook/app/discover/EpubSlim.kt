package com.jullbook.app.discover

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Adelgaza un EPUB pesado tras descargarlo: reduce las imágenes grandes (JPG/PNG) a un tamaño más que
 * suficiente para una pantalla de móvil y las recomprime. Los nombres y formatos de las imágenes no cambian,
 * así que el EPUB sigue siendo válido sin tocar su contenido. El texto no se modifica.
 */
object EpubSlim {
    /** Solo se intenta con archivos mayores que esto. */
    const val THRESHOLD = 6L * 1024 * 1024

    private const val MAX_SIDE = 1600
    private const val JPEG_QUALITY = 72
    private const val MIN_JPEG = 150 * 1024
    private const val MIN_PNG = 300 * 1024

    /** Modo agresivo (archivos enormes): imágenes más pequeñas y más comprimidas. */
    const val HUGE = 100L * 1024 * 1024
    private const val AGG_SIDE = 1200
    private const val AGG_QUALITY = 58
    private const val AGG_MIN = 60 * 1024

    /** Escribe en [dst] la versión reducida. Devuelve true si alguna imagen se pudo reducir. [check] permite cancelar. */
    fun slim(src: File, dst: File, aggressive: Boolean, check: () -> Unit): Boolean {
        var changed = false
        ZipFile(src).use { zf ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(dst))).use { zo ->
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    check()
                    val e = entries.nextElement()
                    if (e.isDirectory) continue
                    val raw = zf.getInputStream(e).use { it.readBytes() }
                    val lower = e.name.lowercase()
                    var data = raw
                    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) {
                        shrink(raw, false, aggressive)?.let { data = it; changed = true }
                    } else if (lower.endsWith(".png")) {
                        shrink(raw, true, aggressive)?.let { data = it; changed = true }
                    }
                    write(zo, e.name, data)
                }
            }
        }
        return changed
    }

    internal fun write(zo: ZipOutputStream, name: String, data: ByteArray) {
        val ze = ZipEntry(name)
        if (name == "mimetype") {
            // El EPUB exige que "mimetype" vaya primero y sin comprimir.
            val crc = CRC32()
            crc.update(data)
            ze.method = ZipEntry.STORED
            ze.size = data.size.toLong()
            ze.compressedSize = data.size.toLong()
            ze.crc = crc.value
        }
        zo.putNextEntry(ze)
        zo.write(data)
        zo.closeEntry()
    }

    /** Devuelve la imagen reducida, o null si no merece la pena (o no se pudo procesar). */
    private fun shrink(raw: ByteArray, png: Boolean, aggressive: Boolean): ByteArray? {
        val maxSide = if (aggressive) AGG_SIDE else MAX_SIDE
        val quality = if (aggressive) AGG_QUALITY else JPEG_QUALITY
        val minSize = if (aggressive) (if (png) 150 * 1024 else AGG_MIN) else (if (png) MIN_PNG else MIN_JPEG)
        if (raw.size < minSize) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
            val big = maxOf(bounds.outWidth, bounds.outHeight)
            if (big <= 0) return null
            var sample = 1
            while (big / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, opts) ?: return null
            val side = maxOf(bmp.width, bmp.height)
            if (side > maxSide) {
                val k = maxSide.toFloat() / side
                val scaled = Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * k).toInt().coerceAtLeast(1),
                    (bmp.height * k).toInt().coerceAtLeast(1),
                    true
                )
                if (scaled !== bmp) bmp.recycle()
                bmp = scaled
            }
            val out = ByteArrayOutputStream(raw.size / 2)
            if (png) bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            else bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bmp.recycle()
            if (out.size() < raw.size * 0.9) out.toByteArray() else null
        } catch (e: Throwable) {
            null
        }
    }
}
