package com.jullbook.app.data

import java.text.Normalizer

/** Colección virtual de los cómics que solo traen numeración ("001.cbz", "#003.cbz"). */
const val UNNAMED_KEY = "~sin-nombre"
const val UNNAMED_NAME = "Sin nombre"

object SeriesParser {
    /** numberEnd solo se rellena en archivos que agrupan varios números ("#36 #38", "36-38"). */
    class Parsed(val title: String, val series: String?, val key: String?, val number: Int?, val numberEnd: Int? = null)

    private class Core(val prefix: String, val hasKeyword: Boolean, val digits: String, val end: Int?, val endDigits: String = "")

    private const val KW = "(?:vol(?:ume|umen)?\\.?\\s*|v\\.?\\s*|tomo\\.?\\s*|t\\.?\\s*|n[º°o]\\.?\\s*|no\\.?\\s*|issue\\s*|cap(?:[ií]tulo)?\\.?\\s*|ch(?:apter)?\\.?\\s*|ep(?:isode)?\\.?\\s*|#\\s*)"
    private const val SEP = "(?:[\\s._\\-]+|(?=#))"
    private const val TAGS = "(?:\\s*[(\\[][^)\\]]*[)\\]])*"

    // [prefijo + separador] [palabra clave] número [-/&/+/, o " #" otro número] [(etiquetas)]
    // Grupos: 1 = prefijo, 2 = palabra clave, 3 = número, 4 = fin de rango.
    private val RANGE = Regex(
        "^(?:(.*?)" + SEP + ")?(" + KW + ")?(\\d{1,4})(?:(?:\\s*[-–—&+,]\\s*|\\s+(?=#))(?:" + KW + ")?(\\d{1,4}))?" + TAGS + "\\s*$",
        RegexOption.IGNORE_CASE
    )

    // "Invincible 001 - Family Matters": número seguido de un subtítulo.
    private val SUBTITLE = Regex(
        "^(.+?)" + SEP + "(" + KW + ")?(\\d{1,4})\\s*[-–—:]\\s+\\S.*$",
        RegexOption.IGNORE_CASE
    )

    private val SPACES = Regex("\\s+")
    private val MARKS = Regex("\\p{Mn}+")
    private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]+")
    private val BRACKETS = Regex("\\s*[(\\[][^)\\]]*[)\\]]\\s*")

    // Palabras que por sí solas no son un nombre de serie ("Capítulo 12" → se usa la carpeta).
    private val GENERIC = setOf(
        "chapter", "capitulo", "cap", "ch", "volume", "volumen", "vol", "tomo", "issue", "episode", "episodio",
        "ep", "part", "parte", "book", "libro", "page", "pagina", "numero", "no", "num", "v", "t", "n"
    )

    fun keyOf(name: String): String =
        Normalizer.normalize(name, Normalizer.Form.NFD)
            .replace(MARKS, "")
            .lowercase()
            .replace(NON_ALNUM, " ")
            .trim()

    private fun cleanName(fileName: String): String =
        fileName.substringBeforeLast('.').replace('_', ' ').replace(SPACES, " ").trim()

    private fun core(clean: String): Core? {
        RANGE.matchEntire(clean)?.let { m ->
            return Core(m.groupValues[1], m.groupValues[2].isNotBlank(), m.groupValues[3], m.groupValues[4].toIntOrNull(), m.groupValues[4])
        }
        SUBTITLE.matchEntire(clean)?.let { m ->
            val kw = m.groupValues[2].isNotBlank()
            val d = m.groupValues[3]
            // Sin pista clara ("#", "Vol", ceros a la izquierda o 3 cifras) un número suelto no se considera numeración.
            if (kw || d.startsWith("0") || d.length >= 3) return Core(m.groupValues[1], kw, d, null)
        }
        return null
    }

    private fun numbers(c: Core): Pair<Int, Int?>? {
        val n = c.digits.toIntOrNull() ?: return null
        // "Batman 1989": un año suelto no es un número de tomo.
        if (!c.hasKeyword && c.digits.length == 4 && n in 1900..2100) return null
        var e = c.end
        if (e != null && (e <= n || e - n > 500)) e = null
        return n to e
    }

    /** Numeración que lleva el archivo (sin inventar nada): inicio y, si es un rango, fin. */
    fun numbersOf(fileName: String): Pair<Int, Int?>? {
        val c = core(cleanName(fileName)) ?: return null
        return numbers(c)
    }

    /** Numeración tal cual está escrita en el archivo ("001", "036"): inicio y, si es un rango válido, fin. */
    fun rawNumbersOf(fileName: String): Pair<String, String?>? {
        val c = core(cleanName(fileName)) ?: return null
        val n = numbers(c) ?: return null
        return c.digits to (if (n.second != null) c.endDigits else null)
    }

    /** true si el cómic solo trae numeración (sin nombre de serie): va a la colección "Sin nombre". */
    fun isUnnamed(fileName: String): Boolean = parse(fileName, "", true).key == UNNAMED_KEY

    /** [folder] ya no se usa como nombre de serie: un archivo solo con numeración nunca hereda el nombre de su carpeta. */
    fun parse(fileName: String, folder: String, isComic: Boolean): Parsed {
        val clean = cleanName(fileName)
        val title = clean.ifBlank { fileName }
        val none = Parsed(title, null, null, null)
        if (!isComic) return none
        val c = core(clean) ?: return none
        val (number, end) = numbers(c) ?: return none
        var name = c.prefix.replace(BRACKETS, " ").replace(SPACES, " ").trim().trim('-', '–', '—', '.', ',', ':', '#', ' ')
        if (keyOf(name) in GENERIC) name = ""
        if (name.isEmpty()) return Parsed(title, UNNAMED_NAME, UNNAMED_KEY, number, end)
        if (name.count { it.isLetter() } < 2) return none
        val key = keyOf(name)
        if (key.isEmpty() || key in GENERIC) return none
        return Parsed(title, name, key, number, end)
    }

    /**
     * "Invincible #036" / "Invincible #36-38". Conserva exactamente la numeración escrita en el archivo
     * (ceros incluidos). Devuelve null si el archivo no trae numeración.
     */
    fun internalName(collection: String, fileName: String, number: Int?): String? {
        val parsed = numbersOf(fileName)
        val raw = rawNumbersOf(fileName)
        val start = number ?: parsed?.first ?: return null
        val same = parsed != null && raw != null && parsed.first == start
        val startTxt = when {
            same -> raw!!.first
            raw != null -> start.toString().padStart(raw.first.length, '0')
            else -> start.toString()
        }
        val endTxt = if (same) raw!!.second else null
        return if (endTxt != null) "$collection #$startTxt-$endTxt" else "$collection #$startTxt"
    }
}
