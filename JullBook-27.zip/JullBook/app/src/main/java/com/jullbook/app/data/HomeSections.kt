package com.jullbook.app.data

/** Secciones dinámicas de Inicio (JullBook 1.1). Se calculan con datos locales; las vacías simplemente no se muestran. */
class HomeData(
    val added: List<Book>,
    val unopened: List<Book>,
    val almost: List<ContinueEntry>,
    val paused: List<ContinueEntry>,
    val unstartedColls: List<SeriesItem>,
    val mostRead: List<Book>,
    /** true si [mostRead] son relecturas (2 o más lecturas); si no, simplemente los más leídos. */
    val reread: Boolean
)

object HomeSections {
    private const val DAY = 86_400_000L

    fun build(lib: Library, now: Long): HomeData {
        val dayKey = now / DAY
        fun shuffleKey(id: Long) = ((id * 2654435761L) xor dayKey) and 0xFFFF

        // Añadidos recientemente: los últimos 14 días. Si casi toda la biblioteca entró a la vez (primer escaneo), no es una novedad.
        val recentAdds = lib.books.values.filter { it.added > 0 && now - it.added <= 14 * DAY }
        val added = if (lib.books.size >= 8 && recentAdds.size >= lib.books.size * 0.8) emptyList()
        else recentAdds.sortedByDescending { it.added }.take(14)

        val touched = HashSet<Long>()
        val almost = ArrayList<ContinueEntry>()
        val paused = ArrayList<ContinueEntry>()
        val colls = ArrayList<SeriesItem>()

        fun consider(b: Book, p: Progress?, s: SeriesItem?) {
            if (p == null) return
            touched.add(b.id)
            if (p.status != ST_READING) return
            if (p.percent >= 0.80f && p.percent < 0.995f) almost.add(ContinueEntry(b, p, s))
            else if (p.percent >= 0.02f && now - p.lastRead > 14 * DAY) paused.add(ContinueEntry(b, p, s))
        }
        for (item in lib.items) {
            when (item) {
                is SingleItem -> consider(item.book, item.progress, null)
                is SeriesItem -> {
                    for (v in item.volumes) if (v.progress != null) touched.add(v.book.id)
                    item.target()?.let { t -> consider(t.book, t.progress, item) }
                    if (!item.isUnnamed && item.volumes.isNotEmpty() && LibraryView.statusOf(item) == StatusFilter.UNSTARTED) colls.add(item)
                }
            }
        }
        val unopened = lib.books.values.filter { it.id !in touched && it.reads == 0 }.sortedBy { shuffleKey(it.id) }

        val reread = lib.books.values.any { it.reads >= 2 }
        val most = lib.books.values.filter { if (reread) it.reads >= 2 else it.reads >= 1 }
            .sortedByDescending { it.reads }.take(14)

        return HomeData(
            added = added,
            unopened = unopened,
            almost = almost.sortedByDescending { it.progress?.percent ?: 0f }.take(12),
            paused = paused.sortedByDescending { it.progress?.lastRead ?: 0L }.take(12),
            unstartedColls = colls.sortedBy { shuffleKey(it.key.hashCode().toLong()) }.take(14),
            mostRead = most,
            reread = reread
        )
    }
}
