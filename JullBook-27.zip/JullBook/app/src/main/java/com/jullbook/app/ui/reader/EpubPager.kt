package com.jullbook.app.ui.reader

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.Color
import com.jullbook.app.data.Mark
import kotlinx.coroutines.launch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.ImageBlock
import com.jullbook.app.data.Images
import com.jullbook.app.data.TextBlock
import com.jullbook.app.translate.TrChapter
import com.jullbook.app.translate.TrView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Espacio reservado arriba/abajo de cada página (las barras del lector se superponen a él). */
const val PAGE_TOP_DP = 56
const val PAGE_BOTTOM_DP = 64

/** Todo lo que afecta a la paginación: si cambia, se vuelve a paginar. widthPx incluye los márgenes. */
data class PageCfg(
    val widthPx: Int,
    val heightPx: Int,
    val fontSize: Float,
    val marginPx: Int,
    val density: Density,
    val family: Int = 1,
    val lineMul: Float = 1.55f,
    val paraDp: Float = 10f,
    val justify: Boolean = false
)

internal fun fontFamilyOf(i: Int): FontFamily = when (i) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    3 -> FontFamily.Cursive
    else -> FontFamily.SansSerif
}

/** Estilo único de párrafo: lo usan la paginación (medida) y el dibujo, así nunca se desajustan. */
internal fun bodyStyle(cfg: PageCfg, b: TextBlock, color: Color = Color.Unspecified): TextStyle = TextStyle(
    color = color,
    fontSize = cfg.fontSize.sp,
    lineHeight = (cfg.fontSize * cfg.lineMul).sp,
    fontFamily = fontFamilyOf(cfg.family),
    textAlign = b.align ?: if (cfg.justify && !b.heading) TextAlign.Justify else TextAlign.Start,
    fontWeight = if (b.heading) FontWeight.Bold else null
)

/** Orden para saltar de página dentro del capítulo [ch] (descartada si el capítulo ya no es el mostrado). */
class PageCmd(val ch: Int, val index: Int, val animate: Boolean)

/** Página del capítulo que contiene el carácter [pos] (sin prefijo de viñeta) del bloque [block]; -1 si no hay. */
fun pageIndexOfChar(pages: List<EpubPage>, block: Int, pos: Int): Int {
    for ((i, p) in pages.withIndex()) for (c in p.chunks) {
        val t = c.text ?: continue
        if (c.block != block) continue
        val shift = if (c.src?.bullet == true) 3 else 0
        val a = c.start - shift
        if (pos >= a && pos < a + t.length) return i
    }
    for ((i, p) in pages.withIndex()) if (p.chunks.any { it.block >= block }) return i
    return -1
}

/** Fragmento de un bloque dentro de una página: un trozo de texto (por líneas completas) o una imagen. */
class Chunk(
    val block: Int,
    /** Posición (carácter) donde empieza este fragmento dentro del bloque y longitud total del bloque. */
    val start: Int,
    val total: Int,
    val text: AnnotatedString?,
    val src: TextBlock?,
    val image: String?,
    val imageH: Int,
    val topPx: Int,
    val bottomPx: Int,
    val quotePx: Int
)

class EpubPage(val chunks: List<Chunk>) {
    val sub: Int get() = chunks.firstOrNull()?.block ?: 0
    val frac: Float get() = chunks.firstOrNull()?.let { it.start.toFloat() / it.total.coerceAtLeast(1) } ?: 0f
}

/** Capítulo ya paginado que se está mostrando. */
class Shown(val ch: Int, val cfg: PageCfg, val pages: List<EpubPage>)

/** Punto de lectura (bloque + fracción dentro del bloque), el mismo formato que el progreso guardado. */
class Anchor(var sub: Int, var frac: Float, var atEnd: Boolean = false)

fun pageIndexFor(pages: List<EpubPage>, a: Anchor): Int {
    if (pages.isEmpty()) return 0
    if (a.atEnd) return pages.lastIndex
    var idx = 0
    for ((i, p) in pages.withIndex()) {
        if (p.chunks.isEmpty()) continue
        if (p.sub < a.sub || (p.sub == a.sub && p.frac <= a.frac + 0.0005f)) idx = i else break
    }
    return idx
}

/**
 * Divide cada capítulo en páginas del tamaño exacto de la pantalla. Los párrafos largos se cortan por líneas
 * completas; las imágenes se ajustan a la página. Mantiene una pequeña caché por capítulo y configuración.
 */
class EpubPaginator(
    private val session: EpubSession,
    private val measurer: TextMeasurer,
    /** Si se indica, los capítulos con traducción activa se paginan con el texto traducido (la caché distingue ambas vistas). */
    private val tr: TrView? = null
) {
    private val mutex = Mutex()
    private val cache = object : LinkedHashMap<Triple<Int, PageCfg, String>, List<EpubPage>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Triple<Int, PageCfg, String>, List<EpubPage>>?): Boolean = size > 10
    }

    @Synchronized
    fun peek(ch: Int, cfg: PageCfg): List<EpubPage>? = cache[Triple(ch, cfg, tr?.displayed(ch)?.stamp ?: "")]

    @Synchronized
    private fun store(key: Triple<Int, PageCfg, String>, pages: List<EpubPage>) {
        cache[key] = pages
    }

    @Synchronized
    private fun lookup(key: Triple<Int, PageCfg, String>): List<EpubPage>? = cache[key]

    suspend fun get(ch: Int, cfg: PageCfg): List<EpubPage> {
        val view = tr?.displayed(ch)
        val key = Triple(ch, cfg, view?.stamp ?: "")
        lookup(key)?.let { return it }
        return mutex.withLock {
            lookup(key) ?: withContext(Dispatchers.Default) { build(ch, cfg, view) }.also { store(key, it) }
        }
    }

    private suspend fun build(ch: Int, cfg: PageCfg, view: TrChapter?): List<EpubPage> {
        val parsed = try {
            EpubText.parse(session.zip, session.info.spine[ch])
        } catch (e: CancellationException) {
            throw e
        } catch (ignored: Throwable) {
            emptyList()
        }
        val blocks = if (view != null) view.withText(parsed) else parsed
        val d = cfg.density
        fun dp(v: Float): Int = with(d) { v.dp.toPx() }.roundToInt()
        val textW = (cfg.widthPx - 2 * cfg.marginPx).coerceAtLeast(120)
        val pageH = cfg.heightPx.coerceAtLeast(200)
        val lineH = with(d) { (cfg.fontSize * cfg.lineMul).sp.toPx() }
        val pages = ArrayList<EpubPage>()
        var cur = ArrayList<Chunk>()
        var used = 0
        fun flush() {
            if (cur.isNotEmpty()) {
                pages.add(EpubPage(cur))
                cur = ArrayList()
                used = 0
            }
        }

        for ((i, b) in blocks.withIndex()) {
            currentCoroutineContext().ensureActive()
            when (b) {
                is TextBlock -> {
                    val base = toAnnotated(b.sp, cfg.fontSize)
                    val text = if (b.bullet) buildAnnotatedString { append("•  "); append(base) } else base
                    val quote = if (b.quote) dp(14f) else 0
                    val style = bodyStyle(cfg, b)
                    val lay = measurer.measure(
                        text = text,
                        style = style,
                        constraints = Constraints(maxWidth = (textW - quote).coerceAtLeast(60)),
                        skipCache = true
                    )
                    val topSp = if (b.heading) dp(14f) else 0
                    val botSp = if (b.heading) dp(14f) else dp(cfg.paraDp)
                    val n = lay.lineCount
                    var line = 0
                    while (line < n) {
                        val top = if (line == 0) topSp else 0
                        val avail = pageH - used - top
                        val y0 = lay.getLineTop(line)
                        var end = line
                        while (end < n && lay.getLineBottom(end) - y0 <= avail) end++
                        if (end == line) {
                            if (used > 0) {
                                flush()
                                continue
                            }
                            end = line + 1 // línea más alta que la página: se fuerza para no bloquearse
                        }
                        if (used > 0 && line == 0) {
                            // Un título no se queda solo al final de la página.
                            val left = avail - (lay.getLineBottom(end - 1) - y0)
                            if (b.heading && end == n && left < 2 * lineH) {
                                flush()
                                continue
                            }
                            // Ni una sola línea de un párrafo al final de la página.
                            if (end < n && end - line == 1) {
                                flush()
                                continue
                            }
                        }
                        // Ni una sola línea suelta al principio de la página siguiente.
                        if (end < n && n - end == 1 && end - line >= 2) end--
                        val whole = end == n
                        val a = lay.getLineStart(line)
                        val z = lay.getLineEnd(end - 1)
                        val h = (lay.getLineBottom(end - 1) - y0).roundToInt()
                        val bottom = if (whole) botSp else 0
                        cur.add(Chunk(i, a, text.length, text.subSequence(a, z), b, null, 0, top, bottom, quote))
                        used += top + h + bottom
                        if (!whole) flush()
                        line = end
                    }
                }
                is ImageBlock -> {
                    val e = session.zip.entry(b.path) ?: continue
                    val raw: Float = try {
                        Images.pageRatio(session.zip, e)
                    } catch (ex: CancellationException) {
                        throw ex
                    } catch (ignored: Throwable) {
                        0.7f
                    }
                    val ratio = raw.coerceIn(0.05f, 20f)
                    val pad = dp(8f)
                    val h = (textW / ratio).roundToInt().coerceAtMost(pageH - 2 * pad).coerceAtLeast(40)
                    if (used > 0 && used + h + 2 * pad > pageH) flush()
                    cur.add(Chunk(i, 0, 1, null, null, b.path, h, pad, pad, 0))
                    used += h + 2 * pad
                }
            }
        }
        flush()
        if (pages.isEmpty()) pages.add(EpubPage(emptyList()))
        return pages
    }
}

/**
 * Páginas de un capítulo en un pager horizontal que sigue al dedo. Antes y después del capítulo hay una página
 * "puente" (última del anterior / primera del siguiente): al asentarse sobre ella se cambia de capítulo sin
 * salto visible, así el gesto continúa directamente en el capítulo contiguo.
 */
@Composable
internal fun ChapterPager(
    session: EpubSession,
    shown: Shown,
    prev: EpubPage?,
    next: EpubPage?,
    initial: Int,
    theme: EpubTheme,
    marks: List<Mark>,
    tapZones: Boolean,
    cmd: PageCmd?,
    onCmdDone: () -> Unit,
    onTap: () -> Unit,
    onLongPress: (Chunk, Int, TextLayoutResult) -> Unit,
    onPage: (index: Int, count: Int, page: EpubPage) -> Unit,
    onSwap: (dir: Int) -> Unit
) {
    val hasPrev = shown.ch > 0
    val hasNext = shown.ch < session.info.spine.size - 1
    val off = if (hasPrev) 1 else 0
    val pages = shown.pages
    val count = off + pages.size + (if (hasNext) 1 else 0)
    val state = rememberPagerState(initialPage = off + initial.coerceIn(0, pages.lastIndex.coerceAtLeast(0))) { count }
    val scope = rememberCoroutineScope()

    LaunchedEffect(state) {
        snapshotFlow { state.settledPage }
            .distinctUntilChanged()
            .collect { w ->
                when {
                    hasPrev && w == 0 -> onSwap(-1)
                    hasNext && w == count - 1 -> onSwap(1)
                    else -> {
                        val i = (w - off).coerceIn(0, pages.lastIndex)
                        onPage(i, pages.size, pages[i])
                    }
                }
            }
    }

    LaunchedEffect(cmd) {
        val c = cmd ?: return@LaunchedEffect
        if (c.ch == shown.ch) {
            val t = off + c.index.coerceIn(0, pages.lastIndex.coerceAtLeast(0))
            if (c.animate) state.animateScrollToPage(t) else state.scrollToPage(t)
        }
        onCmdDone()
    }

    fun step(d: Int) {
        val t = (state.currentPage + d).coerceIn(0, count - 1)
        if (t != state.currentPage) scope.launch { state.animateScrollToPage(t) }
    }

    HorizontalPager(
        state = state,
        modifier = Modifier.fillMaxSize(),
        beyondViewportPageCount = 1,
        flingBehavior = PagerDefaults.flingBehavior(state = state, snapPositionalThreshold = 0.35f)
    ) { w ->
        val page = when {
            hasPrev && w == 0 -> prev
            hasNext && w == count - 1 -> next
            else -> pages[(w - off).coerceIn(0, pages.lastIndex)]
        }
        val pch = when {
            hasPrev && w == 0 -> shown.ch - 1
            hasNext && w == count - 1 -> shown.ch + 1
            else -> shown.ch
        }
        val pm = remember(marks, pch) { marks.filter { it.ch == pch } }
        PageContent(
            session, page, shown.cfg, theme, pm,
            onTap = { o, width ->
                when {
                    tapZones && o.x < width * 0.22f -> step(-1)
                    tapZones && o.x > width * 0.78f -> step(1)
                    else -> onTap()
                }
            },
            onLongPress = onLongPress
        )
    }
}

private class ChunkGeo {
    var layout: TextLayoutResult? = null
    var root: Offset = Offset.Zero
}

@Composable
private fun PageContent(
    session: EpubSession,
    page: EpubPage?,
    cfg: PageCfg,
    theme: EpubTheme,
    marks: List<Mark>,
    onTap: (Offset, Int) -> Unit,
    onLongPress: (Chunk, Int, TextLayoutResult) -> Unit
) {
    val density = LocalDensity.current
    val geos = remember(page) { HashMap<Chunk, ChunkGeo>() }
    val boxRoot = remember { ChunkGeo() }
    Box(
        Modifier
            .fillMaxSize()
            .background(theme.bg)
            .clipToBounds()
            .onGloballyPositioned { boxRoot.root = it.positionInRoot() }
            .pointerInput(page) {
                detectTapGestures(
                    onTap = { o -> onTap(o, size.width) },
                    onLongPress = { o ->
                        val abs = o + boxRoot.root
                        for ((c, g) in geos) {
                            val lay = g.layout ?: continue
                            val local = abs - g.root
                            if (local.x >= 0f && local.y >= 0f && local.x <= lay.size.width && local.y <= lay.size.height) {
                                onLongPress(c, lay.getOffsetForPosition(local), lay)
                                break
                            }
                        }
                    }
                )
            }
    ) {
        if (page == null) return@Box
        Column(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .padding(
                    start = with(density) { cfg.marginPx.toDp() },
                    end = with(density) { cfg.marginPx.toDp() },
                    top = PAGE_TOP_DP.dp,
                    bottom = PAGE_BOTTOM_DP.dp
                )
        ) {
            for (c in page.chunks) {
                val topDp = with(density) { c.topPx.toDp() }
                val botDp = with(density) { c.bottomPx.toDp() }
                if (c.text != null && c.src != null) {
                    ChunkText(c, cfg, theme, marks, topDp, botDp, geos.getOrPut(c) { ChunkGeo() })
                } else if (c.image != null) {
                    PageImage(session, c.image, with(density) { c.imageH.toDp() }, Modifier.padding(top = topDp, bottom = botDp))
                }
            }
        }
    }
}

@Composable
private fun ChunkText(
    c: Chunk,
    cfg: PageCfg,
    theme: EpubTheme,
    marks: List<Mark>,
    topDp: androidx.compose.ui.unit.Dp,
    botDp: androidx.compose.ui.unit.Dp,
    geo: ChunkGeo
) {
    val b = c.src ?: return
    val t = c.text ?: return
    val shown = remember(c, marks) {
        val here = marks.filter { it.block == c.block }
        if (here.isEmpty()) {
            t
        } else {
            val shift = if (b.bullet) 3 else 0
            val map = b.map
            buildAnnotatedString {
                append(t)
                for (k in here) {
                    var ks = k.s
                    var ke = k.e
                    if (map != null && !k.tr) {
                        // Vista traducida: el resaltado (guardado sobre el original) cubre las frases traducidas equivalentes.
                        val r = map.origRangeToTr(ks, ke) ?: continue
                        ks = r.first
                        ke = r.second
                    }
                    val rs = (ks + shift - c.start).coerceAtLeast(0)
                    val re = (ke + shift - c.start).coerceAtMost(t.length)
                    if (re > rs) addStyle(SpanStyle(background = Color(k.color)), rs, re)
                }
            }
        }
    }
    val quoteColor = theme.fg.copy(alpha = 0.35f)
    var m = Modifier.fillMaxWidth().padding(top = topDp, bottom = botDp)
    if (b.quote) {
        m = m
            .drawBehind { drawRect(quoteColor, size = Size(3.dp.toPx(), size.height)) }
            .padding(start = 14.dp)
    }
    Text(
        text = shown,
        style = bodyStyle(cfg, b, theme.fg),
        modifier = m.onGloballyPositioned { geo.root = it.positionInRoot() },
        onTextLayout = { geo.layout = it }
    )
}

@Composable
private fun PageImage(session: EpubSession, path: String, height: androidx.compose.ui.unit.Dp, modifier: Modifier) {
    val widthPx = androidx.compose.ui.platform.LocalContext.current.resources.displayMetrics.widthPixels
    val bmp by produceState<ImageBitmap?>(null, session, path) {
        value = withContext(Dispatchers.IO) {
            try {
                val e = session.zip.entry(path)
                if (e == null) null else Images.decodeSampled(session.zip.read(e), widthPx, Bitmap.Config.ARGB_8888)
            } catch (ex: CancellationException) {
                throw ex
            } catch (ignored: Throwable) {
                null
            }
        }?.asImageBitmap()
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = null, modifier = modifier.fillMaxWidth().height(height), contentScale = ContentScale.Fit)
    } else {
        Box(modifier.fillMaxWidth().height(height))
    }
}
