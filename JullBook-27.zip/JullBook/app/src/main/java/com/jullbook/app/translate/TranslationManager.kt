package com.jullbook.app.translate

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jullbook.app.data.Block
import com.jullbook.app.data.EpubSession
import com.jullbook.app.data.EpubText
import com.jullbook.app.data.Sentences
import com.jullbook.app.data.TextBlock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

sealed interface TrStatus {
    object Idle : TrStatus
    class Chapter(val ch: Int, val done: Int, val total: Int) : TrStatus
    /** [index] capítulos ya procesados de [count]; [done]/[total] frases del capítulo en curso. */
    class Book(val index: Int, val count: Int, val ch: Int, val done: Int, val total: Int) : TrStatus
    class Failed(val message: String) : TrStatus
}

/**
 * Traducción de un libro abierto. Trabaja siempre en segundo plano; el texto original nunca se modifica: cada
 * capítulo traducido se guarda aparte (frase a frase, alineado con el original) y el lector lo muestra, busca y
 * narra a través de [BlockMap]. Solo se envía texto al motor cuando el usuario lo pide.
 */
class TranslationManager(
    ctx: Context,
    private val bookId: Long,
    private val session: EpubSession
) : TrView, SpeakSource {
    private val app = ctx.applicationContext
    private val settings = TrSettings(app)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val loaded = ConcurrentHashMap<Int, TrChapter>()
    private val probed: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    private val caches = HashMap<String, TrCache>()
    private val srcMutex = Mutex()
    private var job: Job? = null
    @Volatile private var gen = 0

    /** true = el lector muestra la traducción (donde exista). */
    var showing by mutableStateOf(settings.showing(bookId))
        private set

    /** Cambia al alternar Original/Traducción o cambiar idioma/motor: el lector vuelve a paginar. */
    var modeVer by mutableIntStateOf(0)
        private set

    private val ver = mutableStateMapOf<Int, Int>()
    var status by mutableStateOf<TrStatus>(TrStatus.Idle)
        private set
    var from by mutableStateOf(settings.from(bookId))
        private set
    var to by mutableStateOf(settings.to)
        private set
    var engineId by mutableStateOf(settings.engine)
        private set
    var libreUrl by mutableStateOf(settings.libreUrl)
        private set
    var libreKey by mutableStateOf(settings.libreKey)
        private set
    var detected by mutableStateOf(settings.detected(bookId))
        private set

    /** Capítulos con traducción guardada para la combinación actual (motor + idiomas). */
    var translated by mutableStateOf<Set<Int>>(emptySet())
        private set
    var translatedKnown by mutableStateOf(false)
        private set

    /** true mientras el motor prepara el idioma (descarga del modelo la primera vez). */
    var preparing by mutableStateOf(false)
        private set

    val running: Boolean get() = status is TrStatus.Chapter || status is TrStatus.Book

    val destination: String get() = engine().destination

    init {
        refreshTranslated()
    }

    fun verOf(ch: Int): Int = ver[ch] ?: 0

    private fun bump(ch: Int) {
        ver[ch] = (ver[ch] ?: 0) + 1
    }

    private fun engine(): TranslationEngine = TrEngines.create(engineId, libreUrl, libreKey)

    // ---------- Qué se muestra ----------

    override val targetTag: String get() = to

    override fun displayed(ch: Int): TrChapter? = if (showing) loaded[ch] else null

    override fun isTranslated(ch: Int): Boolean = showing && loaded.containsKey(ch)

    override suspend fun chapter(ch: Int): TrChapter? {
        if (!showing) return null
        prepare(ch)
        return loaded[ch]
    }

    /** true cuando ya se sabe si el capítulo tiene traducción (para no mostrar páginas a medias). */
    fun ready(ch: Int): Boolean = !showing || probed.contains(ch)

    /** Carga de disco la traducción del capítulo (si existe y sigue siendo válida) antes de paginarlo. */
    suspend fun prepare(ch: Int) {
        if (!showing || probed.contains(ch)) return
        val g = gen
        val c = chapterAny(ch)
        if (g == gen && c != null) loaded[ch] = c
        if (g == gen) probed.add(ch)
    }

    /** La traducción del capítulo, esté o no activa la vista traducida (la usan la búsqueda y la selección). */
    suspend fun chapterAny(ch: Int): TrChapter? {
        loaded[ch]?.let { return it }
        val g = gen
        val c = load(ch)
        if (c != null && g == gen) loaded[ch] = c
        return c
    }

    private suspend fun load(ch: Int): TrChapter? = withContext(Dispatchers.IO) {
        val src = source()
        val cache = cacheFor(src)
        val data = cache.read(ch) ?: return@withContext null
        val blocks = parseChapter(ch) ?: return@withContext null
        val units = unitsOf(blocks)
        if (hashOf(units) != data.hash) {
            // El contenido del capítulo cambió: solo se descarta este capítulo.
            cache.delete(ch)
            translated = translated - ch
            return@withContext null
        }
        build(ch, blocks, data.blocks, stampFor(src, data.hash))
    }

    // ---------- Idioma de origen ----------

    private suspend fun source(): String {
        if (from != "auto") return from
        detected?.let { return it }
        return srcMutex.withLock {
            detected ?: withContext(Dispatchers.IO) { LangDetect.forBook(session) }?.also {
                detected = it
                settings.setDetected(bookId, it)
            }
        } ?: "auto"
    }

    suspend fun ensureDetected() {
        if (from == "auto") source()
    }

    // ---------- Caché ----------

    private fun cacheFor(src: String): TrCache {
        val key = engine().cacheKey.replace(Regex("[^A-Za-z0-9._-]"), "_") + "/" +
            src.replace(Regex("[^A-Za-z0-9_-]"), "_") + "-" + to
        return synchronized(caches) {
            caches.getOrPut(key) { TrCache(File(app.filesDir, "translations/$bookId/$key")) }
        }
    }

    private fun stampFor(src: String, hash: String) = engine().cacheKey + "|" + src + "|" + to + "|" + hash

    fun refreshTranslated() {
        scope.launch {
            val g = gen
            val set = cacheFor(source()).chapters()
            if (g == gen) {
                translated = set
                translatedKnown = true
            }
        }
    }

    // ---------- Texto del capítulo ----------

    private fun parseChapter(ch: Int): List<Block>? = try {
        EpubText.parse(session.zip, session.info.spine[ch])
    } catch (e: CancellationException) {
        throw e
    } catch (ignored: Throwable) {
        null
    }

    private fun origText(b: TextBlock): String = b.sp.toString().replace('￼', ' ')

    /** Frases originales de cada bloque (null en imágenes), con el mismo corte que usan la narración y los resaltados. */
    private fun unitsOf(blocks: List<Block>): List<List<String>?> = blocks.map { b ->
        if (b is TextBlock) {
            val t = origText(b)
            Sentences.split(t).map { t.substring(it.s, it.e) }.takeIf { it.isNotEmpty() }
        } else {
            null
        }
    }

    private fun hashOf(units: List<List<String>?>): String {
        val md = MessageDigest.getInstance("SHA-256")
        for (u in units) {
            md.update(byteArrayOf(2))
            if (u != null) for (s in u) {
                md.update(s.toByteArray(Charsets.UTF_8))
                md.update(byteArrayOf(1))
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }.take(24)
    }

    private fun build(ch: Int, blocks: List<Block>, tr: List<List<String>?>, stamp: String): TrChapter? {
        if (tr.size != blocks.size) return null
        val maps = arrayOfNulls<BlockMap>(blocks.size)
        for ((i, b) in blocks.withIndex()) {
            if (b !is TextBlock) continue
            val t = tr[i] ?: continue
            val orig = origText(b)
            val sents = Sentences.split(orig)
            if (sents.isEmpty() || sents.size != t.size) return null
            val oS = IntArray(sents.size) { sents[it].s }
            val oE = IntArray(sents.size) { sents[it].e }
            val tS = IntArray(t.size)
            val tE = IntArray(t.size)
            val sb = StringBuilder()
            for (k in t.indices) {
                if (k > 0) sb.append(' ')
                tS[k] = sb.length
                sb.append(t[k])
                tE[k] = sb.length
            }
            maps[i] = BlockMap(orig, if (b.bullet) 3 else 0, oS, oE, sb.toString(), tS, tE)
        }
        return TrChapter(ch, stamp, maps)
    }

    // ---------- Traducir ----------

    private fun needs(s: String) = s.any { it.isLetter() }

    private fun clean(res: String, orig: String): String = res.replace(Regex("\\s+"), " ").trim().ifBlank { orig }

    private suspend fun <T> withRetry(block: suspend () -> T): T {
        var attempt = 0
        while (true) {
            try {
                return block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: TrError) {
                if (e.fatal || ++attempt >= 3) throw e
                delay(1500L * attempt)
            }
        }
    }

    /** Traduce un capítulo entero (no hace nada si ya está en caché y el contenido no cambió). */
    private suspend fun runChapter(ch: Int, report: (done: Int, total: Int) -> Unit) {
        val g = gen
        val src = source()
        if (src == to) throw TrError("El idioma de origen y el de destino son el mismo.", true)
        val cache = cacheFor(src)
        val blocks = parseChapter(ch) ?: throw TrError("No se pudo leer el capítulo ${ch + 1}.")
        val units = unitsOf(blocks)
        val hash = hashOf(units)
        val have = cache.read(ch)
        if (have != null && have.hash == hash) {
            if (g == gen) translated = translated + ch
            return
        }
        val todo = LinkedHashSet<String>()
        for (u in units) if (u != null) for (s in u) if (needs(s)) todo.add(s)
        val list = todo.toList()
        val out = HashMap<String, String>()
        val eng = engine()
        prep(eng, src)
        report(0, list.size)
        var i = 0
        while (i < list.size) {
            currentCoroutineContext().ensureActive()
            var j = i
            var chars = 0
            while (j < list.size && j - i < eng.maxBatchItems && (j == i || chars + list[j].length <= eng.maxBatchChars)) {
                chars += list[j].length
                j++
            }
            val batch = list.subList(i, j)
            val res = withRetry { eng.translate(batch, src, to) }
            if (res.size != batch.size) throw TrError("El motor devolvió una respuesta incompleta.")
            for (k in batch.indices) out[batch[k]] = clean(res[k], batch[k])
            i = j
            report(i, list.size)
        }
        currentCoroutineContext().ensureActive()
        cache.write(ch, hash, units.map { u -> u?.map { s -> out[s] ?: s } })
        if (g == gen) {
            translated = translated + ch
            loaded.remove(ch)
            probed.remove(ch)
            bump(ch)
        }
    }

    private suspend fun prep(eng: TranslationEngine, src: String) {
        preparing = true
        try {
            eng.prepare(src, to)
        } finally {
            preparing = false
        }
    }

    private fun fail(e: Throwable) {
        status = TrStatus.Failed(
            if (e is TrError) e.message ?: "No se pudo traducir." else "No se pudo traducir (${e.javaClass.simpleName})."
        )
    }

    fun translateChapter(ch: Int) {
        if (running) return
        status = TrStatus.Chapter(ch, 0, 0)
        job = scope.launch {
            try {
                runChapter(ch) { d, t -> status = TrStatus.Chapter(ch, d, t) }
                status = TrStatus.Idle
            } catch (e: CancellationException) {
                status = TrStatus.Idle
                throw e
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    /** Traduce todo el libro capítulo a capítulo desde [startCh]. Se puede cancelar y reanudar sin perder lo hecho. */
    fun translateBook(startCh: Int) {
        if (running) return
        val n = session.info.spine.size
        val first = startCh.coerceIn(0, n - 1)
        val order = (first until n) + (0 until first)
        status = TrStatus.Book(0, n, first, 0, 0)
        job = scope.launch {
            try {
                for ((idx, ch) in order.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    status = TrStatus.Book(idx, n, ch, 0, 0)
                    runChapter(ch) { d, t -> status = TrStatus.Book(idx, n, ch, d, t) }
                }
                status = TrStatus.Idle
            } catch (e: CancellationException) {
                status = TrStatus.Idle
                throw e
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        if (running) status = TrStatus.Idle
    }

    fun clearError() {
        if (status is TrStatus.Failed) status = TrStatus.Idle
    }

    /** Traduce una frase seleccionada. Si el capítulo ya está traducido usa esa traducción; si no, la pide al motor y la guarda. */
    suspend fun translateSentence(ch: Int, block: Int, s: Int, e: Int, text: String): String {
        val m = chapterAny(ch)?.map(block)
        if (m != null) {
            for (i in 0 until m.count) if (m.oS[i] == s && m.oE[i] == e) return m.sentence(i)
        }
        return translateText(text)
    }

    suspend fun translateText(text: String): String = withContext(Dispatchers.IO) {
        val src = source()
        if (src == to) throw TrError("El idioma de origen y el de destino son el mismo.", true)
        val cache = cacheFor(src)
        val key = hashOf(listOf(listOf(text)))
        cache.selGet(key)?.let { return@withContext it }
        val eng = engine()
        prep(eng, src)
        val res = withRetry { eng.translate(listOf(text), src, to) }
        val t = clean(res.firstOrNull().orEmpty(), text)
        cache.selPut(key, t)
        t
    }

    // ---------- Ajustes ----------

    fun showTranslation(on: Boolean) {
        if (showing == on) return
        showing = on
        settings.setShowing(bookId, on)
        if (on && !translatedKnown) refreshTranslated()
        modeVer++
    }

    fun useFrom(code: String) {
        if (from == code) return
        from = code
        settings.setFrom(bookId, code)
        resetCaches()
    }

    fun useTo(code: String) {
        if (to == code) return
        to = code
        settings.to = code
        resetCaches()
    }

    fun useEngine(id: String) {
        if (engineId == id) return
        engineId = id
        settings.engine = id
        resetCaches()
    }

    fun useLibre(url: String, key: String) {
        val u = url.trim()
        val k = key.trim()
        if (u == libreUrl && k == libreKey) return
        libreUrl = u
        libreKey = k
        settings.libreUrl = u
        settings.libreKey = k
        if (engineId == TrEngines.LIBRE) resetCaches()
    }

    /** Cambió idioma o motor: se deja de usar lo cargado (las traducciones de otras combinaciones siguen intactas en disco). */
    private fun resetCaches() {
        cancel()
        gen++
        loaded.clear()
        probed.clear()
        translated = emptySet()
        translatedKnown = false
        if (status is TrStatus.Failed) status = TrStatus.Idle
        refreshTranslated()
        modeVer++
    }

    fun release() {
        scope.cancel()
        MlKitHub.closeAll()
    }
}
