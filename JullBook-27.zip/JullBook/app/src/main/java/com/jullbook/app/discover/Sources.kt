package com.jullbook.app.discover

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Utilidades comunes de las fuentes basadas en API JSON. */
internal object Net {
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    fun encPath(s: String): String = enc(s).replace("+", "%20")

    fun json(url: String): JSONObject {
        val raw = String(Http.bytes(url, null), Charsets.UTF_8)
        return try {
            JSONObject(raw)
        } catch (e: org.json.JSONException) {
            throw SourceException("La fuente devolvió una respuesta no válida")
        }
    }

    /** Fuerza https (algunas APIs devuelven enlaces http). */
    fun https(u: String?): String? {
        val t = u?.trim().orEmpty()
        if (t.isEmpty()) return null
        return if (t.startsWith("http://", ignoreCase = true)) "https://" + t.substring(7) else t
    }

    private val TAGS = Regex("<[^>]*>")
    private val SPACES = Regex("\\s+")
    private val NOT_WORD = Regex("[^\\p{L}\\p{N}]+")
    private val OPERATORS = setOf("AND", "OR", "NOT")

    fun plain(s: String?): String? {
        if (s == null) return null
        val t = TAGS.replace(s, " ")
            .replace("&quot;", "\"").replace("&amp;", "&").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&#039;", "'").replace("&nbsp;", " ")
        return SPACES.replace(t, " ").trim().ifEmpty { null }
    }

    /** Deja solo letras y números (evita operadores de búsqueda de Lucene). */
    fun terms(s: String): String =
        NOT_WORD.replace(s, " ").trim().split(' ').filter { it.isNotEmpty() && it !in OPERATORS }.joinToString(" ")

    /** Campo que puede venir como texto o como lista. */
    fun text(o: JSONObject, key: String, sep: String = ", "): String? {
        val v = o.opt(key) ?: return null
        if (v == JSONObject.NULL) return null
        if (v is JSONArray) {
            val parts = (0 until v.length()).map { v.optString(it, "").trim() }.filter { it.isNotEmpty() }
            return parts.joinToString(sep).ifEmpty { null }
        }
        return v.toString().trim().ifEmpty { null }
    }

    fun list(o: JSONObject, key: String): List<String> {
        val a = o.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.optString(it, "").trim() }.filter { it.isNotEmpty() }
    }

    fun year(s: String?): String? = s?.let { Regex("(1\\d{3}|20\\d{2})").find(it)?.value }
}

/** Nombres con los que las fuentes escriben cada idioma. */
internal object LangTerms {
    private val EXTRA = mapOf(
        "es" to listOf("spa", "Spanish"),
        "en" to listOf("eng", "English"),
        "fr" to listOf("fre", "fra", "French"),
        "it" to listOf("ita", "Italian"),
        "de" to listOf("ger", "deu", "German"),
        "pt" to listOf("por", "Portuguese"),
        "ja" to listOf("jpn", "Japanese")
    )

    fun all(code: String): List<String> = listOf(code) + (EXTRA[code] ?: emptyList())
    fun iso3(code: String): String? = EXTRA[code]?.firstOrNull()
}

internal fun SearchResult.withDownloads(d: List<DownloadInfo>): SearchResult = SearchResult(
    sourceId = sourceId, sourceName = sourceName, id = id, title = title, author = author,
    coverUrl = coverUrl, thumbUrl = thumbUrl, description = description, genres = genres,
    languageRaw = languageRaw, year = year, downloads = d, detailUrl = detailUrl,
    langFromFilter = langFromFilter
)

/** Lee la lista de archivos de un ítem de Internet Archive y devuelve los formatos que la app abre. */
internal object ArchiveFiles {
    private class Cand(val fmt: DlFormat, val name: String, val size: Long?, val prio: Int)

    /** Lista vacía = ítem restringido (préstamo) o sin archivos compatibles. */
    fun fetch(id: String): List<DownloadInfo> {
        val root = Net.json("https://archive.org/metadata/" + Net.encPath(id))
        val meta = root.optJSONObject("metadata")
        if (meta != null && Net.text(meta, "access-restricted-item")?.equals("true", ignoreCase = true) == true) {
            return emptyList()
        }
        if (root.optBoolean("is_dark", false)) return emptyList()
        val files = root.optJSONArray("files") ?: return emptyList()
        val cands = ArrayList<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name", "")
            val format = f.optString("format", "").lowercase()
            if (name.isBlank() || format.contains("encrypted") || name.startsWith("__ia_thumb")) continue
            val fmt = when (name.substringAfterLast('.', "").lowercase()) {
                "epub" -> DlFormat.EPUB
                "pdf" -> DlFormat.PDF
                "cbz" -> DlFormat.CBZ
                "cbr" -> DlFormat.CBR
                else -> continue
            }
            val prio = if (fmt == DlFormat.PDF) {
                when {
                    format == "text pdf" -> 0
                    format.contains("text pdf") -> 1
                    format.contains("image container") -> 2
                    else -> 3
                }
            } else 0
            cands.add(Cand(fmt, name, f.optString("size", "").toLongOrNull(), prio))
        }
        val base = "https://archive.org/download/" + Net.encPath(id) + "/"
        val main = cands.groupBy { it.fmt }.values
            .mapNotNull { g -> g.minByOrNull { it.prio } }
            .sortedBy { it.fmt.ordinal }
            .map { c ->
                DownloadInfo(
                    c.fmt,
                    base + c.name.split('/').joinToString("/") { Net.encPath(it) },
                    c.size?.takeIf { it > 0 }
                )
            }
        // Texto reconocido (OCR): pesa una fracción y la app lo convierte en un EPUB ligero.
        var txt: DownloadInfo? = null
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name", "")
            if (name.endsWith("_djvu.txt")) {
                val url = base + name.split('/').joinToString("/") { Net.encPath(it) }
                txt = DownloadInfo(DlFormat.EPUB, url, f.optString("size", "").toLongOrNull()?.takeIf { it > 0 }, true)
                break
            }
        }
        return if (txt != null) main + txt else main
    }
}

/** Internet Archive: búsqueda avanzada (JSON). Solo ítems de descarga libre (se excluyen los de préstamo). */
class ArchiveSource(private val cfg: SourceConfig) : Source {
    override val id: String get() = cfg.id
    override val name: String get() = cfg.name

    override fun filtersLanguage(lang: Lang?): Boolean = lang?.code != null

    override fun search(q: SearchQuery, cursor: String?): SearchPage {
        val page = cursor?.toIntOrNull() ?: 1
        val parts = ArrayList<String>()
        val t = Net.terms(q.text)
        if (t.isNotEmpty()) parts.add("(title:($t) OR creator:($t) OR subject:($t))")
        parts.add("mediatype:texts")
        parts.add("NOT access-restricted-item:true")
        parts.add("(format:EPUB OR format:PDF OR format:\"Comic Book ZIP\" OR format:\"Comic Book RAR\")")
        val code = q.lang?.code
        if (code != null) parts.add("language:(" + LangTerms.all(code).joinToString(" OR ") + ")")
        val url = "https://archive.org/advancedsearch.php?q=" + Net.enc(parts.joinToString(" AND ")) +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=description" +
            "&fl%5B%5D=language&fl%5B%5D=year&sort%5B%5D=downloads+desc" +
            "&rows=$ROWS&page=$page&output=json"
        val resp = Net.json(url).optJSONObject("response")
            ?: throw SourceException("Internet Archive no devolvió resultados válidos")
        val docs = resp.optJSONArray("docs") ?: JSONArray()
        val total = resp.optInt("numFound", 0)
        val out = ArrayList<SearchResult>()
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val ident = Net.text(d, "identifier") ?: continue
            val cover = "https://archive.org/services/img/" + Net.encPath(ident)
            out.add(
                SearchResult(
                    sourceId = cfg.id,
                    sourceName = cfg.name,
                    id = ident,
                    title = Net.text(d, "title") ?: ident,
                    author = Net.text(d, "creator"),
                    coverUrl = cover,
                    thumbUrl = cover,
                    description = Net.plain(Net.text(d, "description", " "))?.take(600),
                    genres = emptyList(),
                    languageRaw = Net.text(d, "language", ";"),
                    year = Net.year(Net.text(d, "year")),
                    downloads = emptyList(),
                    detailUrl = "https://archive.org/metadata/" + Net.encPath(ident)
                )
            )
        }
        val next = if (page * ROWS < total && docs.length() > 0) (page + 1).toString() else null
        return SearchPage(out, next)
    }

    override fun details(r: SearchResult): BookDetails {
        if (r.downloads.isNotEmpty()) return BookDetails(r, r.downloads)
        val dl = ArchiveFiles.fetch(r.id)
        return BookDetails(r.withDownloads(dl), dl)
    }

    private companion object {
        const val ROWS = 24
    }
}

/**
 * Open Library: buen catálogo con autor, idioma y portada. Solo obras con ejemplar de acceso público,
 * cuyo archivo vive en Internet Archive (los formatos se resuelven al abrir la ficha).
 */
class OpenLibrarySource(private val cfg: SourceConfig) : Source {
    override val id: String get() = cfg.id
    override val name: String get() = cfg.name

    override fun filtersLanguage(lang: Lang?): Boolean {
        val c = lang?.code ?: return false
        return LangTerms.iso3(c) != null
    }

    override fun search(q: SearchQuery, cursor: String?): SearchPage {
        val page = cursor?.toIntOrNull() ?: 1
        val parts = ArrayList<String>()
        val t = Net.terms(q.text)
        if (t.isNotEmpty()) parts.add("($t)")
        parts.add("ebook_access:public")
        val code = q.lang?.code
        val iso3 = code?.let { LangTerms.iso3(it) }
        if (iso3 != null) parts.add("language:$iso3")
        val url = "https://openlibrary.org/search.json?q=" + Net.enc(parts.joinToString(" AND ")) +
            "&fields=key,title,author_name,first_publish_year,language,ia,cover_i,subject" +
            "&limit=$LIMIT&page=$page"
        val root = Net.json(url)
        val docs = root.optJSONArray("docs") ?: JSONArray()
        val total = root.optInt("numFound", 0)
        val out = ArrayList<SearchResult>()
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val ia = Net.list(d, "ia").take(4)
            if (ia.isEmpty()) continue
            val key = Net.text(d, "key") ?: ia.first()
            val coverId = d.optLong("cover_i", 0L)
            out.add(
                SearchResult(
                    sourceId = cfg.id,
                    sourceName = cfg.name,
                    id = key,
                    title = Net.text(d, "title") ?: continue,
                    author = Net.text(d, "author_name"),
                    coverUrl = if (coverId > 0) "https://covers.openlibrary.org/b/id/$coverId-L.jpg" else null,
                    thumbUrl = if (coverId > 0) "https://covers.openlibrary.org/b/id/$coverId-M.jpg" else null,
                    description = null,
                    genres = Net.list(d, "subject").take(4),
                    languageRaw = Net.text(d, "language", ";"),
                    year = d.optInt("first_publish_year", 0).takeIf { it > 0 }?.toString(),
                    downloads = emptyList(),
                    detailUrl = "ia:" + ia.joinToString(",")
                )
            )
        }
        val next = if (page * LIMIT < total && docs.length() > 0) (page + 1).toString() else null
        return SearchPage(out, next)
    }

    override fun details(r: SearchResult): BookDetails {
        if (r.downloads.isNotEmpty()) return BookDetails(r, r.downloads)
        val ids = (r.detailUrl ?: "").removePrefix("ia:").split(',').filter { it.isNotBlank() }
        var failure: Exception? = null
        for (ident in ids) {
            try {
                val dl = ArchiveFiles.fetch(ident)
                if (dl.isNotEmpty()) return BookDetails(r.withDownloads(dl), dl)
            } catch (e: Exception) {
                failure = e
            }
        }
        if (failure != null && ids.size == 1) throw failure
        return BookDetails(r, emptyList())
    }

    private companion object {
        const val LIMIT = 20
    }
}

/** Google Books: solo libros con EPUB/PDF gratuito (dominio público) descargable. */
class GoogleBooksSource(private val cfg: SourceConfig) : Source {
    override val id: String get() = cfg.id
    override val name: String get() = cfg.name

    override fun filtersLanguage(lang: Lang?): Boolean = lang?.code != null

    override fun search(q: SearchQuery, cursor: String?): SearchPage {
        val start = cursor?.toIntOrNull() ?: 0
        val text = q.text.trim().ifEmpty { "subject:fiction" }
        val code = q.lang?.code
        val url = "https://www.googleapis.com/books/v1/volumes?q=" + Net.enc(text) +
            "&filter=free-ebooks&download=epub&printType=books&maxResults=$MAX&startIndex=$start" +
            (if (code != null) "&langRestrict=$code" else "")
        val root = Net.json(url)
        val items = root.optJSONArray("items") ?: JSONArray()
        val out = ArrayList<SearchResult>()
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val vid = Net.text(item, "id") ?: continue
            val vi = item.optJSONObject("volumeInfo") ?: continue
            val ai = item.optJSONObject("accessInfo")
            val dl = ArrayList<DownloadInfo>()
            for ((key, fmt) in listOf("epub" to DlFormat.EPUB, "pdf" to DlFormat.PDF)) {
                val o = ai?.optJSONObject(key) ?: continue
                val link = Net.https(o.optString("downloadLink", ""))
                if (o.optBoolean("isAvailable", false) && link != null) dl.add(DownloadInfo(fmt, link, null))
            }
            if (dl.isEmpty()) continue
            val thumb = Net.https(vi.optJSONObject("imageLinks")?.optString("thumbnail", ""))
            out.add(
                SearchResult(
                    sourceId = cfg.id,
                    sourceName = cfg.name,
                    id = vid,
                    title = Net.text(vi, "title") ?: continue,
                    author = Net.text(vi, "authors"),
                    coverUrl = thumb,
                    thumbUrl = thumb,
                    description = Net.plain(Net.text(vi, "description", " "))?.take(600),
                    genres = Net.list(vi, "categories").take(4),
                    languageRaw = Net.text(vi, "language"),
                    year = Net.year(Net.text(vi, "publishedDate")),
                    downloads = dl,
                    detailUrl = null
                )
            )
        }
        val next = if (items.length() >= MAX) (start + MAX).toString() else null
        return SearchPage(out, next)
    }

    override fun details(r: SearchResult): BookDetails = BookDetails(r, r.downloads)

    private companion object {
        const val MAX = 20
    }
}

/**
 * Wikisource: obras de dominio público transcritas por voluntarios. El EPUB se genera al vuelo
 * con la herramienta oficial de exportación de Wikimedia. Sin filtro de idioma busca en español e inglés.
 */
class WikisourceSource(private val cfg: SourceConfig) : Source {
    override val id: String get() = cfg.id
    override val name: String get() = cfg.name

    override fun filtersLanguage(lang: Lang?): Boolean = lang?.code != null

    override fun search(q: SearchQuery, cursor: String?): SearchPage {
        val text = q.text.trim()
        if (text.isEmpty()) return SearchPage(emptyList(), null)
        val offset = cursor?.toIntOrNull() ?: 0
        val code = q.lang?.code
        val langs = if (code != null) listOf(code) else listOf("es", "en")
        val out = ArrayList<SearchResult>()
        var more = false
        var ok = 0
        var failure: Exception? = null
        for (lg in langs) {
            try {
                val url = "https://$lg.wikisource.org/w/api.php?action=query&list=search&srsearch=" +
                    Net.enc(text) + "&srnamespace=0&srlimit=$LIMIT&sroffset=$offset&format=json"
                val root = Net.json(url)
                ok++
                if (root.optJSONObject("continue") != null) more = true
                val hits = root.optJSONObject("query")?.optJSONArray("search") ?: continue
                for (i in 0 until hits.length()) {
                    val h = hits.optJSONObject(i) ?: continue
                    val title = h.optString("title", "").trim()
                    // Los subapartados ("Obra/Capítulo 1") no son libros completos.
                    if (title.isEmpty() || title.contains('/')) continue
                    val epub = "https://ws-export.wmcloud.org/?format=epub&lang=$lg&page=" + Net.enc(title)
                    out.add(
                        SearchResult(
                            sourceId = cfg.id,
                            sourceName = cfg.name,
                            id = "$lg:$title",
                            title = title,
                            author = null,
                            coverUrl = null,
                            thumbUrl = null,
                            description = Net.plain(h.optString("snippet", "")),
                            genres = emptyList(),
                            languageRaw = lg,
                            year = null,
                            downloads = listOf(DownloadInfo(DlFormat.EPUB, epub, null)),
                            detailUrl = null
                        )
                    )
                }
            } catch (e: Exception) {
                failure = e
            }
        }
        if (ok == 0 && failure != null) throw failure
        return SearchPage(out, if (more) (offset + LIMIT).toString() else null)
    }

    override fun details(r: SearchResult): BookDetails = BookDetails(r, r.downloads)

    private companion object {
        const val LIMIT = 20
    }
}

/** Crea la fuente adecuada según el tipo de la configuración. */
fun createSource(cfg: SourceConfig): Source = when (cfg.kind) {
    "archive" -> ArchiveSource(cfg)
    "openlibrary" -> OpenLibrarySource(cfg)
    "google" -> GoogleBooksSource(cfg)
    "wikisource" -> WikisourceSource(cfg)
    else -> OpdsSource(cfg)
}
