package com.jullbook.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.AchSnapshot
import com.jullbook.app.data.Achievement
import com.jullbook.app.data.Achievements
import com.jullbook.app.data.Eggs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun AchievementsScreen(vm: AppViewModel, modifier: Modifier = Modifier) {
    val unlocked = remember(vm.achToast, vm.library, vm.memory) { vm.prefs.unlockedAchievements() }
    val snap by produceState<AchSnapshot?>(null, vm.library, vm.memory) {
        value = withContext(Dispatchers.Default) { Achievements.snapshot(vm.library, vm.memory, vm.prefs) }
    }
    val visible = Achievements.ALL.filter { !it.secret || it.id in unlocked }
    val hiddenCount = Achievements.ALL.count { it.secret && it.id !in unlocked }
    val sorted = visible.sortedWith(compareByDescending<Achievement> { it.id in unlocked }.thenByDescending { a ->
        val s = snap
        if (s == null || a.id in unlocked) 0f else a.value(s).toFloat() / a.goal
    })
    // Próximos logros: los 3 no secretos con más avance (solo los que ya llevan algo).
    val next = snap?.let { s ->
        Achievements.ALL
            .filter { !it.secret && it.id !in unlocked && it.goal > 1 && it.value(s) > 0 }
            .sortedByDescending { (it.value(s).toFloat() / it.goal).coerceAtMost(1f) }
            .take(3)
    } ?: emptyList()
    val df = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp, top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.padding(top = 16.dp, bottom = 4.dp)) {
                Text("Logros", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "${unlocked.size} de ${Achievements.ALL.size} desbloqueados",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LinearProgressIndicator(
                    progress = { unlocked.size.toFloat() / Achievements.ALL.size },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
            }
        }
        if (next.isNotEmpty() && snap != null) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("PRÓXIMOS LOGROS", style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary)
                    for (a in next) {
                        val cur = a.value(snap!!).coerceIn(0, a.goal)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(a.emoji, fontSize = 18.sp)
                                Text(a.title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                Text("$cur / ${a.goal}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            LinearProgressIndicator(
                                progress = { cur.toFloat() / a.goal },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                            )
                        }
                    }
                }
            }
        }
        items(sorted, key = { it.id }) { a ->
            val done = a.id in unlocked
            val cur = snap?.let { a.value(it) } ?: 0
            AchRow(a, done, cur, unlocked[a.id]?.let { df.format(Date(it)) })
        }
        if (hiddenCount > 0) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f)).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("🔒", fontSize = 26.sp)
                    Column {
                        Text("Logros secretos", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                        Text(
                            if (hiddenCount == 1) "Queda 1 por descubrir. Juli no suelta prenda."
                            else "Quedan $hiddenCount por descubrir. Juli no suelta prenda.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        val found = vm.eggs.mapNotNull { Eggs.byId(it) }
        item {
            Text(
                "Secretos de Juli · ${found.size}",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 14.dp)
            )
            if (found.isEmpty()) {
                Text(
                    "Juli esconde sorpresas que no son logros. Las verás aquí cuando las encuentres.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        items(found, key = { "egg${it.id}" }) { e ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f)).padding(14.dp)
            ) {
                Text("✨ ${e.title}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(e.line, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun AchRow(a: Achievement, done: Boolean, cur: Int, date: String?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (done) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f)
                else MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.8f)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = if (done) 0.5f else 1f)),
            contentAlignment = Alignment.Center
        ) { Text(a.emoji, fontSize = 22.sp, modifier = Modifier.alpha(if (done) 1f else 0.45f)) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                a.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = if (done) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
            Text(
                if (a.secret && !done) a.hint else a.desc,
                style = MaterialTheme.typography.bodySmall,
                color = if (done) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (done) {
                val tag = (if (a.rare) "✦ Raro · " else "") + (if (date != null) "Desbloqueado · $date" else "Desbloqueado")
                Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
            } else if (a.goal > 1) {
                val shown = cur.coerceIn(0, a.goal)
                LinearProgressIndicator(
                    progress = { shown.toFloat() / a.goal },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
                Text("$shown / ${a.goal} · ${shown * 100 / a.goal}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
