package com.jullbook.app.data

import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.text.Html
import android.text.Layout
import android.text.Spanned
import android.text.SpannedString
import android.text.style.AlignmentSpan
import android.text.style.BulletSpan
import android.text.style.ImageSpan
import android.text.style.QuoteSpan
import android.text.style.RelativeSizeSpan
import androidx.compose.ui.text.style.TextAlign

sealed interface Block

class TextBlock(
    val sp: Spanned,
    val heading: Boolean,
    val align: TextAlign?,
    val quote: Boolean,
    val bullet: Boolean,
    /** Solo en bloques mostrados como traducción: correspondencia frase a frase con el original. */
    val map: com.jullbook.app.translate.BlockMap? = null
) : Block

class ImageBlock(val path: String) : Block

/** Convierte un capítulo XHTML en una lista ligera de bloques (texto con formato e imágenes). */
object EpubText {
    private val BODY = Regex("(?is)<body[^>]*>(.*)</body>")
    private val HEAD = Regex("(?is)<head[^>]*>.*?</head>")
    private val DROP = Regex("(?is)<(script|style)[^>]*>.*?</\\1>")
    private val SVG_IMG = Regex("(?is)<image\\b[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>")

    fun parse(zip: SeekableZip, path: String): List<Block> {
        val e = zip.entry(path) ?: return emptyList()
        var html = String(zip.read(e), Charsets.UTF_8).removePrefix("\uFEFF")
        html = BODY.find(html)?.groupValues?.get(1) ?: HEAD.replace(html, "")
        html = DROP.replace(html, "")
        html = SVG_IMG.replace(html) { "<img src=\"" + it.groupValues[1] + "\"/>" }

        val getter = Html.ImageGetter { _ ->
            val d = ColorDrawable(0)
            d.setBounds(0, 0, 1, 1)
            d
        }
        val sp = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT, getter, null)
        val text = sp.toString()
        val dir = path.substringBeforeLast('/', "")
        val out = ArrayList<Block>()

        fun addText(s0: Int, e0: Int) {
            var s = s0
            var en = e0
            while (s < en && (text[s].isWhitespace() || text[s] == '\uFFFC')) s++
            while (en > s && (text[en - 1].isWhitespace() || text[en - 1] == '\uFFFC')) en--
            if (s >= en) return
            val sub = SpannedString(sp.subSequence(s, en))
            val heading = sub.getSpans(0, sub.length, RelativeSizeSpan::class.java).any { it.sizeChange >= 1.15f }
            val align = when (sub.getSpans(0, sub.length, AlignmentSpan::class.java).firstOrNull()?.alignment) {
                Layout.Alignment.ALIGN_CENTER -> TextAlign.Center
                Layout.Alignment.ALIGN_OPPOSITE -> TextAlign.End
                else -> null
            }
            val quote = sub.getSpans(0, sub.length, QuoteSpan::class.java).isNotEmpty()
            val bullet = sub.getSpans(0, sub.length, BulletSpan::class.java).isNotEmpty()
            out.add(TextBlock(sub, heading, align, quote, bullet))
        }

        var i = 0
        while (i < text.length) {
            var j = text.indexOf('\n', i)
            if (j < 0) j = text.length
            val imgs = sp.getSpans(i, j, ImageSpan::class.java)
                .filter { sp.getSpanStart(it) in i until j }
                .sortedBy { sp.getSpanStart(it) }
            var cur = i
            for (img in imgs) {
                addText(cur, sp.getSpanStart(img))
                val src = img.source
                if (src != null) out.add(ImageBlock(resolvePath(dir, Uri.decode(src.substringBefore('#')))))
                cur = sp.getSpanEnd(img)
            }
            addText(cur, j)
            i = j + 1
        }
        return out
    }
}
