package com.jullbook.app.discover

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/** HTTP mínimo (sin dependencias). Solo HTTPS; las redirecciones se siguen a mano y siempre por HTTPS. */
object Http {
    const val UA = "JullBook/1.2 (lector local)"
    private const val MAX_TEXT = 6 * 1024 * 1024

    /** Credenciales de una fuente; solo se envían al servidor [host] de esa fuente. */
    class Auth(val user: String, val pass: String, val host: String)

    class HttpFail(val code: Int) : IOException("HTTP $code")
    class Insecure : IOException("Solo se admiten direcciones https://")

    /** Abre la conexión ya con respuesta 2xx. El llamador debe hacer disconnect(). */
    fun open(url: String, auth: Auth?, accept: String? = null, readTimeout: Int = 15000): HttpURLConnection {
        var cur = url
        for (hop in 0..5) {
            val u = URL(cur)
            if (!u.protocol.equals("https", true)) throw Insecure()
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = readTimeout
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", UA)
            if (accept != null) c.setRequestProperty("Accept", accept)
            // Las credenciales solo viajan al servidor de la fuente (ni a portadas ni a redirecciones de otros dominios).
            if (auth != null && u.host.equals(auth.host, true)) {
                val raw = (auth.user + ":" + auth.pass).toByteArray(Charsets.UTF_8)
                c.setRequestProperty("Authorization", "Basic " + Base64.getEncoder().encodeToString(raw))
            }
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw HttpFail(code)
                cur = URL(u, loc).toString()
                continue
            }
            if (code !in 200..299) {
                c.disconnect()
                throw HttpFail(code)
            }
            return c
        }
        throw IOException("Demasiadas redirecciones")
    }

    fun bytes(url: String, auth: Auth?, limit: Int = MAX_TEXT): ByteArray {
        val c = open(url, auth)
        try {
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            c.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > limit) throw IOException("Respuesta demasiado grande")
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }

    fun resolve(base: String, href: String): String = try {
        URL(URL(base), href.trim()).toString()
    } catch (e: Exception) {
        href.trim()
    }
}
