package com.jullbook.app.ui.reader

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.translate.TrEngines
import com.jullbook.app.translate.TrError
import com.jullbook.app.translate.TrLangs
import com.jullbook.app.translate.TrStatus
import com.jullbook.app.translate.TranslationManager
import kotlinx.coroutines.CancellationException

/** Hoja "Traducción": Original/Traducción, idiomas, motor, traducir capítulo/libro y progreso. */
@Composable
internal fun TranslateSheet(tm: TranslationManager, cur: Int, chapters: Int, onMode: (Boolean) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    var confirmBook by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        tm.refreshTranslated()
        tm.ensureDetected()
    }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding().padding(bottom = 16.dp)
    ) {
        Text("Traducción", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !tm.showing, onClick = { onMode(false) }, label = { Text("Original") })
            FilterChip(selected = tm.showing, onClick = { onMode(true) }, label = { Text("Traducción") })
        }
        val here = cur in tm.translated
        Text(
            when {
                !tm.translatedKnown -> " "
                here -> "Este capítulo está traducido · ${tm.translated.size} de $chapters en el libro"
                else -> "Este capítulo aún no está traducido · ${tm.translated.size} de $chapters en el libro"
            },
            style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
        )

        val sourceOptions = listOf("auto" to "Automático") + TrLangs.all.map { it.code to it.label }
        val detectedCode = tm.detected
        val sourceLabel = if (tm.from == "auto") {
            "Automático" + (if (detectedCode != null) " (${TrLangs.label(detectedCode)})" else " (sin detectar)")
        } else {
            TrLangs.label(tm.from)
        }
        LangPicker("Idioma de origen", sourceLabel, sourceOptions) { tm.useFrom(it) }
        LangPicker("Idioma de destino", TrLangs.label(tm.to), TrLangs.all.map { it.code to it.label }) { tm.useTo(it) }
        LangPicker("Motor", TrEngines.label(tm.engineId), TrEngines.all) { tm.useEngine(it) }

        if (tm.engineId == TrEngines.LIBRE) {
            var url by remember { mutableStateOf(tm.libreUrl) }
            var key by remember { mutableStateOf(tm.libreKey) }
            OutlinedTextField(
                value = url, onValueChange = { url = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                label = { Text("Servidor (https://…)") }
            )
            OutlinedTextField(
                value = key, onValueChange = { key = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                label = { Text("Clave de API (opcional)") }
            )
            TextButton(onClick = { tm.useLibre(url, key) }) { Text("Guardar servidor") }
        }

        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { tm.translateChapter(cur) }, enabled = !tm.running) { Text("Traducir capítulo") }
            OutlinedButton(onClick = { confirmBook = true }, enabled = !tm.running) { Text("Traducir libro") }
        }

        val st = tm.status
        if (tm.running) {
            Spacer(Modifier.height(10.dp))
            Text(statusText(st, tm.preparing), style = MaterialTheme.typography.labelLarge)
            val f = statusFrac(st)
            if (f != null) {
                LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
            TextButton(onClick = { tm.cancel() }) { Text("Cancelar") }
        } else if (st is TrStatus.Failed) {
            Text(st.message, style = MaterialTheme.typography.bodyMedium, color = scheme.error, modifier = Modifier.padding(top = 10.dp))
            TextButton(onClick = { tm.clearError() }) { Text("Entendido") }
        }

        Text(
            if (tm.engineId == TrEngines.MLKIT) {
                "La traducción se hace en tu teléfono con Google ML Kit: el texto no sale del dispositivo. Solo se descarga el modelo " +
                    "de cada idioma la primera vez (unos 30 MB); después funciona sin conexión. El libro no se modifica y las " +
                    "traducciones se guardan aquí y no se repiten."
            } else {
                "El texto solo se envía a ${tm.destination} cuando tú pulsas Traducir. El archivo del libro no se modifica ni se sube; " +
                    "las traducciones se guardan en este teléfono y no se vuelven a pedir."
            },
            style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp)
        )
    }

    if (confirmBook) {
        AlertDialog(
            onDismissRequest = { confirmBook = false },
            title = { Text("Traducir el libro") },
            text = {
                Text(
                    (if (tm.engineId == TrEngines.MLKIT) "Los capítulos se traducirán en tu teléfono de uno en uno, " else "Los capítulos se enviarán de uno en uno a ${tm.destination} para traducirlos, ") +
                        "empezando por el capítulo actual. " +
                        "Puedes seguir leyendo mientras tanto, cancelar cuando quieras y reanudar después sin repetir lo ya traducido."
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmBook = false; tm.translateBook(cur) }) { Text("Traducir") }
            },
            dismissButton = { TextButton(onClick = { confirmBook = false }) { Text("Cancelar") } }
        )
    }
}

private fun statusText(st: TrStatus, preparing: Boolean): String = if (preparing) "Preparando el idioma (solo la primera vez se descarga)…" else when (st) {
    is TrStatus.Chapter -> "Traduciendo el capítulo… " + (if (st.total > 0) "${st.done * 100 / st.total}%" else "")
    is TrStatus.Book -> "Traduciendo el libro · capítulo ${st.index + 1} de ${st.count}"
    else -> ""
}

private fun statusFrac(st: TrStatus): Float? = when (st) {
    is TrStatus.Chapter -> if (st.total > 0) st.done.toFloat() / st.total else null
    is TrStatus.Book -> {
        val inner = if (st.total > 0) st.done.toFloat() / st.total else 0f
        ((st.index + inner) / st.count.coerceAtLeast(1)).coerceIn(0f, 1f)
    }
    else -> null
}

@Composable
private fun LangPicker(label: String, current: String, options: List<Pair<String, String>>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        Box {
            OutlinedButton(onClick = { open = true }) {
                Text(current, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                for ((code, name) in options) {
                    DropdownMenuItem(text = { Text(name) }, onClick = { open = false; onPick(code) })
                }
            }
        }
    }
}

/**
 * Progreso / aviso de traducción. Con los controles visibles va dentro de la barra inferior; con los controles
 * ocultos es una pastilla arriba (no tapa el texto ni bloquea la lectura).
 */
@Composable
internal fun TranslateStatus(tm: TranslationManager, cur: Int, pill: Boolean) {
    val st = tm.status
    var text: String? = null
    var frac: Float? = null
    var action: String? = null
    var onAction: () -> Unit = {}
    when {
        st is TrStatus.Chapter || st is TrStatus.Book -> {
            text = statusText(st, tm.preparing)
            frac = statusFrac(st)
            action = "Cancelar"
            onAction = { tm.cancel() }
        }
        st is TrStatus.Failed -> {
            text = st.message
            action = "OK"
            onAction = { tm.clearError() }
        }
        tm.showing && tm.translatedKnown && cur !in tm.translated -> {
            text = "Capítulo sin traducir"
            action = "Traducir"
            onAction = { tm.translateChapter(cur) }
        }
    }
    val t: String = text ?: return
    val act: String? = action
    val run: () -> Unit = onAction
    val fr: Float? = frac
    if (pill) {
        Surface(shape = RoundedCornerShape(50), color = Color(0xCC000000)) {
            Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (tm.running) {
                    CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.size(8.dp))
                }
                Text(
                    t, style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                )
                if (act != null) TextButton(onClick = run) { Text(act) }
            }
        }
    } else {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t, style = MaterialTheme.typography.labelMedium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (act != null) TextButton(onClick = run) { Text(act) }
            }
            if (tm.running) {
                if (fr != null) {
                    LinearProgressIndicator(progress = { fr }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

/** Traducción de la frase seleccionada dentro de la hoja de resaltado; no modifica el texto original. */
@Composable
internal fun SnippetTranslation(tm: TranslationManager, ch: Int, block: Int, s: Int, e: Int, text: String, preset: String?) {
    var result by remember(ch, block, s, e) { mutableStateOf(preset) }
    var error by remember(ch, block, s, e) { mutableStateOf<String?>(null) }
    var busy by remember(ch, block, s, e) { mutableStateOf(false) }
    var req by remember(ch, block, s, e) { mutableIntStateOf(0) }
    LaunchedEffect(req) {
        if (req > 0) {
            busy = true
            error = null
            try {
                result = tm.translateSentence(ch, block, s, e, text)
            } catch (x: CancellationException) {
                throw x
            } catch (x: TrError) {
                error = x.message
            } catch (x: Exception) {
                error = "No se pudo traducir."
            }
            busy = false
        }
    }
    val r = result
    if (r != null) {
        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Text("Traducción · ${TrLangs.label(tm.to)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text("«$r»", style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic)
        }
    } else {
        Row(
            Modifier.fillMaxWidth().clickable(enabled = !busy) { req++ }.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Traducir", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
    }
}
