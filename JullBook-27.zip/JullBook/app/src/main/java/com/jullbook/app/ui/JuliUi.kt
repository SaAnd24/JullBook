package com.jullbook.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate as rotateScope
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.JuliMsg
import com.jullbook.app.data.Achievement
import kotlinx.coroutines.delay
import kotlin.random.Random

/** Juli: un círculo con carita dibujado a mano. Parpadea de vez en cuando y gira si le haces cosquillas. */
@Composable
fun JuliAvatar(modifier: Modifier = Modifier, size: Dp = 40.dp, spin: Int = 0, onClick: (() -> Unit)? = null) {
    val rot = remember { Animatable(0f) }
    LaunchedEffect(spin) {
        if (spin > 0) rot.animateTo(rot.value + 360f, tween(700))
    }
    val blink by rememberInfiniteTransition(label = "blink").animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            keyframes {
                durationMillis = 4200
                1f at 0
                1f at 3900
                0.1f at 4000
                1f at 4100
            },
            RepeatMode.Restart
        ),
        label = "blinkV"
    )
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.tertiary
    val ink = MaterialTheme.colorScheme.onPrimary
    var m = modifier.size(size).rotate(rot.value)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Canvas(m) {
        val r = this.size.minDimension / 2f
        drawCircle(Brush.linearGradient(listOf(a, b), Offset.Zero, Offset(this.size.width, this.size.height)), radius = r)
        val ex = this.size.width * 0.22f
        val ey = this.size.height * 0.42f
        val rw = this.size.width * 0.075f
        val rh = rw * blink
        for (sx in listOf(-1f, 1f)) {
            drawOval(ink, topLeft = Offset(center.x + sx * ex - rw, ey - rh), size = Size(rw * 2, rh * 2))
        }
        drawArc(
            color = ink,
            startAngle = 25f,
            sweepAngle = 130f,
            useCenter = false,
            topLeft = Offset(center.x - this.size.width * 0.2f, this.size.height * 0.45f),
            size = Size(this.size.width * 0.4f, this.size.height * 0.28f),
            style = Stroke(width = this.size.width * 0.06f, cap = StrokeCap.Round)
        )
    }
}

/** Burbuja breve de Juli. Aparece sola y se va sola. */
@Composable
fun JuliBubbleHost(vm: AppViewModel, modifier: Modifier = Modifier) {
    val msg = vm.bubble
    LaunchedEffect(msg?.id) {
        val m = msg ?: return@LaunchedEffect
        delay(if (m.title != null) 8000 else 6500)
        vm.dismissBubble(m.id)
    }
    AnimatedContent(
        targetState = msg,
        modifier = modifier,
        transitionSpec = { (fadeIn(tween(250)) + slideInVertically(tween(300)) { it / 2 }) togetherWith (fadeOut(tween(200)) + slideOutVertically(tween(250)) { it / 2 }) },
        label = "bubble"
    ) { m: JuliMsg? ->
        if (m != null) {
            Surface(
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().clickable { vm.dismissBubble(m.id) },
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHighest,
                tonalElevation = 6.dp,
                shadowElevation = 10.dp
            ) {
                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    JuliAvatar(size = 34.dp)
                    Column(Modifier.weight(1f)) {
                        Text(m.title ?: "Juli", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(m.text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

/** Aviso de logro desbloqueado. */
@Composable
fun AchievementToast(ach: Achievement?, onDone: () -> Unit, modifier: Modifier = Modifier) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    LaunchedEffect(ach?.id) {
        if (ach != null) {
            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
            delay(if (ach.rare) 5200 else 3800)
            onDone()
        }
    }
    AnimatedContent(
        targetState = ach,
        modifier = modifier,
        transitionSpec = { (fadeIn(tween(250)) + slideInVertically(tween(350)) { -it }) togetherWith (fadeOut(tween(200)) + slideOutVertically(tween(250)) { -it }) },
        label = "ach"
    ) { a: Achievement? ->
        if (a != null) {
            // El icono "salta" con un rebote al aparecer; los logros raros llevan además un borde de acento.
            val pop = remember(a.id) { Animatable(0.4f) }
            LaunchedEffect(a.id) {
                pop.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.35f, stiffness = 260f))
            }
            Surface(
                modifier = Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clickable(onClick = onDone),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                shadowElevation = 12.dp,
                border = if (a.rare) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(a.emoji, fontSize = 28.sp, modifier = Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value })
                    Column {
                        Text(if (a.rare) "✦ Logro raro desbloqueado" else "Logro desbloqueado", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(a.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

private class Piece(val x: Float, val vx: Float, val vy: Float, val size: Float, val rot: Float, val spin: Float, val color: Int)

/** Confeti local (sin librerías). Se dispara cada vez que sube [count]. */
@Composable
fun ConfettiOverlay(count: Int) {
    val t = remember { Animatable(1f) }
    LaunchedEffect(count) {
        if (count > 0) {
            t.snapTo(0f)
            t.animateTo(1f, tween(2600, easing = LinearEasing))
        }
    }
    if (t.value >= 1f) return
    val cols = listOf(
        MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.secondary,
        Color(0xFFFF6B8B), Color(0xFF55D6BE), Color(0xFFFFD166)
    )
    val pieces = remember(count) {
        val r = Random(count * 7919)
        List(70) {
            Piece(r.nextFloat(), (r.nextFloat() - 0.5f) * 0.25f, 0.55f + r.nextFloat() * 0.9f, 6f + r.nextFloat() * 8f,
                r.nextFloat() * 360f, (r.nextFloat() - 0.5f) * 720f, r.nextInt(6))
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        val p = t.value
        val alpha = if (p > 0.8f) (1f - p) / 0.2f else 1f
        for (c in pieces) {
            val x = (c.x + c.vx * p) * size.width
            val y = (-0.08f + c.vy * p * 1.25f) * size.height
            rotateScope(c.rot + c.spin * p, pivot = Offset(x, y)) {
                drawRect(cols[c.color].copy(alpha = alpha), Offset(x, y), Size(c.size * 1.6f, c.size))
            }
        }
    }
}

/** Texto de Juli en una "nota" con acento a la izquierda (Inicio, tarjetas, Sorpréndeme). */
@Composable
fun JuliNote(text: String, modifier: Modifier = Modifier, avatarSpin: Int = 0, onAvatar: (() -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.78f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        JuliAvatar(size = 30.dp, spin = avatarSpin, onClick = onAvatar)
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            fontStyle = FontStyle.Italic,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun Dot(color: Color, size: Dp = 8.dp) {
    Box(Modifier.size(size).background(color, CircleShape))
}
