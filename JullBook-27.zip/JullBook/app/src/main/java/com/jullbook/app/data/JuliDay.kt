package com.jullbook.app.data

import java.util.Calendar

/** Humor de Juli del día. Se elige con reglas locales (racha, día de la semana, fecha) y un poco de variedad estable. */
enum class JuliMood(val label: String, val lines: List<String>) {
    ORGULLOSA("orgullosa", listOf(
        "Llevas una racha preciosa y hoy me siento un poco responsable.",
        "Hoy presumo de lector. Disimulando, claro.",
        "Estoy de buen humor: tu constancia se nota."
    )),
    RELAJADA("relajada", listOf(
        "Hoy no hay prisa. Lee a tu ritmo o no leas, aquí estaré.",
        "Día para lo tranquilo: un capítulo, una manta y listo.",
        "Fin de semana: la biblioteca y yo vamos en pijama."
    )),
    DRAMATICA("dramática", listOf(
        "Lunes. Solo los libros salvan a la humanidad.",
        "Hoy todo me parece épico, hasta abrir una página.",
        "El destino de esta tarde está en tus manos. O en tu pila de pendientes."
    )),
    MISTERIOSA("misteriosa", listOf(
        "Hay algo raro en el aire. Seguro que es un buen libro.",
        "Hoy guardo secretos. No te los pienso contar.",
        "Los viernes 13 todo es posible, hasta una lectura redonda."
    )),
    CURIOSA("curiosa", listOf(
        "Hoy quiero saber qué vas a abrir.",
        "Tengo curiosidad por lo que elijas hoy.",
        "Pregunta del día: ¿seguir o descubrir?"
    )),
    SABIONDA("sabionda", listOf(
        "Dato del día: leer un rato siempre gana a no leer.",
        "Hoy me siento enciclopédica. Aunque no pregunten.",
        "Humor de bibliotecaria: todo en su sitio, menos tú, que lees en el sofá."
    )),
    TRANQUILA("tranquila", listOf(
        "Hoy estoy serena. Que sea una lectura sin sobresaltos.",
        "Respira, lee, repite.",
        "Día en calma. La biblioteca lo agradece."
    )),
    TRAVIESA("traviesa", listOf(
        "Hoy tengo ganas de recomendarte lo que menos esperas.",
        "Me siento juguetona. Cuidado con Sorpréndeme.",
        "Hoy podría esconder un secreto. O no. O sí."
    ));
}

object JuliDay {
    /** Humor y frase de hoy. Misma respuesta durante todo el día. */
    fun today(userName: String, streak: Int, cal: Calendar = Calendar.getInstance()): Pair<JuliMood, String> {
        val doy = cal.get(Calendar.DAY_OF_YEAR)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val dom = cal.get(Calendar.DAY_OF_MONTH)
        val mood = when {
            dow == Calendar.FRIDAY && dom == 13 -> JuliMood.MISTERIOSA
            streak >= 5 -> JuliMood.ORGULLOSA
            dow == Calendar.SATURDAY || dow == Calendar.SUNDAY -> JuliMood.RELAJADA
            dow == Calendar.MONDAY -> JuliMood.DRAMATICA
            else -> {
                val pool = listOf(JuliMood.CURIOSA, JuliMood.SABIONDA, JuliMood.TRANQUILA, JuliMood.TRAVIESA)
                pool[Math.floorMod(doy * 31 + userName.lowercase().hashCode(), pool.size)]
            }
        }
        return mood to mood.lines[doy % mood.lines.size]
    }
}
