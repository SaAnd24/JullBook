package com.jullbook.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.OrgDialog

/** Barra de acciones de la multiselección. Solo cambia metadatos de la app; los archivos nunca se tocan. */
@Composable
fun SelectionBar(vm: AppViewModel, inSeries: Boolean, modifier: Modifier = Modifier) {
    val ids = vm.selectedBookIds()
    if (vm.selection.isEmpty()) return
    val lib = vm.library
    var menu by remember { mutableStateOf(false) }
    val anyInCollection = ids.any { lib.bookSeries.containsKey(it) }
    val anyAlias = ids.any { lib.books[it]?.alias != null }
    val single = ids.size == 1
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 3.dp
    ) {
        Row(
            Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            IconButton(onClick = { vm.clearSelection() }) {
                Icon(Icons.Default.Close, contentDescription = "Cancelar selección")
            }
            Text(
                "${vm.selection.size}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 4.dp)
            )
            Box(Modifier.weight(1f))
            TextButton(onClick = { vm.dialog = OrgDialog.MoveTo(ids) }, enabled = ids.isNotEmpty()) { Text("Mover") }
            if (inSeries && anyInCollection) {
                TextButton(onClick = { vm.removeFromSaga(ids) }) { Text("Sacar") }
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Más opciones")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (anyInCollection) {
                        DropdownMenuItem(
                            text = { Text("Renombrar internamente…") },
                            onClick = { menu = false; vm.dialog = OrgDialog.RenameOffer(ids) }
                        )
                    }
                    if (anyAlias) {
                        DropdownMenuItem(
                            text = { Text("Restaurar nombre original") },
                            onClick = { menu = false; vm.restoreNames(ids); vm.clearSelection() }
                        )
                    }
                    if (single) {
                        DropdownMenuItem(
                            text = { Text("Corregir número…") },
                            onClick = { menu = false; vm.dialog = OrgDialog.EditNumber(ids[0]) }
                        )
                        if (ids[0] in lib.overridden) {
                            DropdownMenuItem(
                                text = { Text("Restablecer organización") },
                                onClick = { menu = false; vm.resetOrganization(ids[0]) }
                            )
                        }
                    }
                    DropdownMenuItem(
                        text = { Text("Cancelar selección") },
                        onClick = { menu = false; vm.clearSelection() }
                    )
                }
            }
        }
    }
}
