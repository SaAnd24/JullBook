package com.jullbook.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.size
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.jullbook.app.data.LibraryView
import com.jullbook.app.data.SortMode
import com.jullbook.app.data.isRereading
import com.jullbook.app.data.lastReadLabel
import com.jullbook.app.data.statusCaption
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.jullbook.app.OrgDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.pctText
import com.jullbook.app.data.volLabel

@Composable
fun SeriesScreen(series: SeriesItem, vm: AppViewModel, onBack: () -> Unit) {
    val target = series.target()
    val haptic = LocalHapticFeedback.current
    var sortMenu by remember { mutableStateOf(false) }
    val volumes = remember(series, vm.seriesSort) { series.volumes.sortedWith(LibraryView.volComparator(vm.seriesSort)) }
    // Hay algo que reiniciar si algún elemento tiene lectura en curso o ya se había terminado alguna vez.
    val canReset = series.volumes.any { it.progress != null || it.book.reads > 0 }
    Box(Modifier.fillMaxSize()) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(92.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = if (vm.selection.isNotEmpty()) 96.dp else 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.fillMaxWidth().statusBarsPadding()) {
                var menu by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                    Spacer(Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Más opciones")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Añadir tomos") },
                                onClick = { menu = false; vm.dialog = OrgDialog.AddVolumes(series.key) }
                            )
                            if (series.isManual) {
                                DropdownMenuItem(
                                    text = { Text("Eliminar colección") },
                                    onClick = { menu = false; vm.dialog = OrgDialog.DeleteSaga(series.key) }
                                )
                            }
                        }
                    }
                }
                Text(
                    series.name.uppercase(),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${series.volumes.size} ${if (series.isBooks) "libros" else "tomos"} · ${pctText(series.percent)} completado" +
                        if (series.rereading) " · Releyendo" else "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (series.rereading) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = if (series.reads > 0) 4.dp else 16.dp)
                )
                if (series.reads > 0) {
                    Row(
                        Modifier.padding(bottom = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReadsBadge(series.reads, onCover = false)
                        Text(
                            "Leída completa " + (if (series.reads == 1) "1 vez" else "${series.reads} veces"),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (series.volumes.isEmpty()) {
                    Text(
                        "Esta colección está vacía. Usa el menú para añadir tomos.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (target != null) {
                        Button(onClick = { vm.openBook(target.book) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Text(
                                (if (target.progress == null) "Empezar " else "Continuar ") + volLabel(target.book),
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                    }
                    if (canReset) {
                        OutlinedButton(onClick = { vm.dialog = OrgDialog.ResetReading(series.key) }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("Reiniciar lectura", modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        if (series.isBooks) "Libros" else "Tomos",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Box {
                        TextButton(onClick = { sortMenu = true }) {
                            Text("Ordenar: ${vm.seriesSort.label}")
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            for (m in SortMode.entries) {
                                DropdownMenuItem(
                                    text = { Text(m.label) },
                                    trailingIcon = {
                                        if (vm.seriesSort == m) Icon(Icons.Default.Check, contentDescription = "Activo")
                                    },
                                    onClick = { sortMenu = false; vm.changeSeriesSort(m) }
                                )
                            }
                        }
                    }
                }
            }
        }
        items(volumes, key = { it.book.id }) { v ->
            val p = v.progress
            val finished = p?.status == ST_FINISHED
            val selecting = vm.selection.isNotEmpty()
            val sid = "b${v.book.id}"
            BookCard(
                title = volLabel(v.book),
                subtitle = null,
                caption = statusCaption(v.book, p),
                coverPath = v.book.coverPath,
                progress = p?.percent ?: 0f,
                finished = finished,
                stack = false,
                onClick = { if (selecting) vm.toggleSelect(sid) else vm.openBook(v.book) },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    vm.toggleSelect(sid)
                },
                selected = sid in vm.selection,
                format = v.book.format,
                reads = v.book.reads,
                rereading = isRereading(v.book, p),
                lastRead = lastReadLabel(p?.lastRead),
                modifier = Modifier.animateItem()
            )
        }
    }
    SelectionBar(vm, inSeries = true, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
