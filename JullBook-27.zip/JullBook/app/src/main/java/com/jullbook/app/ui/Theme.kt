package com.jullbook.app.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils

val Amber = Color(0xFFE8A93C)

/** Tema predefinido. [hidden] = solo aparece cuando Juli lo desbloquea con un easter egg. */
class ThemeSpec(val id: String, val name: String, val colors: ColorScheme, val hidden: Boolean = false) {
    val dark: Boolean get() = colors.background.luminance() < 0.5f
}

private val AmoledColors = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF241700),
    primaryContainer = Color(0xFF3A2A08),
    onPrimaryContainer = Color(0xFFFFDDA0),
    secondary = Color(0xFFD2BFA0),
    background = Color(0xFF000000),
    onBackground = Color(0xFFEDE6DA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFEDE6DA),
    surfaceVariant = Color(0xFF1B1A18),
    onSurfaceVariant = Color(0xFFB9B1A3),
    surfaceContainer = Color(0xFF0F0E0D),
    surfaceContainerHigh = Color(0xFF191817),
    surfaceContainerHighest = Color(0xFF242321),
    outline = Color(0xFF5A554C),
    outlineVariant = Color(0xFF2E2B27)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF8A5A00),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE2B0),
    onPrimaryContainer = Color(0xFF2C1B00),
    secondary = Color(0xFF6B5B3E),
    background = Color(0xFFFBF8F3),
    onBackground = Color(0xFF1D1B17),
    surface = Color(0xFFFBF8F3),
    onSurface = Color(0xFF1D1B17),
    surfaceVariant = Color(0xFFEDE5D8),
    onSurfaceVariant = Color(0xFF4D463A),
    surfaceContainer = Color(0xFFF4EEE4),
    surfaceContainerHigh = Color(0xFFEEE7DA),
    surfaceContainerHighest = Color(0xFFE8E0D2),
    outline = Color(0xFF7F7667),
    outlineVariant = Color(0xFFD3C9B8)
)

/** Sube el contraste de [fg] sobre [bg] acercándolo al blanco o al negro hasta cumplir [min]. */
fun ensureContrast(fg: Color, bg: Color, min: Float): Color {
    var c = fg
    val toLight = bg.luminance() < 0.5f
    var i = 0
    while (ColorUtils.calculateContrast(c.toArgb(), bg.toArgb()) < min && i < 24) {
        c = lerp(c, if (toLight) Color.White else Color.Black, 0.12f)
        i++
    }
    return c
}

/** Esquema Material completo y coherente a partir de tres colores: fondo, acento y texto. */
fun buildScheme(bg: Color, accentIn: Color, text: Color): ColorScheme {
    val dark = bg.luminance() < 0.5f
    val accent = ensureContrast(accentIn, bg, 3f)
    val base = if (dark) darkColorScheme() else lightColorScheme()
    val fixedText = ensureContrast(text, bg, 7f)
    val onAccent = if (accent.luminance() > 0.42f) Color(0xFF1A1305) else Color.White
    val container = lerp(bg, accent, if (dark) 0.24f else 0.22f)
    val hsl = FloatArray(3)
    ColorUtils.colorToHSL(accent.toArgb(), hsl)
    val tertiary = Color(ColorUtils.HSLToColor(floatArrayOf((hsl[0] + 42f) % 360f, hsl[1], hsl[2])))
    fun lv(t: Float) = lerp(bg, fixedText, t)
    return base.copy(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = container,
        onPrimaryContainer = ensureContrast(fixedText, container, 6f),
        secondary = lerp(accent, fixedText, 0.35f),
        onSecondary = onAccent,
        secondaryContainer = lv(if (dark) 0.14f else 0.11f),
        onSecondaryContainer = fixedText,
        tertiary = ensureContrast(tertiary, bg, 3.5f),
        onTertiary = onAccent,
        background = bg,
        onBackground = fixedText,
        surface = bg,
        onSurface = fixedText,
        surfaceVariant = lv(if (dark) 0.14f else 0.11f),
        onSurfaceVariant = lerp(fixedText, bg, 0.3f),
        surfaceTint = accent,
        surfaceDim = lv(0.0f),
        surfaceBright = lv(if (dark) 0.16f else 0.0f),
        surfaceContainerLowest = lv(0.0f),
        surfaceContainerLow = lv(if (dark) 0.03f else 0.025f),
        surfaceContainer = lv(if (dark) 0.055f else 0.045f),
        surfaceContainerHigh = lv(if (dark) 0.09f else 0.075f),
        surfaceContainerHighest = lv(if (dark) 0.14f else 0.11f),
        outline = lv(0.45f),
        outlineVariant = lv(0.2f)
    )
}

private fun c(argb: Long) = Color(argb)

/** Todos los temas. "Automático" (id "auto") sigue al sistema: AMOLED de noche y Claro de día. */
val THEMES: List<ThemeSpec> = listOf(
    ThemeSpec("amoled", "Negro AMOLED", AmoledColors),
    ThemeSpec("light", "Claro", LightColors),
    ThemeSpec("papel", "Papel", buildScheme(c(0xFFF6EFE0), c(0xFF9A4F1D), c(0xFF2B2118))),
    ThemeSpec("sepia", "Sepia nocturna", buildScheme(c(0xFF1C1612), c(0xFFD9A066), c(0xFFE8D9C2))),
    ThemeSpec("bosque", "Bosque", buildScheme(c(0xFF0E1A14), c(0xFF7BC58F), c(0xFFDCEBDD))),
    ThemeSpec("oceano", "Océano", buildScheme(c(0xFF0B1622), c(0xFF5BB4E5), c(0xFFD9E8F4))),
    ThemeSpec("ciruela", "Ciruela", buildScheme(c(0xFF1A0F1E), c(0xFFE58BD1), c(0xFFF0DDEE))),
    ThemeSpec("atardecer", "Atardecer", buildScheme(c(0xFF1F1210), c(0xFFFF8A5B), c(0xFFF7E3D8))),
    ThemeSpec("lavanda", "Lavanda", buildScheme(c(0xFFF4F0FA), c(0xFF6B4FC4), c(0xFF211B2E))),
    ThemeSpec("menta", "Menta", buildScheme(c(0xFFEEF7F2), c(0xFF1F8A5B), c(0xFF14261E))),
    // Ocultos: los desbloquea Juli.
    ThemeSpec("rosa_juli", "Rosa Juli", buildScheme(c(0xFFFFF0F5), c(0xFFD6336C), c(0xFF3A1F2B)), hidden = true),
    ThemeSpec("madrugada", "Madrugada", buildScheme(c(0xFF05060F), c(0xFF8EA2FF), c(0xFFC9D0F2)), hidden = true),
    ThemeSpec("neon", "Neón Juli", buildScheme(c(0xFF07070A), c(0xFF00F5A0), c(0xFFE8FFF6)), hidden = true),
    ThemeSpec("dorado", "Dorado", buildScheme(c(0xFF17120A), c(0xFFFFC857), c(0xFFF6E8C8)), hidden = true)
)

fun themeById(id: String): ThemeSpec? = THEMES.firstOrNull { it.id == id }

/** Esquema estable del usuario: el que usa el lector y la base de Juli Experience. */
fun resolveScheme(id: String, customBg: Int, customAccent: Int, customText: Int, systemDark: Boolean): ColorScheme = when (id) {
    "auto" -> if (systemDark) AmoledColors else LightColors
    "custom" -> buildScheme(Color(customBg), Color(customAccent), Color(customText))
    else -> themeById(id)?.colors ?: if (systemDark) AmoledColors else LightColors
}

private val BaseType = Typography()

/** Tipografía editorial: títulos con serif del sistema, texto de interfaz sin serif. Sin fuentes extra. */
val JullTypography = Typography(
    displayLarge = BaseType.displayLarge.copy(fontFamily = FontFamily.Serif),
    displayMedium = BaseType.displayMedium.copy(fontFamily = FontFamily.Serif),
    displaySmall = BaseType.displaySmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineLarge = BaseType.headlineLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineMedium = BaseType.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    headlineSmall = BaseType.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
    titleLarge = BaseType.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold)
)

private val JullShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun JullTheme(colors: ColorScheme, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = JullTypography, shapes = JullShapes, content = content)
}
