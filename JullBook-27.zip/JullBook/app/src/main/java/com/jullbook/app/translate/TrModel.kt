package com.jullbook.app.translate

import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import com.jullbook.app.data.Block
import com.jullbook.app.data.TextBlock
import kotlin.math.roundToInt

/**
 * Correspondencia frase a frase entre un bloque original y su traducción.
 * Todo lo que el lector guarda (marcadores, notas, resaltados, progreso, narración) sigue estando en coordenadas del
 * TEXTO ORIGINAL; este mapa solo sirve para dibujarlo / leerlo sobre la traducción, así que la longitud de la
 * traducción no importa.
 */
class BlockMap(
    val orig: String,
    /** 3 si el bloque es una viñeta (el lector antepone "•  "), 0 en caso contrario. */
    val shift: Int,
    val oS: IntArray,
    val oE: IntArray,
    val tText: String,
    val tS: IntArray,
    val tE: IntArray
) {
    val count: Int get() = oS.size

    fun sentence(i: Int): String = tText.substring(tS[i], tE[i])

    fun trSentenceAt(pos: Int): Int {
        for (i in 0 until count) if (pos < tE[i]) return i
        return count - 1
    }

    fun origSentenceAt(pos: Int): Int {
        for (i in 0 until count) if (pos < oE[i]) return i
        return count - 1
    }

    /** Rango traducido que cubre las frases que tocan el rango original [s, e); null si no toca ninguna. */
    fun origRangeToTr(s: Int, e: Int): Pair<Int, Int>? {
        var first = -1
        var last = -1
        for (i in 0 until count) {
            if (oE[i] > s && oS[i] < e) {
                if (first < 0) first = i
                last = i
            }
        }
        if (first < 0) return null
        return tS[first] to tE[last]
    }

    fun trPosToOrig(pos: Int): Int = oS[trSentenceAt(pos.coerceAtLeast(0))]

    fun origPosToTr(pos: Int): Int = tS[origSentenceAt(pos.coerceAtLeast(0))]

    fun toCanonFrac(f: Float): Float {
        val vp = (f * (tText.length + shift)).roundToInt() - shift
        val op = trPosToOrig(vp)
        return (op + shift).toFloat() / (orig.length + shift).coerceAtLeast(1)
    }

    fun toViewFrac(f: Float): Float {
        val op = (f * (orig.length + shift)).roundToInt() - shift
        val vp = origPosToTr(op)
        return (vp + shift).toFloat() / (tText.length + shift).coerceAtLeast(1)
    }
}

/** Traducción de un capítulo validada contra el contenido actual del EPUB. [stamp] identifica motor+idiomas+contenido. */
class TrChapter(val ch: Int, val stamp: String, private val maps: Array<BlockMap?>) {
    val size: Int get() = maps.size

    fun map(block: Int): BlockMap? = maps.getOrNull(block)

    /** Sustituye el texto de los bloques traducidos conservando índice, tipo (título, cita, viñeta) e imágenes. */
    fun withText(blocks: List<Block>): List<Block> = blocks.mapIndexed { i, b ->
        val m = maps.getOrNull(i)
        if (b is TextBlock && m != null) {
            val sp = SpannableString(m.tText)
            if (b.heading && sp.isNotEmpty()) {
                val rs = b.sp.getSpans(0, b.sp.length, RelativeSizeSpan::class.java).maxByOrNull { it.sizeChange }
                if (rs != null) sp.setSpan(RelativeSizeSpan(rs.sizeChange), 0, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            TextBlock(sp, b.heading, b.align, b.quote, b.bullet, m)
        } else {
            b
        }
    }
}

/** Lo que necesita el paginador para saber qué mostrar de cada capítulo. */
interface TrView {
    fun displayed(ch: Int): TrChapter?
}

/** Lo que necesita el narrador para leer la traducción en lugar del original. */
interface SpeakSource {
    val targetTag: String
    suspend fun chapter(ch: Int): TrChapter?
    fun isTranslated(ch: Int): Boolean
}
