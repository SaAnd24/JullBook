package com.jullbook.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NewBook(
    val uri: String,
    val fileName: String,
    val format: Format,
    val title: String,
    val series: String?,
    val seriesKey: String?,
    val number: Int?,
    val folder: String,
    val size: Long,
    val modified: Long
)

/** Corrección manual de un libro. grp: "" = automático, "-" = suelto, "m:<id>" = saga manual, otro = serie automática forzada. */
class BookOverride(val grp: String, val gname: String?, val number: Int?)

/** isBooks: colección de libros (EPUB/PDF); si no, de cómics. */
class ManualSeries(val id: Long, val name: String, val isBooks: Boolean = false)

const val GRP_NONE = ""
const val GRP_STANDALONE = "-"

/** Estado previo de la organización de unos libros, para poder deshacer un movimiento. */
class OrgSnapshot(val overrides: Map<String, BookOverride?>, val aliases: Map<String, String?>)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "jullbook.db", null, 6) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT UNIQUE NOT NULL, file_name TEXT, " +
                "format TEXT, title TEXT, author TEXT, series TEXT, series_key TEXT, number INTEGER, folder TEXT, " +
                "page_count INTEGER DEFAULT 0, size INTEGER, modified INTEGER, cover TEXT, processed INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE progress(book_id INTEGER PRIMARY KEY, pos INTEGER, sub INTEGER, frac REAL, " +
                "percent REAL, last_read INTEGER, status INTEGER, max_percent REAL DEFAULT 0, read_ms INTEGER DEFAULT 0, " +
                "first_read INTEGER DEFAULT 0, finished_at INTEGER DEFAULT 0, sessions INTEGER DEFAULT 0)"
        )
        createV2Tables(db)
        createV3Tables(db)
        db.execSQL("ALTER TABLE books ADD COLUMN isbn TEXT")
        db.execSQL("ALTER TABLE books ADD COLUMN added_at INTEGER DEFAULT 0")
        createV5Tables(db)
    }

    /** Registro de lecturas completadas: una fila por cada vez que se termina un libro/cómic. Nunca se borra al reiniciar. */
    private fun createV5Tables(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS read_log(id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL, " +
                "finished_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_read_log_book ON read_log(book_id)")
    }

    private fun createV3Tables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS book_alias(uri TEXT PRIMARY KEY, name TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS reading_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL, " +
                "start INTEGER NOT NULL, duration INTEGER NOT NULL DEFAULT 0, start_pct REAL DEFAULT 0, end_pct REAL DEFAULT 0, " +
                "end_at INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sessions_start ON reading_sessions(start)")
    }

    private fun createV2Tables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS manual_series(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'COMIC')")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS book_override(uri TEXT PRIMARY KEY, grp TEXT NOT NULL DEFAULT '', " +
                "gname TEXT, number INTEGER)"
        )
        db.execSQL("CREATE TABLE IF NOT EXISTS cover_lookup(uri TEXT PRIMARY KEY, tried_at INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createV2Tables(db)
            try {
                db.execSQL("ALTER TABLE books ADD COLUMN isbn TEXT")
            } catch (ignored: Exception) {
            }
        }
        if (oldVersion < 3) {
            // Memoria de lectura y nombres internos: solo se AÑADEN tablas/columnas; los datos existentes se conservan.
            createV3Tables(db)
            for (col in listOf("max_percent REAL DEFAULT 0", "read_ms INTEGER DEFAULT 0", "first_read INTEGER DEFAULT 0",
                "finished_at INTEGER DEFAULT 0", "sessions INTEGER DEFAULT 0")) {
                try {
                    db.execSQL("ALTER TABLE progress ADD COLUMN $col")
                } catch (ignored: Exception) {
                }
            }
            db.execSQL("UPDATE progress SET max_percent=percent, first_read=last_read WHERE max_percent IS NULL OR max_percent=0")
            db.execSQL("UPDATE progress SET finished_at=last_read WHERE status=2 AND (finished_at IS NULL OR finished_at=0)")
        }
        if (oldVersion < 4) {
            // Colecciones manuales de libros: solo se AÑADE una columna; las colecciones existentes siguen siendo de cómics.
            try {
                db.execSQL("ALTER TABLE manual_series ADD COLUMN kind TEXT NOT NULL DEFAULT 'COMIC'")
            } catch (ignored: Exception) {
            }
            // Re-analizar nombres de cómics: los que solo traen numeración pasan a la colección "Sin nombre".
            // Las correcciones manuales y los nombres internos viven en otras tablas y no se tocan.
            db.beginTransaction()
            try {
                val rows = ArrayList<Triple<Long, String, String>>()
                db.rawQuery("SELECT id,file_name,folder FROM books WHERE format='COMIC'", null).use { c ->
                    while (c.moveToNext()) rows.add(Triple(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: ""))
                }
                for ((id, name, folder) in rows) {
                    val pr = SeriesParser.parse(name, folder, true)
                    val cv = ContentValues()
                    cv.put("series", pr.series)
                    cv.put("series_key", pr.key)
                    cv.put("number", pr.number)
                    db.update("books", cv, "id=?", arrayOf(id.toString()))
                }
                // Los CBR sin portada se vuelven a procesar: ahora la portada se genera al escanear.
                db.execSQL("UPDATE books SET processed=0 WHERE format='COMIC' AND cover IS NULL AND lower(file_name) LIKE '%.cbr'")
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
        if (oldVersion < 5) {
            createV5Tables(db)
            // Lo que ya estaba terminado cuenta como una lectura completada.
            db.execSQL(
                "INSERT INTO read_log(book_id,finished_at) SELECT book_id, " +
                    "CASE WHEN finished_at>0 THEN finished_at ELSE last_read END FROM progress WHERE status=2"
            )
        }
        if (oldVersion < 6) {
            // JullBook 1.1: solo se AÑADE una columna. Lo que ya existía queda con fecha desconocida (0).
            try {
                db.execSQL("ALTER TABLE books ADD COLUMN added_at INTEGER DEFAULT 0")
            } catch (ignored: Exception) {
            }
        }
    }

    /** Veces que se ha completado cada libro. */
    fun allReads(): Map<Long, Int> {
        val out = HashMap<Long, Int>()
        readableDatabase.rawQuery("SELECT book_id, COUNT(*) FROM read_log GROUP BY book_id", null).use { c ->
            while (c.moveToNext()) out[c.getLong(0)] = c.getInt(1)
        }
        return out
    }

    fun allBooks(): List<Book> {
        val out = ArrayList<Book>()
        readableDatabase.rawQuery(
            "SELECT id,uri,file_name,format,title,author,series,series_key,number,folder,page_count,size,modified,cover,processed,isbn,added_at FROM books",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Book(
                        id = c.getLong(0),
                        uri = c.getString(1),
                        fileName = c.getString(2) ?: "",
                        format = Format.valueOf(c.getString(3)),
                        title = c.getString(4) ?: "",
                        author = c.getString(5),
                        series = c.getString(6),
                        seriesKey = c.getString(7),
                        number = if (c.isNull(8)) null else c.getInt(8),
                        folder = c.getString(9) ?: "",
                        pageCount = c.getInt(10),
                        size = c.getLong(11),
                        modified = c.getLong(12),
                        coverPath = c.getString(13),
                        processed = c.getInt(14) == 1,
                        isbn = c.getString(15),
                        added = c.getLong(16)
                    )
                )
            }
        }
        return out
    }

    fun insertBooks(list: List<NewBook>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            for (b in list) {
                val cv = ContentValues()
                cv.put("uri", b.uri)
                cv.put("file_name", b.fileName)
                cv.put("format", b.format.name)
                cv.put("title", b.title)
                cv.put("series", b.series)
                cv.put("series_key", b.seriesKey)
                cv.put("number", b.number)
                cv.put("folder", b.folder)
                cv.put("size", b.size)
                cv.put("modified", b.modified)
                cv.put("processed", 0)
                cv.put("added_at", now)
                db.insertWithOnConflict("books", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetBook(id: Long, size: Long, modified: Long) {
        val cv = ContentValues()
        cv.put("size", size)
        cv.put("modified", modified)
        cv.put("processed", 0)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateParse(id: Long, folder: String, p: SeriesParser.Parsed) {
        val cv = ContentValues()
        cv.put("folder", folder)
        cv.put("series", p.series)
        cv.put("series_key", p.key)
        cv.put("number", p.number)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateCover(id: Long, cover: String) {
        val cv = ContentValues()
        cv.put("cover", cover)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun updateMeta(id: Long, title: String?, author: String?, pages: Int, cover: String?, isbn: String? = null) {
        val cv = ContentValues()
        cv.put("isbn", isbn)
        if (!title.isNullOrBlank()) cv.put("title", title.trim())
        cv.put("author", author)
        cv.put("page_count", pages)
        cv.put("cover", cover)
        cv.put("processed", 1)
        writableDatabase.update("books", cv, "id=?", arrayOf(id.toString()))
    }

    fun deleteBooks(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) {
                db.delete("books", "id=?", arrayOf(id.toString()))
                db.delete("progress", "book_id=?", arrayOf(id.toString()))
                db.delete("reading_sessions", "book_id=?", arrayOf(id.toString()))
                db.delete("read_log", "book_id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearAll() {
        val db = writableDatabase
        db.delete("books", null, null)
        db.delete("progress", null, null)
        db.delete("manual_series", null, null)
        db.delete("book_override", null, null)
        db.delete("cover_lookup", null, null)
        db.delete("book_alias", null, null)
        db.delete("reading_sessions", null, null)
        db.delete("read_log", null, null)
    }

    // ---- Organización manual (solo metadatos de la app; nunca se tocan los archivos) ----

    fun allOverrides(): Map<String, BookOverride> {
        val out = HashMap<String, BookOverride>()
        readableDatabase.rawQuery("SELECT uri,grp,gname,number FROM book_override", null).use { c ->
            while (c.moveToNext()) {
                out[c.getString(0)] = BookOverride(c.getString(1) ?: GRP_NONE, c.getString(2), if (c.isNull(3)) null else c.getInt(3))
            }
        }
        return out
    }

    fun allManualSeries(): List<ManualSeries> {
        val out = ArrayList<ManualSeries>()
        readableDatabase.rawQuery("SELECT id,name,kind FROM manual_series", null).use { c ->
            while (c.moveToNext()) out.add(ManualSeries(c.getLong(0), c.getString(1) ?: "", c.getString(2) == "BOOK"))
        }
        return out
    }

    fun createManualSeries(name: String, isBooks: Boolean = false): Long {
        val cv = ContentValues()
        cv.put("name", name.trim())
        cv.put("kind", if (isBooks) "BOOK" else "COMIC")
        return writableDatabase.insert("manual_series", null, cv)
    }

    fun deleteManualSeries(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Los tomos de la saga vuelven a la agrupación automática (conservan su número corregido).
            db.execSQL("UPDATE book_override SET grp='', gname=NULL WHERE grp=?", arrayOf("m:$id"))
            db.delete("manual_series", "id=?", arrayOf(id.toString()))
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun cleanOverrides(db: SQLiteDatabase) {
        db.delete("book_override", "grp='' AND number IS NULL", null)
    }

    fun setGroup(uris: List<String>, grp: String, gname: String?) {
        if (uris.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (u in uris) {
                db.execSQL(
                    "INSERT OR IGNORE INTO book_override(uri,grp,gname,number) VALUES(?,'',NULL,NULL)",
                    arrayOf(u)
                )
                val cv = ContentValues()
                cv.put("grp", grp)
                cv.put("gname", gname)
                db.update("book_override", cv, "uri=?", arrayOf(u))
            }
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun setNumber(uri: String, number: Int?) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("INSERT OR IGNORE INTO book_override(uri,grp,gname,number) VALUES(?,'',NULL,NULL)", arrayOf(uri))
            val cv = ContentValues()
            cv.put("number", number)
            db.update("book_override", cv, "uri=?", arrayOf(uri))
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun resetOverride(uri: String) {
        writableDatabase.delete("book_override", "uri=?", arrayOf(uri))
        writableDatabase.delete("book_alias", "uri=?", arrayOf(uri))
    }

    // ---- Deshacer movimientos ----

    fun snapshotOrg(uris: List<String>): OrgSnapshot {
        val ov = allOverrides()
        val al = allAliases()
        return OrgSnapshot(uris.associateWith { ov[it] }, uris.associateWith { al[it] })
    }

    fun restoreOrg(s: OrgSnapshot, createdSeriesId: Long?) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for ((uri, o) in s.overrides) {
                if (o == null) {
                    db.delete("book_override", "uri=?", arrayOf(uri))
                } else {
                    val cv = ContentValues()
                    cv.put("uri", uri)
                    cv.put("grp", o.grp)
                    cv.put("gname", o.gname)
                    cv.put("number", o.number)
                    db.insertWithOnConflict("book_override", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            for ((uri, a) in s.aliases) {
                if (a == null) {
                    db.delete("book_alias", "uri=?", arrayOf(uri))
                } else {
                    val cv = ContentValues()
                    cv.put("uri", uri)
                    cv.put("name", a)
                    db.insertWithOnConflict("book_alias", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            if (createdSeriesId != null) db.delete("manual_series", "id=?", arrayOf(createdSeriesId.toString()))
            cleanOverrides(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---- Nombres internos (solo cómo JullBook muestra el archivo; el archivo real no se toca) ----

    fun allAliases(): Map<String, String> {
        val out = HashMap<String, String>()
        readableDatabase.rawQuery("SELECT uri,name FROM book_alias", null).use { c ->
            while (c.moveToNext()) out[c.getString(0)] = c.getString(1) ?: continue
        }
        return out
    }

    fun setAliases(map: Map<String, String>) {
        if (map.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for ((uri, name) in map) {
                val cv = ContentValues()
                cv.put("uri", uri)
                cv.put("name", name)
                db.insertWithOnConflict("book_alias", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun clearAliases(uris: List<String>) {
        if (uris.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (u in uris) db.delete("book_alias", "uri=?", arrayOf(u))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---- Búsqueda de portadas en línea (registro de intentos) ----

    fun recentLookups(since: Long): Set<String> {
        val out = HashSet<String>()
        readableDatabase.rawQuery("SELECT uri FROM cover_lookup WHERE tried_at>=?", arrayOf(since.toString())).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    fun markLookup(uri: String, at: Long) {
        val cv = ContentValues()
        cv.put("uri", uri)
        cv.put("tried_at", at)
        writableDatabase.insertWithOnConflict("cover_lookup", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private val PROG_COLS =
        "book_id,pos,sub,frac,percent,last_read,status,max_percent,read_ms,first_read,finished_at,sessions"

    private fun readProgress(c: android.database.Cursor) = Progress(
        bookId = c.getLong(0),
        pos = c.getInt(1),
        sub = c.getInt(2),
        frac = c.getFloat(3),
        percent = c.getFloat(4),
        lastRead = c.getLong(5),
        status = c.getInt(6),
        maxPercent = if (c.isNull(7)) c.getFloat(4) else c.getFloat(7),
        readMs = if (c.isNull(8)) 0L else c.getLong(8),
        firstRead = if (c.isNull(9)) 0L else c.getLong(9),
        finishedAt = if (c.isNull(10)) 0L else c.getLong(10),
        sessions = if (c.isNull(11)) 0 else c.getInt(11)
    )

    fun allProgress(): Map<Long, Progress> {
        val out = HashMap<Long, Progress>()
        readableDatabase.rawQuery("SELECT $PROG_COLS FROM progress", null).use { c ->
            while (c.moveToNext()) {
                val p = readProgress(c)
                out[p.bookId] = p
            }
        }
        return out
    }

    fun getProgress(id: Long): Progress? =
        readableDatabase.rawQuery("SELECT $PROG_COLS FROM progress WHERE book_id=?", arrayOf(id.toString()))
            .use { c -> if (c.moveToFirst()) readProgress(c) else null }

    private fun writeProgress(db: SQLiteDatabase, p: Progress) {
        val cv = ContentValues()
        cv.put("book_id", p.bookId)
        cv.put("pos", p.pos)
        cv.put("sub", p.sub)
        cv.put("frac", p.frac)
        cv.put("percent", p.percent)
        cv.put("last_read", p.lastRead)
        cv.put("status", p.status)
        cv.put("max_percent", p.maxPercent)
        cv.put("read_ms", p.readMs)
        cv.put("first_read", p.firstRead)
        cv.put("finished_at", p.finishedAt)
        cv.put("sessions", p.sessions)
        db.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** Guarda la posición actual conservando (y actualizando) la memoria: máximo alcanzado, tiempo, terminado. */
    fun saveProgress(p: Progress): Boolean {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = getProgress(p.bookId)
            val max = maxOf(old?.maxPercent ?: 0f, p.percent)
            val finished = p.status == ST_FINISHED || max >= 0.995f
            // Se acaba de terminar (por primera vez o tras reiniciar): cuenta como una lectura completada.
            val newlyFinished = finished && old?.status != ST_FINISHED
            val merged = p.copy(
                status = if (finished) ST_FINISHED else p.status,
                maxPercent = max,
                readMs = old?.readMs ?: 0L,
                firstRead = old?.firstRead?.takeIf { it > 0 } ?: p.lastRead,
                finishedAt = if (newlyFinished) p.lastRead else old?.finishedAt?.takeIf { it > 0 } ?: if (finished) p.lastRead else 0L,
                sessions = old?.sessions ?: 0
            )
            writeProgress(db, merged)
            if (newlyFinished) {
                val cv = ContentValues()
                cv.put("book_id", p.bookId)
                cv.put("finished_at", p.lastRead)
                db.insert("read_log", null, cv)
            }
            db.execSQL(
                "UPDATE reading_sessions SET end_pct=?, end_at=? WHERE id=(SELECT MAX(id) FROM reading_sessions WHERE book_id=?)",
                arrayOf<Any>(p.percent.toDouble(), p.lastRead, p.bookId)
            )
            db.setTransactionSuccessful()
            return newlyFinished
        } finally {
            db.endTransaction()
        }
    }

    /**
     * Reinicia la lectura actual a 0%. Conserva tiempo leído, sesiones, historial, fechas y el registro de lecturas
     * completadas. Lo único que se pone a cero es la posición actual y el "máximo alcanzado" de la lectura en curso.
     */
    fun resetProgress(ids: List<Long>) {
        if (ids.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (id in ids) {
                db.execSQL(
                    "UPDATE progress SET pos=0, sub=0, frac=0, percent=0, max_percent=0, status=$ST_UNREAD WHERE book_id=?",
                    arrayOf<Any>(id)
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Abre el libro: crea/actualiza su progreso, cuenta la sesión y devuelve (progreso previo, id de sesión). */
    fun beginReading(id: Long, now: Long): Pair<Progress?, Long> {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val old = getProgress(id)
            val base = old ?: Progress(id, 0, 0, 0f, 0f, now, ST_READING, 0f, 0L, now, 0L, 0)
            val st = if (base.status == ST_UNREAD) ST_READING else base.status
            writeProgress(db, base.copy(status = st, lastRead = now, sessions = base.sessions + 1))
            val cv = ContentValues()
            cv.put("book_id", id)
            cv.put("start", now)
            cv.put("duration", 0L)
            cv.put("start_pct", base.percent)
            cv.put("end_pct", base.percent)
            cv.put("end_at", now)
            val sid = db.insert("reading_sessions", null, cv)
            db.execSQL("DELETE FROM reading_sessions WHERE id NOT IN (SELECT id FROM reading_sessions ORDER BY id DESC LIMIT 1000)")
            db.setTransactionSuccessful()
            return old to sid
        } finally {
            db.endTransaction()
        }
    }

    fun addReadTime(bookId: Long, sessionId: Long, deltaMs: Long, now: Long) {
        if (deltaMs <= 0) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("UPDATE progress SET read_ms=COALESCE(read_ms,0)+? WHERE book_id=?", arrayOf<Any>(deltaMs, bookId))
            if (sessionId > 0) {
                db.execSQL(
                    "UPDATE reading_sessions SET duration=duration+?, end_at=? WHERE id=?",
                    arrayOf<Any>(deltaMs, now, sessionId)
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun allSessions(): List<SessionRec> {
        val out = ArrayList<SessionRec>()
        readableDatabase.rawQuery(
            "SELECT id,book_id,start,duration,start_pct,end_pct FROM reading_sessions WHERE duration>=3000 ORDER BY start DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(SessionRec(c.getLong(0), c.getLong(1), c.getLong(2), c.getLong(3), c.getFloat(4), c.getFloat(5)))
            }
        }
        return out
    }
}

class SessionRec(val id: Long, val bookId: Long, val start: Long, val duration: Long, val startPct: Float, val endPct: Float)
