package com.jullbook.app.ui.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.jullbook.app.AppViewModel
import com.jullbook.app.data.Book
import com.jullbook.app.data.Format
import com.jullbook.app.data.Progress

@Composable
fun ReaderHost(book: Book, vm: AppViewModel, onBack: () -> Unit) {
    var loaded by remember(book.id) { mutableStateOf(false) }
    var start by remember(book.id) { mutableStateOf<Progress?>(null) }
    LaunchedEffect(book.id) {
        start = vm.beginReading(book.id)
        loaded = true
    }
    val active = vm.readerVisible
    androidx.compose.runtime.CompositionLocalProvider(LocalReaderActive provides active) {
        if (loaded) ReadClock(book.id, vm, active)
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (!loaded) {
                ReaderLoading()
            } else {
                when (book.format) {
                    Format.EPUB -> EpubReader(book, start, vm, onBack)
                    Format.PDF -> PdfReader(book, start, vm, onBack)
                    Format.COMIC -> ComicReader(book, start, vm, onBack)
                }
            }
        }
    }
}

/** Cuenta el tiempo de lectura activo (lector visible y app en primer plano) y lo guarda cada 15 s, al pausar y al salir. */
@Composable
private fun ReadClock(bookId: Long, vm: AppViewModel, active: Boolean) {
    val owner = LocalLifecycleOwner.current
    val clock = remember(bookId) { Clock(bookId, vm) }
    LaunchedEffect(clock) {
        while (true) {
            delay(15_000)
            clock.commit()
        }
    }
    DisposableEffect(owner, clock, active) {
        if (active && owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) clock.resume()
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> { if (active) clock.resume() }
                Lifecycle.Event.ON_STOP -> clock.pause()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            clock.pause()
        }
    }
}

private class Clock(private val bookId: Long, private val vm: AppViewModel) {
    private var since = 0L

    fun resume() {
        if (since == 0L) since = SystemClock.elapsedRealtime()
    }

    fun commit() {
        if (since == 0L) return
        val now = SystemClock.elapsedRealtime()
        val d = now - since
        since = now
        vm.recordReadTime(bookId, d)
    }

    fun pause() {
        commit()
        since = 0L
    }
}
