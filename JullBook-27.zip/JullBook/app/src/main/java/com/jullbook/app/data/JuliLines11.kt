package com.jullbook.app.data

/**
 * JullBook 1.1: comentarios nuevos de Juli. Todo local. Los de [JuliCtx.GEM] son rarísimos y no dependen de ningún dato.
 * Marcadores: {t} título, {c} colección, {name} nombre, {n} número, {d} "5 días", {v} "3 tomos".
 */
internal val EXTRA_LINES: Map<JuliCtx, List<String>> = mapOf(
    JuliCtx.SURPRISE_SHORT to listOf(
        "«{t}» es cortito. Cabe en un rato libre sin remordimientos.",
        "¿Poco tiempo? «{t}» se lee sin pedirte media tarde.",
        "Algo breve para hoy: «{t}». Empiezas y terminas antes de que se enfríe el café.",
        "Si no quieres compromisos largos, «{t}» es ideal.",
        "Una lectura de tamaño bolsillo: «{t}».",
        "«{t}» no te va a robar la noche. Solo un ratito.",
        "Hoy toca ligero: «{t}», y a otra cosa.",
        "Terminar algo hoy es posible. Empieza por «{t}»."
    ),
    JuliCtx.SURPRISE_FORGOTTEN to listOf(
        "«{c}» lleva tiempo sin que nadie la abra. Con {v} esperando.",
        "Tienes «{c}» y no has probado ni un tomo. Empieza por «{t}».",
        "Colección olvidada: «{c}». Hoy la rescatamos con «{t}».",
        "«{c}» acumula {v} sin abrir. Alguien tiene que dar el primer paso: «{t}».",
        "Esa colección que guardaste y no tocaste: «{c}». Hoy es buen día.",
        "«{c}» sigue intacta. Qué tentación empezar por «{t}».",
        "Ni una página de «{c}». Lo bueno es que todo está por descubrir.",
        "Yo no olvido «{c}», aunque tú sí. Va, «{t}»."
    ),
    JuliCtx.SURPRISE_ALMOST to listOf(
        "Te falta muy poco de «{t}»: un {n}% y lo cierras.",
        "«{t}» está a punto de terminar. Solo queda un {n}%.",
        "Casi lo tienes: «{t}», a un {n}% del final.",
        "Un empujoncito más y «{t}» pasa a terminados. Faltan un {n}%.",
        "Dejarlo a un {n}% del final sería injusto con «{t}».",
        "Estás tan cerca del final de «{t}» que ya huele a punto final.",
        "El último tramo de «{t}» te espera. Es un {n}%, no es nada.",
        "Terminar «{t}» hoy está a tu alcance: un {n}% y listo."
    ),
    JuliCtx.SURPRISE_RANDOM to listOf(
        "Esta vez no hay motivo, solo azar: «{t}».",
        "Sorteo limpio, sin trampas. Salió «{t}».",
        "Tiré los dados dentro de tu biblioteca y cayó «{t}».",
        "Sin criterio alguno, con mucho cariño: «{t}».",
        "Hoy decide el azar. Y el azar dice «{t}».",
        "Selección aleatoria: «{t}». Ni yo sé por qué.",
        "A veces lo mejor es no pensarlo. «{t}».",
        "Cierro los ojos, señalo y… «{t}»."
    ),
    JuliCtx.SESSION_LONG to listOf(
        "Llevas un buen rato leyendo. Estira los hombros, que yo vigilo la página.",
        "Sesión larga, {name}. Un vaso de agua no le hace daño a nadie.",
        "Esto ya es una sesión de las serias. Aquí sigo.",
        "Tanto tiempo seguido... Me gusta, pero parpadea de vez en cuando.",
        "Mucho rato con la vista en las páginas. Mira un punto lejano unos segundos.",
        "Larga sesión. Prometo no interrumpir otra vez."
    ),
    JuliCtx.FAST_READ to listOf(
        "Qué velocidad con «{t}». ¿Seguro que no te saltaste nada?",
        "«{t}» cayó rapidísimo. Vas a necesitar más biblioteca.",
        "Lectura exprés: «{t}». Impresionante, y un poco sospechoso.",
        "Pasaste «{t}» a un ritmo de vértigo. Anoto el récord.",
        "Eso fue veloz. «{t}» no tuvo tiempo de ponerse cómodo.",
        "Terminaste «{t}» volando. A mí me falta el aliento."
    ),
    JuliCtx.SMALL_LIBRARY to listOf(
        "Pocos libros, todos tuyos. Una biblioteca pequeña también se quiere.",
        "Tu biblioteca es compacta. Eso significa que conoces cada rincón.",
        "Con {n} elementos tienes lo justo para empezar. Y lo justo, a veces, es perfecto.",
        "Biblioteca pequeña, posibilidades enormes.",
        "Poco a poco. {n} elementos ya son un buen comienzo."
    ),
    JuliCtx.ODD to listOf(
        "Abriendo muchas cosas en poco rato. ¿Catando o buscando?",
        "Vas saltando de una lectura a otra. Yo no juzgo, solo cuento.",
        "Tanto abrir y cerrar... Algo andas buscando, {name}.",
        "Detecto curiosidad inquieta. Me gusta.",
        "Hoy estás de picoteo. Se permite."
    ),
    JuliCtx.GEM to listOf(
        "A veces me pregunto qué sueñan los libros cuando cierras la aplicación.",
        "He contado todos los puntos finales de tu biblioteca. Mejor no te digo cuántos.",
        "Dato inútil del día: nada. Pero me hacía ilusión decirlo.",
        "Hoy me desperté con ganas de ser un marcapáginas.",
        "Si los tomos hablaran, el primero de cada colección diría que lo leíste con más ganas.",
        "Una vez conté hasta mil páginas. Perdí la cuenta en la dos.",
        "No es un comentario útil. Es un comentario raro. Disfrútalo mientras dura.",
        "Tengo una teoría: tu próxima lectura favorita ya está aquí y no lo sabes.",
        "Psst. Esto lo digo muy pocas veces: gracias por abrir la app.",
        "Escribo estas frases sin teclado. Y sin manos. Y sin nada.",
        "Hay una página perdida entre tus archivos. Es broma. Creo.",
        "Hoy el silencio de la biblioteca es especialmente cómodo."
    )
)
