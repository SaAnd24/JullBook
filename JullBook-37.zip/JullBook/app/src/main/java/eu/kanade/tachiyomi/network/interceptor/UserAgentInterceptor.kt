package eu.kanade.tachiyomi.network.interceptor

import okhttp3.Interceptor
import okhttp3.Response

/**
 * Pone el User-Agent por defecto cuando la petición no trae uno (o trae el de OkHttp). Algunas extensiones comprueban
 * que este interceptor exista en el cliente por defecto (el nombre y el paquete deben coincidir con los de Mihon).
 */
class UserAgentInterceptor(
    private val defaultUserAgentProvider: () -> String,
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val ua = originalRequest.header("User-Agent")
        return if (ua.isNullOrEmpty() || ua.contains("okhttp", ignoreCase = true)) {
            chain.proceed(
                originalRequest.newBuilder()
                    .header("User-Agent", defaultUserAgentProvider())
                    .build(),
            )
        } else {
            chain.proceed(originalRequest)
        }
    }
}
