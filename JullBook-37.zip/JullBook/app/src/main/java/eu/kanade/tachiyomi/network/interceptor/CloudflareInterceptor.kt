package eu.kanade.tachiyomi.network.interceptor

import okhttp3.Interceptor
import okhttp3.Response

/**
 * Marcador de compatibilidad: existe para que las extensiones que comprueban su presencia en el cliente por defecto
 * no fallen. NO resuelve retos de Cloudflare (no hay WebView); simplemente deja pasar la petición.
 */
class CloudflareInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.proceed(chain.request())
}
