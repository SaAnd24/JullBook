package com.jullbook.app.ui

import android.text.format.DateUtils
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullbook.app.AppViewModel
import com.jullbook.app.LibTab
import com.jullbook.app.Tab
import com.jullbook.app.data.Book
import com.jullbook.app.data.ContinueEntry
import com.jullbook.app.data.HomeSections
import com.jullbook.app.data.JuliDay
import com.jullbook.app.data.Format
import com.jullbook.app.data.LibItem
import com.jullbook.app.data.SeriesItem
import com.jullbook.app.data.SingleItem
import com.jullbook.app.data.ST_FINISHED
import com.jullbook.app.data.SurpriseEngine
import com.jullbook.app.data.formatLabel
import com.jullbook.app.data.lastReadLabel
import com.jullbook.app.data.isRereading
import com.jullbook.app.data.pctText
import com.jullbook.app.data.readsText
import com.jullbook.app.data.durText
import com.jullbook.app.data.volLabel
import androidx.compose.material3.LinearProgressIndicator as Linear

private fun isBookItem(i: LibItem): Boolean = when (i) {
    is SeriesItem -> i.isBooks
    is SingleItem -> i.book.format != Format.COMIC
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: AppViewModel, onPickFolder: () -> Unit, modifier: Modifier = Modifier) {
    val lib = vm.library
    val amb = LocalAmbient.current
    val stats = vm.memory.stats
    val colls = remember(lib) {
        lib.series.values.filter { it.volumes.isNotEmpty() && !it.isUnnamed }
            .sortedWith(compareByDescending<SeriesItem> { it.lastRead }.thenBy { it.name.lowercase() })
    }
    // Secciones dinámicas (JullBook 1.1): las vacías no se dibujan.
    val sec = remember(lib) { HomeSections.build(lib, System.currentTimeMillis()) }
    val undiscovered = sec.unopened
    val todayCard = TodayCard(vm)
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (vm.userName.isBlank()) "Hola 👋" else "Hola, ${vm.userName} 👋",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.combinedClickable(onClick = {}, onLongClick = { vm.onGreetingHold() })
                    )
                    Text(
                        "Esta es tu biblioteca",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                JuliAvatar(size = 44.dp, spin = vm.waveSpin, onClick = { vm.onJuliTap() })
            }
        }
        if (vm.homeNote.isNotBlank()) item { JuliNote(vm.homeNote, Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) }
        if (vm.folderLost) item { FolderBanner(onPickFolder) }
        if (vm.scanning) item { ScanBar(vm.scanDone, vm.scanTotal) }

        if (lib.items.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        if (vm.scanning) "Buscando en tus carpetas…" else "Tu biblioteca está vacía",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (!vm.scanning) {
                        Text(
                            "No se encontraron EPUB, PDF, CBZ ni CBR en las carpetas elegidas.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = onPickFolder) { Text("Cambiar carpeta de libros") }
                    }
                }
            }
            return@LazyColumn
        }

        // Continuar leyendo: carrusel grande. La portada de la página actual tiñe la biblioteca (Juli Experience).
        if (lib.cont.isNotEmpty()) {
            item { SectionTitle("Continuar leyendo") }
            item {
                val cont = lib.cont
                val pager = rememberPagerState(pageCount = { cont.size })
                LaunchedEffect(pager, cont) {
                    snapshotFlow { pager.settledPage }.collect { vm.ambientPath = cont.getOrNull(it)?.book?.coverPath }
                }
                HorizontalPager(
                    state = pager,
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    pageSpacing = 12.dp,
                    pageSize = PageSize.Fixed(310.dp)
                ) { page -> HeroCard(cont[page], vm, amb) }
            }
        }

        item { SurpriseButton(onClick = { vm.surpriseMe() }, Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) }

        todayCard?.let { card -> item { card() } }

        if (sec.almost.isNotEmpty()) {
            item { SectionTitle("Casi terminados") }
            item { ProgressRow(sec.almost, vm) }
        }
        if (sec.paused.isNotEmpty()) {
            item { SectionTitle("Lecturas pausadas") }
            item { ProgressRow(sec.paused, vm) }
        }

        val books = lib.items.filter { isBookItem(it) }
        val comics = lib.items.filter { !isBookItem(it) }
        if (books.isNotEmpty()) {
            item { SectionTitle("Libros") { TextButton(onClick = { vm.selectLibTab(LibTab.BOOKS); vm.tab = Tab.LIBRARY }) { Text("Ver todo · ${books.size}") } } }
            item { ItemsRow(books.take(14), vm) }
        }
        if (comics.isNotEmpty()) {
            item { SectionTitle("Cómics") { TextButton(onClick = { vm.selectLibTab(LibTab.COMICS); vm.tab = Tab.LIBRARY }) { Text("Ver todo · ${comics.size}") } } }
            item { ItemsRow(comics.take(14), vm) }
        }

        if (sec.added.isNotEmpty()) {
            item { SectionTitle("Añadidos recientemente") }
            item { TilesRow(sec.added, vm, "added") }
        }

        if (colls.isNotEmpty()) {
            item { SectionTitle("Colecciones y sagas") }
            item { ItemsRow(colls.take(14), vm) }
        }

        if (sec.unstartedColls.isNotEmpty()) {
            item { SectionTitle("Colecciones sin empezar") }
            item { ItemsRow(sec.unstartedColls, vm) }
        }

        if (sec.mostRead.isNotEmpty()) {
            item { SectionTitle(if (sec.reread) "Más releídos" else "Más leídos") }
            item { TilesRow(sec.mostRead, vm, "most") }
        }

        if (undiscovered.isNotEmpty() && lib.books.size >= 4) {
            item { SectionTitle("Nunca abiertos") { Text("${undiscovered.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(undiscovered.take(14), key = { it.id }) { b -> BookTile(b, vm) }
                }
            }
        }

        item { SectionTitle("Progreso general") }
        item { OverallCard(vm, Modifier.padding(horizontal = 20.dp)) }

        item { SectionTitle("Tu lectura") { TextButton(onClick = { vm.showStats = true }) { Text("Ver más") } } }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Hoy", durText(stats.todayMs), Modifier.weight(1f))
                StatTile("7 días", durText(stats.weekMs), Modifier.weight(1f))
                StatTile("Racha", if (stats.streak == 1) "1 día" else "${stats.streak} d", Modifier.weight(1f))
                StatTile("Lecturas", "${stats.completions}", Modifier.weight(1f))
            }
        }

        if (lib.recent.isNotEmpty()) {
            item { SectionTitle("Actividad reciente") }
            items(lib.recent, key = { "r${it.book.id}" }) { e -> RecentRow(e, vm) }
        }
    }
}

@Composable
private fun ItemsRow(list: List<LibItem>, vm: AppViewModel) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(list, key = { it.id }) { item ->
            ItemCard(item, onBook = { vm.openBook(it.book) }, onSeries = { vm.openSeries(it.key) }, modifier = Modifier.width(116.dp))
        }
    }
}

@Composable
private fun TilesRow(list: List<Book>, vm: AppViewModel, tag: String) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(list, key = { "$tag${it.id}" }) { b -> BookTile(b, vm) }
    }
}

/** Fila de lecturas en curso (casi terminadas, pausadas) con su avance. */
@Composable
private fun ProgressRow(list: List<ContinueEntry>, vm: AppViewModel) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(list, key = { "pr${it.book.id}" }) { e ->
            val p = e.progress
            BookCard(
                title = SurpriseEngine.displayTitle(e.book, e.series),
                subtitle = e.book.author ?: formatLabel(e.book.format),
                caption = p?.let { pctText(it.percent) },
                coverPath = e.book.coverPath,
                progress = p?.percent ?: 0f,
                finished = false,
                stack = false,
                onClick = { vm.openBook(e.book) },
                modifier = Modifier.width(116.dp),
                format = e.book.format,
                reads = e.book.reads,
                lastRead = lastReadLabel(p?.lastRead)
            )
        }
    }
}

/** "Hoy en tu biblioteca": solo actividad y datos locales; si no hay nada que decir, no aparece. */
@Composable
private fun TodayCard(vm: AppViewModel): (@Composable () -> Unit)? {
    val stats = vm.memory.stats
    val lib = vm.library
    val now = System.currentTimeMillis()
    val startOfToday = remember(now / 3_600_000L) {
        java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val finishedToday = vm.memory.books.count { (_, p) -> p.status == ST_FINISHED && p.finishedAt >= startOfToday }
    val addedToday = lib.books.values.count { it.added >= startOfToday }
    val facts = ArrayList<String>()
    if (stats.todayMs >= 60_000L) facts.add("Hoy llevas ${durText(stats.todayMs)} de lectura.")
    if (finishedToday > 0) facts.add(if (finishedToday == 1) "Has terminado 1 título hoy." else "Has terminado $finishedToday títulos hoy.")
    if (addedToday > 0 && addedToday < lib.books.size) facts.add(if (addedToday == 1) "Se ha añadido 1 título nuevo hoy." else "Se han añadido $addedToday títulos hoy.")
    val day = if (vm.juliTalk > 0) JuliDay.today(vm.userName, stats.streak) else null
    if (facts.isEmpty() && day == null) return null
    return {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 2.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("HOY EN TU BIBLIOTECA", style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary)
            for (f in facts) Text(f, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            if (day != null) {
                Text(
                    "Juli está ${day.first.label} hoy: ${day.second}",
                    style = MaterialTheme.typography.bodySmall,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = if (facts.isEmpty()) 0.dp else 4.dp)
                )
            }
        }
    }
}

@Composable
private fun BookTile(b: Book, vm: AppViewModel) {
    val s = vm.library.bookSeries[b.id]
    BookCard(
        title = SurpriseEngine.displayTitle(b, s),
        subtitle = b.author ?: formatLabel(b.format),
        caption = readsText(b.reads).ifEmpty { null },
        coverPath = b.coverPath,
        progress = 0f,
        finished = false,
        stack = false,
        onClick = { vm.openBook(b) },
        modifier = Modifier.width(116.dp),
        format = b.format,
        reads = b.reads
    )
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.8f))
            .padding(horizontal = 10.dp, vertical = 12.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, fontWeight = FontWeight.SemiBold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun SurpriseButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.tertiary
    val fg = if (a.luminance() > 0.45f) Color(0xFF1A1305) else Color.White
    Row(
        modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.horizontalGradient(listOf(a, b)))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("🎲", fontSize = 30.sp)
        Column(Modifier.weight(1f)) {
            Text("Sorpréndeme", style = MaterialTheme.typography.titleLarge, color = fg)
            Text("Juli elige algo de tu biblioteca", style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = 0.85f))
        }
    }
}

@Composable
private fun HeroCard(e: ContinueEntry, vm: AppViewModel, amb: AmbientState?) {
    val p = e.progress
    val s = e.series
    val re = isRereading(e.book, p)
    val glowColor = amb?.glow?.firstOrNull() ?: MaterialTheme.colorScheme.primary
    val glow = if (amb != null && amb.enabled && amb.style == ExpStyle.GLOW) 0.25f + 0.4f * amb.intensity else 0f
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f))
            .clickable { vm.openBook(e.book) }
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(Modifier.coverGlow(glowColor, glow)) {
            CoverImage(
                e.book.coverPath, e.book.title,
                Modifier.size(width = 104.dp, height = 156.dp).shadow(10.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp)),
                format = e.book.format
            )
        }
        Column(Modifier.weight(1f).height(156.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(
                    if (re) "RELEYENDO" else "SIGUE POR AQUÍ",
                    style = MaterialTheme.typography.labelSmall,
                    letterSpacing = 1.2.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    s?.name ?: e.book.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Text(
                    if (s != null) volLabel(e.book) else (e.book.author ?: formatLabel(e.book.format)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Column {
                Linear(
                    progress = { (p?.percent ?: 0f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                )
                Text(
                    (if (p == null) "Sin empezar" else pctText(p.percent)) + (if (s != null) " · colección ${pctText(s.percent)}" else ""),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Button(onClick = { vm.openBook(e.book) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) { Text("Continuar") }
            }
        }
    }
}

@Composable
private fun OverallCard(vm: AppViewModel, modifier: Modifier = Modifier) {
    val total = vm.library.books.size
    val st = vm.memory.stats
    val frac = if (total == 0) 0f else (st.finished.toFloat() / total).coerceIn(0f, 1f)
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
            .clickable { vm.showStats = true }
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 9.dp.toPx()
                val inset = w / 2
                val sz = Size(this.size.width - w, this.size.height - w)
                drawArc(track, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
                drawArc(primary, -90f, 360f * frac, false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
            }
            Text("${(frac * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("${st.finished} de $total terminados", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text("${st.reading} en curso · ${st.unstarted} sin empezar", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (st.completions > st.finished) {
                Text("${st.completions} lecturas completadas en total", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun FolderBanner(onPick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onPick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("No se puede acceder a la carpeta", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
        Text(
            "Tu biblioteca se conserva tal cual. Elige la carpeta de nuevo para actualizarla.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(onClick = onPick) { Text("Elegir carpeta") }
    }
}

@Composable
fun ScanBar(done: Int, total: Int) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(
            if (total > 0) "Preparando biblioteca… $done de $total" else "Buscando libros…",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (total > 0) {
            LinearProgressIndicator(
                progress = { (done.toFloat() / total).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun RecentRow(e: ContinueEntry, vm: AppViewModel) {
    val p = e.progress
    val title = if (e.book.alias != null) e.book.alias else e.series?.let { "${it.name} ${volLabel(e.book)}" } ?: e.book.title
    val status = when {
        p == null -> ""
        p.status == ST_FINISHED -> "Terminado"
        isRereading(e.book, p) -> "Releyendo · ${pctText(p.percent)}"
        else -> pctText(p.percent)
    }
    val whenText = p?.let {
        DateUtils.getRelativeTimeSpanString(it.lastRead, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
    } ?: ""
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { vm.openBook(e.book) }
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        CoverImage(
            e.book.coverPath, title,
            Modifier.size(width = 44.dp, height = 64.dp).clip(RoundedCornerShape(6.dp)),
            format = e.book.format
        )
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOf(formatLabel(e.book.format), status, whenText, readsText(e.book.reads)).filter { it.isNotEmpty() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
