package com.jullbook.app.ui

import android.graphics.Bitmap
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullbook.app.data.Images
import com.jullbook.app.sources.LoadedSource
import com.jullbook.app.sources.Res
import com.jullbook.app.sources.SourceHub
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

private object ReaderCache {
    // Las páginas se decodifican en RGB_565 (mitad de memoria) y se reutilizan al volver atrás.
    val cache = object : LruCache<String, Bitmap>(64 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
}

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "avif")

/** Origen de las páginas del capítulo: la fuente en línea o, si ya está descargado, su CBZ local. */
private class PageSet(val count: Int, val key: String, val load: suspend (Int) -> ByteArray)

private suspend fun openPages(hub: SourceHub, s: LoadedSource, manga: SManga, chapter: SChapter): Res<PageSet> {
    // Si el capítulo ya está guardado se lee del dispositivo (sin red).
    val local = hub.store.dlManga(hub.downloads.mangaKey(s.id, manga.url))?.chapters?.get(chapter.url)
        ?.let { File(it) }?.takeIf { it.exists() }
    if (local != null) {
        val names = withContext(Dispatchers.IO) {
            runCatching {
                ZipFile(local).use { z ->
                    z.entries().asSequence().map { it.name }
                        .filter { it.substringAfterLast('.').lowercase() in IMAGE_EXT }.sorted().toList()
                }
            }.getOrNull()
        }
        if (!names.isNullOrEmpty()) {
            return Res.Ok(PageSet(names.size, "local|${local.absolutePath}") { i ->
                withContext(Dispatchers.IO) {
                    ZipFile(local).use { z -> z.getInputStream(z.getEntry(names[i])).use { it.readBytes() } }
                }
            })
        }
    }
    val src = s.source as? HttpSource ?: return Res.Err("Esta fuente no permite leer en línea.")
    return when (val r = hub.pages(s, chapter)) {
        is Res.Err -> Res.Err(r.message)
        is Res.Ok -> {
            val pages: List<Page> = r.value
            if (pages.isEmpty()) {
                Res.Err("La fuente no devolvió ninguna página para este capítulo.")
            } else {
                Res.Ok(PageSet(pages.size, "net|${s.id}|${manga.url}|${chapter.url}") { i ->
                    fetchOnline(src, pages[i])
                })
            }
        }
    }
}

private suspend fun fetchOnline(src: HttpSource, p: Page): ByteArray {
    var last: Throwable? = null
    for (attempt in 1..2) {
        try {
            return withContext(Dispatchers.IO) {
                if (p.imageUrl.isNullOrEmpty()) p.imageUrl = src.getImageUrl(p)
                src.getImage(p).use { resp ->
                    if (!resp.isSuccessful) throw eu.kanade.tachiyomi.network.HttpException(resp.code)
                    val b = resp.body.bytes()
                    if (b.isEmpty()) throw java.io.IOException("Imagen vacía")
                    b
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            last = e
            if (attempt < 2) delay(1000)
        }
    }
    throw last ?: java.io.IOException("No se pudo cargar la página")
}

/**
 * Lector en línea de capítulos de las fuentes: las páginas se piden a la fuente a medida que se desplazan
 * (sin descargar el capítulo; si ya estaba descargado se lee del dispositivo). Descargar es opcional.
 *
 * [chapters] está en el orden de la fuente (normalmente de más nuevo a más antiguo).
 */
@Composable
fun OnlineReader(
    hub: SourceHub,
    s: LoadedSource,
    manga: SManga,
    chapters: List<SChapter>,
    startIndex: Int,
    onDownload: (SChapter) -> Unit,
    onClose: () -> Unit,
) {
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, (chapters.size - 1).coerceAtLeast(0))) }
    var bars by remember { mutableStateOf(true) }
    var note by remember { mutableStateOf<String?>(null) }
    val chapter = chapters.getOrNull(index)
    val listState = rememberLazyListState()
    var retry by remember { mutableIntStateOf(0) }

    BackHandler { onClose() }

    if (chapter == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val set by produceState<Res<PageSet>?>(null, chapter.url, retry) {
        value = null
        value = openPages(hub, s, manga, chapter)
    }

    LaunchedEffect(index) {
        note = null
        runCatching { listState.scrollToItem(0) }
    }

    val widthPx = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp.roundToPx() }

    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        Box(Modifier.fillMaxSize()) {
            when (val r = set) {
                null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                is Res.Err -> Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(r.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = { retry++ }) { Text("Reintentar") }
                }
                is Res.Ok -> {
                    val ps = r.value
                    LazyColumn(Modifier.fillMaxSize().clickable { bars = !bars }, state = listState) {
                        items(ps.count, key = { i -> "${ps.key}#$i" }) { i ->
                            PageImage(ps, i, widthPx)
                        }
                        item(key = "end") {
                            Column(
                                Modifier.fillMaxWidth().padding(24.dp).navigationBarsPadding(),
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Fin de «${chapter.name}»", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                if (index > 0) OutlinedButton(onClick = { index-- }) { Text("Siguiente capítulo") }
                                else Text("No hay capítulos más recientes.", color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            if (bars) {
                Surface(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                ) {
                    Column(Modifier.statusBarsPadding().padding(horizontal = 4.dp, vertical = 2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Cerrar lector") }
                            Column(Modifier.weight(1f)) {
                                Text(manga.title, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(chapter.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { index++ }, enabled = index < chapters.size - 1) { Text("‹ Anterior") }
                            TextButton(onClick = { index-- }, enabled = index > 0) { Text("Siguiente ›") }
                            TextButton(onClick = { onDownload(chapter); note = "Descarga en cola." }) { Text("Descargar") }
                        }
                        note?.let { Text(it, Modifier.padding(start = 12.dp, bottom = 4.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageImage(ps: PageSet, i: Int, widthPx: Int) {
    val ck = "${ps.key}#$i"
    var attempt by remember(ck) { mutableIntStateOf(0) }
    val state by produceState<Any?>(ReaderCache.cache.get(ck), ck, attempt) {
        ReaderCache.cache.get(ck)?.let { value = it; return@produceState }
        value = null
        value = try {
            val bytes = ps.load(i)
            withContext(Dispatchers.Default) { Images.decodeSampled(bytes, widthPx.coerceAtMost(1080), Bitmap.Config.RGB_565) }
                ?.also { ReaderCache.cache.put(ck, it) }
                ?: "No se pudo decodificar la imagen."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            e.message ?: e.javaClass.simpleName
        }
    }
    when (val st = state) {
        is Bitmap -> Image(st.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
        is String -> Box(Modifier.fillMaxWidth().heightIn(min = 220.dp).clickable { attempt++ }, contentAlignment = Alignment.Center) {
            Text("Página ${i + 1}: $st\nToca para reintentar", color = Color.LightGray, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(16.dp))
        }
        else -> Box(Modifier.fillMaxWidth().heightIn(min = 400.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}
