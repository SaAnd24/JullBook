package com.jullbook.app.sources

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import eu.kanade.tachiyomi.network.HttpException
import eu.kanade.tachiyomi.network.NetworkHelper
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.LicensedMangaChaptersException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.IOException

sealed class Res<out T> {
    class Ok<T>(val value: T) : Res<T>()
    class Err(val message: String) : Res<Nothing>()
}

/**
 * Punto central del sistema de fuentes: extensiones instaladas/disponibles, repositorios, instalación,
 * operaciones de exploración y cola de descargas. Cada llamada al código de una extensión está aislada
 * (Throwable capturado, tiempo máximo) para que una fuente defectuosa no cierre la aplicación.
 * Límite honesto: un fallo nativo (SIGSEGV) o un bucle que consuma CPU/memoria en el mismo proceso no se puede aislar.
 */
class SourceHub(val app: Application) {

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val store = ExtStore(app)

    private val network: NetworkHelper get() = Injekt.get()
    val installer: ExtensionInstaller by lazy { ExtensionInstaller(app, network.client) }

    val installed = MutableStateFlow<List<InstalledExt>>(emptyList())
    val available = MutableStateFlow<List<AvailableExt>>(emptyList())
    val repos = MutableStateFlow(store.repos())
    val loading = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val working = MutableStateFlow<Set<String>>(emptySet())
    val showNsfw = MutableStateFlow(store.showNsfw)

    val downloads = MangaDownloads(this)

    /** La biblioteca (ViewModel) se suscribe aquí para registrar cada capítulo guardado. */
    @Volatile
    var chapterSink: ((SavedChapter) -> Unit)? = null

    private val loadMutex = Mutex()
    private val cache = HashMap<String, Pair<Long, InstalledExt>>()
    private val pendingSig = HashMap<String, String>()

    init {
        installer.register(
            onResult = { pkg, ok, msg ->
                if (pkg != null) working.value = working.value - pkg
                message.value = if (ok) "Extensión instalada. Aprueba su firma para activarla." else "Instalación fallida: $msg"
                refreshInstalled()
            },
            onPackagesChanged = { refreshInstalled() }
        )
        refreshInstalled()
    }

    // ---------------------------------------------------------------- extensiones instaladas

    fun refreshInstalled() {
        scope.launch(Dispatchers.IO) {
            loadMutex.withLock {
                val trusted = store.trusted()
                val disabled = store.disabled()
                val list = runCatching {
                    val pm = app.packageManager
                    ExtensionLoader.installedPackages(pm).map { p ->
                        val prev = cache[p.packageName]
                        val sig = ExtensionLoader.signatureOf(p)
                        val trustedNow = sig != null && sig in trusted
                        val enabledNow = p.packageName !in disabled
                        if (prev != null && prev.first == p.lastUpdateTime && prev.second.signature == sig &&
                            prev.second.enabled == enabledNow && (prev.second.state == ExtState.UNTRUSTED) != trustedNow
                        ) {
                            prev.second
                        } else {
                            val e = ExtensionLoader.loadOne(app, p, trusted, disabled)
                            cache[p.packageName] = p.lastUpdateTime to e
                            e
                        }
                    }.sortedBy { it.name.lowercase() }
                }.getOrElse {
                    message.value = "No se pudo leer la lista de extensiones: ${it.message}"
                    emptyList()
                }
                installed.value = list
            }
        }
    }

    fun trust(ext: InstalledExt) {
        ext.signature?.let { store.trust(it) }
        refreshInstalled()
    }

    fun setEnabled(pkg: String, enabled: Boolean) {
        store.setEnabled(pkg, enabled)
        refreshInstalled()
    }

    fun setShowNsfw(v: Boolean) {
        store.showNsfw = v
        showNsfw.value = v
    }

    fun uninstall(pkg: String) {
        // Desinstalar NO borra capítulos descargados ni progreso: viven en la carpeta y la base de datos de la app.
        installer.uninstall(pkg)
    }

    // ---------------------------------------------------------------- repositorios

    fun addRepo(input: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val url = RepoClient.normalize(input)
                if (repos.value.any { it.url == url }) {
                    message.value = "Ese repositorio ya está añadido."
                    return@launch
                }
                loading.value = true
                RepoClient.fetchIndex(network.client, url) // valida que el índice es legible antes de guardarlo
                val (name, fp) = RepoClient.fetchMeta(network.client, url)
                val list = repos.value + Repo(url, name ?: url.removePrefix("https://").substringBefore('/'), fp)
                store.saveRepos(list)
                repos.value = list
                message.value = "Repositorio añadido." + if (fp == null) " No publica huella de firma: la procedencia de sus APK solo se puede comprobar manualmente." else ""
                loading.value = false
                refreshRepos()
            } catch (e: Exception) {
                loading.value = false
                message.value = "No se pudo añadir el repositorio: ${friendly(e)}"
            }
        }
    }

    fun removeRepo(url: String) {
        val list = repos.value.filter { it.url != url }
        store.saveRepos(list)
        repos.value = list
        available.value = available.value.filter { it.repoUrl != url }
    }

    /** Vuelve a consultar los catálogos de todos los repositorios. */
    fun refreshRepos() {
        scope.launch(Dispatchers.IO) {
            loading.value = true
            val all = ArrayList<AvailableExt>()
            val errors = ArrayList<String>()
            for (r in repos.value) {
                try {
                    all.addAll(RepoClient.fetchIndex(network.client, r.url))
                } catch (e: Exception) {
                    errors.add("${r.name}: ${friendly(e)}")
                }
            }
            available.value = all.groupBy { it.pkg }.map { (_, l) -> l.maxByOrNull { it.versionCode }!! }
                .sortedBy { it.name.lowercase() }
            if (errors.isNotEmpty()) message.value = errors.joinToString("\n")
            loading.value = false
        }
    }

    fun install(ext: AvailableExt) {
        if (ext.pkg in working.value) return
        working.value = working.value + ext.pkg
        scope.launch(Dispatchers.IO) {
            val fp = repos.value.firstOrNull { it.url == ext.repoUrl }?.fingerprint
            val r = installer.downloadAndStage(ext, fp)
            if (!r.ok) {
                working.value = working.value - ext.pkg
                message.value = "${ext.name}: ${r.message}"
                return@launch
            }
            r.signature?.let { pendingSig[ext.pkg] = it }
            val c = installer.commit(ext.pkg)
            if (!c.ok) {
                working.value = working.value - ext.pkg
                message.value = "${ext.name}: ${c.message}"
            }
        }
    }

    /** Huella del repositorio de origen de [ext] si existe (para mostrar «firma verificada por el repositorio»). */
    fun repoFingerprintFor(ext: AvailableExt): String? = repos.value.firstOrNull { it.url == ext.repoUrl }?.fingerprint

    fun availableFor(pkg: String): AvailableExt? = available.value.firstOrNull { it.pkg == pkg }

    fun updateAvailable(ext: InstalledExt): AvailableExt? =
        availableFor(ext.pkg)?.takeIf { it.versionCode > ext.versionCode }

    /** Firma anunciada por algún repositorio para este paquete, si coincide con la instalada. */
    fun verifiedByRepo(ext: InstalledExt): Boolean {
        val sig = ext.signature ?: return false
        val av = availableFor(ext.pkg) ?: return false
        return repoFingerprintFor(av)?.equals(sig, ignoreCase = true) == true
    }

    // ---------------------------------------------------------------- fuentes y exploración

    fun sources(): List<LoadedSource> =
        installed.value
            .filter { it.state == ExtState.READY && it.enabled && (showNsfw.value || !it.nsfw) }
            .flatMap { it.sources }
            .filter { it.source != null }
            .sortedWith(compareBy({ it.name.lowercase() }, { it.lang }))

    suspend fun <T> guarded(timeoutMs: Long = 90_000, block: suspend () -> T): Res<T> = withContext(Dispatchers.IO) {
        try {
            Res.Ok(withTimeout(timeoutMs) { block() })
        } catch (e: TimeoutCancellationException) {
            Res.Err("La fuente tardó demasiado en responder.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Res.Err(friendly(e))
        }
    }

    suspend fun popular(s: LoadedSource, page: Int): Res<MangasPage> = guarded { s.source!!.getPopularManga(page) }

    suspend fun latest(s: LoadedSource, page: Int): Res<MangasPage> = guarded {
        if (!s.source!!.supportsLatest) throw IllegalStateException("Esta fuente no ofrece «Últimas».")
        s.source.getLatestUpdates(page)
    }

    suspend fun search(s: LoadedSource, page: Int, query: String): Res<MangasPage> =
        guarded { s.source!!.getSearchManga(page, query, s.source.getFilterList()) }

    /** Detalles de la obra fusionados sobre los datos que ya teníamos. */
    private fun merge(manga: SManga, d: SManga): SManga {
        val m = manga.copy()
        m.title = runCatching { d.title }.getOrNull() ?: manga.title
        d.author?.let { m.author = it }
        d.artist?.let { m.artist = it }
        d.description?.let { m.description = it }
        d.genre?.let { m.genre = it }
        m.status = d.status
        d.thumbnail_url?.let { m.thumbnail_url = it }
        // API 1.6: el «memo» es el estado interno de la extensión; si la fuente lo actualiza al pedir detalles, se conserva.
        if (d.memo.isNotEmpty()) m.memo = d.memo
        m.initialized = true
        return m
    }

    suspend fun details(s: LoadedSource, manga: SManga): Res<SManga> = guarded {
        val u = s.source!!.getMangaUpdate(manga, emptyList(), fetchDetails = true, fetchChapters = false)
        merge(manga, u.manga)
    }

    suspend fun chapters(s: LoadedSource, manga: SManga): Res<List<SChapter>> = guarded {
        s.source!!.getMangaUpdate(manga, emptyList(), fetchDetails = false, fetchChapters = true).chapters
    }

    /** Resultado de [update]: lo que se pudo obtener y, si algo falló, el motivo. */
    class MangaData(val manga: SManga, val chapters: List<SChapter>, val error: String?)

    /**
     * Detalles + capítulos de una obra. Las fuentes de la API 1.6 hacen una sola petición combinada
     * (`getMangaUpdate`); las de 1.4/1.5 se piden por separado, de modo que si fallan los detalles todavía
     * se intenta obtener los capítulos.
     */
    suspend fun update(s: LoadedSource, base: SManga): Res<MangaData> {
        if (s.isLib16) {
            return when (val r = guarded {
                s.source!!.getMangaUpdate(base, emptyList(), fetchDetails = true, fetchChapters = true)
            }) {
                is Res.Ok -> Res.Ok(MangaData(merge(base, r.value.manga), r.value.chapters, null))
                is Res.Err -> r
            }
        }
        var manga = base
        var error: String? = null
        when (val d = details(s, base)) {
            is Res.Ok -> manga = d.value
            is Res.Err -> error = d.message
        }
        var list = emptyList<SChapter>()
        when (val c = chapters(s, manga)) {
            is Res.Ok -> list = c.value
            is Res.Err -> error = c.message
        }
        return Res.Ok(MangaData(manga, list, error))
    }

    suspend fun pages(s: LoadedSource, chapter: SChapter): Res<List<Page>> = guarded { s.source!!.getPageList(chapter) }

    // ---------------------------------------------------------------- utilidades

    fun friendly(e: Throwable): String = when (e) {
        is HttpException -> when (e.code) {
            403, 503 -> "La fuente respondió HTTP ${e.code}. Puede estar protegida por una verificación de navegador (p. ej. Cloudflare) que no se pudo superar automáticamente."
            404 -> "HTTP 404: la fuente cambió de dirección o dejó de funcionar."
            429 -> "HTTP 429: demasiadas peticiones; espera un momento."
            else -> "La fuente respondió con el error HTTP ${e.code}."
        }
        is LicensedMangaChaptersException -> "Esta obra está licenciada: la fuente no ofrece capítulos."
        is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.net.ConnectException ->
            "Sin conexión con la fuente (${e.javaClass.simpleName})."
        is IOException -> "Error de red: ${e.message ?: e.javaClass.simpleName}"
        else -> ExtensionLoader.describe(e)
    }

    fun startDownloadService() {
        runCatching {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        }
    }
}
