package com.jullbook.app.discover

import com.jullbook.app.data.Format

/** Formatos descargables que la biblioteca existente sabe abrir. */
enum class DlFormat(val ext: String, val label: String, val mime: String, val isComic: Boolean) {
    EPUB("epub", "EPUB", "application/epub+zip", false),
    PDF("pdf", "PDF", "application/pdf", false),
    CBZ("cbz", "CBZ", "application/octet-stream", true),
    CBR("cbr", "CBR", "application/octet-stream", true);

    /** Formato equivalente de la biblioteca (para reutilizar las portadas genéricas). */
    val libFormat: Format get() = when (this) {
        EPUB -> Format.EPUB
        PDF -> Format.PDF
        else -> Format.COMIC
    }

    companion object {
        private val CBZ_TYPES = setOf("application/vnd.comicbook+zip", "application/x-cbz", "application/cbz")
        private val CBR_TYPES = setOf("application/vnd.comicbook-rar", "application/x-cbr", "application/cbr")

        /** Detecta el formato por tipo MIME y, si no basta, por la extensión de la URL o el título del enlace. */
        fun detect(type: String?, href: String, linkTitle: String?): DlFormat? {
            val t = (type ?: "").lowercase().substringBefore(';').trim()
            when {
                t == "application/epub+zip" -> return EPUB
                t == "application/pdf" -> return PDF
                t in CBZ_TYPES -> return CBZ
                t in CBR_TYPES -> return CBR
            }
            val path = runCatching { java.net.URL(href).path }.getOrDefault(href).lowercase()
            for (f in DlFormat.entries) if (path.endsWith("." + f.ext)) return f
            val lt = (linkTitle ?: "").trim().lowercase()
            for (f in DlFormat.entries) if (lt == f.ext) return f
            return null
        }
    }
}

class DownloadInfo(val format: DlFormat, val url: String, val size: Long?)

/** Un resultado de búsqueda. Ningún campo es obligatorio salvo el título: no todas las fuentes lo dan todo. */
class SearchResult(
    val sourceId: String,
    val sourceName: String,
    val id: String,
    val title: String,
    val author: String?,
    val coverUrl: String?,
    val thumbUrl: String?,
    val description: String?,
    val genres: List<String>,
    val languageRaw: String?,
    val year: String?,
    val downloads: List<DownloadInfo>,
    /** Ficha OPDS con más datos y enlaces de descarga (algunas fuentes solo los dan ahí). */
    val detailUrl: String?,
    /** Idioma asumido SOLO porque la fuente filtró por él y no indica idioma en el resultado. */
    val langFromFilter: Lang? = null
) {
    /** Idiomas normalizados; vacío = no especificado. */
    val langs: List<Lang> = Lang.parseAll(languageRaw)

    fun withFilterLang(l: Lang): SearchResult = SearchResult(
        sourceId, sourceName, id, title, author, coverUrl, thumbUrl, description, genres,
        languageRaw, year, downloads, detailUrl, l
    )
}

class BookDetails(val result: SearchResult, val downloads: List<DownloadInfo>, val error: String? = null)

class SearchQuery(val text: String, val lang: Lang?)

class SearchPage(val results: List<SearchResult>, val next: String?)

/** Una fuente de contenido. Las llamadas son bloqueantes: se invocan desde un hilo de E/S. */
interface Source {
    val id: String
    val name: String

    /** true si la fuente puede filtrar por [lang] en la propia consulta (si no, se filtra en local). */
    fun filtersLanguage(lang: Lang?): Boolean

    fun search(q: SearchQuery, cursor: String?): SearchPage
    fun details(r: SearchResult): BookDetails
}

/** Error "legible" de una fuente. */
class SourceException(message: String) : Exception(message)
